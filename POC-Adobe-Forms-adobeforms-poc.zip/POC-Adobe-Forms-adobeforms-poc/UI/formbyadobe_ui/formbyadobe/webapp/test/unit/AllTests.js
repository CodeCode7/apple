sap.ui.define([
	"comapplescpui/formbyadobe/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
