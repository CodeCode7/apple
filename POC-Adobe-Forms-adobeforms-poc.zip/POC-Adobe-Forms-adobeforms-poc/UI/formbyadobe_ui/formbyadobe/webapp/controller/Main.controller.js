sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,MessageBox) {
        "use strict";

        return Controller.extend("com.apple.scp.ui.formbyadobe.controller.Main", {
            onInit: function () {
            // let me = this;
            // fetch("/getUserInfo")
            //     .then(res => res.json())
            //     .then(data => {
            //         me._userModel.setProperty("/", data);
            //     })
            //     .catch();
            jQuery.ajax({
                url: "/afs_api/v1/forms",
                method: "GET",
                type: "GET",
                dataType: "json",
                async: false,
                success: function (data, textStatus, jqXHR) {
                    MessageBox.success("inside success");
                    
                },
                error: function (data, textStatus, jqXHR) {
                    MessageBox.error(data);
               
                }
                });

            },
            onSubmitPress: function () {
                var sSerialNumber = this.byId("id_srlNum").getValue();
                var sIME1Number = this.byId("id_rmaNum").getValue();
                if (sSerialNumber.trim().length === 0) {
                    MessageBox.error("Serial Number cannot be blank.");
                    return;
                } else if (sIME1Number.trim().length === 0) {
                    MessageBox.error("IME1 Number cannot be blank.");
                    return;
                }
                var xmldata =
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?><form1><IM_BOX_HEADER><ZBOXID>" + "B5601LAT22210302070" + "</ZBOXID> <WERKS>" + "5601" + "</WERKS><LGORT>" + "SAC" + "</LGORT> <ASIS_PART_NUMBER>" + "AM661-14992"  + "</ASIS_PART_NUMBER><FG_PART_NUMBER>" + "4WH82AM/A" + "</FG_PART_NUMBER><ZBOX_QUANTITY>" + "20" + "</ZBOX_QUANTITY><LGPLA>" + "B63 37 04" + "</LGPLA><ZSSCC18>" + "001959490000000052" + "</ZSSCC18><ZMODEL>" + "A2161" + "</ZMODEL><EAN11>" + "190199561953" + "</EAN11><COO>" + "Assembled in China" +"</COO></IM_BOX_HEADER><IM_T_SERIALNUMBERS><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA><DATA><SERIAL_NUMBER_LS>" + sSerialNumber + "</SERIAL_NUMBER_LS><SERIAL_NUMBER_RS>" + sSerialNumber + "</SERIAL_NUMBER_RS></DATA></IM_T_SERIALNUMBERS><IM_T_IMEI1><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA><DATA><IMEI1_NUMBER_LS>" + sIME1Number + "</IMEI1_NUMBER_LS><IMEI1_NUMBER_RS>" + sIME1Number + "</IMEI1_NUMBER_RS></DATA></IM_T_IMEI1></form1>";            
                var encdata = btoa(xmldata);
                var jsondata = "{  " + "\"xdpTemplate\": \"" + "ZSMN_POC_BOX_LABEL/ZSMN_POC_BOX_LABEL" + "\", " + "\"xmlData\": \"" + encdata + "\"}";
                var url_render1 = "/afs_api/v1/adsRender/pdf?templateSource=storageName";
                //make the API call
                $.ajax({
                    url: url_render1,
                    type: "post",
                    contentType: "application/json",
                    data: jsondata,
                    success: function (data, textStatus, jqXHR) {
                        //once the API call is successfull, Display PDF on screen
                        var decodedPdfContent = atob(data.fileContent);
                        var byteArray = new Uint8Array(decodedPdfContent.length);
                        for (var i = 0; i < decodedPdfContent.length; i++) {
                            byteArray[i] = decodedPdfContent.charCodeAt(i);
                        }
                        var blob = new Blob([byteArray.buffer], {
                            type: 'application/pdf'
                        });
                        var _pdfurl = URL.createObjectURL(blob);
    
                        if (!this._PDFViewer) {
                            this._PDFViewer = new sap.m.PDFViewer({
                                width: "auto",
                                source: _pdfurl
                            });
                            jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                        }
    
                        this._PDFViewer.open();
                    },
                    error: function (data) {
                        sap.m.MessageToast.show("No data");
    
                    }
                });
            }
        });
    });
