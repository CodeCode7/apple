/*
* AdobeFormsService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package adobeforms.adobeforms_api.handler;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cloud.sdk.cloudplatform.connectivity.DestinationAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpDestination;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import cds.gen.adobeformsapi.AdobeFormsAPI_;
import cds.gen.adobeformsapi.GetPdfPayLoadContext;
import io.vavr.control.Option;

/**
 * AdobeFormsService is a java class used for generating pdfs using Adobe Forms
 * Service.
 *
 * @version 1.0
 * @date 10 Aug 2022
 * @author mvijetha
 */
@Component
@ServiceName(AdobeFormsAPI_.CDS_NAME)
public class AdobeFormsService extends AdobeFormsConstants implements EventHandler {
    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    @Autowired
    RestTemplate restTemplate;

    Logger logger = LoggerFactory.getLogger(AdobeFormsService.class);

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * onGetPdfPayLoad - Function to generate Adobe forms pdf
     * 
     * @implSpec - Function to generate Adobe forms pdf by setting the xml values
     * @param GetPdfPayLoadContext context
     * @return void - set pdf details
     * @author mvijetha
     */
    @On(event = GetPdfPayLoadContext.CDS_NAME)
    public void onGetPdfPayLoad(GetPdfPayLoadContext context) throws JAXBException, IOException, URISyntaxException {
        logger.info("Inside onGetPdfPayLoad");
        // String formName = "ZACSC_BTP_BOX_LABEL_IMEI1";

        // Encode the form template file
        // String xdpTemplate = encodeXdpTemplate(formName);

        // Encode Data xml file
        String xmlData = encodeXmlData(context);

        // Prepare the body of the request
        String json = "{  " + "\"xdpTemplate\": \"" + "ZACSC_BTP_BOX_LABEL_IMEI1/ZACSC_BTP_BOX_LABEL_IMEI1" + "\", "
                + "\"xmlData\": \"" + xmlData + "\"}";
        logger.info("json:" + json);

        // Call the adobe pdf service
        String adobePdfResponse = callPdfAdobeService(json);
        logger.info("adobePdfResponse - " + adobePdfResponse);

        context.setResult(adobePdfResponse);
    }

    /**
     * encodeXdpTemplate - This function is used to Encode xmlTemplate
     * 
     * @implSpec - This function is used to Encode xmlTemplate
     * @param String formName
     * @return String - xdpTemplate
     * @author mvijetha
     */
    private String encodeXdpTemplate(String formName) {
        // Fetch xdp from cloud
        String xdpFileName = "ZACSC_BTP_BOX_LABEL_IMEI1_ZACSC_BTP_BOX_LABEL_IMEI1.xdp";
        String xdpTemplate = "";
        try {
            xdpTemplate = encodeFileToBase64Binary(xdpFileName);
            logger.info("xdpTemplate conversion done - " + xdpTemplate);
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return xdpTemplate;
    }

    /**
     * encodeXmlData - This function is used to Encode xmlData
     * 
     * @implSpec - This function is used to Encode xmlData
     * @param GetPdfPayLoadContext context
     * @return String - xmlData
     * @author mvijetha
     */
    private String encodeXmlData(GetPdfPayLoadContext context) throws JAXBException {
        // Fetch xsd from cloud and then set the values to xml
        logger.info("Start encodeXmlData()");
        // Set input values in xml
        Data data = setXmlValues(context);

        // JAXB marshal without @XmlRootElement
        JAXBElement<Data> jaxbElement = new JAXBElement<Data>(new QName("", "data"), Data.class, data);
        logger.info("After setting xml data:" + jaxbElement.getValue());

        JAXBContext jxbContext = JAXBContext.newInstance(Data.class);
        Marshaller jaxbMarshaller = jxbContext.createMarshaller();

        // To format XML
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        jaxbMarshaller.marshal(jaxbElement, System.out);

        jaxbMarshaller.marshal(jaxbElement, new File("ZACSC_BTP_BOX_LABEL_IMEI1.xml"));

        // Encode the data xml file
        String xmlFileName = "ZACSC_BTP_BOX_LABEL_IMEI1.xml";
        String xmlData = "";
        try {
            xmlData = encodeFileToBase64Binary(xmlFileName);
            logger.info("XmlData conversion done - " + xmlData);
        } catch (IOException e1) {
            logger.info("Exception in encodeXmlData()- " + e1);
        }
        return xmlData;
    }

    /**
     * setXmlValues - Function set input values in xml
     * 
     * @implSpec - This method is used to set input values in xml
     * @param GetPdfPayLoadContext context
     * @return Data
     * @author mvijetha
     */
    private Data setXmlValues(GetPdfPayLoadContext context) {
        logger.info("Start setXmlValues()");
        final ObjectFactory factory = new ObjectFactory();
        // Dynamic retrival of xsd
        final Data data = factory.createData();
        data.setWSERIALNUMBER(context.getSerialNumber());
        data.setCOUNT1("1");
        data.setWIMEI1NUMBER(context.getIMEi());
        return data;
    }

    /**
     * callPdfAdobeService - This method is used to call the Adobe service
     * 
     * @implSpec - This method is used to call the Adobe reder pdf service using he
     *           xmlData and xdpTemplate
     * @param String json
     * @return String response
     * @author mvijetha
     * @throws IOException
     * @throws UnsupportedOperationException
     */
    private String callPdfAdobeService(String json)
            throws URISyntaxException, UnsupportedOperationException, IOException {
        logger.info("Start callPdfAdobeService");
        ObjectMapper mapper = new ObjectMapper();
        JsonNode payload = mapper.readTree(json);
        logger.info("payload:" + payload.toString());

        // Get destination details
        final HttpDestination destination = DestinationAccessor.getDestination(ADOBEFORMS_DESTINATION_NAME).asHttp();
        final URI uri = destination.getUri();
        logger.info("uri:" + uri);

        // Get the oAuth token
        String token = getoauthToken();

        final URI path = new URI(uri.getScheme(), null, uri.getHost(), uri.getPort(), uri.getPath(), null, null);
        logger.info("uri path:" + path);

        String targetUrl = path.toString() + ADOBEFORMS_DEST_URL_POSTFIX;
        logger.info("Target URL : " + targetUrl);

        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpPost request = new HttpPost(targetUrl);
        logger.info("targetUrl:" + targetUrl);

        request.addHeader("Authorization", "Bearer " + token);
        request.addHeader("Content-Type", "application/json");
        StringEntity input = null;
        try {
            input = new StringEntity(json);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        // Call the service and get the result
        request.setEntity(input);
        logger.info("request:" + request);
        HttpResponse response = null;
        try {
            // Execute the request
            response = httpClient.execute(request);
            logger.info("response:" + response);
        } catch (IOException e) {
            logger.info("Exception during http httpClient.execute:" + e);
        }
        JSONObject tokenjson = null;
        try {
            tokenjson = new JSONObject(IOUtils.toString(response.getEntity().getContent(), "UTF-8"));
            logger.info("tokenjson:" + tokenjson);
        } catch (JSONException e) {
            logger.info("Exception:" + e);
        }
        return tokenjson.toString();
    }

    /**
     * getoauthToken - Retrieve the auth token from Adobe service
     * 
     * @implSpec - To fecth the oAuth token for Authentication
     * @return String token
     * @author mvijetha
     * @throws IOException
     * @throws UnsupportedOperationException
     */
    private String getoauthToken() throws UnsupportedOperationException, IOException {
        final HttpDestination destination = DestinationAccessor.getDestination(ADOBEFORMS_DESTINATION_NAME).asHttp();
        Option<Object> clientIdOpt = destination.get("clientId");
        Option<Object> clientSecretOpt = destination.get("clientSecret");
        String clientId = clientIdOpt.get().toString();
        String clientSecret = clientSecretOpt.get().toString();
        String token = "";
        String tokenEndpoint = destination.get("tokenServiceURL").get().toString();
        String grant_type = "client_credentials";

        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost(tokenEndpoint);

        String base64Credentials = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes());
        // 1. Prepare the request headers
        httpPost.addHeader("Authorization", "Basic " + base64Credentials);
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");

        StringEntity input = null;
        try {
            input = new StringEntity("grant_type=" + grant_type);
            httpPost.setEntity(input);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        // 2. Post the request
        HttpResponse response = null;
        try {
            response = httpClient.execute(httpPost);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 3. Retrieve the token from the response
        try {
            JSONObject tokenjson = new JSONObject(IOUtils.toString(response.getEntity().getContent(), "UTF-8"));
            token = tokenjson.getString("access_token");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return token;
    }

    /**
     * encodeFileToBase64Binary - This method is used to encode the input files
     * 
     * @implSpec - This method is used to encode the input files to Base 64 format
     * @param fileName
     * @throws IOException
     * @return String - Base 64 encode file
     * @author mvijetha
     */
    private String encodeFileToBase64Binary(final String fileName) throws IOException {
        File file = new File(fileName);
        return Base64.getEncoder().encodeToString(FileUtils.readFileToByteArray(file));
    }
}
