/*
* AdobeFormsConstants.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package adobeforms.adobeforms_api.handler;

/**
 * ---------------------------------------------------------------------------
 * Constant(s)
 * ---------------------------------------------------------------------------
 */
public class AdobeFormsConstants {

    protected static final String AdobeFormsDestinationName = "ADOBEFORMS_DESTINATION_NAME";
    protected static final String ADOBEFORMS_DESTINATION_NAME = System.getenv().get(AdobeFormsDestinationName);
    protected static final String AdobeFormsDestUrlPostfix = "ADOBEFORMS_DEST_URL_POSTFIX";
    protected static final String ADOBEFORMS_DEST_URL_POSTFIX = System.getenv().get(AdobeFormsDestUrlPostfix);
    protected static final String AdobeFormsDestAuthUrlPostfix = "ADOBEFORMS_DEST_AUTH_URL_POSTFIX";
    protected static final String ADOBEFORMS_DEST_AUTH_URL_POSTFIX = System.getenv().get(AdobeFormsDestAuthUrlPostfix);
    protected static final String ZACSC_ARTS_LABEL_BOX_FORM_NAME = "ZACSC_ARTS_LABEL_BOX";

}
