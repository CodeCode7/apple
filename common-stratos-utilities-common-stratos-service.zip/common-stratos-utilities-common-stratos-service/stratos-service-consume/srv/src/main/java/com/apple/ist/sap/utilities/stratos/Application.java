package com.apple.ist.sap.utilities.stratos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

/**
 * Application is a SpringBoot starter class.
 */
@ComponentScan({ "com.sap.cloud.sdk", "com.apple.ist.sap.utilities.stratos.handlers" })
@ServletComponentScan({ "com.sap.cloud.sdk", "com.apple.ist.sap.utilities.stratos.handlers" })
@SpringBootApplication
public class Application {
    /**
     * ---------------------------------------------------------------------------
     * Class Method(s)
     * ---------------------------------------------------------------------------
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }

    @Bean
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }

}
