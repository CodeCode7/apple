/*
* StratosHttpHeader.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.ist.sap.utilities.stratos.handlers;

public enum StratosHttpHeader {
    SSP_SERVICE_NAME, SSP_SERVICE_VER, SSP_ESP_ENVIRONMENT, SSP_SERVICE_OPR, SSP_CONSUMER_ID, SSP_CONSUMER_APP_SEQ_NO,
    SSP_ESP_CLIENT_VERSION, SSP_INPUT_DATA_FORMAT, SSP_OUTPUT_DATA_FORMAT, SSP_PROVIDER_ID, CONTEXT, CONTEXT_VERSION;

    public static final String HEADER_PREFIX = "HTTP_HEADER_";

    @Override
    public String toString() {
        return HEADER_PREFIX + this.name();
    }

}
