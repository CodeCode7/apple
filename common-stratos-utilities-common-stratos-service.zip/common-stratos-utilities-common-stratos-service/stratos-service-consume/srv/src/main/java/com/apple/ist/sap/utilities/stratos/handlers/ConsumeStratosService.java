/*
* ConsumeStratosService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.ist.sap.utilities.stratos.handlers;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.cds.ql.Insert;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.ParameterInfo;
import com.sap.cloud.sdk.cloudplatform.connectivity.DestinationAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpDestination;

import org.apache.http.entity.ContentType;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import cds.gen.consumestratosservice.AuditLogging;
import cds.gen.consumestratosservice.AuditLogging_;
import cds.gen.consumestratosservice.ConsumeStratosServiceContext;
import cds.gen.consumestratosservice.ConsumeStratosService_;
import cds.gen.consumestratosservice.PayloadLog;
import cds.gen.stratosconsumerconfigurationservice.StratosConsumerConfiguration;
import cds.gen.stratosconsumerconfigurationservice.StratosConsumerConfiguration_;
import io.vavr.control.Option;

/**
 * ConsumeStratosService is a java class used for consuming stratos services.
 *
 * @version 1.0
 * @date 10 Feb 2022
 * @author mvijetha
 */
@Component
@ServiceName(ConsumeStratosService_.CDS_NAME)
public class ConsumeStratosService extends StratosConstants implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    PersistenceService db;

    @Autowired
    ParameterInfo parameterInfo;

    Logger logger = LoggerFactory.getLogger(ConsumeStratosService.class);

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    ConsumeStratosService(PersistenceService db) {
        this.db = db;
    }

    /**
     * onConsumeStratosService - onEvent handler to fetch response for the
     * eventName, consumerAppId and request payload
     * 
     * @implSpec - Function to consume stratos service by passing AppId, EventName
     *           and Payload in the request
     * @param ConsumeStratosServiceContext context
     * @return context.setResult(response)
     * @author mvijetha
     * @throws URISyntaxException
     * @throws JSONException
     * @throws URISyntaxException
     * @throws ParseException
     */
    @On(event = ConsumeStratosServiceContext.CDS_NAME)
    public void onConsumeStratosService(ConsumeStratosServiceContext context)
            throws IOException, JSONException, URISyntaxException, ParseException {
        logger.info("Inside onCallStratosService");
        // Fetch the input request values form the context
        String eventName = context.getEventName();
        String consumerAppId = context.getAppID();
        String jsonString = context.getPayload();
        String ipAddressReq = (String) context.get("x_forwarded_for");
        logger.info("ipAddressReq - " + ipAddressReq);

        ParameterInfo parameterInfo = context.getParameterInfo();
        String ipAddress = parameterInfo.getHeader("x_forwarded_for");

        logger.info("ipAddress - " + ipAddress);
        logger.info("Headers - " + parameterInfo.getHeaders());

        logger.info("Query Parameter - " + parameterInfo.getQueryParams());

        logger.info("jsonString --> " + jsonString);
        Map<String, String> payLoadMap = new HashMap<>();

        // Set the request payload with the input request values fecthed from the
        // context
        PayloadLog requestPayloadLog = setRequestPayload(eventName, consumerAppId, jsonString);
        PayloadLog responsePayloadLog = PayloadLog.create();

        ObjectMapper mapper = new ObjectMapper();
        JsonNode payload = mapper.readTree(jsonString);

        // Set Request Date and Time for Audit logging
        payLoadMap.put(REQ_TIME, getCurrentTime());
        payLoadMap.put(REQ_DATE, getCurrentDate());

        // Call Stratos service for the request payload
        JsonNode response = callStratosService(eventName, consumerAppId, payload, requestPayloadLog,
                responsePayloadLog);

        // Set Response Date and Time for Audit logging
        payLoadMap.put(RES_TIME, getCurrentTime());
        payLoadMap.put(RES_DATE, getCurrentDate());

        // Set response payload for
        responsePayloadLog = setResponsePayload(eventName, response.toString());

        // Set Consumer Ip address for Audit logging
        payLoadMap.put(CONSUMER_IP, ipAddress);

        // Set request and response payload for Audit logging
        List<PayloadLog> payloads = new ArrayList<>();
        payloads.add(requestPayloadLog);
        payloads.add(responsePayloadLog);

        // Set payload map with exception message details if any for Audit logging
        setPayLoadMap(payLoadMap, response);

        logger.info("payLoadMap:" + payLoadMap);

        // Set AuditLogging object with request and response details for Audit logging
        AuditLogging auditLoggingRequest = setAudiLogginRequest(eventName, consumerAppId, payloads, payLoadMap);
        logger.info("auditLoggingRequest:" + auditLoggingRequest);

        // Insert the Audit log data into DB
        insertAuditLoggingRequest(auditLoggingRequest);
        logger.info("Final response: " + response);
        context.setResult(response.toString());
    }

    /**
     * setPayLoadMap - method for setting values from the Devices Stratos response
     * object
     * 
     * @implSpec - From Devices JsonNode stratos reponse object fetch response
     *           values and set it in payloadMap, If there are any exceptions, set
     *           the Exception messagevalues
     * 
     * @param JsonNode jsonObj
     * @return Set responseMap
     * @author mvijetha
     */
    private void setPayLoadMap(Map<String, String> payLoadMap, JsonNode jsonObj) {
        JsonNode espResponseHeader = jsonObj.findParent(ESP_RESPONSE_HEADER);
        payLoadMap.put(EXCEPTION_MESSAGE, espResponseHeader.findValuesAsText(EXCEPTION_MESSAGE).get(0));
        payLoadMap.put(ESP_GUID, espResponseHeader.findValuesAsText(ESP_GUID).get(0));
        payLoadMap.put(STATUS_CD, espResponseHeader.findValuesAsText(STATUS_CD).get(0));
        payLoadMap.put(APP_EXCEPTION_ID, espResponseHeader.findValuesAsText(APP_EXCEPTION_ID).get(0));
        payLoadMap.put(LANGUAGE_CD, espResponseHeader.findValuesAsText(LANGUAGE_CD).get(0));
        // return payLoadMap;
    }

    /**
     * setAudiLogginRequest - method to set Stratos Audit Log
     * 
     * @implSpec - method to set Stratos Audit Log
     * @return AuditLogging
     * @author mvijetha
     * @param eventName
     * @param consumerAppId
     * @param payloads
     * @param Map<String,   String> payLoadMap
     * @throws ParseException
     */
    private AuditLogging setAudiLogginRequest(String eventName, String consumerAppId, List<PayloadLog> payloads,
            Map<String, String> payLoadMap) throws ParseException {
        StratosConsumerConfiguration stratosConfig = getConfigsForEventNameAndConsumerId(eventName, consumerAppId);
        AuditLogging auditLoggingRequest = AuditLogging.create();
        auditLoggingRequest.setEventname(eventName);
        auditLoggingRequest.setConsumerId(consumerAppId);
        auditLoggingRequest.setPayloads(payloads);
        auditLoggingRequest.setServiceName(stratosConfig.getServiceName());
        auditLoggingRequest.setVersionNo(stratosConfig.getVersionNo());
        auditLoggingRequest.setEspEnv(stratosConfig.getEspEnv());
        auditLoggingRequest.setOperationName(stratosConfig.getOperationName());
        auditLoggingRequest.setReqLog(stratosConfig.getLog());
        auditLoggingRequest.setRetries(Integer.parseInt(stratosConfig.getRetry()));
        auditLoggingRequest.setAuthenticate(AUTHENTICATE_FLAG);
        auditLoggingRequest.setReqDate(payLoadMap.get(REQ_DATE));
        auditLoggingRequest.setReqTime(payLoadMap.get(REQ_TIME));
        auditLoggingRequest.setResDate(payLoadMap.get(RES_DATE));
        auditLoggingRequest.setResTime(payLoadMap.get(RES_TIME));
        auditLoggingRequest.setEpsguid(payLoadMap.get(ESP_GUID));
        auditLoggingRequest.setStatuscd(payLoadMap.get(STATUS_CD));
        auditLoggingRequest.setSubrc(payLoadMap.get(STATUS_CD).equals(OK) ? 0 : 1);
        auditLoggingRequest.setExceptionid(payLoadMap.get(APP_EXCEPTION_ID));
        auditLoggingRequest.setExceptionmessage(payLoadMap.get(EXCEPTION_MESSAGE));
        auditLoggingRequest.setConsumerIp(payLoadMap.get(CONSUMER_IP));

        for (PayloadLog payloadLog : payloads) {
            if (payloadLog.getPayloadType().equals(REQUEST_PAYLOAD)) {
                auditLoggingRequest.setReqLength(payloadLog.getPayload().length());
            } else {
                auditLoggingRequest.setResLength(payloadLog.getPayload().length());
            }
        }
        auditLoggingRequest.setRunTime(getRunTime(payLoadMap.get(REQ_TIME), payLoadMap.get(RES_TIME)));
        auditLoggingRequest.setSspTimeStamp(getSspTimeStamp());
        return auditLoggingRequest;
    }

    /**
     * getRunTime - method to fetch run time between Request and Reponse
     * 
     * @implSpec - method to fetch run time between Request and Reponse
     * @return Integer
     * @author mvijetha
     * @throws ParseException
     */
    private Integer getRunTime(String reqTime, String resTime) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(TIME_FORMAT);
        Date requestTime = format.parse(reqTime);
        Date responseTime = format.parse(resTime);
        return (int) ((responseTime.getTime() - requestTime.getTime()));
    }

    /**
     * getSspTimeStamp - method to fetch Current timestamp in GMT zone
     * 
     * @implSpec - method to fetch Current timestamp in GMT zone
     * @return Current timestamp in GMT
     * @author mvijetha
     */
    private String getSspTimeStamp() {
        SimpleDateFormat sdf = new SimpleDateFormat(GMT_DATE_FORMAT);
        sdf.setTimeZone(TimeZone.getTimeZone(GMT));
        return sdf.format(new Date()) + " : " + GMT;
    }

    /**
     * getCurrentTime - method to fetch Current time
     * 
     * @implSpec - method to fetch Current time
     * @return Current time
     * @author mvijetha
     */
    private String getCurrentTime() {
        return LocalTime.now().toString();
    }

    /**
     * getCurrentDate - method to fetch Current date
     * 
     * @implSpec - method to fetch Current date
     * @return Current Date
     * @author mvijetha
     */
    private String getCurrentDate() {
        LocalDate localDate = LocalDate.now();
        // Function call
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DD_MM_YYYY);
        return formatter.format(localDate);
    }

    /**
     * insertAuditLoggingRequest - method to Insert the Stratos Audit log
     * 
     * @implSpec - method to Insert the Stratos Audit log
     * @return void
     * @author mvijetha
     * @param auditLoggingRequest
     */
    private void insertAuditLoggingRequest(AuditLogging auditLoggingRequest) {
        db.run(Insert.into(AuditLogging_.class).entry(auditLoggingRequest));
    }

    /**
     * setResponsePayload - method to set Stratos response payload
     * 
     * @implSpec - method to set Stratos response payload
     * @return PayloadLog
     * @author mvijetha
     * @param eventName
     * @param jsonString
     */
    private PayloadLog setResponsePayload(String eventName, String jsonString) {
        PayloadLog responsePayloadLog = PayloadLog.create();
        responsePayloadLog.setId(UUID.randomUUID().toString());
        responsePayloadLog.setEventname(eventName);
        responsePayloadLog.setPayload(jsonString);
        responsePayloadLog.setPayloadType(RESPONSE_PAYLOAD);
        return responsePayloadLog;
    }

    /**
     * setRequestPayload - method to set Stratos request payload
     * 
     * @implSpec - method to set Stratos request payload
     * @return PayloadLog
     * @author mvijetha
     * @param eventName
     * @param consumerAppId
     * @param jsonString
     */
    private PayloadLog setRequestPayload(String eventName, String consumerAppId, String jsonString) {
        PayloadLog requestPayloadLog = PayloadLog.create();
        requestPayloadLog.setId(UUID.randomUUID().toString());
        requestPayloadLog.setEventname(eventName);
        requestPayloadLog.setPayload(jsonString);
        requestPayloadLog.setPayloadType(REQUEST_PAYLOAD);
        return requestPayloadLog;
    }

    /**
     * callStratosService - method to fetch Stratos response for the input payload
     * 
     * @implSpec - Fetch Stratos response details by passing the input payload,
     *           header and OAuth token(required at APIM) Once the request is sent
     *           to Stratos via APIM, APIM will forward the request to Stratos by
     *           generating A3 token
     * @param String eventname, JsonNode requestPayload
     * @return JsonNode
     * @author mvijetha
     * @param responsePayloadLog
     * @param requestPayloadLog
     * @throws URISyntaxException
     * @throws JSONException
     * @throws IOException
     */
    private JsonNode callStratosService(String eventName, String consumerAppId, JsonNode requestPayload,
            PayloadLog requestPayloadLog, PayloadLog responsePayloadLog)
            throws JSONException, URISyntaxException, IOException {
        logger.info("Inside callStratosService");
        // Generate oAuth token for setting in request header
        String token = generateJwtToken();
        // Generate http headers for queryDevice
        HttpHeaders headers = getHeadersDetails(eventName, consumerAppId);
        // Fetch url from destination details
        String destURL = getDestinationURL();
        // Append postfix url for the queryDevice request url
        String apimurl = destURL + DEST_URL_POSTFIX;
        // Set the generated oAuth token
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(APP_ID_KEY, APP_ID_VALUE);

        ObjectMapper objmap = new ObjectMapper();
        HttpEntity<String> entity = new HttpEntity<String>(objmap.writeValueAsString(requestPayload), headers);
        try {
            logger.info("Inside callStratosService: entity -> " + entity);
            String respstr = restTemplate.exchange(apimurl, HttpMethod.POST, entity, String.class).getBody();
            // Set response in the responsePalyloadLog for Audit logging
            responsePayloadLog.setPayload(respstr);
            responsePayloadLog.setPayloadType(RESPONSE_PAYLOAD);
            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getFactory();
            JsonParser parser = factory.createParser(respstr);
            JsonNode responseJson = mapper.readTree(parser);
            logger.info("Inside callStratosService : responseJson -> " + responseJson);
            return responseJson;
        } catch (Exception e) {
            // Set exception details for Audit logging
            AuditLogging auditLoggingRequest = AuditLogging.create();
            auditLoggingRequest.setSubrc(SUBRC_EXCEPTION_FLAG);
            auditLoggingRequest.setExceptionmessage(e.getMessage());
            List<PayloadLog> payloads = new ArrayList<>();
            payloads.add(requestPayloadLog);
            payloads.add(responsePayloadLog);
            auditLoggingRequest.setPayloads(payloads);
            // Insert the Audit log data into DB
            insertAuditLoggingRequest(auditLoggingRequest);
            throw new ServiceException(e);
        }
    }

    /**
     * getDestinationURL - method to fetch Destination URL
     * 
     * @implSpec - Fetch Destination URL
     * @return URI path
     * @author mvijetha
     * @throws URISyntaxException
     */
    private String getDestinationURL() throws URISyntaxException {
        final HttpDestination destination = DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();
        final URI uri = destination.getUri();
        final URI path = new URI(uri.getScheme(), null, uri.getHost(), uri.getPort(), uri.getPath(), null, null);
        return path.toString();
    }

    /**
     * generateJwtToken - method to fetch Jwt Token
     * 
     * @implSpec - Fetch Jwt Token by using apim authentocation url, clientId and
     *           clientSecret from destination details.
     * @return String jwtToken
     * @author mvijetha
     * @throws URISyntaxException
     * @throws MalformedURLException
     */
    private String generateJwtToken() throws URISyntaxException, MalformedURLException {
        final HttpDestination destination = DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();
        logger.info("Inside generateJwtToken");
        Option<Object> clientIdOpt = destination.get("clientId");
        Option<Object> clientSecretOpt = destination.get("clientSecret");
        String clientId = clientIdOpt.get().toString();
        String clientSecret = clientSecretOpt.get().toString();

        String destURL = getDestinationURL();
        String apimauthurl = destURL + DEST_AUTH_URL_POSTFIX;

        logger.info("apimauthurl:" + apimauthurl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(clientId, clientSecret);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
        map.add("client_id", clientId);
        map.add("grant_type", "client_credentials");
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(map, headers);
        RestTemplate restTemplate = new RestTemplate();
        String responseString = restTemplate.exchange(apimauthurl, HttpMethod.POST, entity, String.class).getBody();
        JSONObject obj = new JSONObject(responseString);
        String jwtToken = obj.getString("access_token");
        return jwtToken;
    }

    /**
     * getHeadersDetails - method to fetch Header details for eventName and
     * consumerAppId
     * 
     * @implSpec - Fetch Header details for eventName and consumerAppId
     * @param String eventName
     * @param String consumerAppId
     * @return HttpHeaders headers
     * @author mvijetha
     */
    private HttpHeaders getHeadersDetails(String eventName, String consumerAppId) {
        StratosConsumerConfiguration stratosConfig = getConfigsForEventNameAndConsumerId(eventName, consumerAppId);
        HttpHeaders headers = new HttpHeaders();
        headers.set(StratosHttpHeader.SSP_SERVICE_NAME.toString(), stratosConfig.getServiceName());
        headers.set(StratosHttpHeader.SSP_SERVICE_VER.toString(), stratosConfig.getVersionNo());
        headers.set(StratosHttpHeader.SSP_ESP_ENVIRONMENT.toString(), stratosConfig.getEspEnv());
        headers.set(StratosHttpHeader.SSP_SERVICE_OPR.toString(), stratosConfig.getOperationName());
        headers.set(StratosHttpHeader.SSP_CONSUMER_ID.toString(), consumerAppId);
        headers.set(StratosHttpHeader.SSP_CONSUMER_APP_SEQ_NO.toString(), UUID.randomUUID().toString());
        headers.set(StratosHttpHeader.SSP_ESP_CLIENT_VERSION.toString(), stratosConfig.getEspClientVersion());
        headers.set(StratosHttpHeader.SSP_INPUT_DATA_FORMAT.toString(), stratosConfig.getInputDataFormat());
        headers.set(StratosHttpHeader.SSP_OUTPUT_DATA_FORMAT.toString(), stratosConfig.getOutputDataFormat());
        headers.set(StratosHttpHeader.SSP_PROVIDER_ID.toString(), STRATOS_SERVICE_PROVIDER_ID);
        headers.set(StratosHttpHeader.CONTEXT.toString(), stratosConfig.getContext());
        headers.set(StratosHttpHeader.CONTEXT_VERSION.toString(), stratosConfig.getContextVersion());
        headers.set(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.toString());
        return headers;
    }

    /**
     * getConfigsForEventNameAndConsumerId - Fetch Values from
     * COM_APPLE_IST_SAP_STRATOS_T_STRATOS_CONSUMER_CONFIGURATION table for
     * eventName and consumerAppId
     * 
     * @implSpec - Return StratosConsumerConfiguration details for the eventName and
     *           consumerAppId
     * @param String eventName
     * @param String consumerAppId
     * @return StratosConsumerConfiguration object
     * @author mvijetha
     */
    private StratosConsumerConfiguration getConfigsForEventNameAndConsumerId(String eventName, String consumerAppId) {
        CqnSelect sel = Select.from(StratosConsumerConfiguration_.class).where(scc -> scc.EVENT_NAME().eq(eventName)
                .and(scc.CONSUMER_APP().eq(consumerAppId)).and(scc.ACTIVE().eq(ACTIVE_FLAG)));
        return db.run(sel).first(StratosConsumerConfiguration.class).orElseThrow(() -> new ServiceException(
                ErrorStatuses.NOT_FOUND + " Configuration details for eventName = " + eventName + " doesn't exist"));
    }

}