package com.apple.ist.sap.utilities.stratos.handlers;

/**
 * ---------------------------------------------------------------------------
 * Constant(s)
 * ---------------------------------------------------------------------------
 */
public class StratosConstants {
    protected static final String DestinationName = "DESTINATION_NAME";
    protected static final String DESTINATION_NAME = System.getenv().get(DestinationName);
    protected static final String DestUrlPostfix = "DEST_URL_POSTFIX";
    protected static final String DEST_URL_POSTFIX = System.getenv().get(DestUrlPostfix);
    protected static final String DestAuthUrlPostfix = "DEST_AUTH_URL_POSTFIX";
    protected static final String DEST_AUTH_URL_POSTFIX = System.getenv().get(DestAuthUrlPostfix);
    protected static final String AppId = "AppId";
    protected static final String APP_ID_KEY = "appid";
    protected static final String APP_ID_VALUE = System.getenv().get(AppId);
    protected static final String StratosServiceProviderId = "STRATOS_SERVICE_PROVIDER_ID";
    protected static final String STRATOS_SERVICE_PROVIDER_ID = System.getenv().get(StratosServiceProviderId);
    protected static final String REQUEST_PAYLOAD = "REQUEST PAYLOAD";
    protected static final String RESPONSE_PAYLOAD = "RESPONSE PAYLOAD";
    protected static final String DD_MM_YYYY = "dd/MM/YYYY";
    protected static final String ESP_RESPONSE_HEADER = "espResponseHeader";
    protected static final String EXCEPTION_MESSAGE = "exceptionMessage";
    protected static final String ESP_GUID = "espGuid";
    protected static final String STATUS_CD = "statusCD";
    protected static final String APP_EXCEPTION_ID = "appExceptionID";
    protected static final String LANGUAGE_CD = "languageCD";
    protected static final String REQ_TIME = "reqTime";
    protected static final String REQ_DATE = "reqDate";
    protected static final String RES_TIME = "resTime";
    protected static final String RES_DATE = "resDate";
    protected static final String SSP_TIME_STAMP = "SSP_TIME_STAMP";
    protected static final String OK = "OK";
    protected static final String FAULT = "FAULT";
    protected static final String GMT_DATE_FORMAT = "YYYY/MM/dd hh:mm:ss.SSS";
    protected static final String GMT = "GMT";
    protected static final String TIME_FORMAT = "HH:mm:ss.SSS";
    protected static final String AUTHENTICATE_FLAG = "X";
    protected static final String ACTIVE_FLAG = "Y";
    protected static final Integer SUBRC_EXCEPTION_FLAG = 2;
    protected static final String CONSUMER_IP = "CONSUMER_IP";
}