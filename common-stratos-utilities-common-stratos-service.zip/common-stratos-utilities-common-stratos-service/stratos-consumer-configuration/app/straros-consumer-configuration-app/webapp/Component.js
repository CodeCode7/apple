sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("com.apple.scp.ui.strarosconsumerconfigurationapp.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
