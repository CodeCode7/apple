sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/type/String",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
	"sap/ui/model/Filter"
], function (Controller, BaseController, JSONModel, MessageBox, typeString, Spreadsheet, exportLibrary, Filter) {
	"use strict";

	return BaseController.extend("com.apple.scp.ui.artsship.controller.LinkShipment", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.apple.scp.ui.artsship.view.LinkShipment
		 */
		onInit: function () {
			this.getRouter().attachRouteMatched(this._onRouteMatched, this);
			this.getModel().sDefaultUpdateMethod = "PUT";
		},

		_onRouteMatched: function (oEvent) {
			var sRoute = oEvent.getParameter("name");
			if (sRoute === "LinkShipment") {
				var that = this;
				this.shipmentNum = oEvent.getParameter("arguments").ShipmentNum;
				this.getModel("oGlobalModel").setProperty("/sShipmentNum", this.shipmentNum);
				this.oShipmentHdrModel = new JSONModel();
				this.getView().setModel(that.oShipmentHdrModel, "oShipmentHdrModel");

				this.oShipmentItemModel = new JSONModel();
				this.getView().setModel(that.oShipmentItemModel, "oShipmentItemModel");
				this.getModel("oShipmentHdrModel").setProperty("/Port", "");
				this.getModel("appModel").setProperty("/busy", true);
				this.getModel("shipmentModel").read("/ShipmentHeaderSet(ShipmentNumber='" + this.shipmentNum + "')", {
					urlParameters: {
						"$expand": "PackHeader,PackItem,TMSData,ControlFlags"
					},
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);

						that.oShipmentHdrModel.setData(oData.PackHeader.results[0]);

						that.oShipmentItemModel.setData(oData.PackItem.results);
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			}
		},

		onShipmentLinkPress: function () {
			var that = this;
			this.getModel("shipmentModel").setDeferredGroups(["linkShipmentGrp"]);

			var oPayload = {
				ShipmentNumber: this.getModel("oGlobalModel").getProperty("/sShipmentNum"),
				Port: this.getModel("oShipmentHdrModel").getProperty("/Port")
			};
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").callFunction("/LinkShipmentPallets", {
				urlParameters: oPayload,
				method: "POST",
				batchGroupId: "linkShipmentGrp"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "linkShipmentGrp",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined &&
						oData.__batchResponses[0].__changeResponses[0].data.MessageType === "S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Shipment linked successfully");
						}
						that.getRouter().navTo("FinalShipment", {
								ShipmentNum: that.getModel("oGlobalModel").getProperty("/sShipmentNum")
							});
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		onBackPress: function () {
			this.getRouter().navTo("Main");
		}

	});

});