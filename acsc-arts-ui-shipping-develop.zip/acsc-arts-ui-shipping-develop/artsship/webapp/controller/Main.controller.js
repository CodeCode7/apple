sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"./BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageBox",
		"sap/ui/model/type/String",
		"sap/ui/export/Spreadsheet",
		"sap/ui/export/library",
		"sap/ui/model/Filter"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, BaseController, JSONModel, MessageBox, typeString, Spreadsheet, exportLibrary, Filter) {
		"use strict";

		return BaseController.extend("com.apple.scp.ui.artsship.controller.Main", {
			onInit: function () {
				this.getRouter().attachRouteMatched(this._onRouteMatched, this);
				this.getModel().sDefaultUpdateMethod = "PUT";
			},

			_onRouteMatched: function (oEvent) {
				var sRoute = oEvent.getParameter("name");
				if (sRoute === "Main") {

				}
			},

			onSubmitPress: function () {
				if(this.byId("id_shipmentNum").getValue().trim().length > 0) {
					if(this.byId("id_shipmentNum").getValue() === "123") {
						this.getRouter().navTo("LinkShipment", {
					ShipmentNum: this.byId("id_shipmentNum").getValue()
				});
					} else {
						this.getRouter().navTo("FinalShipment", {
					ShipmentNum: this.byId("id_shipmentNum").getValue()
				});
					}
					
				} else {
					MessageBox.error("Shipment number cannot be blank");
				}
				
			}
		});
	});