sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/type/String",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
	"sap/ui/model/Filter"
], function (Controller, BaseController, JSONModel, MessageBox, typeString, Spreadsheet, exportLibrary, Filter) {
	"use strict";

	return BaseController.extend("com.apple.scp.ui.artsship.controller.FinalShipment", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.apple.scp.ui.artsship.view.FinalShipment
		 */
		onInit: function () {
			this.getRouter().attachRouteMatched(this._onRouteMatched, this);
			this.getModel().sDefaultUpdateMethod = "PUT";
		},

		_onRouteMatched: function (oEvent) {
			var sRoute = oEvent.getParameter("name");
			if (sRoute === "FinalShipment") {
				this.setModel(new JSONModel({
					sShipmentNo: oEvent.getParameter("arguments").ShipmentNum,
					bComplete: false
				}), "oShipmentModel");
				this.getShipmentData("Init");
			}
		},

		getShipmentData: function (sParam) {
			var that = this;
			var sExpand = "";
			this.sParam = sParam;
			this.bAll = true;
			if (sParam === "Init" || sParam === "" || sParam === undefined) {
				sExpand = "PackHeader,PackItem,ControlFlags";
			} else if (sParam === "TMS") {
				this.bAll = false;
				sExpand = "TMSData";
			}
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").read("/ShipmentHeaderSet(ShipmentNumber='" + this.getModel("oGlobalModel").getProperty(
				"/sShipmentNum") + "')", {
				urlParameters: {
					"$expand": sExpand
				},
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					that.getModel("oGlobalModel").setProperty("/bSuccess", true);
					if (that.bAll) {
						that.setDynamicShipmentHeaderData(oData);
						that.setShipmentHeaderTableData(oData);
						that.setShipmentItemTableData(oData);
					} else if (!that.bAll) {
						that.setTMSData(oData);
					}

				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					that.getModel("oGlobalModel").setProperty("/bSuccess", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		setDynamicShipmentHeaderData: function (oData) {
			if (!this.oDynamicShipmentHdrModel) {
				this.oDynamicShipmentHdrModel = new JSONModel();
				this.getView().setModel(this.oDynamicShipmentHdrModel, "oDynamicShipmentHdrModel");
			}
			if (oData.ShipmentStatusCode === "13") {
				this.getModel("oShipmentModel").setProperty("/bComplete", true);
			} else {
				this.getModel("oShipmentModel").setProperty("/bComplete", false);
			}
			this.oDynamicShipmentHdrModel.setData(oData);
			this.oDynamicShipmentHdrModel.refresh(true);
			this.getModel("oShipmentModel").refresh(true);
		},

		setShipmentHeaderTableData: function (oData) {
			if (!this.oShipmentHdrModel) {
				this.oShipmentHdrModel = new JSONModel();
				this.getView().setModel(this.oShipmentHdrModel, "oShipmentHdrModel");
			}
			this.oShipmentHdrModel.setData(oData.PackHeader.results);
			this.oShipmentHdrModel.refresh(true);
		},

		setShipmentItemTableData: function (oData) {
			if (!this.oShipmentItemModel) {
				this.oShipmentItemModel = new JSONModel();
				this.getView().setModel(this.oShipmentItemModel, "oShipmentItemModel");
			}
			this.oShipmentItemModel.setData(oData.PackItem.results);
			this.oShipmentItemModel.refresh(true);
		},

		setTMSData: function (oData) {
			if (!this.oTMSDataModel) {
				this.oTMSDataModel = new JSONModel();
				this.getView().setModel(this.oTMSDataModel, "oTMSDataModel");
			}
			this.oTMSDataModel.setData(oData.TMSData);
			this.oTMSDataModel.refresh(true);
		},

		setReconfirmationButtonStatus: function (sTenderStatus) {
			if (!this.getModel("oShipmentModel").getProperty("/bComplete") && (sTenderStatus !== "CF" && sTenderStatus !== "AC")) {
				return true;
			} else {
				return false;
			}
		},

		onBackPress: function () {
			this.getRouter().navTo("LinkShipment", {
				ShipmentNum: this.getModel("oGlobalModel").getProperty("/sShipmentNum")
			});
		},

		onCarrierDet: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["DetermineCarrierGroup"]);
			this.getModel("shipmentModel").callFunction("/DetermineCarrier", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "DetermineCarrierGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "DetermineCarrierGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Carrier Determination Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}

				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onConfirmPress: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["ConfirmGroup"]);
			this.getModel("shipmentModel").callFunction("/Confirmation", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "ConfirmGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "ConfirmGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Confirmation Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onReconfirmPress: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["ReConfirmGroup"]);
			this.getModel("shipmentModel").callFunction("/ReprocessConfirmation", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "ReConfirmGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "ReConfirmGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Re-Confirmation Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onTMSDataPress: function () {

			this.getShipmentData("TMS");
			if (this.getModel("oGlobalModel").getProperty("/bSuccess")) {
				if (!this._oTMSDataDialog) {
					this._oTMSDataDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.TMSData", this);
				}
				this.getView().addDependent(this._oTMSDataDialog);
				this._oTMSDataDialog.open();
			}

		},

		onTMSViewDialogClose: function () {
			this._oTMSDataDialog.close();
		},

		onWtDimOverridePress: function (oEvent) {
			var selContextPath = this.byId("id_packedHdrTbl").getSelectedContextPaths();
			if (selContextPath.length === 0) {
				MessageBox.error("Please select atleast one row to do Weight Dimension Override");
			} else {
				var aWtDimOverrideData = [];
				for (var a = 0; a < selContextPath.length; a++) {
					var oWtDimOverrideData = {};

					oWtDimOverrideData.ShipmentNumber = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).ShipmentNumber;
					oWtDimOverrideData.PackID = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).PackedID;
					oWtDimOverrideData.NewWeight = "0";
					oWtDimOverrideData.NewWidth = "0";
					oWtDimOverrideData.NewLength = "0";
					oWtDimOverrideData.NewHeight = "0";
					aWtDimOverrideData.push(oWtDimOverrideData);
				}
				this.oWtDimOverrideModel = new JSONModel();
				this.setModel(this.oWtDimOverrideModel, "oWtDimOverrideModel");
				this.oWtDimOverrideModel.setData(aWtDimOverrideData);
				if (!this._oWtDimOverrideDialog) {
					this._oWtDimOverrideDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.WeightDimensionOverride", this);
				}
				this.getView().addDependent(this._oWtDimOverrideDialog);
				this._oWtDimOverrideDialog.open();
			}
		},

		onWtDimClose: function () {
			this._oWtDimOverrideDialog.close();
		},

		onWtDimOverrideSubmit: function () {
			var that = this;
			var oWtDimOverrideData = this.getModel("oWtDimOverrideModel").getData();
			this.getModel("shipmentModel").setDeferredGroups(["WtDimensionOverrideGrp"]);
			for (var x = 0; x < oWtDimOverrideData.length; x++) {
				var oWtDimOverrideData1 = {};

				oWtDimOverrideData1.ShipmentNumber = oWtDimOverrideData[x].ShipmentNumber;
				oWtDimOverrideData1.PackID = oWtDimOverrideData[x].PackID;
				oWtDimOverrideData1.NewWeight = oWtDimOverrideData[x].NewWeight;
				oWtDimOverrideData1.NewWidth = oWtDimOverrideData[x].NewWidth;
				oWtDimOverrideData1.NewLength = oWtDimOverrideData[x].NewLength;
				oWtDimOverrideData1.NewHeight = oWtDimOverrideData[x].NewHeight;

				this.getModel("shipmentModel").callFunction("/SetPalletWeightAndDimensions", {
					urlParameters: oWtDimOverrideData1,
					method: "POST",
					batchGroupId: "WtDimensionOverrideGrp"
				});
			}
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "WtDimensionOverrideGrp",
				async: false,
				changeSetId: "WtDimChangeSetID",
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Wt Dimension Override Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
					that.byId("id_packedHdrTbl").removeSelections();
					that.onWtDimClose();
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					that.onWtDimClose();
				}
			});
		},

		handleDimensions: function (oEvent) {
			var decimal1 = /^\d*(\.\d{0,3})?$/;
			var enteredvalue = oEvent.getParameters().value;
			if (!enteredvalue.match(decimal1) && enteredvalue.length > 0) {
				oEvent.getSource().setValue(enteredvalue.substr(0, enteredvalue.length - 1));
			}
		}

	});

});