sap.ui.define([
	"comapplescpui/artsship/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
