sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"./BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageBox"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, BaseController, JSONModel, MessageBox) {
		"use strict";

		return BaseController.extend("com.apple.scp.ui.artsrts.controller.Main", {
			onInit: function () {

			},

			onSubmitPress: function () {
				var sSerialNumber = this.byId("id_srlNum").getValue();
				var sRMANumber = this.byId("id_rmaNum").getValue();
				if (sSerialNumber.trim().length === 0) {
					MessageBox.error("Serial Number cannot be blank.");
					return;
				} else if (sRMANumber.trim().length === 0) {
					MessageBox.error("RMA Number cannot be blank.");
					return;
				} else {
					var sUrl = "/sap/opu/odata/sap/zod_acsc_rts_srv/ShippingLabelSet(SerialNumber='" + sSerialNumber + "',RMANumber='" +
						sRMANumber + "')/$value";
					sap.m.URLHelper.redirect(sUrl);
				}
			}
		});
	});