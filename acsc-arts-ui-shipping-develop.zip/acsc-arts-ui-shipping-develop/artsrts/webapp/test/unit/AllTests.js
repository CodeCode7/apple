sap.ui.define([
	"comapplescpui/artsrts/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
