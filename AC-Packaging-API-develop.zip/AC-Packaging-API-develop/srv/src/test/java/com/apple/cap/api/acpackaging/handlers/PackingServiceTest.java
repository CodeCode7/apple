/*
* PackingServiceTest.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import com.sap.cds.Result;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.VPalletContentsForSalesRequest;
import cds.gen.packingservice.BoxItems;
import cds.gen.packingservice.GetBoxesByShipmentContext;
import cds.gen.packingservice.GetPalletContentsContext;
import cds.gen.packingservice.GetPalletContentsForPackingContext;
import cds.gen.packingservice.GetPalletContentsForSalesRequestContext;
import cds.gen.packingservice.GetPalletContentsForUnPackingContext;
import cds.gen.packingservice.SetPalletPackedContext;
import cds.gen.packingservice.SetPalletUnPackedContext;
import cds.gen.packingservice.ShipmentBoxDetails;
import cds.gen.packingservice.ValidatePalletForTypeContext;
import cds.gen.palletservice.PalletItems;
import cds.gen.palletservice.Pallets;

public class PackingServiceTest implements EventHandler {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @InjectMocks
    PackingService packingService = new PackingService(persistenceService);

    @Mock
    Result result = Mockito.mock(Result.class);

    @Mock
    GetPalletContentsContext getPalletContentsContext = Mockito.mock(GetPalletContentsContext.class);

    @Mock
    GetPalletContentsForPackingContext getPalletContentsForPackingContext = Mockito
            .mock(GetPalletContentsForPackingContext.class);

    @Mock
    GetPalletContentsForUnPackingContext getPalletContentsForUnPackingContext = Mockito
            .mock(GetPalletContentsForUnPackingContext.class);

    @Mock
    GetPalletContentsForSalesRequestContext getPalletContentsForSalesRequestContext = Mockito
            .mock(GetPalletContentsForSalesRequestContext.class);

    @Mock
    ValidatePalletForTypeContext validatePalletForTypeContext = Mockito.mock(ValidatePalletForTypeContext.class);

    @Mock
    SetPalletPackedContext setPalletPackedContext = Mockito.mock(SetPalletPackedContext.class);

    @Mock
    SetPalletUnPackedContext setPalletUnPackedContext = Mockito.mock(SetPalletUnPackedContext.class);

    @Mock
    GetBoxesByShipmentContext getBoxesByShipmentContext = Mockito.mock(GetBoxesByShipmentContext.class);

    private static final String BOXID1 = "B5651AC1021010700393";
    private static final String BOXID2 = "B5651AC1021010700394";
    private static final String PALLETID = "P5601SAC21130700234";
    private static final String AS_IS_PART_NUM = "LL661-09559";
    private static final String AS_IS_PART_NUM1 = "LL661-06435";
    private static final String FG_MPN = "4Q8J2LL/A";
    private static final String PLANT = "5601";
    private static final String MODEL_NUM = "A1864";
    private static final String SERIAL_NUM1 = "FD7Y60XHJCLP";
    private static final String SERIAL_NUM2 = "FD7Y60XJJCLP";
    private static final Integer BOX_SEQUENCE_NUM1 = 1;
    private static final Integer BOX_SEQUENCE_NUM2 = 2;
    private static final String SHIPMENT_NUM = "00999888";
    private static final String SSCC18_1 = "001959491420001348";
    private static final String SSCC18_2 = "001959491420001349";
    private static final String IMEI_IS1 = "IMEI1SNLAS-IS1";
    private static final String IMEI_IS2 = "IMEI1SNLAS-IS2";
    private static final String TYPE = "B";
    private static final String CUSTOMER = "Likewize - 1037536";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testOnGetPalletContents() {
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        Optional<Pallets> palletsResponse = generatePalletsResponse();

        when(getPalletContentsContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);
        Assertions.assertDoesNotThrow(() -> packingService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsServiceExpPallet() {
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(getPalletContentsContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.first(Supplier.class)).thenThrow(ServiceException.class);
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsServiceExpBoxEmpty() {
        List<BoxItems> boxIdListActual = generateEmptyBoxListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        Optional<Pallets> palletsResponse = generatePalletsResponse();

        when(getPalletContentsContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsForPacking() {
        List<Pallets> palletsList = generatePalletsList();
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        Optional<Pallets> palletsResponse = generatePalletsResponse();

        when(getPalletContentsForPackingContext.getPalletId()).thenReturn(PALLETID);
        when(getPalletContentsContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);
        when(result.listOf(Pallets.class)).thenReturn(palletsList);
        Assertions.assertDoesNotThrow(
                () -> packingService.onGetPalletContentsForPacking(getPalletContentsForPackingContext));
    }

    @Test
    public void testOnGetPalletContentsForUnPacking() {
        List<Pallets> palletsList = generatePalletsList();
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        Optional<Pallets> palletsResponse = generatePalletsResponse();

        when(getPalletContentsForUnPackingContext.getPalletId()).thenReturn(PALLETID);
        when(getPalletContentsContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);
        when(result.listOf(Pallets.class)).thenReturn(palletsList);
        Assertions.assertDoesNotThrow(
                () -> packingService.onGetPalletContentsForUnPacking(getPalletContentsForUnPackingContext));
    }

    @Test
    public void testOnGetPalletContentsForSalesRequest() {
        List<VPalletContentsForSalesRequest> palletcontentsBoxitemsListActual = generateSalesOrderRequestItemsDetails();

        when(getPalletContentsForSalesRequestContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(VPalletContentsForSalesRequest.class)).thenReturn(palletcontentsBoxitemsListActual);
        Assertions.assertDoesNotThrow(
                () -> packingService.onGetPalletContentsForSalesRequest(getPalletContentsForSalesRequestContext));
    }

    @Test
    public void testOnGetPalletContentsForSalesRequestPalletIdNull() {
        when(getPalletContentsForSalesRequestContext.getPalletId()).thenReturn(null);
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContentsForSalesRequest(getPalletContentsForSalesRequestContext));
    }

    @Test
    public void testOnGetPalletContentsForSalesRequestPalletIdEmpty() {
        when(getPalletContentsForSalesRequestContext.getPalletId()).thenReturn("");
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContentsForSalesRequest(getPalletContentsForSalesRequestContext));
    }

    @Test
    public void testOnGetPalletContentsForSalesRequestSrvExpEmpty() {
        List<VPalletContentsForSalesRequest> palletcontentsBoxitemsListActual = new ArrayList<>();

        when(getPalletContentsForSalesRequestContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(VPalletContentsForSalesRequest.class)).thenReturn(palletcontentsBoxitemsListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContentsForSalesRequest(getPalletContentsForSalesRequestContext));
    }

    @Test
    public void testOnGetPalletContentsForSalesRequestSrvExpNull() {
        List<VPalletContentsForSalesRequest> palletcontentsBoxitemsListActual = null;

        when(getPalletContentsForSalesRequestContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(VPalletContentsForSalesRequest.class)).thenReturn(palletcontentsBoxitemsListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> packingService.onGetPalletContentsForSalesRequest(getPalletContentsForSalesRequestContext));
    }

    @Test
    public void testOnValidatePalletForTypeTrue() {
        when(validatePalletForTypeContext.getPalletId()).thenReturn(PALLETID);
        when(validatePalletForTypeContext.getType()).thenReturn(TYPE);
        when(validatePalletForTypeContext.getEvent()).thenReturn(CUSTOMER);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Optional<Pallets> palletDetailsResponse = generatePalletDetailsResponse();
        when(result.first(Pallets.class)).thenReturn(palletDetailsResponse);
        Assertions.assertDoesNotThrow(() -> packingService.onValidatePalletForType(validatePalletForTypeContext));
    }

    @Test
    public void testOnValidatePalletForTypeFalse() {
        when(validatePalletForTypeContext.getPalletId()).thenReturn(PALLETID);
        when(validatePalletForTypeContext.getType()).thenReturn(TYPE);
        when(validatePalletForTypeContext.getEvent()).thenReturn(CUSTOMER);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Assertions.assertDoesNotThrow(() -> packingService.onValidatePalletForType(validatePalletForTypeContext));
    }

    @Test
    public void testOnSetPalletPacked() {
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(setPalletPackedContext.getPalletId()).thenReturn(PALLETID);
        when(setPalletPackedContext.getShipmentNumber()).thenReturn(SHIPMENT_NUM);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> packingService.onSetPalletPacked(setPalletPackedContext));
    }

    @Test
    public void testOnSetPalletPackedException() {
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(setPalletPackedContext.getPalletId()).thenReturn(PALLETID);
        when(setPalletPackedContext.getShipmentNumber()).thenReturn(SHIPMENT_NUM);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(persistenceService.run(any(CqnUpdate.class))).thenThrow(ServiceException.class);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> packingService.onSetPalletPacked(setPalletPackedContext));
    }

    @Test
    public void testOnSetPalletUnPacked() {
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(setPalletUnPackedContext.getPalletId()).thenReturn(PALLETID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> packingService.onSetPalletUnPacked(setPalletUnPackedContext));
    }

    @Test
    public void testOnGetBoxesByShipment() {
        List<ShipmentBoxDetails> shipmentBoxDetailsList = new ArrayList<>();
        ShipmentBoxDetails shipmentBoxDetails1 = ShipmentBoxDetails.create();
        shipmentBoxDetails1.setBoxid(BOXID1);
        shipmentBoxDetails1.setSerialnumber(SERIAL_NUM1);
        shipmentBoxDetails1.setSscc18(SSCC18_1);
        ShipmentBoxDetails shipmentBoxDetails2 = ShipmentBoxDetails.create();
        shipmentBoxDetails2.setBoxid(BOXID2);
        shipmentBoxDetails2.setSerialnumber(SERIAL_NUM2);
        shipmentBoxDetails2.setSscc18(SSCC18_2);
        shipmentBoxDetailsList.add(shipmentBoxDetails1);
        shipmentBoxDetailsList.add(shipmentBoxDetails2);

        when(getBoxesByShipmentContext.getShipmentNumber()).thenReturn(SHIPMENT_NUM);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(ShipmentBoxDetails.class)).thenReturn(shipmentBoxDetailsList);
        Assertions.assertDoesNotThrow(() -> packingService.onGetBoxesByShipment(getBoxesByShipmentContext));
    }

    private Optional<Pallets> generatePalletsResponse() {
        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setPlant(PLANT);
        return Optional.of((Pallets) palletsMock);
    }

    private List<PalletItems> generateTwoPalletIdListActual() {
        List<PalletItems> palletIdListActual = new ArrayList<>();
        PalletItems palletsItem1 = PalletItems.create();
        palletsItem1.setBoxIDBoxID(BOXID1);
        PalletItems palletsItem2 = PalletItems.create();
        palletsItem2.setBoxIDBoxID(BOXID2);
        palletIdListActual.add(palletsItem1);
        palletIdListActual.add(palletsItem2);
        return palletIdListActual;
    }

    private List<BoxItems> generateTwoBoxIdListActual() {
        List<BoxItems> boxIdListActual = new ArrayList<>();
        BoxItems boxItems1 = BoxItems.create();
        boxItems1.setBoxIDBoxID(BOXID1);
        boxItems1.setPlant(PLANT);
        boxItems1.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems1.setModelNumber(MODEL_NUM);
        boxItems1.setImei1(IMEI_IS1);
        boxItems1.setImei2(IMEI_IS2);
        boxItems1.setFinishedGoodsMPN(FG_MPN);
        boxItems1.setSerialNumber(SERIAL_NUM1);
        boxItems1.setBoxSequence(BOX_SEQUENCE_NUM1);
        BoxItems boxItems2 = BoxItems.create();
        boxItems2.setBoxIDBoxID(BOXID2);
        boxItems2.setPlant(PLANT);
        boxItems2.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems2.setModelNumber(MODEL_NUM);
        boxItems2.setImei1(IMEI_IS1);
        boxItems2.setImei2(IMEI_IS2);
        boxItems2.setFinishedGoodsMPN(FG_MPN);
        boxItems2.setSerialNumber(SERIAL_NUM2);
        boxItems2.setBoxSequence(BOX_SEQUENCE_NUM2);
        boxIdListActual.add(boxItems1);
        boxIdListActual.add(boxItems2);
        return boxIdListActual;
    }

    private List<Pallets> generatePalletsList() {
        List<Pallets> palletsList = new ArrayList<>();
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        palletsList.add(pallets);
        return palletsList;
    }

    private List<BoxItems> generateEmptyBoxListActual() {
        List<BoxItems> boxIdListActual = new ArrayList<>();
        BoxItems boxItems1 = BoxItems.create();
        BoxItems boxItems2 = BoxItems.create();
        boxIdListActual.add(boxItems1);
        boxIdListActual.add(boxItems2);
        return boxIdListActual;
    }

    private List<VPalletContentsForSalesRequest> generateSalesOrderRequestItemsDetails() {
        List<VPalletContentsForSalesRequest> palletcontentsBoxitemsListActual = new ArrayList<>();
        VPalletContentsForSalesRequest palletcontentsBoxitems1 = VPalletContentsForSalesRequest.create();
        palletcontentsBoxitems1.setPalletid(PALLETID);
        palletcontentsBoxitems1.setBoxid(BOXID1);
        palletcontentsBoxitems1.setAsispartnumber(AS_IS_PART_NUM);
        palletcontentsBoxitems1.setFgmpn(FG_MPN);
        palletcontentsBoxitems1.setSerialnumber(SERIAL_NUM1);
        palletcontentsBoxitems1.setBoxsequence(BOX_SEQUENCE_NUM1);
        VPalletContentsForSalesRequest palletcontentsBoxitems2 = VPalletContentsForSalesRequest.create();
        palletcontentsBoxitems2.setPalletid(PALLETID);
        palletcontentsBoxitems2.setBoxid(BOXID2);
        palletcontentsBoxitems2.setAsispartnumber(AS_IS_PART_NUM);
        palletcontentsBoxitems2.setFgmpn(FG_MPN);
        palletcontentsBoxitems2.setSerialnumber(SERIAL_NUM2);
        palletcontentsBoxitems2.setBoxsequence(BOX_SEQUENCE_NUM2);
        palletcontentsBoxitemsListActual.add(palletcontentsBoxitems1);
        palletcontentsBoxitemsListActual.add(palletcontentsBoxitems2);
        return palletcontentsBoxitemsListActual;
    }

    private Optional<Pallets> generatePalletDetailsResponse() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        pallets.setType(TYPE);
        pallets.setCustomer(CUSTOMER);
        return Optional.of((Pallets) pallets);
    }

}