package com.apple.cap.api.acpackaging.handlers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.sap.cds.Result;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.UserInfo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.adminconfigservice.NumberRanges;
//import cds.gen.transferorderservice.PartWashTransferOrder;

public class ACPServiceTest implements EventHandler {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @Mock
    UserInfo userInfo = Mockito.mock(UserInfo.class);

    // @Mock
    // PartWashTransferOrder partWashTransferOrderRequest = Mockito.mock(PartWashTransferOrder.class);

    @InjectMocks
    ACPService aCPService = new ACPService(persistenceService, userInfo);

    @Mock
    ACPService aCPServiceMock = Mockito.mock(ACPService.class);

    @Mock
    Result result = Mockito.mock(Result.class);

    private static final String NUMBER_RANGE_TYPE = "BOX";
    private static final String PLANT = "5601";
    private static final String PLANT1 = "5651";
    private static final Integer CURRENT_NUMBER = 100;
    private static final String USER_ATTRIBUTE_PLANT = "Plant";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIncrementNumberRangeExp() {
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Assertions.assertThrows(ServiceException.class,
                () -> aCPService.incrementNumberRange(NUMBER_RANGE_TYPE, PLANT));
    }

    @Test
    public void testIncrementNumberRange() {
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        Assertions.assertDoesNotThrow(() -> aCPService.incrementNumberRange(NUMBER_RANGE_TYPE, PLANT));
    }

    @Test
    public void testHasPlantAccessTrue() {
        when(userInfo.isUnrestrictedAttribute(anyString())).thenReturn(true);
        Assertions.assertDoesNotThrow(() -> aCPService.hasPlantAccess(PLANT));
    }

    @Test
    public void testHasPlantAccessFalse() {
        when(userInfo.isUnrestrictedAttribute(anyString())).thenReturn(false);
        List<String> assignedPlants = new ArrayList<>();
        assignedPlants.add(PLANT);
        assignedPlants.add(PLANT1);
        when(userInfo.getAttributeValues(USER_ATTRIBUTE_PLANT)).thenReturn(assignedPlants);
        Assertions.assertDoesNotThrow(() -> aCPService.hasPlantAccess(PLANT));
    }

    @Test
    public void testHasPlantAccessFalseDoesntContain() {
        when(userInfo.isUnrestrictedAttribute(anyString())).thenReturn(false);
        List<String> assignedPlants = new ArrayList<>();
        assignedPlants.add(PLANT1);
        when(userInfo.getAttributeValues(USER_ATTRIBUTE_PLANT)).thenReturn(assignedPlants);
        Assertions.assertDoesNotThrow(() -> aCPService.hasPlantAccess(PLANT));
    }

}