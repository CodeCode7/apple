/*
* ManifestReportServiceTest.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sap.cds.Result;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsReadEventContext;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.ParameterInfo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.boxservice.Boxes;
import cds.gen.palletservice.Pallets;

public class ManifestReportServiceTest {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @InjectMocks
    ManifestReportService manifestReportService = new ManifestReportService(persistenceService);

    @Mock
    Result result = Mockito.mock(Result.class);

    @Mock
    CdsReadEventContext context = Mockito.mock(CdsReadEventContext.class);

    @Mock
    ParameterInfo parameterInfo = Mockito.mock(ParameterInfo.class);

    @Mock
    Map<String, String> map = Mockito.mock(Map.class);

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    private static final String FILTER = "$filter";
    private static final String BOXID1 = "B5651AC1021010700393";
    private static final String BOXID2 = "B5651AC1021010700394";

    private static final String PALLETID = "P5601SAC21130700234";

    private static final String IF_PLANT_NULL = "PALLETID eq 'P5601SAC21130700234' and PLANT eq null";
    private static final String IF_NO_PLANT = "PALLETID eq 'P5601SAC21130700234'";
    private static final String IF_VALID_PALLET = "PALLETID eq 'P5601SAC21130700234' and PLANT eq '5601'";
    private static final String IF_VALID_BOX = "BOXID eq 'B5651AC1021010700393' and PLANT eq '5601'";
    private static final String IF_INVALID_BOX = "BOXID eq 'B5601LAT11050700764' and PLANT eq '5601'";
    private static final String IF_INVALID_PALLET = "PALLETID eq 'P5601SAC11130700234' and PLANT eq '5601'";
    private static final String IF_VALID_PALLET_BOX = "BOXID eq 'B5651AC1021010700393' and PALLETID eq 'P5601SAC21130700234' and PLANT eq '5601'";
    private static final String IF_BOX_BTW = "PLANT eq '5601' and BOXID bt 'B5651AC1021010700393...B5651AC1021010700394'";
    private static final String IF_MULTIPLE_BOXES = "BOXID eq 'B5651AC1021010700393' or BOXID eq 'B5651AC1021010700394' and PALLETID eq 'P5601SAC21130700234' and PLANT eq '5601'";
    private static final String IF_BOX_NULL = "BOXID eq null and PLANT eq '5601'";
    private static final String IF_PALLET_NULL = "PALLETID eq null and PLANT eq '5601'";
    private static final String IF_VALID_SERIALNUMBER = "SERIALNUMBER eq 'FD7Y65V8JCLP' or SERIALNUMBER eq 'FD7Y18V8JCLP'";
    private static final String SERIALNUMBER_EQ_NULL = "SERIALNUMBER eq null";
    private static final String DOESNT_CONTAIN_SERIALNUMBER = "BOXID eq 'B5651AC1021010700393'";

    @Test
    public void testBeforeManifestItemReportByBoxIfPlantExists() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_NO_PLANT);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxIfPlantNull() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_PLANT_NULL);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxValidPallet() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_PALLET);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxValidBox() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_BOX);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxInvalidBoxId() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_INVALID_BOX);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxInvalidPalletId() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_INVALID_PALLET);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testBeforeManifestItemReportByBoxNullContext() {
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestItemReportByBox(null));
    }

    @Test
    public void testBeforeManifestItemReportByBoxNoFilter() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(null);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestItemReportByBox(context));
    }

    @Test
    public void testbeforeManifestItemReportByPalletValidBox() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_PALLET_BOX);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestItemReportByPallet(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByBoxFG() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_PALLET_BOX);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByBox(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByBoxFGPalletNull() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_PALLET_NULL);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByBox(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByBoxASIS() {
        List<Boxes> boxIdListActual = generateTwoBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_BOX_BTW);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByBox(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByPalletFG() {
        List<Boxes> boxIdListActual = generateTwoBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_MULTIPLE_BOXES);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByPallet(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByPalletASIS() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_PALLET_BOX);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByPallet(context));
    }

    @Test
    public void testBeforeManifestHeaderReportByPalletASISBoxNull() {
        List<Boxes> boxIdListActual = generateBoxIdListActual();
        List<Pallets> palletIdListActual = generatePalletIdListActual();

        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_BOX_NULL);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.listOf(Pallets.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestHeaderReportByPallet(context));
    }

    @Test
    public void testBeforeManifestSerialNumberDetails() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(IF_VALID_SERIALNUMBER);
        Assertions.assertDoesNotThrow(() -> manifestReportService.beforeManifestSerialNumberDetails(context));
    }

    @Test
    public void testBeforeManifestSerialNumberDetailsSNNull() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(SERIALNUMBER_EQ_NULL);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestSerialNumberDetails(context));
    }

    @Test
    public void testBeforeManifestSerialNumberDetailsDoesntContainSN() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(DOESNT_CONTAIN_SERIALNUMBER);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestSerialNumberDetails(context));
    }

    @Test
    public void testBeforeManifestSerialNumberDetailsNoFilter() {
        when(context.getParameterInfo()).thenReturn(parameterInfo);
        when(parameterInfo.getQueryParams()).thenReturn(map);
        when(map.get(FILTER)).thenReturn(null);
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestSerialNumberDetails(context));
    }

    @Test
    public void testBeforeManifestSerialNumberDetailsNullContext() {
        Assertions.assertThrows(ServiceException.class,
                () -> manifestReportService.beforeManifestSerialNumberDetails(null));
    }

    private List<Pallets> generatePalletIdListActual() {
        List<Pallets> palletIdListActual = new ArrayList<>();
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        palletIdListActual.add(pallets);
        return palletIdListActual;
    }

    private List<Boxes> generateBoxIdListActual() {
        List<Boxes> boxIdListActual = new ArrayList<>();
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID1);
        boxIdListActual.add(boxes);
        return boxIdListActual;
    }

    private List<Boxes> generateTwoBoxIdListActual() {
        List<Boxes> boxIdListActual = new ArrayList<>();
        Boxes boxes1 = Boxes.create();
        boxes1.setBoxID(BOXID1);
        Boxes boxes2 = Boxes.create();
        boxes2.setBoxID(BOXID2);
        boxIdListActual.add(boxes1);
        boxIdListActual.add(boxes2);
        return boxIdListActual;
    }

}
