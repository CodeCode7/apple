/*
* TransferOrderServiceTest.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/

package com.apple.cap.api.acpackaging.handlers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import com.sap.cds.Result;
import com.sap.cds.ql.cqn.CqnDelete;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.transferorderservice.BeginProcessingContext;
import cds.gen.transferorderservice.ResetProcessingContext;
import cds.gen.transferorderservice.SuccessfullyProcessedContext;

public class TransferOrderServiceTest implements EventHandler {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @Mock
    Result result = Mockito.mock(Result.class);

    @InjectMocks
    TransferOrderService transferOrderService = new TransferOrderService(persistenceService);

    @Mock
    BeginProcessingContext beginProcessingContext = Mockito.mock(BeginProcessingContext.class);

    @Mock
    ResetProcessingContext resetProcessingContext = Mockito.mock(ResetProcessingContext.class);

    @Mock
    SuccessfullyProcessedContext successfullyProcessedContext = Mockito.mock(SuccessfullyProcessedContext.class);

    private static final String PWTO_UUID = "70233f22-b0ad-4fd8-b311-49f8085d3a4d,e9990ce6-c595-4567-9592-b6303bf9e7f7";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testOnBeginProcessing() {
        when(beginProcessingContext.getId()).thenReturn(PWTO_UUID);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Optional<Integer> response = Optional.of(0);
        when(result.first(Integer.class)).thenReturn(response);
        Assertions.assertDoesNotThrow(() -> transferOrderService.onBeginProcessing(beginProcessingContext));
    }

    @Test
    public void testOnResetProcessing() {
        when(resetProcessingContext.getId()).thenReturn(PWTO_UUID);
        when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Optional<Integer> response = Optional.of(0);
        when(result.first(Integer.class)).thenReturn(response);
        Assertions.assertDoesNotThrow(() -> transferOrderService.onResetProcessing(resetProcessingContext));
    }

    @Test
    public void testOnResetProcessingExp() {
        when(resetProcessingContext.getId()).thenReturn(PWTO_UUID);
        when(persistenceService.run(any(CqnUpdate.class))).thenThrow(ServiceException.class);
        Assertions.assertDoesNotThrow(() -> transferOrderService.onResetProcessing(resetProcessingContext));
    }

    @Test
    public void testOnSuccessfullyProcessed() {
        when(successfullyProcessedContext.getId()).thenReturn(PWTO_UUID);
        when(persistenceService.run(any(CqnDelete.class))).thenReturn(result);
        Optional<Integer> response = Optional.of(0);
        when(result.first(Integer.class)).thenReturn(response);
        Assertions.assertDoesNotThrow(() -> transferOrderService.onSuccessfullyProcessed(successfullyProcessedContext));
    }

    @Test
    public void testOnSuccessfullyProcessedExp() {
        when(successfullyProcessedContext.getId()).thenReturn(PWTO_UUID);
        when(persistenceService.run(any(CqnDelete.class))).thenThrow(ServiceException.class);
        Assertions.assertDoesNotThrow(() -> transferOrderService.onSuccessfullyProcessed(successfullyProcessedContext));
    }
}