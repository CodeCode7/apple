package com.apple.cap.api.acpackaging.handlers;

import com.sap.cds.Result;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.adminconfigservice.ConfigValues;
import cds.gen.adminconfigservice.GetNumberRangeTypesContext;
import cds.gen.adminconfigservice.NumberRanges;

public class AdminConfigServiceTest implements EventHandler {
    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @InjectMocks
    AdminConfigService adminConfigService = new AdminConfigService(persistenceService);

    @Mock
    Result result = Mockito.mock(Result.class);

    @Mock
    GetNumberRangeTypesContext getNumberRangeTypesContext = Mockito.mock(GetNumberRangeTypesContext.class);

    private static final String PLANT = "5601";
    private static final String TYPE = "BOX";
    private static final Integer MAX_NUMBER = 99999;
    private static final String CONFIG_NAME = "TestConfigNew";
    private static final String CONFIG_VALUE = "555555";
    private static final Integer INVALID_MAX_NUMBER = -1;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testBeforeConfigValues() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName(CONFIG_NAME);
        configValues.setValue(CONFIG_VALUE);
        Assertions.assertDoesNotThrow(() -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesNull() {
        Assertions.assertDoesNotThrow(() -> adminConfigService.beforeConfigValues(null));
    }

    @Test
    public void testBeforeConfigValuesEmptyValue() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName(CONFIG_NAME);
        configValues.setValue("");
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesEmptyName() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName("");
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesNullValue() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName(CONFIG_NAME);
        configValues.setValue(null);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesNullName() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName(null);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesName() {
        ConfigValues configValues = ConfigValues.create();
        configValues.setName(CONFIG_NAME);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeConfigValuesEmpty() {
        ConfigValues configValues = ConfigValues.create();
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeConfigValues(configValues));
    }

    @Test
    public void testBeforeNumberRanges() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        numberRanges.setType(TYPE);
        numberRanges.setMaxNumber(MAX_NUMBER);
        Assertions.assertDoesNotThrow(() -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesPlant() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesType() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        numberRanges.setType(TYPE);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesMaxNumber() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        numberRanges.setType(TYPE);
        numberRanges.setMaxNumber(INVALID_MAX_NUMBER);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesEmptyPlant() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant("");
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesEmptyType() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        numberRanges.setType("");
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesNullPlant() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(null);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesNullType() {
        NumberRanges numberRanges = NumberRanges.create();
        numberRanges.setPlant(PLANT);
        numberRanges.setType(null);
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesEmpty() {
        NumberRanges numberRanges = NumberRanges.create();
        Assertions.assertThrows(ServiceException.class, () -> adminConfigService.beforeNumberRanges(numberRanges));
    }

    @Test
    public void testBeforeNumberRangesNull() {
        Assertions.assertDoesNotThrow(() -> adminConfigService.beforeNumberRanges(null));
    }

    @Test
    public void testOnGetNumberRangeTypes() {
        Assertions.assertDoesNotThrow(() -> adminConfigService.onGetNumberRangeTypes(getNumberRangeTypesContext));
    }

}
