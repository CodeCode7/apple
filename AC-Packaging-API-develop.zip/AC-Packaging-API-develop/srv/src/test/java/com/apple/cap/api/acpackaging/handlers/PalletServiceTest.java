/*
* PalletServiceTest.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import com.sap.cds.Result;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CqnService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.boxservice.Boxes;
import cds.gen.palletservice.BoxItems;
import cds.gen.palletservice.CheckDuplicateBoxNumbersContext;
import cds.gen.palletservice.GetPalletContentsContext;
import cds.gen.palletservice.PalletItems;
import cds.gen.palletservice.Pallets;

public class PalletServiceTest extends ACPService implements EventHandler {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @Mock
    CqnService eventMeshService = Mockito.mock(CqnService.class);

    @InjectMocks
    PalletService palletService = new PalletService(persistenceService, eventMeshService, null);

    @InjectMocks
    PalletService palletServiceDefault = new PalletService();

    @Mock
    Result result = Mockito.mock(Result.class);

    @Mock
    GetPalletContentsContext getPalletContentsContext = Mockito.mock(GetPalletContentsContext.class);

    @Mock
    CheckDuplicateBoxNumbersContext checkDuplicateBoxNumbersContext = Mockito
            .mock(CheckDuplicateBoxNumbersContext.class);

    private static final String BOXID1 = "B5651AC1021010700393";
    private static final String BOXID2 = "B5651AC1021010700394";
    private static final String BOXID3 = "B5651AC1021010700395";
    private static final String BOXID = "B5651AC1021010700393";
    private static final String PALLETID = "P5601SAC21130700234";
    private static final String BOXID_DUPS = "B5651AC1021010700393,B5651AC1021010700393";
    private static final String AS_IS_PART_NUM = "LL661-09559";
    private static final String FG_MPN = "4Q8J2LL/A";
    private static final String COUNTRY_OF_ORIGIN = "USA";
    private static final String PLANT = "5601";
    private static final String STORAGE_LOC = "LAT";
    private static final String BOX_STATUS_CREATED = "0";
    private static final String BOX_STATUS_SHIPPED = "3";
    private static final Integer QUANTITY = 10;
    private static final String PALLET_SHIPMENT_LINKED = "3";
    private static final String PALLET_STATUS_COMPLETED = "2";
    private static final String BOX_STATUS_ON_PALLET = "2";
    private static final Integer CURRENT_NUMBER = 100;
    private static final boolean RESPONSE_FALSE = false;
    private static final boolean RESPONSE_TRUE = true;
    private static final String NUMBER_RANGE_TYPE_PALLET = "PALLET";
    private static final String A_TYPE = "A";
    private static final String B_TYPE = "B";
    private static final String CUSTOMER = "Likewize";
    private static final String STORAGE_LOC_SAC = "SAC";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testBeforeCreatePallet() {
        Pallets pallet = Pallets.create();
        pallet.setPlant(PLANT);
        PalletService palletServiceSpy = Mockito.spy(new PalletService(persistenceService, eventMeshService, null));
        Mockito.doReturn(RESPONSE_TRUE).when(palletServiceSpy).hasPlantAccess(PLANT);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Mockito.doReturn(numberRangesMock).when(palletServiceSpy).incrementNumberRange(NUMBER_RANGE_TYPE_PALLET, PLANT);
        Assertions.assertDoesNotThrow(() -> palletServiceSpy.onBeforeCreatePallet(pallet));
    }

    @Test
    public void testBeforeCreatePalletFalse() {
        Pallets pallet = Pallets.create();
        pallet.setPlant(PLANT);
        PalletService palletServiceSpy = Mockito.spy(new PalletService(persistenceService, eventMeshService, null));
        Mockito.doReturn(RESPONSE_FALSE).when(palletServiceSpy).hasPlantAccess(PLANT);
        Assertions.assertThrows(ServiceException.class, () -> palletServiceSpy.onBeforeCreatePallet(pallet));
    }

    @Test
    public void testOnBeforeUpdatePallet() {
        Pallets pallet = Pallets.create();
        pallet.setPlant(PLANT);
        pallet.setPalletID(PALLETID);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setStatus(PALLET_STATUS_COMPLETED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);

        PalletService palletServiceSpy = Mockito
                .spy(new PalletService(persistenceService, eventMeshService, new ArrayList<>()));
        Mockito.doReturn(RESPONSE_TRUE).when(palletServiceSpy).hasPlantAccess(PLANT);

        Assertions.assertDoesNotThrow(() -> palletServiceSpy.onBeforeUpdatePallet(pallet));
    }

    @Test
    public void testOnBeforeUpdatePalletStatusShipped() {
        Pallets pallet = Pallets.create();
        pallet.setPlant(PLANT);
        pallet.setPalletID(PALLETID);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setStatus(PALLET_SHIPMENT_LINKED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        PalletService palletServiceSpy = Mockito
                .spy(new PalletService(persistenceService, eventMeshService, new ArrayList<>()));
        Mockito.doReturn(RESPONSE_TRUE).when(palletServiceSpy).hasPlantAccess(PLANT);

        Assertions.assertDoesNotThrow(() -> palletServiceSpy.onBeforeUpdatePallet(pallet));
    }

    @Test
    public void testOnBeforeUpdatePalletEmpty() {
        Pallets pallet = Pallets.create();

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setStatus(PALLET_SHIPMENT_LINKED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        PalletService palletServiceSpy = Mockito
                .spy(new PalletService(persistenceService, eventMeshService, new ArrayList<>()));
        Mockito.doReturn(RESPONSE_TRUE).when(palletServiceSpy).hasPlantAccess(PLANT);

        Assertions.assertDoesNotThrow(() -> palletServiceSpy.onBeforeUpdatePallet(pallet));
    }

    @Test
    public void testOnBeforeUpdatePalletFalse() {
        Pallets pallet = Pallets.create();
        pallet.setPlant(PLANT);
        PalletService palletServiceSpy = Mockito.spy(new PalletService(persistenceService, eventMeshService, null));
        Mockito.doReturn(RESPONSE_FALSE).when(palletServiceSpy).hasPlantAccess(PLANT);
        Assertions.assertThrows(ServiceException.class, () -> palletServiceSpy.onBeforeUpdatePallet(pallet));
    }

    @Test
    public void testOnAfterUpdatePalletShipmentLinked() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setStatus(PALLET_SHIPMENT_LINKED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);
        Assertions.assertDoesNotThrow(() -> palletService.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnAfterUpdatePalletEmptyPallet() {
        Pallets pallets = Pallets.create();
        Assertions.assertDoesNotThrow(() -> palletService.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnAfterUpdatePalletStatusCompleted() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        pallets.setType(ASIS_TYPE);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(ASIS_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStatus(PALLET_STATUS_COMPLETED);

        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        PalletService palletServiceSpy = Mockito
                .spy(new PalletService(persistenceService, eventMeshService, palletIdListActual));

        Assertions.assertDoesNotThrow(() -> palletServiceSpy.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnAfterUpdatePalletStatusCompletedSTVType() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        pallets.setType(STV_TYPE);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStatus(PALLET_STATUS_COMPLETED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertDoesNotThrow(() -> palletService.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnAfterUpdatePalletSrvExp() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setStatus(PALLET_SHIPMENT_LINKED);

        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Supplier.class)).thenThrow(ServiceException.class);
        Assertions.assertThrows(ServiceException.class, () -> palletService.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnAfterUpdatePalletStatusNullType() {
        Pallets pallets = Pallets.create();
        pallets.setPalletID(PALLETID);
        pallets.setType(STV_TYPE);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(null);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStatus(PALLET_STATUS_COMPLETED);

        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertDoesNotThrow(() -> palletService.onAfterUpdatePallet(pallets));
    }

    @Test
    public void testOnGetPalletContentsPalletIdNull() {
        when(getPalletContentsContext.getPalletID()).thenReturn(null);
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxIdNull() {
        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(null);
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsPalletIdEmpty() {
        when(getPalletContentsContext.getPalletID()).thenReturn("");
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxIdEmpty() {
        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn("");
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsDuplicateBoxIds() {
        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID_DUPS);
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxIDDupDB() {
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxNotPacked() {
        List<BoxItems> boxIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxIdsShipped() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_SHIPPED);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsNotPacked() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_CREATED);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID3);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContents() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_CREATED);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertDoesNotThrow(() -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsAsIsSrvExp() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_CREATED);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID3);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(A_TYPE);
        palletsMock.setCustomer(null);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsBoxStatusOnPallet() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_ON_PALLET);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertDoesNotThrow(() -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsServiceExpPallet() {
        List<BoxItems> boxItemIdListActual = generateEmptyBoxListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_ON_PALLET);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);
        when(result.first(Supplier.class)).thenThrow(ServiceException.class);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsGetTypeCustSrvExp() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_ON_PALLET);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnGetPalletContentsStorageLocExp() {
        List<BoxItems> boxItemIdListActual = generateTwoBoxIdListActual();
        List<PalletItems> palletIdListActual = new ArrayList<>();
        List<Boxes> boxIdListActual = generateBoxIdListActual(BOX_STATUS_CREATED);

        when(getPalletContentsContext.getPalletID()).thenReturn(PALLETID);
        when(getPalletContentsContext.getBoxID()).thenReturn(BOXID);
        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(BoxItems.class)).thenReturn(boxItemIdListActual);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        when(result.listOf(Boxes.class)).thenReturn(boxIdListActual);

        Pallets palletsMock = Pallets.create();
        palletsMock.setPalletID(PALLETID);
        palletsMock.setType(B_TYPE);
        palletsMock.setCustomer(CUSTOMER);
        palletsMock.setStorageLocation(STORAGE_LOC_SAC);
        palletsMock.setPlant(PLANT);
        Optional<Pallets> palletsResponse = Optional.of((Pallets) palletsMock);
        when(result.first(Pallets.class)).thenReturn(palletsResponse);

        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onGetPalletContents(getPalletContentsContext));
    }

    @Test
    public void testOnCheckDuplicateBoxNumbersBoxIdDups() {
        when(checkDuplicateBoxNumbersContext.getPalletID()).thenReturn(PALLETID);
        when(checkDuplicateBoxNumbersContext.getBoxID()).thenReturn(BOXID_DUPS);
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onCheckDuplicateBoxNumbers(checkDuplicateBoxNumbersContext));
    }

    @Test
    public void testOnCheckDuplicateBoxNumbersBoxIdDupsDB() {

        when(checkDuplicateBoxNumbersContext.getPalletID()).thenReturn(PALLETID);
        when(checkDuplicateBoxNumbersContext.getBoxID()).thenReturn(BOXID1);

        List<PalletItems> palletIdListActual = generateTwoPalletIdListActual();

        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> palletService.onCheckDuplicateBoxNumbers(checkDuplicateBoxNumbersContext));
    }

    @Test
    public void testOnCheckDuplicateBoxNumbers() {

        when(checkDuplicateBoxNumbersContext.getPalletID()).thenReturn(PALLETID);
        when(checkDuplicateBoxNumbersContext.getBoxID()).thenReturn(BOXID1);

        List<PalletItems> palletIdListActual = new ArrayList<>();

        when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        when(result.listOf(PalletItems.class)).thenReturn(palletIdListActual);
        Assertions.assertDoesNotThrow(() -> palletService.onCheckDuplicateBoxNumbers(checkDuplicateBoxNumbersContext));
        assertEquals((Integer) 0, checkDuplicateBoxNumbersContext.getResult());
    }

    private List<PalletItems> generateTwoPalletIdListActual() {
        List<PalletItems> palletIdListActual = new ArrayList<>();
        PalletItems palletsItem1 = PalletItems.create();
        palletsItem1.setBoxIDBoxID(BOXID1);
        PalletItems palletsItem2 = PalletItems.create();
        palletsItem2.setBoxIDBoxID(BOXID2);
        palletIdListActual.add(palletsItem1);
        palletIdListActual.add(palletsItem2);
        return palletIdListActual;
    }

    private List<BoxItems> generateTwoBoxIdListActual() {
        List<BoxItems> boxIdListActual = new ArrayList<>();
        BoxItems boxItems1 = BoxItems.create();
        boxItems1.setBoxIDBoxID(BOXID1);
        boxItems1.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems1.setFinishedGoodsMPN(FG_MPN);
        boxItems1.setCountryOfOrigin(COUNTRY_OF_ORIGIN);
        BoxItems boxItems2 = BoxItems.create();
        boxItems2.setBoxIDBoxID(BOXID2);
        boxItems2.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems2.setFinishedGoodsMPN(FG_MPN);
        boxItems2.setCountryOfOrigin(COUNTRY_OF_ORIGIN);
        boxIdListActual.add(boxItems1);
        boxIdListActual.add(boxItems2);
        return boxIdListActual;
    }

    private List<Boxes> generateBoxIdListActual(String status) {
        String boxStatus = BOX_STATUS_SHIPPED;
        if (status.equals(BOX_STATUS_CREATED)) {
            boxStatus = BOX_STATUS_CREATED;
        } else if (status.equals(BOX_STATUS_ON_PALLET)) {
            boxStatus = BOX_STATUS_ON_PALLET;
        }
        List<Boxes> boxIdListActual = new ArrayList<>();
        Boxes boxes1 = Boxes.create();
        boxes1.setBoxID(BOXID1);
        boxes1.setStatus(boxStatus);
        boxes1.setPlant(PLANT);
        boxes1.setStorageLocation(STORAGE_LOC);
        boxes1.setQuantity(QUANTITY);
        Boxes boxes2 = Boxes.create();
        boxes2.setBoxID(BOXID2);
        boxes2.setStatus(boxStatus);
        boxes2.setPlant(PLANT);
        boxes2.setStorageLocation(STORAGE_LOC);
        boxes2.setQuantity(QUANTITY);
        boxIdListActual.add(boxes1);
        boxIdListActual.add(boxes2);
        return boxIdListActual;
    }

    private List<BoxItems> generateEmptyBoxListActual() {
        List<BoxItems> boxIdListActual = new ArrayList<>();
        BoxItems boxItems1 = BoxItems.create();
        BoxItems boxItems2 = BoxItems.create();
        boxIdListActual.add(boxItems1);
        boxIdListActual.add(boxItems2);
        return boxIdListActual;
    }

}