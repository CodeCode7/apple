/*
* BoxServiceTest.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import static org.mockito.ArgumentMatchers.any;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.sap.cds.Result;
import com.sap.cds.ql.Delete;
import com.sap.cds.ql.cqn.CqnDelete;
import com.sap.cds.ql.cqn.CqnInsert;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.reflect.CdsModel;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsDeleteEventContext;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cloud.sdk.cloudplatform.connectivity.exception.DestinationAccessException;
//import com.sap.cloud.sdk.testutil.MockUtil;

// import org.junit.BeforeClass;
// import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cds.gen.VBoxitemsWithSerialnumber;
import cds.gen.ZtaCtrlmat;
import cds.gen.adminconfigservice.ConfigValues;
import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.boxservice.BoxItems;
import cds.gen.boxservice.Boxes;
import cds.gen.boxservice.Boxes_;
import cds.gen.boxservice.CheckDuplicateSerialNumbersContext;
import cds.gen.boxservice.SerialNumberDetailsContext;
import cds.gen.boxservice.ValidateSerialNumbersContext;
import cds.gen.transferorderservice.PartWashTransferOrder;

public class BoxServiceTest implements EventHandler {

    @Mock
    PersistenceService persistenceService = Mockito.mock(PersistenceService.class);

    @Mock
    PartWashTransferOrder partWashTransferOrderMock = Mockito.mock(PartWashTransferOrder.class);

    @Mock
    CdsModel model = Mockito.mock(CdsModel.class);

    @InjectMocks
    BoxService boxService = new BoxService(persistenceService, partWashTransferOrderMock);

    @InjectMocks
    BoxService boxServiceDefault = new BoxService();

    @Mock
    BoxService boxServiceMock = Mockito.mock(BoxService.class);

    @Mock
    Result result = Mockito.mock(Result.class);

    @Mock
    CheckDuplicateSerialNumbersContext checkDuplicateSerialNumbersContext = Mockito
            .mock(CheckDuplicateSerialNumbersContext.class);

    @Mock
    ValidateSerialNumbersContext validateSerialNumbersContext = Mockito.mock(ValidateSerialNumbersContext.class);

    @Mock
    SerialNumberDetailsContext serialNumberDetailsContext = Mockito.mock(SerialNumberDetailsContext.class);

    @Mock
    CdsDeleteEventContext cdsDeleteEventContext = Mockito.mock(CdsDeleteEventContext.class);

    @Mock
    PartWashTransferOrder partWashTransferOrderRequest = Mockito.mock(PartWashTransferOrder.class);

    // private static final MockUtil mockUtil = new MockUtil();

    // @Mock
    // final HttpDestination destination = Mockito.mock(HttpDestination.class);

    // final Destination destination = mockUtil.mockDestination(
    // MockDestination.builder()
    // .name(DESTINATION_NAME)
    // .uri(URI.create(DESTINATION_URI))
    // .isTrustingAllCertificates(true)
    // .build());
    // mockUtil.mockDestination(destination);
    // DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();

    // @Mock
    // DestinationAccessor destinationAccessor =
    // Mockito.mockStatic(DestinationAccessor.class);

    private static final String BOXID = "B5651AC1021010700393";
    private static final String BOXID1 = "B5651AC1021010700394";
    private static final String BOXID2 = "B5651AC1021010700395";
    private static final String SERIAL_NUMBER_STR = "FD7Y60XHJCLP";
    private static final String SERIAL_NUMBER_DUP = "FD7Y60XHJCLP,FD7Y60XJJCLP,FD7Y60XHJCLP,FD7Y60XJJCLP";
    private static final String SERIAL_NUMBER_UNQ = "FD7Y60XHJCLP,FD7Y60XJJCLP";
    private static final String SERIAL_NUMBER_MULTIPART = "FD7Y70LEHG07,FD7Y71LEHG07";
    private static final String SEQUENCE_POS = "1,2";
    private static final String[] SERIAL_NUMBER_ARR = { SERIAL_NUMBER_DUP };
    private static final String PLANT = "5601";
    private static final String STORAGE_LOC = "LAT";
    private static final String SSCC18_VALUE = "001959491420001348";
    private static final Integer CURRENT_NUMBER = 100;
    private static final String NUMBER_RANGE_TYPE_BOX = "BOX";
    private static final boolean RESPONSE_FALSE = false;
    private static final boolean RESPONSE_TRUE = true;
    private static final String INITIAL_PROCESSING_STATUS = "A";
    private static final String AS_IS_PART_NUM = "LL661-09559";
    private static final String AS_IS_PART_NUM_COMMA = "LL661-09559,LL661-09560";
    private static final String FG_MPN = "4Q8J2LL/A";
    private static final String FG_MPN_COMMA = "4Q8J2LL/A,4NQQ2AM/A";
    private static final Integer BOX_QUANTITY = 2;
    private static final Integer BOX_QUANTITY_EQUALZERO = 1;
    private static final String EVENTNAME_DEVICES = "Devices";
    private static final String DESTINATION_NAME = "ACSC_STRATOS_APIM";
    private static final String DESTINATION_URI = "https://apidev.prod.apimanagement.us10.hana.ondemand.com";
    private static final String CONFIG_CODE_JCLP = "JCLP";
    private static final String ASIS_PN_JCLP = "LL661-09559";
    private static final String FG_PN_JCLP = "4NQQ2AM/A";
    private static final String EAN11_JCLP = "190198690333";
    private static final String MODEL_JCLP = "A1864";
    private static final String CELLULAR_JCLP = "";
    private static final String CELLULAR_X = "X";
    private static final String COO_JCLP = "CN";
    private static final String CONFIG_CODE_HG07 = "HG07";
    private static final String ASIS_PN_HG07_1 = "AM661-06421";
    private static final String ASIS_PN_HG07_2 = "AZD661-06421";
    private static final String FG_PN_HG07 = "4NQQ2AM/A";
    private static final String STATUS_CREATED = "0";
    private static final String BOX_STATUS_COMPLETED = "1";
    private static final String ASIS_TYPE = "A";
    private static final String STV_TYPE = "B";

    // @Rule
    // public MockitoRule rule = MockitoJUnit.rule();

    // @BeforeClass
    // public static void beforeClass() {
    // mockUtil.mockDefaults();
    // }

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testOnBeforeCreateBox() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setStorageLocation(STORAGE_LOC);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Mockito.doReturn(numberRangesMock).when(boxServiceSpy).incrementNumberRange(NUMBER_RANGE_TYPE_BOX, PLANT);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeCreateBox(boxes));
    }

    @Test
    public void testOnBeforeCreateBoxFalse() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setStorageLocation(STORAGE_LOC);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_FALSE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Assertions.assertThrows(ServiceException.class, () -> boxServiceSpy.onBeforeCreateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxFalse() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_FALSE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Assertions.assertThrows(ServiceException.class, () -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBox() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItem.setFinishedGoodsMPN(FG_MPN);
        boxes.setToBoxItems(boxItemsList);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(INITIAL_PROCESSING_STATUS);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxModifyNeg() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItems = BoxItems.create();
        boxItems.setBoxIDBoxID(BOXID);
        boxItems.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems.setFinishedGoodsMPN(FG_MPN);
        BoxItems boxItem = BoxItems.create();
        boxItem.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItem.setFinishedGoodsMPN(FG_MPN);
        boxItemsList.add(boxItems);
        boxes.setToBoxItems(boxItemsList);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(INITIAL_PROCESSING_STATUS);
        boxesMock.setQuantity(BOX_QUANTITY);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxModifyZero() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItems = BoxItems.create();
        boxItems.setBoxIDBoxID(BOXID);
        boxItems.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems.setFinishedGoodsMPN(FG_MPN);
        BoxItems boxItem = BoxItems.create();
        boxItem.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItem.setFinishedGoodsMPN(FG_MPN);
        boxItemsList.add(boxItems);
        boxes.setToBoxItems(boxItemsList);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(INITIAL_PROCESSING_STATUS);
        boxesMock.setQuantity(BOX_QUANTITY_EQUALZERO);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxModifyPos() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        List<BoxItems> boxItemsList = generateThreeBoxIdListActual();
        boxes.setToBoxItems(boxItemsList);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(INITIAL_PROCESSING_STATUS);
        boxesMock.setQuantity(BOX_QUANTITY);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxModify() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        List<BoxItems> boxItemsList = generateThreeBoxIdListActual();
        boxes.setToBoxItems(boxItemsList);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(INITIAL_PROCESSING_STATUS);
        boxesMock.setQuantity(BOX_QUANTITY);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        Assertions.assertDoesNotThrow(() -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnBeforeUpdateBoxSrvExp() {
        Boxes boxes = Boxes.create();
        boxes.setPlant(PLANT);
        boxes.setBoxID(BOXID);
        BoxService boxServiceSpy = createBoxSpy();
        Mockito.doReturn(RESPONSE_TRUE).when(boxServiceSpy).hasPlantAccess(PLANT);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Assertions.assertThrows(ServiceException.class, () -> boxServiceSpy.onBeforeUpdateBox(boxes));
    }

    @Test
    public void testOnAfterUpdateBox() {
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID);
        boxes.setPlant(PLANT);
        boxes.setType(ASIS_TYPE);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setSerialNumber(SERIAL_NUMBER_STR);
        boxes.setToBoxItems(boxItemsList);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setSscc18(SSCC18_VALUE);
        boxesMock.setType(ASIS_TYPE);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        Mockito.when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        ConfigValues configValuesMock = ConfigValues.create();
        configValuesMock.setValue(SSCC18_VALUE);
        Optional<ConfigValues> configValuesResponse = Optional.of((ConfigValues) configValuesMock);
        Mockito.when(result.first(ConfigValues.class)).thenReturn(configValuesResponse);
        PartWashTransferOrder partWashTransferOrder = PartWashTransferOrder.create();
        partWashTransferOrder.setBoxQuantity(BOX_QUANTITY);
        Mockito.when(partWashTransferOrderMock.getBoxQuantity()).thenReturn(BOX_QUANTITY);
        Optional<PartWashTransferOrder> partWashResponse = Optional
                .of((PartWashTransferOrder) partWashTransferOrderMock);
        Mockito.when(persistenceService.run(any(CqnInsert.class))).thenReturn(result);
        Mockito.when(result.single(PartWashTransferOrder.class)).thenReturn(partWashTransferOrder);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterUpdateBox(boxes));
    }

    @Test
    public void testOnAfterUpdateBoxASISNull() {
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID);
        boxes.setPlant(PLANT);
        boxes.setType(null);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setSerialNumber(SERIAL_NUMBER_STR);
        boxes.setToBoxItems(boxItemsList);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setSscc18(SSCC18_VALUE);
        boxesMock.setType(null);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        Mockito.when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        ConfigValues configValuesMock = ConfigValues.create();
        configValuesMock.setValue(SSCC18_VALUE);
        Optional<ConfigValues> configValuesResponse = Optional.of((ConfigValues) configValuesMock);
        Mockito.when(result.first(ConfigValues.class)).thenReturn(configValuesResponse);
        PartWashTransferOrder partWashTransferOrder = PartWashTransferOrder.create();
        partWashTransferOrder.setBoxQuantity(BOX_QUANTITY);
        Mockito.when(partWashTransferOrderMock.getBoxQuantity()).thenReturn(BOX_QUANTITY);
        Optional<PartWashTransferOrder> partWashResponse = Optional
                .of((PartWashTransferOrder) partWashTransferOrderMock);
        Mockito.when(persistenceService.run(any(CqnInsert.class))).thenReturn(result);
        Mockito.when(result.single(PartWashTransferOrder.class)).thenReturn(partWashTransferOrder);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterUpdateBox(boxes));
    }

    @Test
    public void testOnAfterUpdateBoxSubs() {
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID);
        boxes.setPlant(PLANT);
        boxes.setType(STV_TYPE);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setSerialNumber(SERIAL_NUMBER_STR);
        boxes.setToBoxItems(boxItemsList);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setSscc18(SSCC18_VALUE);
        boxesMock.setType(STV_TYPE);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        Mockito.when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        ConfigValues configValuesMock = ConfigValues.create();
        configValuesMock.setValue(SSCC18_VALUE);
        Optional<ConfigValues> configValuesResponse = Optional.of((ConfigValues) configValuesMock);
        Mockito.when(result.first(ConfigValues.class)).thenReturn(configValuesResponse);
        PartWashTransferOrder partWashTransferOrder = PartWashTransferOrder.create();
        partWashTransferOrder.setBoxQuantity(BOX_QUANTITY);
        Mockito.when(partWashTransferOrderMock.getBoxQuantity()).thenReturn(BOX_QUANTITY);
        Optional<PartWashTransferOrder> partWashResponse = Optional
                .of((PartWashTransferOrder) partWashTransferOrderMock);
        Mockito.when(persistenceService.run(any(CqnInsert.class))).thenReturn(result);
        Mockito.when(result.single(PartWashTransferOrder.class)).thenReturn(partWashTransferOrder);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterUpdateBox(boxes));
    }

    @Test
    public void testOnAfterUpdateBoxSSCC18NotPresent() {
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID);
        boxes.setPlant(PLANT);
        boxes.setType(ASIS_TYPE);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setSerialNumber(SERIAL_NUMBER_STR);
        boxes.setToBoxItems(boxItemsList);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Boxes boxMock = Boxes.create();
        boxMock.setSscc18(null);
        boxMock.setType(ASIS_TYPE);
        Optional<Boxes> boxResponse = Optional.of((Boxes) boxMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxResponse);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        Mockito.when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        ConfigValues configValuesMock = ConfigValues.create();
        configValuesMock.setValue(SSCC18_VALUE);
        Optional<ConfigValues> configValuesResponse = Optional.of((ConfigValues) configValuesMock);
        Mockito.when(result.first(ConfigValues.class)).thenReturn(configValuesResponse);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterUpdateBox(boxes));
    }

    @Test
    public void testOnAfterUpdateBoxSSCC18NotPresentException() {
        Boxes boxes = Boxes.create();
        boxes.setBoxID(BOXID);
        boxes.setPlant(PLANT);
        boxes.setType(ASIS_TYPE);
        List<BoxItems> boxItemsList = new ArrayList<>();
        BoxItems boxItem = BoxItems.create();
        boxItem.setSerialNumber(SERIAL_NUMBER_STR);
        boxes.setToBoxItems(boxItemsList);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(persistenceService.run(any(CqnUpdate.class))).thenReturn(result);
        Boxes boxMock = Boxes.create();
        boxMock.setSscc18(null);
        boxMock.setType(ASIS_TYPE);
        Optional<Boxes> boxResponse = Optional.of((Boxes) boxMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxResponse);
        NumberRanges numberRangesMock = NumberRanges.create();
        numberRangesMock.setCurrentNumber(CURRENT_NUMBER);
        Optional<NumberRanges> numberRangesResponse = Optional.of((NumberRanges) numberRangesMock);
        Mockito.when(result.first(NumberRanges.class)).thenReturn(numberRangesResponse);
        Assertions.assertThrows(ServiceException.class, () -> boxService.onAfterUpdateBox(boxes));
    }

    @Test
    public void testOnCheckDuplicateSerialNumbersWithinListException() {
        Mockito.when(checkDuplicateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_DUP);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCheckDuplicateSerialNumbers(checkDuplicateSerialNumbersContext));
    }

    @Test
    public void testOnCheckDuplicateSerialNumbersDBException() {
        List<VBoxitemsWithSerialnumber> boxItemsListActual = new ArrayList<>();
        VBoxitemsWithSerialnumber boxItem = Mockito.mock(VBoxitemsWithSerialnumber.class);
        boxItem.setBoxid(BOXID);
        boxItem.setSerialnumber(SERIAL_NUMBER_STR);
        boxItemsListActual.add(boxItem);
        Mockito.when(checkDuplicateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_STR);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(boxItemsListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCheckDuplicateSerialNumbers(checkDuplicateSerialNumbersContext));
    }

    @Test
    public void testOnCheckDuplicateSerialNumbers() throws ServiceException, URISyntaxException, IOException {
        List<VBoxitemsWithSerialnumber> boxItemsListActual = new ArrayList<>();
        Mockito.when(checkDuplicateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(boxItemsListActual);
        Mockito.when(boxServiceMock.getExistingSerialNumbers(BOXID, SERIAL_NUMBER_ARR)).thenReturn(boxItemsListActual);
        Assertions
                .assertDoesNotThrow(() -> boxService.onCheckDuplicateSerialNumbers(checkDuplicateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbersWithinListException() {
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_DUP);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbersDBException() {
        List<VBoxitemsWithSerialnumber> boxItemsListActual = new ArrayList<>();
        VBoxitemsWithSerialnumber boxItem = Mockito.mock(VBoxitemsWithSerialnumber.class);
        boxItem.setBoxid(BOXID);
        boxItem.setSerialnumber(SERIAL_NUMBER_STR);
        boxItemsListActual.add(boxItem);
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_STR);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(boxItemsListActual);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbers12Digits() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createZtaCtrlmatItems();
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(validateSerialNumbersContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Assertions.assertDoesNotThrow(() -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbersNullZtaCtrlmatItems() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(validateSerialNumbersContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(null);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbersEmptyZtaCtrlmatItems() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = new ArrayList<>();
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(validateSerialNumbersContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallValidateSerialNumbersMultiPartZtaCtrlmatItems() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createZtaCtrlmatMultipartItems();
        Mockito.when(validateSerialNumbersContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_MULTIPART);
        Mockito.when(validateSerialNumbersContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Assertions.assertDoesNotThrow(() -> boxService.onCallValidateSerialNumbers(validateSerialNumbersContext));
    }

    @Test
    public void testOnCallSerialNumberDetailsSTVType() {
        // MockDestination mockDestination = MockDestination.builder()
        // .name(DESTINATION_NAME)
        // .uri(URI.create(DESTINATION_URI))
        // .isTrustingAllCertificates(true)
        // .build();
        // mockUtil.mockDestination(mockDestination);
        // DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createCtrlmatDataForAsisPn();
        Mockito.when(serialNumberDetailsContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(serialNumberDetailsContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(serialNumberDetailsContext.getSequencePositions()).thenReturn(SEQUENCE_POS);
        Mockito.when(serialNumberDetailsContext.getConfigID()).thenReturn(CONFIG_CODE_JCLP);
        Mockito.when(serialNumberDetailsContext.getAsIsPartNumber()).thenReturn(ASIS_PN_JCLP);

        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);

        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setType(STV_TYPE);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);

        // Assertions.assertDoesNotThrow(() ->
        // boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
        // Assertions.assertThrows(DestinationAccessException.class,
        // () -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
    }

    @Test
    public void testOnCallSerialNumberDetailsNullType() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createCtrlmatDataForAsisPnCellX();
        Mockito.when(serialNumberDetailsContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(serialNumberDetailsContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(serialNumberDetailsContext.getSequencePositions()).thenReturn(SEQUENCE_POS);
        Mockito.when(serialNumberDetailsContext.getConfigID()).thenReturn(CONFIG_CODE_JCLP);
        Mockito.when(serialNumberDetailsContext.getAsIsPartNumber()).thenReturn(ASIS_PN_JCLP);
        Mockito.when(serialNumberDetailsContext.getFinishedGoodsMPN()).thenReturn(FG_MPN);

        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);

        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setType(null);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);

        Assertions.assertDoesNotThrow(() -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
        // Assertions.assertThrows(DestinationAccessException.class,
        // () -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
    }

    @Test
    public void testOnCallSerialNumberDetailsASISTypeMultiASISPart() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createCtrlmatDataForAsisPn();
        Mockito.when(serialNumberDetailsContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(serialNumberDetailsContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(serialNumberDetailsContext.getSequencePositions()).thenReturn(SEQUENCE_POS);
        Mockito.when(serialNumberDetailsContext.getConfigID()).thenReturn(CONFIG_CODE_JCLP);
        Mockito.when(serialNumberDetailsContext.getAsIsPartNumber()).thenReturn(AS_IS_PART_NUM_COMMA);
        Mockito.when(serialNumberDetailsContext.getFinishedGoodsMPN()).thenReturn(FG_MPN_COMMA);

        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);

        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setType(ASIS_TYPE);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);

        Assertions.assertDoesNotThrow(() -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
        // Assertions.assertThrows(ArrayIndexOutOfBoundsException.class,
        // () -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
    }

    @Test
    public void testOnCallSerialNumberDetailsASISType() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createCtrlmatDataForAsisPn();
        Mockito.when(serialNumberDetailsContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(serialNumberDetailsContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(serialNumberDetailsContext.getSequencePositions()).thenReturn(SEQUENCE_POS);
        Mockito.when(serialNumberDetailsContext.getConfigID()).thenReturn(CONFIG_CODE_JCLP);
        Mockito.when(serialNumberDetailsContext.getAsIsPartNumber()).thenReturn(ASIS_PN_JCLP);
        Mockito.when(serialNumberDetailsContext.getFinishedGoodsMPN()).thenReturn(FG_MPN);

        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);

        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setType(ASIS_TYPE);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);

        Assertions.assertDoesNotThrow(() -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
    }

    @Test
    public void testOnCallSerialNumberDetailsSrvExp() {
        List<VBoxitemsWithSerialnumber> vBoxitemsWithSerialnumberActual = new ArrayList<>();
        List<ZtaCtrlmat> ztaCtrlmatActual = createCtrlmatDataForAsisPn();
        Mockito.when(serialNumberDetailsContext.getBoxID()).thenReturn(BOXID);
        Mockito.when(serialNumberDetailsContext.getSerialNumbers()).thenReturn(SERIAL_NUMBER_UNQ);
        Mockito.when(serialNumberDetailsContext.getSequencePositions()).thenReturn(SEQUENCE_POS);
        Mockito.when(serialNumberDetailsContext.getConfigID()).thenReturn(CONFIG_CODE_JCLP);
        Mockito.when(serialNumberDetailsContext.getAsIsPartNumber()).thenReturn(ASIS_PN_JCLP);

        Mockito.when(result.listOf(VBoxitemsWithSerialnumber.class)).thenReturn(vBoxitemsWithSerialnumberActual);
        Mockito.when(result.listOf(ZtaCtrlmat.class)).thenReturn(ztaCtrlmatActual);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);

        Assertions.assertThrows(ServiceException.class,
                () -> boxService.onCallSerialNumberDetails(serialNumberDetailsContext));
    }

    @Test
    public void testOnBeforeDeleteBox() {
        CqnDelete delete = Delete.from(Boxes_.class).where(b -> b.get("BoxID").eq(BOXID));
        Mockito.when(cdsDeleteEventContext.getModel()).thenReturn(model);
        Mockito.when(cdsDeleteEventContext.getCqn()).thenReturn(delete);
        Map<String, Object> filterValues = new HashMap<>();
        filterValues.put("BoxID", BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(BOX_STATUS_COMPLETED);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxService.onBeforeDeleteBox(cdsDeleteEventContext));
    }

    @Test
    public void testOnBeforeDeleteBoxStatusCreated() {
        CqnDelete delete = Delete.from(Boxes_.class).where(b -> b.get("BoxID").eq(BOXID));
        Mockito.when(cdsDeleteEventContext.getModel()).thenReturn(model);
        Mockito.when(cdsDeleteEventContext.getCqn()).thenReturn(delete);
        Map<String, Object> filterValues = new HashMap<>();
        filterValues.put("BoxID", BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(STATUS_CREATED);
        Optional<Boxes> boxesResponse = Optional.of((Boxes) boxesMock);
        Mockito.when(result.first(Boxes.class)).thenReturn(boxesResponse);
        BoxItems boxItemMock = BoxItems.create();
        boxItemMock.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItemMock.setFinishedGoodsMPN(FG_MPN);
        Optional<BoxItems> boxItemResponse = Optional.of((BoxItems) boxItemMock);
        Mockito.when(result.first(BoxItems.class)).thenReturn(boxItemResponse);
        Assertions.assertDoesNotThrow(() -> boxService.onBeforeDeleteBox(cdsDeleteEventContext));
    }

    @Test
    public void testOnBeforeDeleteBoxSrvExp() {
        CqnDelete delete = Delete.from(Boxes_.class).where(b -> b.get("BoxID").eq(BOXID));
        Mockito.when(cdsDeleteEventContext.getModel()).thenReturn(model);
        Mockito.when(cdsDeleteEventContext.getCqn()).thenReturn(delete);
        Map<String, Object> filterValues = new HashMap<>();
        filterValues.put("BoxID", BOXID);
        Mockito.when(persistenceService.run(any(CqnSelect.class))).thenReturn(result);
        Boxes boxesMock = Boxes.create();
        boxesMock.setBoxID(BOXID);
        boxesMock.setStorageLocation(STORAGE_LOC);
        boxesMock.setPlant(PLANT);
        boxesMock.setStatus(STATUS_CREATED);
        Assertions.assertThrows(ServiceException.class, () -> boxService.onBeforeDeleteBox(cdsDeleteEventContext));
    }

    @Test
    public void testOnAfterDeleteBox() {
        Mockito.when(partWashTransferOrderMock.getBoxID()).thenReturn(BOXID);
        PartWashTransferOrder partWashTransferOrder = Mockito.mock(PartWashTransferOrder.class);
        partWashTransferOrder.setBoxQuantity(BOX_QUANTITY);
        Mockito.when(persistenceService.run(any(CqnInsert.class))).thenReturn(result);
        Mockito.when(result.single(PartWashTransferOrder.class)).thenReturn(partWashTransferOrder);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterDeleteBox(cdsDeleteEventContext));
    }

    @Test
    public void testOnAfterDeleteBoxPwtoNull() {
        PartWashTransferOrder partWashTransferOrder = Mockito.mock(PartWashTransferOrder.class);
        partWashTransferOrder.setBoxQuantity(BOX_QUANTITY);
        Mockito.when(persistenceService.run(any(CqnInsert.class))).thenReturn(result);
        Mockito.when(result.single(PartWashTransferOrder.class)).thenReturn(partWashTransferOrder);
        Assertions.assertDoesNotThrow(() -> boxService.onAfterDeleteBox(cdsDeleteEventContext));
    }

    private List<ZtaCtrlmat> createCtrlmatDataForAsisPn() {
        List<ZtaCtrlmat> ztaCtrlmatActual = new ArrayList<>();
        ZtaCtrlmat ztaCtrlmatItem = Mockito.mock(ZtaCtrlmat.class);
        ztaCtrlmatItem.setZmatnrAsIs(ASIS_PN_JCLP);
        ztaCtrlmatItem.setZmatnrFg(FG_PN_JCLP);
        ztaCtrlmatItem.setZeee(CONFIG_CODE_JCLP);
        ztaCtrlmatItem.setEan11(EAN11_JCLP);
        ztaCtrlmatItem.setZmodel(MODEL_JCLP);
        ztaCtrlmatItem.setZcell(CELLULAR_JCLP);
        ztaCtrlmatItem.setHerkl(COO_JCLP);
        ztaCtrlmatActual.add(ztaCtrlmatItem);
        return ztaCtrlmatActual;
    }

    private List<ZtaCtrlmat> createCtrlmatDataForAsisPnCellX() {
        List<ZtaCtrlmat> ztaCtrlmatActual = new ArrayList<>();
        ZtaCtrlmat ztaCtrlmatItem = Mockito.mock(ZtaCtrlmat.class);
        ztaCtrlmatItem.setZmatnrAsIs(ASIS_PN_JCLP);
        ztaCtrlmatItem.setZmatnrFg(FG_PN_JCLP);
        ztaCtrlmatItem.setZeee(CONFIG_CODE_JCLP);
        ztaCtrlmatItem.setEan11(EAN11_JCLP);
        ztaCtrlmatItem.setZmodel(MODEL_JCLP);
        ztaCtrlmatItem.setZcell(CELLULAR_X);
        ztaCtrlmatItem.setHerkl(COO_JCLP);
        ztaCtrlmatActual.add(ztaCtrlmatItem);
        return ztaCtrlmatActual;
    }

    private List<ZtaCtrlmat> createZtaCtrlmatMultipartItems() {
        List<ZtaCtrlmat> ztaCtrlmatActual = new ArrayList<>();
        ZtaCtrlmat ztaCtrlmatItem1 = Mockito.mock(ZtaCtrlmat.class);
        ztaCtrlmatItem1.setZmatnrAsIs(ASIS_PN_HG07_1);
        ztaCtrlmatItem1.setZmatnrFg(FG_PN_HG07);
        ztaCtrlmatItem1.setZeee(CONFIG_CODE_HG07);
        ZtaCtrlmat ztaCtrlmatItem2 = Mockito.mock(ZtaCtrlmat.class);
        ztaCtrlmatItem2.setZmatnrAsIs(ASIS_PN_HG07_2);
        ztaCtrlmatItem2.setZmatnrFg(FG_PN_HG07);
        ztaCtrlmatItem2.setZeee(CONFIG_CODE_HG07);
        ztaCtrlmatActual.add(ztaCtrlmatItem1);
        ztaCtrlmatActual.add(ztaCtrlmatItem2);
        return ztaCtrlmatActual;
    }

    private List<ZtaCtrlmat> createZtaCtrlmatItems() {
        List<ZtaCtrlmat> ztaCtrlmatActual = new ArrayList<>();
        ZtaCtrlmat ztaCtrlmatItem = Mockito.mock(ZtaCtrlmat.class);
        ztaCtrlmatItem.setZmatnrAsIs(ASIS_PN_JCLP);
        ztaCtrlmatItem.setZmatnrFg(FG_PN_JCLP);
        ztaCtrlmatItem.setZeee(CONFIG_CODE_JCLP);
        ztaCtrlmatActual.add(ztaCtrlmatItem);
        return ztaCtrlmatActual;
    }

    private List<BoxItems> generateThreeBoxIdListActual() {
        List<BoxItems> boxIdListActual = new ArrayList<>();
        BoxItems boxItems1 = BoxItems.create();
        boxItems1.setBoxIDBoxID(BOXID1);
        boxItems1.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems1.setFinishedGoodsMPN(FG_MPN);
        BoxItems boxItems2 = BoxItems.create();
        boxItems2.setBoxIDBoxID(BOXID2);
        boxItems2.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems2.setFinishedGoodsMPN(FG_MPN);
        BoxItems boxItems3 = BoxItems.create();
        boxItems3.setBoxIDBoxID(BOXID);
        boxItems3.setAsIsPartNumber(AS_IS_PART_NUM);
        boxItems3.setFinishedGoodsMPN(FG_MPN);
        boxIdListActual.add(boxItems1);
        boxIdListActual.add(boxItems2);
        boxIdListActual.add(boxItems3);
        return boxIdListActual;
    }

    private BoxService createBoxSpy() {
        return Mockito.spy(new BoxService(persistenceService, partWashTransferOrderMock));
    }

}
