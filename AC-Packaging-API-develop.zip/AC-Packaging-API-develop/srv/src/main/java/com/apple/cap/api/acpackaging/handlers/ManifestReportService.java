/*
* ManifestReportService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsReadEventContext;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cds.gen.boxservice.Boxes;
import cds.gen.boxservice.Boxes_;
import cds.gen.manifestreportservice.ManifestHeaderReportByBox_;
import cds.gen.manifestreportservice.ManifestHeaderReportByPallet_;
import cds.gen.manifestreportservice.ManifestItemReportByBox_;
import cds.gen.manifestreportservice.ManifestItemReportByPallet_;
import cds.gen.manifestreportservice.ManifestReportService_;
import cds.gen.manifestreportservice.ManifestSerialNumberDetails_;
import cds.gen.palletservice.Pallets;
import cds.gen.palletservice.Pallets_;

/**
 * ManifestReportService is a java class used for processing Pallets and Box
 * reports.
 *
 * @version 1.0
 * @date 15 June 2021
 * @author mvijetha
 */
@Component
@ServiceName(ManifestReportService_.CDS_NAME)
public class ManifestReportService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Constant(s)
     * ---------------------------------------------------------------------------
     */
    private static final String ERROR_PLANT_REQUIRED = "Plant is a required field";
    private static final String PLANT = "PLANT";
    private static final String PLANT_EQ_NULL = "PLANT eq null";
    private static final String BOXID = "BOXID";
    private static final String BOXID_EQ_NULL = "BOXID eq null";
    private static final String PALLETID = "PALLETID";
    private static final String PALLETID_EQ_NULL = "PALLETID eq null";
    private static final String FILTER = "$filter";
    private static final String BOXID_ERROR = "Please enter the correct Box ID/s. Invalid Box ID/s : ";
    private static final String PALLETID_ERROR = "Please enter the correct Pallet ID/s. Invalid Pallet ID/s : ";
    private static final String AND_OR = "and|or";
    private static final String FILTER_COMPARISON_SYMBOLS = "eq|ge|le|ne|gt|lt|bt";
    private static final String SERIALNUMBER = "SERIALNUMBER";
    private static final String SERIALNUMBER_EQ_NULL = "SERIALNUMBER eq null";
    private static final String ERROR_SERIALNUMBER_REQUIRED = "Serial Number is a required field";

    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    @Autowired
    PersistenceService db;

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    ManifestReportService(PersistenceService db) {
        this.db = db;
    }

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * beforeManifestItemReportByBox - @Before event for validating mandatory fields
     * 
     * @implSpec - For ManifestItemReportByBox view apply mandatory validations for
     *           Plant,BoxID,PalletID - Atleast one of them is entered
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = CdsService.EVENT_READ, entity = ManifestItemReportByBox_.CDS_NAME)
    public void beforeManifestItemReportByBox(CdsReadEventContext context) {
        validateMandatoryFields(context);
    }

    /**
     * beforeManifestItemReportByPallet - @Before event for validating mandatory
     * fields
     * 
     * @implSpec - For ManifestItemReportByPallet view apply mandatory validations
     *           for Plant,BoxID,PalletID - Atleast one of them is entered
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = CdsService.EVENT_READ, entity = ManifestItemReportByPallet_.CDS_NAME)
    public void beforeManifestItemReportByPallet(CdsReadEventContext context) {
        validateMandatoryFields(context);
    }

    /**
     * beforeManifestHeaderReportByBox - @Before event for validating mandatory
     * fields
     * 
     * @implSpec - For ManifestHeaderReportByBox view apply mandatory validations
     *           for Plant,BoxID,PalletID - Atleast one of them is entered
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = CdsService.EVENT_READ, entity = ManifestHeaderReportByBox_.CDS_NAME)
    public void beforeManifestHeaderReportByBox(CdsReadEventContext context) {
        validateMandatoryFields(context);
    }

    /**
     * beforeManifestHeaderReportByPallet - @Before event for validating mandatory
     * fields
     * 
     * @implSpec - For ManifestHeaderReportByPallet view apply mandatory for
     *           Plant,BoxID,PalletID - Atleast one of them is entered
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = CdsService.EVENT_READ, entity = ManifestHeaderReportByPallet_.CDS_NAME)
    public void beforeManifestHeaderReportByPallet(CdsReadEventContext context) {
        validateMandatoryFields(context);
    }

    /**
     * beforeManifestSerialNumberDetails - @Before event for validating mandatory
     * fields
     * 
     * @implSpec - For ManifestSerialNumberDetails view apply mandatory for
     *           SerialNumber
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of serialNumber empty or null
     * @author mvijetha
     */
    @Before(event = CdsService.EVENT_READ, entity = ManifestSerialNumberDetails_.CDS_NAME)
    public void beforeManifestSerialNumberDetails(CdsReadEventContext context) {
        if (context != null) {
            String filter = context.getParameterInfo().getQueryParams().get(FILTER);
            if (filter == null || !filter.contains(SERIALNUMBER) || filter.contains(SERIALNUMBER_EQ_NULL)) {
                throw new ServiceException(ERROR_SERIALNUMBER_REQUIRED);
            }
        } else {
            throw new ServiceException(ERROR_SERIALNUMBER_REQUIRED);
        }
    }

    /**
     * validateMandatoryFields - method for validating mandatory fields
     * 
     * @implSpec - Validate if Plant,BoxID,PalletID exists and valid
     * @param CdsReadEventContext context
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void validateMandatoryFields(CdsReadEventContext context) {
        if (context != null) {
            String filter = context.getParameterInfo().getQueryParams().get(FILTER);
            if (filter != null) {
                checkIfPlantExists(filter);
                checkIfValidBoxID(filter);
                checkIfValidPalletID(filter);
            }
        }
    }

    /**
     * checkIfValidPalletID - method for validating PalletID field
     * 
     * @implSpec - Validate if PalletID exists and valid
     * @param String filter
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void checkIfValidPalletID(String filter) {
        if (filter.contains(PALLETID) && !filter.contains(PALLETID_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            List<String> filteredPalletIds = map.get(PALLETID);
            List<Pallets> palletIDs = checkIfPalletIDExists(filteredPalletIds);
            List<String> palletIDsList = palletIDs.stream().map(Pallets::getPalletID).collect(Collectors.toList());
            List<String> invalidPalletIds = filteredPalletIds.stream().filter(pIds -> !palletIDsList.contains(pIds))
                    .collect(Collectors.toList());
            if (invalidPalletIds != null && !invalidPalletIds.isEmpty()) {
                throw new ServiceException(PALLETID_ERROR + invalidPalletIds);
            }
        }
    }

    /**
     * checkIfPalletIDExists - method to query T_PALLETS table for validating
     * palletID field
     * 
     * @implSpec - Query to fetch all the palletIDs in T_PALLETS table
     * @param String palletID
     * @return List<Pallets>
     * @author mvijetha
     */
    private List<Pallets> checkIfPalletIDExists(List<String> palletID) {
        // query to get PALLET_ID from T_PALLETS table
        CqnSelect sel = Select.from(Pallets_.class).columns(Pallets.PALLET_ID)
                .where(pID -> pID.PalletID().in(palletID));
        return db.run(sel).listOf(Pallets.class);
    }

    /**
     * checkIfValidBoxID - method for validating BoxID field
     * 
     * @implSpec - Validate if BoxID exists and valid
     * @param String filter
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void checkIfValidBoxID(String filter) {
        if (filter.contains(BOXID) && !filter.contains(BOXID_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            List<String> filteredBoxIds = map.get(BOXID);
            List<Boxes> boxIDList = checkIfBoxIDExists(filteredBoxIds);
            List<String> boxIDPresentList = boxIDList.stream().map(Boxes::getBoxID).collect(Collectors.toList());
            List<String> invalidBoxIds = filteredBoxIds.stream().filter(bxIds -> !boxIDPresentList.contains(bxIds))
                    .collect(Collectors.toList());
            if (invalidBoxIds != null && !invalidBoxIds.isEmpty()) {
                throw new ServiceException(BOXID_ERROR + invalidBoxIds);
            }
        }
    }

    /**
     * checkIfBoxIDExists - method to query T_BOXES table for validating BoxID field
     * 
     * @implSpec - Query to fetch all the BoxIDs in T_BOXES table
     * @param String boxID
     * @return List<Boxes>
     * @author mvijetha
     */
    private List<Boxes> checkIfBoxIDExists(List<String> boxID) {
        // query to get BOX_ID from T_BOXES table
        CqnSelect sel = Select.from(Boxes_.class).columns(Boxes.BOX_ID).where(bID -> bID.BoxID().in(boxID));
        return db.run(sel).listOf(Boxes.class);
    }

    /**
     * checkIfPlantExists - method for validating Plant field
     * 
     * @implSpec - Validate if Plant exists
     * @param String filter
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void checkIfPlantExists(String filter) {
        if (!filter.contains(PLANT) || filter.contains(PLANT_EQ_NULL)) {
            throw new ServiceException(ERROR_PLANT_REQUIRED);
        }
    }

    /**
     * convertStringTokenizerToMap - method for String Tokenizing filter
     * 
     * @implSpec - Tokenize the filter and return all the values as
     *           Map<String,List<String>> -> Map<LABEL,List<VALUE>> Eg:
     *           {BOXID=[B5601LAT21160700958, B5601LAT21160700959], PLANT=[5601],
     *           BOXCREATEDATE=[2021-07-16T00:00:00.000Z, 2021-07-17T23:59:59.000Z]}
     * @param String filter
     * @return Map<String,List<String>>
     * @author mvijetha
     */
    private Map<String, List<String>> convertStringTokenizerToMap(String filter) {
        String str = filter.replaceAll("['()]", "").trim();

        Map<String, List<String>> map = new HashMap<>();
        String key = null;
        String value = null;

        for (String actualElement : str.split(AND_OR)) {
            List<String> myList = null;
            key = actualElement.split(FILTER_COMPARISON_SYMBOLS)[0].trim();
            value = actualElement.split(FILTER_COMPARISON_SYMBOLS)[1].trim();
            if (value.contains("...")) {
                myList = new ArrayList<>(Arrays.asList(value.replace("...", ",").split(",")));
            } else {
                myList = new ArrayList<>(Arrays.asList(value));
            }

            if (map.containsKey(key)) {
                List<String> valueList = map.get(key);
                valueList.addAll(myList);
                map.put(key, valueList);
            } else {
                map.put(key, myList);
            }
        }
        return map;
    }

}
