/*
* PackingService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.sap.cds.ql.Select;
import com.sap.cds.ql.Update;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;

import org.springframework.stereotype.Component;

import cds.gen.VBoxesByShipment;
import cds.gen.VBoxesByShipment_;
import cds.gen.VPalletContentsForSalesRequest;
import cds.gen.VPalletContentsForSalesRequest_;
import cds.gen.boxservice.BoxItems_;
import cds.gen.boxservice.Boxes;
import cds.gen.boxservice.Boxes_;
import cds.gen.packingservice.BoxItems;
import cds.gen.packingservice.GetBoxesByShipmentContext;
import cds.gen.packingservice.GetPalletContentsContext;
import cds.gen.packingservice.GetPalletContentsForPackingContext;
import cds.gen.packingservice.GetPalletContentsForSalesRequestContext;
import cds.gen.packingservice.GetPalletContentsForUnPackingContext;
import cds.gen.packingservice.PackingService_;
import cds.gen.packingservice.SalesOrderRequestItems;
import cds.gen.packingservice.SetPalletPackedContext;
import cds.gen.packingservice.SetPalletUnPackedContext;
import cds.gen.packingservice.ShipmentBoxDetails;
import cds.gen.packingservice.ValidatePalletForTypeContext;
import cds.gen.palletservice.PalletItems;
import cds.gen.palletservice.PalletItems_;
import cds.gen.palletservice.Pallets;
import cds.gen.palletservice.Pallets_;

/**
 * PackingService is a java class used for Pallet processing for packaging
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */
@Component
@ServiceName(PackingService_.CDS_NAME)
public class PackingService extends ACPService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    PackingService(PersistenceService db) {
        this.db = db;
    }

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * onGetPalletContents - onEvent action to fetch boxItem details of boxIds
     * 
     * @implSpec - For each Pallet and for each boxID, get all the boxItems details
     * @param GetPalletContentsContext context
     * @return set context with List<BoxItems>
     * @author steven_lau
     */
    @On(event = GetPalletContentsContext.CDS_NAME)
    public void onGetPalletContents(GetPalletContentsContext context) {
        List<BoxItems> boxItemsDetails = null;

        String[] splitPalletID = context.getPalletId().split(";");

        // Fetch details for each pallet
        boxItemsDetails = fetchDetailsForEachPallet(splitPalletID);

        context.setResult(boxItemsDetails);

    }

    /**
     * fetchDetailsForEachPallet - method to fetch boxItem details of boxIds
     * 
     * @implSpec - For each Pallet and for each boxID, get all the boxItems details
     *           including AsIsPartNumber, BoxId, Plant, FinishedGoodsMPN,
     *           ModelNumber, IMEI1, IMEI2, SerialNumber, BoxSequence
     * @param String[] splitPalletID
     * @return List<BoxItems>
     * @author steven_lau
     */
    private List<BoxItems> fetchDetailsForEachPallet(String[] splitPalletID) {
        List<BoxItems> boxItemsDetails = new ArrayList<>();
        List<BoxItems> boxItemsList = null;
        BoxItems boxItems = null;
        for (String plalletId : splitPalletID) {
            // Fetch all the boxIds present in a PalletId
            List<PalletItems> boxIdsListForEachPallet = this.getBoxIdsList(plalletId);
            String[] splitBoxIds = boxIdsListForEachPallet.stream().map(PalletItems::getBoxIDBoxID)
                    .toArray(String[]::new);

            // Fetch plant for a PalletId
            String plant = getPlantForPallet(plalletId);

            // Fetch all the BoxItems for all the BoxIds
            boxItemsList = this.getBoxItems(splitBoxIds);

            Iterator<BoxItems> boxItemsItr = boxItemsList.iterator();
            while (boxItemsItr.hasNext()) {
                BoxItems newBoxItem = BoxItems.create();
                boxItems = boxItemsItr.next();

                newBoxItem.setAsIsPartNumber(boxItems.getAsIsPartNumber());
                newBoxItem.setBoxIDBoxID(boxItems.getBoxIDBoxID());
                newBoxItem.setPlant(plant);
                newBoxItem.setFinishedGoodsMPN(boxItems.getFinishedGoodsMPN());
                newBoxItem.setModelNumber(boxItems.getModelNumber());
                newBoxItem.setImei1(boxItems.getImei1());
                newBoxItem.setImei2(boxItems.getImei2());
                newBoxItem.setSerialNumber(boxItems.getSerialNumber());
                newBoxItem.setBoxSequence(boxItems.getBoxSequence());

                boxItemsDetails.add(newBoxItem);

            }
        }
        return boxItemsDetails;
    }

    /**
     * fetchDetailsForEachPalletForSalesRequest - method to fetch boxItem details of
     * boxIds for Sales request in PalletId
     * 
     * @implSpec - For each Pallet and for each boxID, get all the boxItems details
     *           including PalletID, BoxID, AsISPartNumber, SerialNumber,
     *           BoxSequence, FinishedGoodsMPN
     * @param String[] splitPalletID
     * @return List<SalesOrderRequestItems>
     * @author mvijetha
     */
    private List<SalesOrderRequestItems> fetchDetailsForEachPalletForSalesRequest(String[] splitPalletID) {
        List<SalesOrderRequestItems> salesOrderRequestItemsDetails = new ArrayList<>();
        List<VPalletContentsForSalesRequest> boxItemsList = null;
        VPalletContentsForSalesRequest boxItems = null;
        boxItemsList = getSalesOrderRequestItemsDetails(splitPalletID);
        if (boxItemsList == null || boxItemsList.isEmpty()) {
            throw new ServiceException(" Pallet ID/s = " + Arrays.toString(splitPalletID) + DOES_NOT_EXIST);
        }
        Iterator<VPalletContentsForSalesRequest> boxItemsItr = boxItemsList.iterator();
        while (boxItemsItr.hasNext()) {
            SalesOrderRequestItems newBoxItem = SalesOrderRequestItems.create();
            boxItems = boxItemsItr.next();

            newBoxItem.setPalletID(boxItems.getPalletid());
            newBoxItem.setBoxIDBoxID(boxItems.getBoxid());
            newBoxItem.setAsIsPartNumber(boxItems.getAsispartnumber());
            newBoxItem.setSerialNumber(boxItems.getSerialnumber());
            newBoxItem.setBoxSequence(boxItems.getBoxsequence());
            newBoxItem.setFinishedGoodsMPN(boxItems.getFgmpn());

            salesOrderRequestItemsDetails.add(newBoxItem);
        }
        return salesOrderRequestItemsDetails;
    }

    /**
     * getSalesOrderRequestItemsDetails returns List of VPalletContentsForSalesRequest
     * 
     * @implSpec Fetch all the details from V_PALLET_CONTENTS_FOR_SALES_REQUEST view for
     *           PalletIds, status BOX_STATUS_ON_PALLET = 2 and TYPE = STV/B
     * @param String[] splitPalletID
     * @return List of VPalletContentsForSalesRequest
     * @author mvijetha
     */
    public List<VPalletContentsForSalesRequest> getSalesOrderRequestItemsDetails(String[] splitPalletID) {
        // build query to get Boxes details from the Boxes table
        CqnSelect sel = Select.from(VPalletContentsForSalesRequest_.class).where(view -> view.PALLETID().in(splitPalletID)
                .and(view.STATUS().eq(BOX_STATUS_ON_PALLET)).and(view.TYPE().eq(STV_TYPE)));
        return db.run(sel).listOf(VPalletContentsForSalesRequest.class);
    }

    /**
     * onGetPalletContentsForPacking - onEvent action to fetch boxItem details of
     * boxIds for Packing
     * 
     * @implSpec - For each Pallet and for each boxID, get all the boxItems details
     * @param GetPalletContentsForPackingContext context
     * @return set context result with List<BoxItems>
     * @author steven_lau
     */
    @On(event = GetPalletContentsForPackingContext.CDS_NAME)
    public void onGetPalletContentsForPacking(GetPalletContentsForPackingContext context) {
        List<BoxItems> boxItemsDetails = null;

        String[] splitPalletID = context.getPalletId().split(PALLETID_SEPARATOR);

        List<Pallets> packingStatusPallet = this.getPalletIdsForStatusList(splitPalletID, BOX_STATUS_ON_PALLET);
        List<String> packingStatusPalletList = packingStatusPallet.stream().map(Pallets::getPalletID)
                .collect(Collectors.toList());

        // Fetch details for each pallet
        boxItemsDetails = fetchDetailsForEachPallet(packingStatusPalletList.stream().toArray(String[]::new));

        context.setResult(boxItemsDetails);

    }

    /**
     * onGetPalletContentsForUnPacking - onEvent action to fetch boxItem details for
     * unpacking
     * 
     * @implSpec - For a boxID, get all the boxItems details including
     *           AsIsPartNumber, BoxId, Plant, FinishedGoodsMPN, ModelNumber, IMEI1,
     *           IMEI2, SerialNumber, BoxSequence
     * @param GetPalletContentsForUnPackingContext context
     * @return set context result with List<BoxItems>
     * @author steven_lau
     */
    @On(event = GetPalletContentsForUnPackingContext.CDS_NAME)
    public void onGetPalletContentsForUnPacking(GetPalletContentsForUnPackingContext context) {
        List<BoxItems> boxItemsDetails = null;

        String[] splitPalletID = context.getPalletId().split(PALLETID_SEPARATOR);

        List<Pallets> unPackingStatusPallet = this.getPalletIdsForStatusList(splitPalletID, STATUS_SHIPMENT_PACKED);
        List<String> unPackingStatusPalletList = unPackingStatusPallet.stream().map(Pallets::getPalletID)
                .collect(Collectors.toList());

        // Fetch details for each pallet
        boxItemsDetails = fetchDetailsForEachPallet(unPackingStatusPalletList.stream().toArray(String[]::new));

        context.setResult(boxItemsDetails);

    }

    /**
     * onGetPalletContentsForSalesRequest - onEvent action to fetch boxItem details
     * of boxIds in each Pallet for Packing
     * 
     * @implSpec - For each Pallet and for each boxID, get all the boxItems details
     * @param GetPalletContentsForSalesRequestContext context
     * @return set context result with List<SalesOrderRequestItems>
     * @author mvijetha
     */
    @On(event = GetPalletContentsForSalesRequestContext.CDS_NAME)
    public void onGetPalletContentsForSalesRequest(GetPalletContentsForSalesRequestContext context) {
        String palletId = context.getPalletId();
        List<SalesOrderRequestItems> boxItemsDetailsForSalesRequest = null;
        if(palletId != null && !palletId.isEmpty()){
            // Fetch details for each pallet
            boxItemsDetailsForSalesRequest = fetchDetailsForEachPalletForSalesRequest(
                palletId.split(PALLETID_SEPARATOR));
        }else{
            throw new ServiceException("Pallet Id/s cannot be null/empty");
        }

        context.setResult(boxItemsDetailsForSalesRequest);

    }

    /**
     * onValidatePalletForType - function to validate whether the Pallet belongs to
     * correct type
     * 
     * @implSpec - For the PalletId and Type passed, validate if customer values
     *           exists. returns Y - if the type matches for the palletId and
     *           Customer number exists, else returns N
     * @param ValidatePalletForTypeContext context
     * @return set context result with String
     * @author mvijetha
     */
    @On(event = ValidatePalletForTypeContext.CDS_NAME)
    public void onValidatePalletForType(ValidatePalletForTypeContext context) {
        String validPalletForType = "N";
        boolean customerTypeExists = validatePalletForType(context.getPalletId(), context.getType(),
                context.getCustomer());
        if (customerTypeExists) {
            validPalletForType = "Y";
        }
        context.setResult(validPalletForType);
    }

    /**
     * validatePalletForType - returns boolean if entry exists for the PalletId,
     * Type and Customer in Pallets table
     * 
     * @implSpec - Validate if entry exists for the PalletId, Type and Customer in
     *           T_PALLETS table
     * 
     * @param String palletId
     * @param String type
     * @param String customer
     * @return boolean
     * @author mvijetha
     */
    private boolean validatePalletForType(String palletId, String type, String customer) {
        CqnSelect sel = Select.from(Pallets_.class)
                .where(pID -> pID.PalletID().eq(palletId).and(pID.Type().eq(type)).and(pID.Customer().eq(customer)));
        Optional<Pallets> pallets = db.run(sel).first(Pallets.class);
        return pallets.isPresent();
    }

    /**
     * onSetPalletPacked - onEvent action is used to Pack the shipment
     * 
     * @implSpec - Packing the shipment by updating the Pallet information in Pallet
     *           table with below details for all the pallets: ShipmentNumber =
     *           shipmentNumber param Status = 3 ShipmentDate = CurrentDate
     * @param SetPalletPackedContext context
     * @return set context result with 0 if success
     * @author steven_lau
     */
    @On(event = SetPalletPackedContext.CDS_NAME)
    public void onSetPalletPacked(SetPalletPackedContext context) {
        Pallets pallets = Pallets.create();
        List<PalletItems> palletItems = null;
        String shipmentNumber = context.getShipmentNumber();
        String[] splitpalletId = context.getPalletId().split(";");
        int flag = 0;

        pallets.setShipmentNumber(shipmentNumber);
        pallets.setStatus(STATUS_SHIPMENT_PACKED);
        pallets.setShipmentDate(Instant.now());

        flag = this.updatePalletPackedAndUnpacked(pallets.getShipmentNumber(), pallets.getShipmentDate(),
                pallets.getStatus(), splitpalletId);
        palletItems = this.getBoxIds(splitpalletId);

        Iterator<PalletItems> ids = palletItems.iterator();
        while (ids.hasNext()) {
            flag = this.updateBoxStatus(ids.next(), pallets);
        }
        context.setResult(flag);
    }

    /**
     * onSetPalletUnPacked - onEvent action is used to unpack the shipment
     * 
     * @implSpec - Unpack the shipment by updating the Pallet information in Pallet
     *           table with below details for all the pallets: ShipmentNumber = null
     *           Status = 2 ShipmentDate = CurrentDate
     * @param SetPalletUnPackedContext context
     * @return set context result with 0 if success
     * @author steven_lau
     */
    @On(event = SetPalletUnPackedContext.CDS_NAME)
    public void onSetPalletUnPacked(SetPalletUnPackedContext context) {
        Pallets pallets = Pallets.create();
        List<PalletItems> palletItems = null;
        String[] splitpalletId = context.getPalletId().split(";");
        int flag = 0;

        pallets.setShipmentNumber(null);
        pallets.setStatus(BOX_STATUS_ON_PALLET);
        pallets.setShipmentDate(Instant.now());

        flag = this.updatePalletPackedAndUnpacked(pallets.getShipmentNumber(), pallets.getShipmentDate(),
                pallets.getStatus(), splitpalletId);
        palletItems = this.getBoxIds(splitpalletId);
        Iterator<PalletItems> ids = palletItems.iterator();
        while (ids.hasNext()) {
            flag = this.updateBoxStatus(ids.next(), pallets);
        }

        context.setResult(flag);
    }

    /**
     * onGetBoxesByShipment - onEvent action to fetch List of ShipmentBoxDetails
     * from VBoxesByShipment
     * 
     * @implSpec - For a shipmentNumber, get all the ShipmentBoxDetails including
     *           serialNumber, BoxId and SSCC18
     * @param GetBoxesByShipmentContext context
     * @return set context result with List<ShipmentBoxDetails>
     * @author steven_lau
     */
    @On(event = GetBoxesByShipmentContext.CDS_NAME)
    public void onGetBoxesByShipment(GetBoxesByShipmentContext context) {
        String shipmentNumber = context.getShipmentNumber();

        // query the hana view
        CqnSelect sel = Select.from(VBoxesByShipment_.class)
                .columns(VBoxesByShipment.BOXID, VBoxesByShipment.SERIALNUMBER, VBoxesByShipment.SSCC18)
                .where(view -> view.SHIPMENTNUMBER().eq(shipmentNumber));
        List<ShipmentBoxDetails> boxDetails = db.run(sel).listOf(ShipmentBoxDetails.class);

        context.setResult(boxDetails);
    }

    /**
     * getBoxIds method to fetch BoxIds details of PalletID[]
     * 
     * @implSpec - Fetch all the box Ids for all PalletIDs from PalletItems table
     * @param String[] palletId
     * @return List<PalletItems>
     * @author steven_lau
     */
    private List<PalletItems> getBoxIds(String[] palletId) {
        // build query to get Box ids from the PalletItems table
        CqnSelect sel = Select.from(PalletItems_.class).columns(PalletItems.BOX_ID_BOX_ID)
                .where(pID -> pID.PalletID_PalletID().in(palletId));
        return db.run(sel).listOf(PalletItems.class);
    }

    /**
     * getBoxIdsList method to fetch BoxIds details of PalletID
     * 
     * @implSpec - Fetch all the box Ids for a PalletID from PalletItems table
     * @param String palletId
     * @return List<PalletItems>
     * @author steven_lau
     */
    private List<PalletItems> getBoxIdsList(String palletId) {
        // build query to get Box ids from the PalletItems table
        CqnSelect sel = Select.from(PalletItems_.class).columns(PalletItems.BOX_ID_BOX_ID)
                .where(pID -> pID.PalletID_PalletID().eq(palletId));
        return db.run(sel).listOf(PalletItems.class);

    }

    /**
     * getPalletIdsForStatusList method returns List of Pallets containing PalletID
     * 
     * @implSpec Fetch all the PalletIDs from Pallets table for palletIds and status
     *           param
     * @param String   status
     * @param String[] palletId
     * @return List of Pallets
     * @author steven_lau
     */
    private List<Pallets> getPalletIdsForStatusList(String[] palletId, String status) {
        // build query to get Box ids from the Pallet table for status = 02
        CqnSelect sel = Select.from(Pallets_.class).columns(Pallets.PALLET_ID)
                .where(pID -> pID.PalletID().in(palletId).and(pID.Status().eq(status)));
        return db.run(sel).listOf(Pallets.class);

    }

    /**
     * updateBoxStatus method used to update Boxes table
     * 
     * @implSpec - This method is used to update the following Boxes details for
     *           BoxId based on ShipmentNumber: If ShipmentNumber is not null, then
     *           update Box STATUS = STATUS_SHIPMENT_PACKED(3) * If ShipmentNumber
     *           is null, then update Box STATUS = BOX_STATUS_ON_PALLET(2)
     * @param PalletItems palletItems
     * @param Pallets     pallets
     * @return return 0 if update is successful, in case of exception return 1
     * @author steven_lau
     */
    private Integer updateBoxStatus(PalletItems palletItems, Pallets pallets) {
        try {
            if (pallets.getShipmentNumber() != null) {
                CqnUpdate update = Update.entity(Boxes_.class).data(Boxes.STATUS, STATUS_SHIPMENT_PACKED)
                        .where(bID -> bID.BoxID().eq(palletItems.getBoxIDBoxID()));
                db.run(update);
                return 0;
            } else {
                CqnUpdate update = Update.entity(Boxes_.class).data(Boxes.STATUS, BOX_STATUS_ON_PALLET)
                        .where(bID -> bID.BoxID().eq(palletItems.getBoxIDBoxID()));
                db.run(update);
                return 0;
            }

        } catch (Exception sql) {
            sql.getMessage();
            return 1;
        }

    }

    /**
     * updatePalletPackedAndUnpacked method used to update Pallets table
     * 
     * @implSpec - This method is used to update the following Pallets details for
     *           all the palletId[]: shipmentNumber, shipmentDate, status
     * @param String   shipmentNumber
     * @param Instant  shipmentDate
     * @param String   status
     * @param String[] palletId
     * @return return 0 if update is successful, in case of exception return 1
     * @author steven_lau
     */
    private Integer updatePalletPackedAndUnpacked(String shipmentNumber, Instant shipmentDate, String status,
            String[] palletId) {
        try {
            Map<String, Object> elements = new HashMap<>();
            elements.put(Pallets.SHIPMENT_NUMBER, shipmentNumber);
            elements.put(Pallets.SHIPMENT_DATE, shipmentDate);
            elements.put(Pallets.STATUS, status);

            CqnUpdate update = Update.entity(Pallets_.class).data(elements).where(pID -> pID.PalletID().in(palletId));
            db.run(update);

            return 0;
        } catch (Exception sql) {
            sql.getMessage();
            return 1;

        }
    }

    /**
     * getBoxItems method returns List of BoxItems
     * 
     * @implSpec Fetch details from BoxItems table for all the splitBoxNumber[]
     * @param String[] splitBoxNumber
     * @return List of BoxItems
     * @author steven_lau
     */
    private List<BoxItems> getBoxItems(String[] splitBoxNumber) {
        // build query to get all BoxItems from the BoxItems table
        CqnSelect sel = Select.from(BoxItems_.class).where(bID -> bID.BoxID_BoxID().in(splitBoxNumber));
        List<BoxItems> boxItemsList = db.run(sel).listOf(BoxItems.class);
        boxItemsList.parallelStream().filter(BoxItems::isEmpty)
                .forEach(boxItems -> throwServiceException(boxItems.getBoxIDBoxID()));
        return boxItemsList;
    }

    /**
     * throwServiceException method throws ServiceException
     * 
     * @implSpec Throw ServiceException with customised meesage with BoxItem
     * @param String boxItem
     * @throws ServiceException
     * @author steven_lau
     */
    private Object throwServiceException(String boxItem) {
        throw new ServiceException(ErrorStatuses.NOT_FOUND + "Box ID = " + boxItem + DOES_NOT_EXIST);
    }

    /**
     * getPlantForPallet method returns Plant for the input Pallet
     * 
     * @implSpec Fetch Plant from Pallets table for palletID
     * @param String palletID
     * @return String Plant
     * @author steven_lau
     */
    private String getPlantForPallet(String palletID) {
        CqnSelect sel = Select.from(Pallets_.class).where(pallet -> pallet.PalletID().eq(palletID));
        Pallets pallet = db.run(sel).first(Pallets.class).orElseThrow(
                () -> new ServiceException(ErrorStatuses.NOT_FOUND + " Pallet ID = " + palletID + DOES_NOT_EXIST));

        return pallet.getPlant();

    }

}
