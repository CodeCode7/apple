/*
* AdminConfigService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.util.ArrayList;
import java.util.List;

import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;

import org.springframework.stereotype.Component;

import cds.gen.adminconfigservice.AdminConfigService_;
import cds.gen.adminconfigservice.ConfigValues;
import cds.gen.adminconfigservice.ConfigValues_;
import cds.gen.adminconfigservice.GetNumberRangeTypesContext;
import cds.gen.adminconfigservice.NumberRangeTypes;
import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.adminconfigservice.NumberRanges_;

/**
 * AdminConfigService is a java class used for Admin configurations.
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */

@Component
@ServiceName(AdminConfigService_.CDS_NAME)
public class AdminConfigService extends ACPService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Constant(s)
     * ---------------------------------------------------------------------------
     */
    private static final String ERROR_PLANT_REQUIRED = "Plant is a required field";
    private static final String ERROR_TYPE_REQUIRED = "Type is a required field";
    private static final String ERROR_MAXNUMBER_REQUIRED_GT0 = "Max Number is a required field and should be greater than 0";
    private static final String ERROR_VALUE_REQUIRED = "Value is a required field";
    private static final String ERROR_NAME_REQUIRED = "Name is a required field";

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * AdminConfigService constructor
     */
    AdminConfigService(PersistenceService db) {
        this.db = db;
    }

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * beforeConfigValues - @Before event for validating mandatory fields
     * 
     * @implSpec - For ConfigValues view apply mandatory validations for Name, Value
     *           not null or empty
     * @param ConfigValues configValues
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = { CdsService.EVENT_CREATE, CdsService.EVENT_UPDATE }, entity = ConfigValues_.CDS_NAME)
    public void beforeConfigValues(ConfigValues configValues) {
        validateMandatoryFieldsForConfigValues(configValues);
    }

    /**
     * validateMandatoryFieldsForConfigValues - method for validating mandatory
     * fields
     * 
     * @implSpec - For ConfigValues view apply mandatory validations for Name, Value
     *           not null or empty
     * @param ConfigValues configValues
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void validateMandatoryFieldsForConfigValues(ConfigValues configValues) {
        if (configValues != null) {
            String configName = configValues.getName();
            String configValue = configValues.getValue();
            if (configName == null || configName.isEmpty()) {
                throw new ServiceException(ERROR_NAME_REQUIRED);
            }
            if (configValue == null || configValue.isEmpty()) {
                throw new ServiceException(ERROR_VALUE_REQUIRED);
            }
        }
    }

    /**
     * beforeNumberRanges - @Before event for validating mandatory fields
     * 
     * @implSpec - For NumberRanges view apply mandatory validations for TYPE, PLANT
     *           must not be null or empty string. MaxNumber must be > 0 - Atleast
     *           one of them is entered
     * @param NumberRanges numberRanges
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    @Before(event = { CdsService.EVENT_CREATE, CdsService.EVENT_UPDATE }, entity = NumberRanges_.CDS_NAME)
    public void beforeNumberRanges(NumberRanges numberRanges) {
        validateMandatoryFieldsForNumberRanges(numberRanges);
    }

    /**
     * validateMandatoryFieldsForNumberRanges - method for validating mandatory
     * fields
     * 
     * @implSpec -For NumberRanges view apply mandatory validations for TYPE, PLANT
     *           must not be null or empty string. MaxNumber must be > 0
     * @param NumberRanges numberRanges
     * @return void - ServiceException in case of Validation fail
     * @author mvijetha
     */
    private void validateMandatoryFieldsForNumberRanges(NumberRanges numberRanges) {
        if (numberRanges != null) {
            String numRangePlant = numberRanges.getPlant();
            String numRangeType = numberRanges.getType();
            Integer numRangeMaxNumber = numberRanges.getMaxNumber();
            if (numRangePlant == null || numRangePlant.isEmpty()) {
                throw new ServiceException(ERROR_PLANT_REQUIRED);
            }
            if (numRangeType == null || numRangeType.isEmpty()) {
                throw new ServiceException(ERROR_TYPE_REQUIRED);
            }
            if (numRangeMaxNumber == null || numRangeMaxNumber < 0) {
                throw new ServiceException(ERROR_MAXNUMBER_REQUIRED_GT0);
            }
        }
    }

    /**
     * onGetNumberRangeTypes - onEvent action to fetch list of Number range types
     * 
     * @implSpec - Fetch list NumberRanges types
     * @param GetNumberRangeTypesContext context
     * @return set context result with Number Range Types list
     * @author mvijetha
     */
    @On(event = GetNumberRangeTypesContext.CDS_NAME)
    public synchronized void onGetNumberRangeTypes(GetNumberRangeTypesContext context) {

        List<String> numberRangeTypesList = new ArrayList<>();
        numberRangeTypesList.add(NUMBER_RANGE_TYPE_BOX);
        numberRangeTypesList.add(NUMBER_RANGE_TYPE_PALLET);
        numberRangeTypesList.add(NUMBER_RANGE_TYPE_SSCC);
        List<NumberRangeTypes> numberRangeTypes = generateNumberRangeTypes(numberRangeTypesList);
        context.setResult(numberRangeTypes);
    }

    /**
     * generateNumberRangeTypes - method to generate Number range types List
     * 
     * @implSpec - Fetch list NumberRanges types
     * @param GetNumberRangeTypesContext context
     * @return set context result with Number Range Types list
     * @author mvijetha
     */
    private List<NumberRangeTypes> generateNumberRangeTypes(List<String> numberRangeTypesList) {
        List<NumberRangeTypes> numberRangeTypes = new ArrayList<>();
        for (String numberRangeType : numberRangeTypesList) {
            NumberRangeTypes newNumberRangeTypes = NumberRangeTypes.create();
            newNumberRangeTypes.setType(numberRangeType);
            numberRangeTypes.add(newNumberRangeTypes);
        }
        return numberRangeTypes;
    }
}