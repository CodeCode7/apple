/*
* Application.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;

/**
 * Application is a SpringBoot starter class.
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */
@ComponentScan({"com.sap.cloud.sdk", "com.apple.cap.api.acpackaging.handlers"})
@ServletComponentScan({"com.sap.cloud.sdk", "com.apple.cap.api.acpackaging.handlers"})
@SpringBootApplication
public class Application {
    /**
     * ---------------------------------------------------------------------------
     * Class Method(s)
     * ---------------------------------------------------------------------------
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }
}