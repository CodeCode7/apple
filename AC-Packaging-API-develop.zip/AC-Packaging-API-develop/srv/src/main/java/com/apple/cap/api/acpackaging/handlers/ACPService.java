/*
* ACPService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.util.List;

import com.sap.cds.ql.Select;
import com.sap.cds.ql.Update;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.UserInfo;

import org.springframework.beans.factory.annotation.Autowired;

import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.adminconfigservice.NumberRanges_;

/**
 * ACPService is a java utility class with constants used for Box and Pallet
 * processing
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */
public class ACPService {

    /**
     * ---------------------------------------------------------------------------
     * Constant(s)
     * ---------------------------------------------------------------------------
     */
    protected static final String LABEL_PREFIX = "B";
    protected static final String STATUS_CREATED = "0";
    protected static final String BOX_STATUS_COMPLETED = "1";
    protected static final String BOX_STATUS_ON_PALLET = "2";
    protected static final String PALLET_STATUS_CREATED = "0";
    protected static final String PALLET_STATUS_COMPLETED = "2";
    protected static final String PALLET_SHIPMENT_LINKED = "3";
    protected static final String STATUS_SHIPMENT_PACKED = "3";
    protected static final String SSCC_PREFIX = "0";
    protected static final String SSCC_NAME = "SSCC";
    protected static final String CELLULAR_FLAG = "X";
    protected static final String STRING_FORMAT_YEAR_LENGTH_2 = "yy";

    protected static final String STRING_FORMAT_ZERO_PAD_LENGTH_8 = "%08d";
    protected static final String STRING_FORMAT_ZERO_PAD_LENGTH_9 = "%09d";
    protected static final String STRING_FORMAT_ZERO_PAD_LENGTH_5 = "%05d";
    protected static final String STRING_FORMAT_ZERO_PAD_LENGTH_2 = "%02d";
    protected static final String SERIAL_NUMBER_SEPARATOR = ",";
    protected static final String BOXID_SEPARATOR = ",";
    protected static final String PALLETID_SEPARATOR = ",";
    protected static final String UUID_SEPARATOR = ",";

    protected static final String NUMBER_RANGE_TYPE_BOX = "BOX";
    protected static final String NUMBER_RANGE_TYPE_PALLET = "PALLET";
    protected static final String NUMBER_RANGE_TYPE_SSCC = "SSCC";

    protected static final String USER_ATTRIBUTE_PLANT = "Plant";

    protected static final String INITIAL_PROCESSING_STATUS = "A";
    protected static final String BEGIN_PROCESSING_STATUS = "P";
    protected static final String SUCCESSFULLY_PROCESSED_STATUS = "C";
    protected static final String RESET_PROCESSING_STATUS = "I";
    protected static final String REVERSE_TRANSFER_ORDER_FLAG = "X";

    // Stratos call constants
    protected static final String APP_ID = "AppId";
    // DESTINATION_NAME = "ACSC_STRATOS_APIM"
    protected static final String DESTINATIONNAME = "DESTINATION_NAME";
    protected static final String DESTINATION_NAME = System.getenv().get(DESTINATIONNAME);
    // DEST_URL_POSTFIX = "/v1/acsc/stratos/esp/services/espservice/httpservice"
    protected static final String DESTURLPOSTFIX = "DEST_URL_POSTFIX";
    protected static final String DEST_URL_POSTFIX = System.getenv().get(DESTURLPOSTFIX);
    protected static final String APP_ID_KEY = "appid";
    protected static final String APP_ID_VALUE = System.getenv().get(APP_ID);
    protected static final String SERIAL_NUMBER_DEVICES = "serialNumber";
    protected static final String SERIAL_NUMBER_METADATA = "SerialNumber";
    protected static final String METADATA_LOOKUP = "MetaDataLookup";
    protected static final String APPLICATION_JSON = "application/json";
    protected static final String DEVICES = "Devices";
    protected static final String METADATALOOKUP_APPID = "3408";
    protected static final String METADATALOOKUP_REQUESTTYPE = "01";
    protected static final String DEVICE_ARRAY_TYPE = "deviceArrayType";
    protected static final String IMEI = "imei";
    protected static final String IMEI_CONST = "IMEI";
    protected static final String IMEI1 = "IMEI1";
    protected static final String IMEI2 = "IMEI2";
    protected static final String ESP_RESPONSE_HEADER = "espResponseHeader";
    protected static final String EXCEPTION_MESSAGE = "exceptionMessage";
    protected static final int SERIAL_NUMBER_LENGTH_11 = 11;
    protected static final int SERIAL_NUMBER_LENGTH_12 = 12;
    protected static final int BEGIN_INDEX_8 = 8;
    protected static final int END_INDEX_11 = 11;
    protected static final int END_INDEX_12 = 12;
    protected static final String CONFIG_ID = "configID";
    protected static final String MULTI_PARTS = "multipleParts";
    protected static final String ASIS_PART_NUMBER = "asIsPartNumber";
    protected static final String MULTIPARTS_FLAG = "X";
    protected static final String ASIS_TYPE = "A";
    protected static final String STV_TYPE = "B";
    protected static final String CONFIG_CODE = "ConfigCode";
    protected static final String DOES_NOT_EXIST = " does not exist";
    protected static final String CONFIGID = "ConfigId";
    protected static final String LOGINFO = "LogInfo";
    protected static final String MESSAGETEXT = "MessageText";
    protected static final String ESP_JSON = "ESP_JSON";

    protected static final String BOXID = "BoxID";

    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    @Autowired
    PersistenceService db;

    @Autowired
    UserInfo userInfo;

    /**
     * ACPService constructor
     */
    ACPService() {
    }

    ACPService(PersistenceService db, UserInfo userInfo) {
        this.db = db;
        this.userInfo = userInfo;
    }

    /**
     * incrementNumberRange - method is used to fetch NumberRanges
     * 
     * @implSpec - Based on Plant and Number Range type from NumberRanges and
     *           increment the counter
     * @param String numberRangeType
     * @param String plant
     * @return NumberRanges object
     * @author steven_lau
     */
    protected NumberRanges incrementNumberRange(String numberRangeType, String plant) {

        // build query to find the number range
        CqnSelect sel = Select.from(NumberRanges_.class)
                .where(nr -> nr.Type().eq(numberRangeType).and(nr.Plant().eq(plant)));

        // execute query; throw an exeception if no number range can be found
        NumberRanges numberRange = db.run(sel).first(NumberRanges.class)
                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND,
                        numberRangeType + " Number Range for plant " + plant + DOES_NOT_EXIST));

        int newCurrentNumber = numberRange.getCurrentNumber() + 1;

        numberRange.setCurrentNumber(newCurrentNumber);

        // update the number range with new current number
        CqnUpdate update = Update.entity(NumberRanges_.class).data(numberRange)
                .where(nr -> nr.Type().eq(numberRangeType).and(nr.Plant().eq(plant)));

        db.run(update);

        return numberRange;
    }

    /**
     * hasPlantAccess - method is used to check if user has access to the input
     * Plant
     * 
     * @implSpec - check if user has $unrestricted for Plant attribute. If not check
     *           Plant attribute assignment values for against the input plant.
     * @param String plant
     * @return boolean hasPlantAccess
     * @author steven_lau
     */
    protected boolean hasPlantAccess(String plant) {
        boolean access = false;
        // check if user is assigned $unrestricted for Plant attribute
        boolean hasUnrestrictedPlant = userInfo.isUnrestrictedAttribute(USER_ATTRIBUTE_PLANT);

        if (hasUnrestrictedPlant) {
            return hasUnrestrictedPlant;
        } else {
            // Check if user has access to specific plant if not assigned $unrestricted
            List<String> assignedPlants = userInfo.getAttributeValues(USER_ATTRIBUTE_PLANT);
            if (assignedPlants.contains(plant)) {
                return true;
            }
        }
        return access;
    }
}
