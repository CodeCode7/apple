/*
* BoxService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sap.cds.Result;
import com.sap.cds.ql.Insert;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.Update;
import com.sap.cds.ql.cqn.AnalysisResult;
import com.sap.cds.ql.cqn.CqnAnalyzer;
import com.sap.cds.ql.cqn.CqnDelete;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.reflect.CdsModel;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsDeleteEventContext;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.After;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cloud.sdk.cloudplatform.connectivity.DestinationAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpClientAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpDestination;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.openapitools.client.ApiClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import cds.gen.VBoxitemsWithSerialnumber;
import cds.gen.VBoxitemsWithSerialnumber_;
import cds.gen.ZtaCtrlmat;
import cds.gen.ZtaCtrlmat_;
import cds.gen.adminconfigservice.ConfigValues;
import cds.gen.adminconfigservice.ConfigValues_;
import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.boxservice.BoxItems;
import cds.gen.boxservice.BoxItems_;
import cds.gen.boxservice.BoxService_;
import cds.gen.boxservice.Boxes;
import cds.gen.boxservice.Boxes_;
import cds.gen.boxservice.CheckDuplicateSerialNumbersContext;
import cds.gen.boxservice.SerialNumberDetailsContext;
import cds.gen.boxservice.SerialNumberResponseType;
import cds.gen.boxservice.SerialNumberValidationResultType;
import cds.gen.boxservice.ValidateSerialNumbersContext;
import cds.gen.transferorderservice.PartWashTransferOrder;
import cds.gen.transferorderservice.PartWashTransferOrder_;
import devices.Body;
import devices.EspRequestPayload;
import devices.EspServiceRequest;
import devices.Header;
import devices.QueryDeviceRequest__1;
import metadatalookup.Input;
import metadatalookup.RequestDetails__1;
import metadatalookup.RequestInput;
import metadatalookup.SerialNumbers;
import metadatalookup.Sndetails;

/**
 * BoxService is a java class used for Box creation/modification process.
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */
@Component
@ServiceName(BoxService_.CDS_NAME)
public class BoxService extends ACPService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Constant(s)
     * ---------------------------------------------------------------------------
     */
    private static final String LABEL_PREFIX = "B";

    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    private PartWashTransferOrder partWashTransferOrderRequest;

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    BoxService() {
    }

    BoxService(PersistenceService db, PartWashTransferOrder partWashTransferOrderRequest) {
        this.db = db;
        this.partWashTransferOrderRequest = partWashTransferOrderRequest;
    }

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * onBeforeCreateBox - @Before event meant for creating newBoxId for newBox
     * 
     * @implSpec newBoxId will be generated for the below combination:
     *           LABEL_PREFIX,Box.Plant,Box.StrorageLocation,Today's date, Sequence
     *           generator
     * @param Boxes object
     * @return void - set NewBoxId to Box object
     * @author steven_lau
     */
    @Before(event = CdsService.EVENT_CREATE, entity = Boxes_.CDS_NAME)
    public void onBeforeCreateBox(Boxes box) {
        // validate user has access to Plant requested
        if (!hasPlantAccess(box.getPlant())) {
            throw new ServiceException("No Authorization for Plant: " + box.getPlant());
        }

        LocalDate today = LocalDate.now();

        NumberRanges boxNumberRange = incrementNumberRange(NUMBER_RANGE_TYPE_BOX, box.getPlant());
        int nextNumber = boxNumberRange.getCurrentNumber();
        String nextNumberString = String.format(STRING_FORMAT_ZERO_PAD_LENGTH_5, nextNumber);

        StringBuilder newBoxID = new StringBuilder(LABEL_PREFIX).append(box.getPlant()).append(box.getStorageLocation())
                .append(today.format(DateTimeFormatter.ofPattern(STRING_FORMAT_YEAR_LENGTH_2)))
                .append(String.format(STRING_FORMAT_ZERO_PAD_LENGTH_2, today.getDayOfMonth()))
                .append(String.format(STRING_FORMAT_ZERO_PAD_LENGTH_2, today.getMonthValue())).append(nextNumberString);

        box.setBoxID(newBoxID.toString());
        box.setStatus(STATUS_CREATED);

    }

    /**
     * onBeforeUpdateBox - @Before event meant for validating Plant access during
     * box update.
     * 
     * @implSpec validate the plant requested is valid plant for the user.
     * 
     * @param Boxes object
     * @return void
     * @author steven_lau
     */
    @Before(event = { CdsService.EVENT_UPDATE, CdsService.EVENT_UPSERT }, entity = Boxes_.CDS_NAME)
    public void onBeforeUpdateBox(Boxes box) {
        // validate user has access to Plant requested
        if (!hasPlantAccess(box.getPlant())) {
            throw new ServiceException("No Authorization for Plant: " + box.getPlant());
        }
        if ((box.getType() == null || (box.getType() != null && box.getType().equals(ASIS_TYPE)))) {
            // when box is compelted need to evaluate if Transfer order is needed.
            buildPartWashTransferOrderRequest(box);
        }
    }

    /**
     * onAfterUpdateBox - @After update event on T_BOXES table
     * 
     * @implSpec - Update T_BOXES table with below values: STATUS = 2 QUANTITY =
     *           Boxes size SSCC18 - Value to be generated only if SSCC18 is null,
     *           else ignore
     * @param - Boxes box
     * @return - void
     * @author steven_lau
     */
    @After(event = CdsService.EVENT_UPDATE, entity = Boxes_.CDS_NAME)
    public void onAfterUpdateBox(Boxes box) {
        String newSSCC18 = "";

        int boxQuantity = box.getToBoxItems().size();
        Map<String, Object> elements = new HashMap<>();
        elements.put(Boxes.QUANTITY, boxQuantity);
        elements.put(Boxes.STATUS, BOX_STATUS_COMPLETED);

        // Fetch the Box details for boxID from DB
        Boxes boxHeader = getBoxIDDetails(box.getBoxID());

        if ((boxHeader.getSscc18() == null) && (boxHeader.getType() == null
                || (boxHeader.getType() != null && boxHeader.getType().equals(ASIS_TYPE)))) {
            NumberRanges iSSCC18NumberRange = incrementNumberRange(NUMBER_RANGE_TYPE_SSCC, box.getPlant());
            int nextNumber = iSSCC18NumberRange.getCurrentNumber();

            String nextNumberString = String.format(STRING_FORMAT_ZERO_PAD_LENGTH_9, nextNumber);

            ConfigValues ssccValue = this.getSSCCValue(SSCC_NAME);
            String numsForLastDigit = SSCC_PREFIX + ssccValue.getValue() + nextNumberString;
            int lastdigit = this.lastDigitCalculation(numsForLastDigit);
            newSSCC18 = SSCC_PREFIX + ssccValue.getValue() + nextNumberString + lastdigit;
            elements.put(Boxes.SSCC18, newSSCC18);
        }

        db.run(Update.entity(Boxes_.class).data(elements).where(bID -> bID.BoxID().eq(box.getBoxID())));

        // check if transfer order needed
        if (partWashTransferOrderRequest != null && partWashTransferOrderRequest.getBoxQuantity() > 0
        // && box.getType().equals(ASIS_TYPE)
        ) {
            // for some boxes item level details AS IS PN and FG PN may not exist and
            // current save attempt data needed to be used.
            insertPartWashTransferOrderRequest(partWashTransferOrderRequest);
        }
    }

    /**
     * onBeforeDeleteBox - @Before Delete event is meant for building PWTO object
     * for ASIS type.
     * 
     * @implSpec - onBeforeDeleteBox method is used to build the PartWash
     *           TransferOrder details request with Box Items before deleting the
     *           ASIS type entity
     * 
     * @param CdsDeleteEventContext context
     * @return void
     * @author mvijetha
     */
    @Before(event = { CdsService.EVENT_DELETE }, entity = Boxes_.CDS_NAME)
    public void onBeforeDeleteBox(CdsDeleteEventContext context) {
        // Fetch BoxID value from Delete context
        // Get Modal from CdsDeleteEvent Context
        CdsModel cdsModel = context.getModel();

        // CqnAnalyzer allows to analyze CDS QL statements and extract values and
        // information on the CDS entities
        CqnAnalyzer cqnAnalyzer = CqnAnalyzer.create(cdsModel);

        // Fetch the delete query from CdsDeleteEvent Context
        CqnDelete delete = context.getCqn();

        // The corresponding CQN statement is analyzed using the analyze method of the
        // CqnAnalyzer
        AnalysisResult result = cqnAnalyzer.analyze(delete.ref());

        // Based on the AnalysisResult values are extracted
        Map<String, Object> filterValues = result.targetValues();

        // Fetch the value of BoxID
        String boxID = (String) filterValues.get(BOXID);

        // Fetch the Box details for boxID from DB as the Delete context doesn't contain
        // all the required fields for building PWTO request object
        Boxes box = getBoxIDDetails(boxID);

        // Building PWTO request object is required only for ASIS type
        if ((box.getType() == null || (box.getType() != null && box.getType().equals(ASIS_TYPE)))
                && !box.getStatus().equals(STATUS_CREATED)) {
            // Prepare PWTO before BOX delete
            buildPartWashTransferOrderRequest(box);
        }
    }

    /*
     * getBoxIDDetails - Method to fetch Boxes details for a boxID
     * 
     * @implSpec - To fetch Box Details from T_BOXES table for boxID
     * 
     * @param String boxID
     * 
     * @return Boxes
     * 
     * @author mvijetha
     */
    private Boxes getBoxIDDetails(String boxID) {
        // query to get Box Details from T_BOXES table
        CqnSelect sel = Select.from(Boxes_.class).where(bID -> bID.BoxID().eq(boxID));
        return db.run(sel).first(Boxes.class)
                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND + "BoxID: " + boxID + DOES_NOT_EXIST));
    }

    /**
     * onAfterDeleteBox - @After DELETE event - To insert PWTO details for the
     * deleted entity
     * 
     * @implSpec - Insert PWTO details into Partwash table present in session object
     *           partWashTransferOrderRequest
     * @param - CdsDeleteEventContext context
     * @return - void
     * @author mvijetha
     */
    @After(event = CdsService.EVENT_DELETE, entity = Boxes_.CDS_NAME)
    public void onAfterDeleteBox(CdsDeleteEventContext context) {
        // check if transfer order needed
        if (partWashTransferOrderRequest != null
        // && box.getType().equals(ASIS_TYPE)
        ) {
            insertPartWashTransferOrderRequest(partWashTransferOrderRequest);
        }
    }

    /**
     * fillItemLevelDetails - method is used to set BoxItem details to the PWTO
     * request
     * 
     * @implSpec - While setting PWTO request, check for item level details on
     *           previously saved box items, this will ensure we have item details
     *           in a case where all serial numbers are removed from a box. If
     *           boxItems for the boxId is present, then set AsIsPartNumber and
     *           FGPartNumber Else set AsIsPartNumber and FGPartNumber from the pwto
     *           request param
     * @param - PartWashTransferOrder pwto
     * @param - Boxes box
     * @return - void
     * @author steven_lau
     */
    private void fillItemLevelDetails(PartWashTransferOrder pwto, Boxes box) {
        BoxItems boxItems = getBoxItems(box.getBoxID());
        if (boxItems != null && !boxItems.isEmpty()) {
            partWashTransferOrderRequest.setAsIsPartNumber(boxItems.getAsIsPartNumber());
            partWashTransferOrderRequest.setFGPartNumber(boxItems.getFinishedGoodsMPN());
        } else {
            pwto.setAsIsPartNumber(box.getToBoxItems().get(0).getAsIsPartNumber());
            pwto.setFGPartNumber(box.getToBoxItems().get(0).getFinishedGoodsMPN());
        }
    }

    /**
     * onCallValidateSerialNumbers - Function to check duplicate serial numbers and
     * to fetch ConfigID, MultipleParts and AsIsPartNumber from ZTA_CTRLMAT table
     * for ConfigID
     * 
     * @implSpec - Check for duplicates with the list and also within DB for a BoxID
     *           and Get SerialNumberValidationResult by invoking the
     *           validateSerialNumbers call by passing BoxID and SerialNumbers
     * @param ValidateSerialNumbersContext context
     * @return void - set configID, MultipleParts and AsIsPartNumber to context
     *         result
     * @author mvijetha
     * @throws IOException
     * @throws URISyntaxException
     */
    @On(event = ValidateSerialNumbersContext.CDS_NAME)
    public void onCallValidateSerialNumbers(ValidateSerialNumbersContext context)
            throws URISyntaxException, IOException {

        String boxID = context.getBoxID();
        String[] splitSerialNumber = context.getSerialNumbers().split(SERIAL_NUMBER_SEPARATOR);

        checkDuplicateSerialNumbers(splitSerialNumber, boxID);

        Map<String, String> snlValidationResult = validateSerialNumbers(splitSerialNumber);

        SerialNumberValidationResultType sNumberValidationResult = SerialNumberValidationResultType.create();

        sNumberValidationResult.setConfigID(snlValidationResult.get(CONFIG_ID));
        sNumberValidationResult.setMultipleParts(snlValidationResult.get(MULTI_PARTS));
        sNumberValidationResult.setAsIsPartNumber(snlValidationResult.get(ASIS_PART_NUMBER));

        context.setResult(sNumberValidationResult);
    }

    /**
     * validateSerialNumbers - Function to get ConfigID, MultipleParts and
     * AsIsPartNumber
     * 
     * @implSpec - Fetch ConfigID, MultipleParts and AsIsPartNumber by passing BoxID
     *           and SerialNumbers Step 1 - Fetch config Ids for the serial Numbers
     *           Step 2 - Fetch AsIs Partnumber/s and Multipart value for the
     *           configID
     * @param String[] serialNumbers
     * @return void - set configID, MultipleParts and AsIsPartNumber to context
     *         result
     * @author mvijetha
     * @throws IOException
     * @throws URISyntaxException
     */
    private Map<String, String> validateSerialNumbers(String[] serialNumbers) throws URISyntaxException, IOException {
        Map<String, String> serialNumValidationResultMap = new HashMap<>();

        String configID = fetchConfigCodeForSerialNumbers(serialNumbers);
        Map<String, String> fetchAsIsPartNumberForConfigIDMap = fetchAsIsPartNumberForConfigID(configID);

        serialNumValidationResultMap.put(CONFIG_ID, configID);
        serialNumValidationResultMap.put(ASIS_PART_NUMBER, fetchAsIsPartNumberForConfigIDMap.get(ASIS_PART_NUMBER));
        serialNumValidationResultMap.put(MULTI_PARTS, fetchAsIsPartNumberForConfigIDMap.get(MULTI_PARTS));
        return serialNumValidationResultMap;
    }

    /**
     * fetchAsIsPartNumberForConfigID - Function to get MultipleParts and
     * AsIsPartNumber Step 1 : Query ZTA_CTRLMAT by passing configID to fetch
     * AsIsPartNumber, FG and ConfigID Step 2 : If the result contains more than 1
     * AsIsPartNumber then set MULTI_PARTS to 'X' Step 3 : If the result contains
     * more than 1 AsIsPartNumber, then concatenate multiple AsIsPartNumbers with
     * comma(,) and return as a String
     * 
     * @implSpec - Fetch MultipleParts and AsIsPartNumber by passing configID
     * 
     * @param String configID
     * @return Map<String, String> asIsPartNumberForConfigIDMap
     * @author mvijetha
     */
    private Map<String, String> fetchAsIsPartNumberForConfigID(String configID) {
        Map<String, String> asIsPartNumberForConfigIDMap = new HashMap<>();

        List<ZtaCtrlmat> asIsPartNumbersForConfigIDList = getAsIsPartNumbersForConfigID(configID);

        if (asIsPartNumbersForConfigIDList == null || asIsPartNumbersForConfigIDList.isEmpty()) {
            throwServiceException(configID);
        }

        if (asIsPartNumbersForConfigIDList.size() > 1) {
            asIsPartNumberForConfigIDMap.put(MULTI_PARTS, MULTIPARTS_FLAG);
        } else {
            asIsPartNumberForConfigIDMap.put(MULTI_PARTS, " ");
        }

        String asIsPartNumberStr = "";
        List<String> asIsPartNumberList = asIsPartNumbersForConfigIDList.stream().map(ZtaCtrlmat::getZmatnrAsIs)
                .collect(Collectors.toList());
        asIsPartNumberStr = StringUtils.join(asIsPartNumberList, ',');

        asIsPartNumberForConfigIDMap.put(ASIS_PART_NUMBER, asIsPartNumberStr);

        return asIsPartNumberForConfigIDMap;
    }

    /**
     * getAsIsPartNumbersForConfigID returns List of ZtaCtrlmat containing
     * ASISPartNumber, FG and ConfigIDs
     * 
     * @implSpec Fetch ASISPartNumber, FG and ConfigID from ZTA_CTRLMAT table for
     *           ConfigID
     * @param String configID
     * @return List of ZtaCtrlmat
     * @author mvijetha
     */
    public List<ZtaCtrlmat> getAsIsPartNumbersForConfigID(String configID) {
        // build query to get ZtaCtrlmat details from ZTA_CTRLMAT table
        CqnSelect sel = Select.from(ZtaCtrlmat_.class)
                .columns(ZtaCtrlmat.ZMATNR_AS_IS, ZtaCtrlmat.ZMATNR_FG, ZtaCtrlmat.ZEEE)
                .where(view -> view.ZEEE().eq(configID));
        return db.run(sel).listOf(ZtaCtrlmat.class);
    }

    /**
     * throwServiceException method throws ServiceException
     * 
     * @implSpec Throw ServiceException with customised message
     * @param String configID
     * @throws ServiceException
     * @author mvijetha
     */
    private Object throwServiceException(String configID) {
        throw new ServiceException("ConfigID: " + configID + " doesn't exist in ZTA_CTRLMAT table");
    }

    /**
     * fetchConfigCodeForSerialNumbers - Function to get ConfigID
     * 
     * @implSpec - Fetch ConfigID by passing serialNumbers Step 1: Count the no of
     *           digits of the Serial Number Step 2: If the no of digits of the
     *           Serial no is 11, the last 3 digits will be the Config ID. Step 3:
     *           If the no of digits of the Serial no is 12, the last 4 digits will
     *           be the Config ID. Step 4: If the No of digits of the Serial number
     *           is neither 11 nor 12, pass the Serial number into Metadata System
     *           and get back the Config ID.
     * @exception - Throw ServiceException if each of the configCodes retrived
     *              doesn't match with the firstConfigCode Exception message -
     *              "serial numbers have mismatched config code" Eg : 1 of 2 serial
     *              numbers have mismatched config code
     * @param String[] serialNumbers
     * @return firstConfigCode
     * @author mvijetha
     * @throws IOException
     * @throws URISyntaxException
     */
    private String fetchConfigCodeForSerialNumbers(String[] serialNumbers) throws URISyntaxException, IOException {
        int serialNumberLength = 0;
        String configCode = "";
        String firstConfigCode = "";
        int configCodeMisMatch = 0;
        List<String> serialNumberList = Arrays.asList(serialNumbers);
        Map<String, Map<String, String>> queryDeviceResponseMap = null;
        for (String serialNumber : serialNumbers) {
            serialNumberLength = serialNumber.length();
            if (serialNumberLength == SERIAL_NUMBER_LENGTH_11) {
                configCode = serialNumber.substring(BEGIN_INDEX_8, END_INDEX_11);
            } else if (serialNumberLength == SERIAL_NUMBER_LENGTH_12) {
                configCode = serialNumber.substring(BEGIN_INDEX_8, END_INDEX_12);
            } else {
                queryDeviceResponseMap = invokeStratosCall(METADATA_LOOKUP, serialNumberList);
                configCode = queryDeviceResponseMap.get(serialNumber).get(CONFIG_CODE);
            }
            if (firstConfigCode.isEmpty()) {
                firstConfigCode = configCode;
            }
            if (!firstConfigCode.equals(configCode)) {
                configCodeMisMatch++;
            }
        }
        if (configCodeMisMatch > 0) {
            throw new ServiceException(
                    configCodeMisMatch + " of " + serialNumbers.length + " serial numbers have mismatched config code");
        }
        return firstConfigCode;
    }

    /**
     * onCallSerialNumberDetails - Function to get the values of
     * SerialNumberResponse
     * 
     * @implSpec - Set SerialNumberResponse by invoking the getSerialNumberDetails
     *           call by passing SerialNumberString, sequencePositions, boxID,
     *           configID, asIsPartNumber. Also set IMEI details by invoking Stratos
     *           call for Devices by passing serialNumber
     * @param SerialNumberDetailsContext context
     * @return void - set SerialNumberResponse to context result
     * @author mvijetha
     * @throws IOException
     * @throws URISyntaxException
     */
    @On(event = SerialNumberDetailsContext.CDS_NAME)
    public void onCallSerialNumberDetails(SerialNumberDetailsContext context) throws URISyntaxException, IOException {
        String boxID = context.getBoxID();
        String serialNumbersStr = context.getSerialNumbers();
        String[] serialNumbers = serialNumbersStr.split(SERIAL_NUMBER_SEPARATOR);
        String configID = context.getConfigID();
        String asIsPartNumber = context.getAsIsPartNumber();
        String cellular = "";

        // Fetch TYPE for BoxID
        String type = fetchTypeForBoxID(boxID);

        List<ZtaCtrlmat> ctrlmatDataForAsisPnList = new ArrayList<>();

        if (type == null || type.equals(ASIS_TYPE)) {
            // Call Validate serial numbers
            ValidateSerialNumbersContext validateSerialNumbersContext = ValidateSerialNumbersContext.create();
            validateSerialNumbersContext.setBoxID(boxID);
            validateSerialNumbersContext.setSerialNumbers(serialNumbersStr);
            onCallValidateSerialNumbers(validateSerialNumbersContext);

            ctrlmatDataForAsisPnList = getCtrlmatDataForAsisPn(configID, asIsPartNumber);

            for (ZtaCtrlmat ctrlmatDataForAsisPn : ctrlmatDataForAsisPnList) {
                cellular = ctrlmatDataForAsisPn.getZcell();
            }
        }

        List<String> serialNumberList = Arrays.asList(serialNumbers);
        Map<String, Map<String, String>> queryDeviceResponseMap = new HashMap<>();

        // Implementing Stratos call
        if (!serialNumberList.isEmpty() && (type != null && type.equals(STV_TYPE)
                || (type == null && cellular != null && !cellular.isEmpty()))) {
            queryDeviceResponseMap = invokeStratosCall(DEVICES, serialNumberList);
        }

        List<SerialNumberResponseType> serialNumberResponseList = setSerialNumberReponseList(context,
                queryDeviceResponseMap, ctrlmatDataForAsisPnList);
        context.setResult(serialNumberResponseList);
    }

    /**
     * setSerialNumberReponseList - Function to set the values of
     * SerialNumberResponse
     * 
     * @implSpec - Set SerialNumberResponse with the responses from Stratos call and
     *           validateSerialNumber call
     * @param SerialNumberDetailsContext context
     * @param Map<String,                Map<String, String>> queryDeviceResponseMap
     * @param List<ZtaCtrlmat>           ctrlmatDataForAsisPnList
     * @author mvijetha
     */
    private List<SerialNumberResponseType> setSerialNumberReponseList(SerialNumberDetailsContext context,
            Map<String, Map<String, String>> queryDeviceResponseMap, List<ZtaCtrlmat> ctrlmatDataForAsisPnList) {
        String boxID = context.getBoxID();
        String serialNumbersStr = context.getSerialNumbers();
        String[] serialNumbers = serialNumbersStr.split(SERIAL_NUMBER_SEPARATOR);
        String[] sequencePositions = context.getSequencePositions().split(SERIAL_NUMBER_SEPARATOR);
        String configID = context.getConfigID();
        String asIsPartNumber = context.getAsIsPartNumber();
        String[] asIsPartNumberArr = asIsPartNumber.split(SERIAL_NUMBER_SEPARATOR);
        String finishedGoodsMPN = context.getFinishedGoodsMPN();
        String[] finishedGoodsMPNArr = finishedGoodsMPN != null ? finishedGoodsMPN.split(SERIAL_NUMBER_SEPARATOR)
                : null;
        String cellular = "";
        String ean11 = "";
        String modelNumber = "";
        String countryOfOrigin = "";

        for (ZtaCtrlmat ctrlmatDataForAsisPn : ctrlmatDataForAsisPnList) {
            finishedGoodsMPN = ctrlmatDataForAsisPn.getZmatnrFg();
            ean11 = ctrlmatDataForAsisPn.getEan11();
            modelNumber = ctrlmatDataForAsisPn.getZmodel();
            cellular = ctrlmatDataForAsisPn.getZcell();
            countryOfOrigin = ctrlmatDataForAsisPn.getHerkl();
        }

        List<SerialNumberResponseType> serialNumberResponseList = new ArrayList<>();
        int index = 0;
        Map<String, String> imeiMap = null;
        for (String serialNumber : serialNumbers) {
            SerialNumberResponseType serialNumberResponseType = SerialNumberResponseType.create();
            serialNumberResponseType.setBoxIDBoxID(boxID);
            serialNumberResponseType.setBoxSequence(sequencePositions[index]);
            serialNumberResponseType.setSerialNumber(serialNumber);
            imeiMap = queryDeviceResponseMap.get(serialNumber);
            // For STV type, IMEI1 is mandatory and IMEI2 is optional for few Devices
            serialNumberResponseType
                    .setImei1((imeiMap != null && imeiMap.get(IMEI1) != null) ? imeiMap.get(IMEI1) : "");
            serialNumberResponseType
                    .setImei2((imeiMap != null && imeiMap.get(IMEI2) != null) ? imeiMap.get(IMEI2) : "");
            // For STV type, asIsPartNumber would be different for every serialNumber,
            // For ASIS type, asIsPartNumber is same for all the serialNumbers
            serialNumberResponseType.setAsIsPartNumber(
                    (asIsPartNumberArr != null && asIsPartNumberArr.length > 1) ? asIsPartNumberArr[index]
                            : asIsPartNumber);
            serialNumberResponseType.setFinishedGoodsMPN(
                    (finishedGoodsMPNArr != null && finishedGoodsMPNArr.length > 1) ? finishedGoodsMPNArr[index]
                            : finishedGoodsMPN);
            serialNumberResponseType.setConfigID(configID);
            serialNumberResponseType.setEan11(ean11);
            serialNumberResponseType.setModelNumber(modelNumber);
            serialNumberResponseType.setCellular(cellular);
            serialNumberResponseType.setCountryOfOrigin(countryOfOrigin);
            serialNumberResponseList.add(serialNumberResponseType);
            index++;
        }
        return serialNumberResponseList;
    }

    /**
     * fetchTypeForBoxID returns Type for boxID
     * 
     * @implSpec Fetch Type of boxID from T_BOXES table
     * @param String boxID
     * @return Boxes Type
     * @author mvijetha
     */
    private String fetchTypeForBoxID(String boxID) {
        // query to get TYPE from T_BOXES table
        CqnSelect sel = Select.from(Boxes_.class).columns(Boxes.TYPE).where(bID -> bID.BoxID().eq(boxID));
        Boxes box = db.run(sel).first(Boxes.class)
                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND + "BoxID: " + boxID + DOES_NOT_EXIST));

        return box.getType();
    }

    /**
     * getCtrlmatDataForAsisPn returns List of ZtaCtrlmat containing ASISPartNumber,
     * FG and ConfigIDs
     * 
     * @implSpec Fetch ASISPartNumber, FG and ConfigID from ZTA_CTRLMAT table for
     *           ConfigID
     * @param String asIsPartNumber
     * @return List of ZtaCtrlmat
     * @author mvijetha
     */
    public List<ZtaCtrlmat> getCtrlmatDataForAsisPn(String configID, String asIsPartNumber) {
        // build query to get ZtaCtrlmat details from ZTA_CTRLMAT table
        CqnSelect sel = Select.from(ZtaCtrlmat_.class)
                .columns(ZtaCtrlmat.ZMATNR_AS_IS, ZtaCtrlmat.ZEEE, ZtaCtrlmat.ZMATNR_FG, ZtaCtrlmat.EAN11,
                        ZtaCtrlmat.ZMODEL, ZtaCtrlmat.ZCELL, ZtaCtrlmat.HERKL)
                .where(view -> view.ZMATNR_AS_IS().eq(asIsPartNumber));
        List<ZtaCtrlmat> ztaCtrlmatList = db.run(sel).listOf(ZtaCtrlmat.class);
        ztaCtrlmatList.parallelStream().filter(ZtaCtrlmat::isEmpty)
                .forEach(ztaCtrlmat -> throwServiceException(configID));
        return ztaCtrlmatList;
    }

    /**
     * onCheckDuplicateSerialNumbers - Function to check duplicate Serial numbers
     * for a boxID
     * 
     * @implSpec - Check for duplicates with the list and also within DB for a BoxID
     * @param - CheckDuplicateSerialNumbersContext context
     * @return - Set context result = 0, if no duplicates found. Else throw Service
     *         Exception with error message
     * @author steven_lau
     * @throws ServiceException
     */
    @On(event = CheckDuplicateSerialNumbersContext.CDS_NAME)
    public void onCheckDuplicateSerialNumbers(CheckDuplicateSerialNumbersContext context) throws ServiceException {
        String[] splitSerialNumber = context.getSerialNumbers().split(SERIAL_NUMBER_SEPARATOR);
        String boxID = context.getBoxID();

        checkDuplicateSerialNumbers(splitSerialNumber, boxID);

        context.setResult(0);
    }

    /**
     * checkDuplicateSerialNumbers - Function to check duplicate Serial numbers for
     * a boxID
     * 
     * @implSpec - Check for duplicates with the list and also within DB for a BoxID
     * @param -      String[] splitSerialNumber
     * @param String boxID
     * @return - In case if the validation fails throw Service Exception with error
     *         message
     * @author mvijetha
     * @throws ServiceException
     */
    private void checkDuplicateSerialNumbers(String[] splitSerialNumber, String boxID) {
        List<VBoxitemsWithSerialnumber> boxItems = null;

        // check duplicates within the list of SerialNumbers
        List<String> serialNumberList = Arrays.asList(splitSerialNumber);
        Set<String> serialNumberDuplicateSet = serialNumberList.stream()
                .filter(sn -> Collections.frequency(serialNumberList, sn) > 1).collect(Collectors.toSet());

        if (!serialNumberDuplicateSet.isEmpty()) {
            throw new ServiceException(
                    "Duplicate Serial number(s):" + serialNumberDuplicateSet.toString() + " exists!!");
        }

        // check the DB for duplicates
        boxItems = getExistingSerialNumbers(boxID, splitSerialNumber);

        if (!boxItems.isEmpty()) {
            StringBuilder duplicateSerialNumbers = new StringBuilder();
            String currentSeparator = "";
            String separator = ", ";

            // To add existing serial numbers to the String Arraylist
            for (VBoxitemsWithSerialnumber boxItem : boxItems) {
                duplicateSerialNumbers.append(currentSeparator);
                duplicateSerialNumbers.append(boxItem.getSerialnumber());
                duplicateSerialNumbers.append(":");
                duplicateSerialNumbers.append(boxItem.getBoxid());
                currentSeparator = separator;
            }

            throw new ServiceException(
                    "Serial number(s):" + duplicateSerialNumbers.toString() + " exists in other Boxes");
        }
    }

    /**
     * invokeStratosCall - method for Stratos call
     * 
     * @implSpec - Calling Stratos service for each serialNumber/s
     * 
     * @param List<String> serialNumberList
     * @return Map<String, ResponseEntity<String>> responseMap
     * @author mvijetha
     * @throws URISyntaxException
     * @throws IOException
     */
    private Map<String, Map<String, String>> invokeStratosCall(String eventName, List<String> serialNumberList)
            throws URISyntaxException, IOException {
        String jsonString = "";
        String serialNumberParam = "";
        JsonNode payload = null;
        ResponseEntity<String> response = null;

        ApiClient apiClient = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonObj = null;
        Map<String, Map<String, String>> convertMapToReponseMap = new HashMap<>();

        if (eventName.equals(DEVICES)) {
            jsonString = generateJsonRequestForDevices("");
            serialNumberParam = SERIAL_NUMBER_DEVICES;
        } else {
            jsonString = generateJsonRequestForMetaDataLookup("");
            serialNumberParam = SERIAL_NUMBER_METADATA;
        }

        for (String serialNumber : serialNumberList) {
            apiClient = createAPIClient(eventName);
            // Set the serialNumber in request payload
            payload = setSerialNumberInPayload(jsonString, serialNumber, serialNumberParam);
            response = queryDeviceWithHttpInfoBatch(payload, apiClient);
            jsonObj = objectMapper.readTree(response.getBody());
            Map<String, String> payLoadMap = new HashMap<>();
            if (eventName.equals(DEVICES)) {
                payLoadMap = setPayLoadMapForDevices(jsonObj);
            } else if (eventName.equals(METADATA_LOOKUP)) {
                payLoadMap = setPayLoadMapForMetaDataLookup(jsonObj);
            }
            convertMapToReponseMap.put(serialNumber, payLoadMap);
        }
        return convertMapToReponseMap;
    }

    /**
     * setPayLoadMapForDevices - method for setting IMEI1 and IMEI2 values from the
     * Devices Stratos response object
     * 
     * @implSpec - From Devices JsonNode stratos reponse object fetch IMEI1 and
     *           IMEI2 values and set it in payloadMap, If there are any exceptions
     *           then throw ServiceException
     * 
     * @param JsonNode jsonObj
     * @return Map<String, ResponseEntity<String>> responseMap
     * @author mvijetha
     * @throws ServiceException
     */
    private Map<String, String> setPayLoadMapForDevices(JsonNode jsonObj) {
        Map<String, String> payLoadMap = new HashMap<>();
        JsonNode deviceArrayType = null;
        deviceArrayType = jsonObj.findParent(DEVICE_ARRAY_TYPE);
        if (deviceArrayType != null) {
            List<String> imeList = deviceArrayType.findValuesAsText(IMEI);
            for (int index = 0; index < imeList.size(); index++) {
                payLoadMap.put(IMEI_CONST + (index + 1), imeList.get(index));
            }
        } else {
            JsonNode espResponseHeader = jsonObj.findParent(ESP_RESPONSE_HEADER);
            List<String> exceptionMessage = espResponseHeader.findValuesAsText(EXCEPTION_MESSAGE);
            payLoadMap.put(EXCEPTION_MESSAGE, exceptionMessage.get(0));
            throw new ServiceException(exceptionMessage.get(0));
        }
        return payLoadMap;
    }

    /**
     * setPayLoadMapForMetaDataLookup - method for setting configId values from the
     * MetaDataLookup Stratos response object
     * 
     * @implSpec - From MetaDataLookup JsonNode stratos reponse object fetch
     *           configId values and set it in payloadMap, If there are any
     *           exceptions then throw ServiceException
     * 
     * @param JsonNode jsonObj
     * @return Map<String, ResponseEntity<String>> responseMap
     * @author mvijetha
     * @throws ServiceException
     */
    private Map<String, String> setPayLoadMapForMetaDataLookup(JsonNode jsonObj) {
        Map<String, String> payLoadMap = new HashMap<>();
        JsonNode deviceArrayType = null;
        deviceArrayType = jsonObj.findParent(DEVICE_ARRAY_TYPE);
        if (deviceArrayType != null) {
            /* TO-DO - determine the config Id */
        } else {
            JsonNode espResponsePayload = jsonObj.findParent(LOGINFO);
            List<String> exceptionMessage = espResponsePayload.findValuesAsText(MESSAGETEXT);
            payLoadMap.put(EXCEPTION_MESSAGE, exceptionMessage.get(0));
            throw new ServiceException(exceptionMessage.get(0));
        }
        return payLoadMap;
    }

    /**
     * setSerialNumberInPayload - method to set serialNumber in payload
     * 
     * @implSpec - Fetch Stratos response details by passing the input payload using
     *           invokeAPI
     * 
     * @param String jsonString
     * @param String serialNumber
     * @param String serialNumber
     * @return JsonNode
     * @author mvijetha
     * @throws JsonProcessingException
     */
    private JsonNode setSerialNumberInPayload(String jsonString, String serialNumber, String serialNumberParam)
            throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode payload = mapper.readTree(jsonString);
        // Set the serialNumber in request payload
        List<JsonNode> parentNodes = payload.findParents(serialNumberParam);
        if (parentNodes != null) {
            for (JsonNode parentNode : parentNodes) {
                ((ObjectNode) parentNode).replace(serialNumberParam, mapper.valueToTree(serialNumber));
            }
        }
        return payload;
    }

    /**
     * queryDeviceWithHttpInfoBatch - method to fetch Stratos response for the input
     * payload
     * 
     * @implSpec - Fetch Stratos response details by passing the input payload using
     *           invokeAPI
     * @param JsonNode  requestPayload
     * @param eventName
     * @param ApiClient apiClientParam
     * @return ResponseEntity<String>
     * @author mvijetha
     * @throws RestClientException
     */
    public ResponseEntity<String> queryDeviceWithHttpInfoBatch(JsonNode requestPayload, ApiClient apiClientParam)
            throws RestClientException {
        // Set apiClient
        ApiClient apiClient = apiClientParam;
        Object postBody = requestPayload;

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<>();

        final String[] localVarAccepts = { APPLICATION_JSON };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] contentTypes = { APPLICATION_JSON };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {};

        ParameterizedTypeReference<String> returnType = new ParameterizedTypeReference<String>() {
        };
        return apiClient.invokeAPI("/queryDevice", HttpMethod.POST, Collections.<String, Object>emptyMap(), queryParams,
                postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, authNames,
                returnType);
    }

    /**
     * createAPIClient - method to generate ApiClient
     * 
     * @implSpec - Generate apiClient by passing restTemplate and setting request
     *           headers and base path using detinations details
     * @return ApiClient
     * @author mvijetha
     * @throws URISyntaxException
     */
    private ApiClient createAPIClient(String eventName) throws URISyntaxException {
        final HttpDestination destination = DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();
        // instantiate RestTemplate and ApiClient
        final RestTemplate restTemplate = createRestTemplate();
        final ApiClient apiClient = new ApiClient(restTemplate);
        // set root of API Client base path
        final URI uri = destination.getUri();
        final URI path = new URI(uri.getScheme(), null, uri.getHost(), uri.getPort(), uri.getPath(), null, null);
        apiClient.setBasePath(path.toString() + DEST_URL_POSTFIX);
        if (!eventName.equals(METADATA_LOOKUP)) {
            // Set request header values
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_NAME", DEVICES);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_VER", "2.2");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_ESP_ENVIRONMENT", "UAT");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_CONSUMER_ID", "176879");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_CONSUMER_APP_SEQ_NO", "22222222-2222-4222-a222-222222222222");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_ESP_CLIENT_VERSION", "2.0");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_INPUT_DATA_FORMAT", ESP_JSON);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_OUTPUT_DATA_FORMAT", ESP_JSON);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_OPR", "queryDevice");
            apiClient.addDefaultHeader("HTTP_HEADER_CONTEXT", "#Devices#");
            apiClient.addDefaultHeader("HTTP_HEADER_CONTEXT_VERSION", "3");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_PROVIDER_ID", "4237");
        } else {
            // Set request header values
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_NAME", METADATA_LOOKUP);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_VER", "3.1");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_ESP_ENVIRONMENT", "UAT");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_CONSUMER_ID", "176879");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_CONSUMER_APP_SEQ_NO", "22222222-2222-4222-a222-222222222222");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_ESP_CLIENT_VERSION", "2.0");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_INPUT_DATA_FORMAT", ESP_JSON);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_OUTPUT_DATA_FORMAT", ESP_JSON);
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_SERVICE_OPR", "getSerialNumberDetails");
            apiClient.addDefaultHeader("HTTP_HEADER_CONTEXT", "#MetaDataLookup#");
            apiClient.addDefaultHeader("HTTP_HEADER_CONTEXT_VERSION", "3");
            apiClient.addDefaultHeader("HTTP_HEADER_SSP_PROVIDER_ID", "4237");
        }
        // APIM header
        apiClient.addDefaultHeader(APP_ID_KEY, APP_ID_VALUE);
        return apiClient;
    }

    /**
     * createRestTemplate - method to generate RestTemplate
     * 
     * @implSpec - Generate restTemplate by HttpClient using detinations details
     * @return RestTemplate
     * @author mvijetha
     */
    private RestTemplate createRestTemplate() {
        final HttpDestination destination = DestinationAccessor.getDestination(DESTINATION_NAME).asHttp();
        // create new HttpClient for destination
        final HttpClient httpClient = HttpClientAccessor.getHttpClient(destination);

        // instantiate template with prepared HttpClient
        final RestTemplate restTemplate = new RestTemplate();
        final HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        httpRequestFactory.setHttpClient(httpClient);
        restTemplate.setRequestFactory(new BufferingClientHttpRequestFactory(httpRequestFactory));
        return restTemplate;
    }

    /**
     * generateJsonRequestForDevices - method to generate request Json
     * 
     * @implSpec - Using serialNumber as input and generated java classes, contruct
     *           the json request for Devices service
     * 
     * @param String serialNumber
     * @return espServiceRequest
     * @author mvijetha
     */
    public String generateJsonRequestForDevices(String serialNumber) throws JsonProcessingException {
        QueryDeviceRequest__1 queryDeviceRequest1 = new QueryDeviceRequest__1();
        queryDeviceRequest1.setSerialNumber(serialNumber);

        devices.QueryDeviceRequest queryDeviceRequest = new devices.QueryDeviceRequest();
        queryDeviceRequest.setQueryDeviceRequest(queryDeviceRequest1);

        Body body = new Body();
        body.setQueryDeviceRequest(queryDeviceRequest);
        Header header = new Header();

        EspRequestPayload espRequestPayload = new EspRequestPayload();
        espRequestPayload.setBody(body);
        espRequestPayload.setHeader(header);

        EspServiceRequest espServiceRequest = new EspServiceRequest();
        espServiceRequest.setEspRequestPayload(espRequestPayload);

        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(espServiceRequest);
    }

    /**
     * generateJsonRequestForMetaDataLookup - method to generate request Json
     * 
     * @implSpec - Using serialNumber as input and generated java classes, construct
     *           the json request for MetaDataLookup service
     * 
     * @param String serialNumber
     * @return espServiceRequest
     * @author mvijetha
     */
    private String generateJsonRequestForMetaDataLookup(String serialNumber) throws JsonProcessingException {
        Sndetails sndetails = new Sndetails();
        sndetails.setSerialNumber(serialNumber);

        SerialNumbers serialNumbers = new SerialNumbers();
        serialNumbers.setSndetails(sndetails);

        RequestDetails__1 requestDetails1 = new RequestDetails__1();
        requestDetails1.setAppID(METADATALOOKUP_APPID);
        requestDetails1.setRequestType(METADATALOOKUP_REQUESTTYPE);
        requestDetails1.setSerialNumbers(serialNumbers);

        metadatalookup.RequestDetails requestDetails = new metadatalookup.RequestDetails();
        requestDetails.setRequestDetails(requestDetails1);

        RequestInput requestInput = new RequestInput();
        requestInput.setRequestDetails(requestDetails);

        Input input = new Input();
        input.setRequestInput(requestInput);

        metadatalookup.Body body = new metadatalookup.Body();
        body.setInput(input);

        metadatalookup.Header header = new metadatalookup.Header();

        metadatalookup.EspRequestPayload espRequestPayload = new metadatalookup.EspRequestPayload();
        espRequestPayload.setHeader(header);
        espRequestPayload.setBody(body);

        metadatalookup.EspServiceRequest espServiceRequest = new metadatalookup.EspServiceRequest();
        espServiceRequest.setEspRequestPayload(espRequestPayload);

        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(espServiceRequest);
    }

    /**
     * getSSCCValue - Fetch Values from T_GLOBAL_CONFIGURATION table for Name
     * 
     * @implSpec - Return ConfigValues object with Value for Name param
     * @param String name
     * @return ConfigValues object
     * @author steven_lau
     */
    private ConfigValues getSSCCValue(String name) {
        // build query to get SSCCValue from ConfigValues table data
        CqnSelect sel = Select.from(ConfigValues_.class).columns(ConfigValues.VALUE).where(sn -> sn.Name().eq(name));
        return db.run(sel).first(ConfigValues.class).orElseThrow(
                () -> new ServiceException(ErrorStatuses.NOT_FOUND + " SSCC NAME = " + name + DOES_NOT_EXIST));

    }

    /**
     * lastDigitCalculation is used to fetch the last digit
     * 
     * @param String digit
     * @return Integer lastdigit
     * @author steven_lau
     */
    private Integer lastDigitCalculation(String digit) {
        char[] list = digit.toCharArray();
        int[] num = new int[digit.length()];

        for (int i = 0; i < digit.length(); i++) {
            num[i] = Character.digit(list[i], 10);
        }

        int evenSum = 0;
        int oddSum = 0;
        int lastSum = 0;
        for (int i = 0; i < num.length; i++) {
            if (i % 2 == 0)
                oddSum += num[i] * 3;
            if (i % 2 == 1)
                evenSum += num[i];
        }

        lastSum = oddSum + evenSum;

        int roundDigit = (lastSum / 10) * 10;

        int lastdigit = roundDigit - lastSum;

        if (lastdigit < 0) {
            lastdigit = lastdigit * -1;
        }

        return lastdigit;

    }

    /**
     * getExistingSerialNumbers returns List of VBoxitemsWithSerialnumber containing
     * SerialNumber
     * 
     * @implSpec Fetch all the BoxID and SerialNumbers from BoxItems table but for
     *           boxID and serialNumber params excluding Box status
     *           STATUS_SHIPMENT_PACKED = 3
     * @param String   boxID
     * @param String[] serialNumber
     * @return List of VBoxitemsWithSerialnumber
     * @author steven_lau
     */
    public List<VBoxitemsWithSerialnumber> getExistingSerialNumbers(String boxID, String[] serialNumber) {
        // build query to get Boxes details from the Boxes table
        CqnSelect sel = Select.from(VBoxitemsWithSerialnumber_.class)
                .columns(VBoxitemsWithSerialnumber.BOXID, VBoxitemsWithSerialnumber.SERIALNUMBER)
                .where(view -> view.SERIALNUMBER().in(serialNumber).and(view.STATUS().ne(STATUS_SHIPMENT_PACKED))
                        .and(view.BOXID().ne(boxID)));
        return db.run(sel).listOf(VBoxitemsWithSerialnumber.class);
    }

    /**
     * getSSCC18ForBoxId - Method to check if SSCC18 if null in Boxes table for a
     * boxID
     * 
     * @implSpec - Fetch SSCC18 for a boxID from T_BOXES table and check if its
     *           null, If the value is null return true, else return false
     * @param String boxID
     * @return boolean isSsccPresent
     * @author mvijetha
     */
    private Boxes getBoxDetails(String boxID) {
        // query to get all the columns from T_BOXES table
        Optional<Boxes> boxes = db.run(Select.from(Boxes_.class).where(bID -> bID.BoxID().eq(boxID)))
                .first(Boxes.class);
        if (!boxes.isPresent()) {
            throw new ServiceException("Box ID : " + boxID + DOES_NOT_EXIST);
        }
        return boxes.get();
    }

    /**
     * buildPartWashTransferOrderRequest method used to construct the PWTO request
     * params
     * 
     * @implSpec - This method is used to construct the PartWash TransferOrder
     *           details request with Box Items and calculate the box quantity
     *           difference and set the ReverseTransferOrderFlag
     * @param Boxes box
     * @return void
     * @author mvijetha
     */
    private void buildPartWashTransferOrderRequest(Boxes box) {
        // create a new instance
        partWashTransferOrderRequest = PartWashTransferOrder.create();

        String boxId = box.getBoxID();

        // get previously saved Box Details
        Boxes persistedBoxDetails = getBoxDetails(boxId);

        partWashTransferOrderRequest.setBoxID(boxId);
        partWashTransferOrderRequest.setStorageLocation(persistedBoxDetails.getStorageLocation());
        partWashTransferOrderRequest.setPlant(persistedBoxDetails.getPlant());
        partWashTransferOrderRequest.setStatus(INITIAL_PROCESSING_STATUS);

        fillItemLevelDetails(partWashTransferOrderRequest, box);

        // run calculation to deterimine TO qty and if reversal needs to take place
        calculateTransferOrderQuantity((box.getToBoxItems() != null) ? box.getToBoxItems().size() : 0,
                persistedBoxDetails.getQuantity(), partWashTransferOrderRequest);
    }

    /**
     * calculateTransferOrderQuantity method is used to calculate the PWTO
     * boxQuantity
     * 
     * @implSpec - This method is used to calculate PWTO box quantity: 1. If
     *           oldBoxQuantity is null, then set the PWTO box qualtity as
     *           currentBoxQuantity 2. Else calculate the quantityDiff ->
     *           currentBoxQuantity - oldBoxQuantity a. If the quantityDiff
     *           difference is -ve, then set the PWTO boxQuantity with
     *           quantityDiff(convert to +ve number) and set reverseFlag to X b. If
     *           quantityDiff is 0, then set the PWTO boxQuantity with 0 c. If
     *           update quantityDiff difference is +ve, then set the PWTO
     *           boxQuantity with quantityDiff
     * @param Integer               currentBoxQuantity
     * @param Integer               oldBoxQuantity
     * @param PartWashTransferOrder pwtoReq
     * @return Set pwtoReq with calculated boxQuantity
     * @author mvijetha
     */
    private void calculateTransferOrderQuantity(Integer currentBoxQuantity, Integer oldBoxQuantity,
            PartWashTransferOrder pwtoReq) {
        if (oldBoxQuantity != null) {
            int quantityDiff = currentBoxQuantity - oldBoxQuantity;
            if (quantityDiff == 0) {
                pwtoReq.setBoxQuantity(0);
                return;
            }
            if (quantityDiff < 0) {
                pwtoReq.setReverseTransferOrderFlag(REVERSE_TRANSFER_ORDER_FLAG);
            }
            pwtoReq.setBoxQuantity(Math.abs(quantityDiff));
            return;
        }
        pwtoReq.setBoxQuantity(currentBoxQuantity);
    }

    /**
     * insertPartWashTransferOrderRequest method used to insert data into PartWash
     * table
     * 
     * @implSpec - This method is used to insert PartWash TransferOrder details
     * @param PartWashTransferOrder pwtoRequest
     * @return void
     * @author mvijetha
     */
    private void insertPartWashTransferOrderRequest(PartWashTransferOrder pwtoRequest) {
        Result result = db.run(Insert.into(PartWashTransferOrder_.class).entry(pwtoRequest));
        result.single(PartWashTransferOrder.class);
    }

    /**
     * getBoxItems method returns List of BoxItems for the boxId
     * 
     * @implSpec - Fetch details of a BoxId from the BoxItems table for the input
     *           boxId
     * @param String boxId
     * @return BoxItems
     * @author mvijetha
     */
    private BoxItems getBoxItems(String boxId) {
        // build query to get all BoxItems
        Optional<BoxItems> boxItems = db.run(Select.from(BoxItems_.class).where(bID -> bID.BoxID_BoxID().eq(boxId)))
                .first(BoxItems.class);
        if (boxItems.isPresent()) {
            return boxItems.get();
        }
        return null;
    }
}