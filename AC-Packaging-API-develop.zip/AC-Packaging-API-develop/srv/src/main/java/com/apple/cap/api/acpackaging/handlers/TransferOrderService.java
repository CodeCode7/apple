package com.apple.cap.api.acpackaging.handlers;

import com.sap.cds.ql.Delete;
import com.sap.cds.ql.Update;
import com.sap.cds.ql.cqn.CqnDelete;
import com.sap.cds.ql.cqn.CqnUpdate;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;

import org.springframework.stereotype.Component;

import cds.gen.transferorderservice.BeginProcessingContext;
import cds.gen.transferorderservice.PartWashTransferOrder;
import cds.gen.transferorderservice.PartWashTransferOrder_;
import cds.gen.transferorderservice.ResetProcessingContext;
import cds.gen.transferorderservice.SuccessfullyProcessedContext;
import cds.gen.transferorderservice.TransferOrderService_;

/**
 * TransferOrderService is a java class used for Transfer Order process.
 *
 * @version 1.0
 * @date 09 Oct 2021
 * @author mvijetha
 */
@Component
@ServiceName(TransferOrderService_.CDS_NAME)
public class TransferOrderService extends ACPService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    TransferOrderService(PersistenceService db) {
        this.db = db;
    }

    /**
     * onBeginProcessing - @On action event for updating status to P in PartWash
     * table
     * 
     * @implSpec - Updating status to P in PartWash table for the ID
     * @param BeginProcessingContext context
     * @return void
     * @author mvijetha
     */
    @On(event = BeginProcessingContext.CDS_NAME)
    public void onBeginProcessing(BeginProcessingContext context) {
        int flag = 0;
        flag = updatePartWashTransferOrderStatus(context.getId().split(UUID_SEPARATOR), BEGIN_PROCESSING_STATUS);
        context.setResult(flag);
    }

    /**
     * onSuccessfullyProcessed - @On action event for updating status to C in
     * PartWash table
     * 
     * @implSpec - Updating status to C in PartWash table for the ID
     * @param SuccessfullyProcessedContext context
     * @return void
     * @author mvijetha
     */
    @On(event = SuccessfullyProcessedContext.CDS_NAME)
    public void onSuccessfullyProcessed(SuccessfullyProcessedContext context) {
        int flag = 0;
        flag = deletePartWashTransferOrderStatus(context.getId().split(UUID_SEPARATOR));
        context.setResult(flag);
    }

    /**
     * onResetProcessing - @On action event for updating status to A/I in PartWash
     * table
     * 
     * @implSpec - Updating status to A/I in PartWash table for the ID
     * @param ResetProcessingContext context
     * @return void
     * @author mvijetha
     */
    @On(event = ResetProcessingContext.CDS_NAME)
    public void onResetProcessing(ResetProcessingContext context) {
        int flag = 0;
        flag = updatePartWashTransferOrderStatus(context.getId().split(UUID_SEPARATOR), RESET_PROCESSING_STATUS);
        context.setResult(flag);
    }

    /**
     * updatePartWashTransferOrderStatus method used to update PartWash table
     * 
     * @implSpec - This method is used to update the following PartWash
     *           TransferOrder details for BoxId based on ID
     * @param String[] uUID
     * @param String   status
     * @return return 0 if update is successful, in case of exception return 1
     * @author mvijetha
     */
    private Integer updatePartWashTransferOrderStatus(String[] uUID, String status) {
        try {
            CqnUpdate update = Update.entity(PartWashTransferOrder_.class).data(PartWashTransferOrder.STATUS, status)
                    .where(uID -> uID.ID().in(uUID));
            db.run(update);
            return 0;
        } catch (Exception sql) {
            sql.getMessage();
            return 1;
        }
    }

    /**
     * deletePartWashTransferOrderStatus method used to delete UUID/s from PartWash
     * table
     * 
     * @implSpec - This method is used to delete UUID/s from PartWash
     * @param String[] uUID
     * @return return 0 if delete is successful, in case of exception return 1
     * @author mvijetha
     */
    private Integer deletePartWashTransferOrderStatus(String[] uUID) {
        try {
            CqnDelete delete = Delete.from(PartWashTransferOrder_.class).where(uID -> uID.ID().in(uUID));
            db.run(delete);
            return 0;
        } catch (Exception sql) {
            sql.getMessage();
            return 1;
        }
    }

}
