/*
* PalletService.java
*
* Copyright (c) Apple, Inc.
* 410 N Mary Ave, Sunnyvale, California, 94085, U.S.A.
* All rights reserved.
*
* This software is the confidential and proprietary information of Apple Inc.
* ("Confidential Information"). You shall not disclose such
* Confidential Information and shall use it only in accordance
* with the terms of the license agreement you entered into with Apple.
*/
package com.apple.cap.api.acpackaging.handlers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.sap.cds.ql.Select;
import com.sap.cds.ql.Update;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.cds.CqnService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.After;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import cds.gen.adminconfigservice.NumberRanges;
import cds.gen.boxservice.BoxItems_;
import cds.gen.boxservice.Boxes;
import cds.gen.boxservice.Boxes_;
import cds.gen.palletservice.BoxItems;
import cds.gen.palletservice.CheckDuplicateBoxNumbersContext;
import cds.gen.palletservice.GetPalletContentsContext;
import cds.gen.palletservice.LamsUpdate;
import cds.gen.palletservice.LamsUpdateContext;
import cds.gen.palletservice.PalletItems;
import cds.gen.palletservice.PalletItems_;
import cds.gen.palletservice.PalletService_;
import cds.gen.palletservice.Pallets;
import cds.gen.palletservice.Pallets_;

/**
 * PalletService is a java class used fo Creation and modification of Pallets.
 *
 * @version 1.0
 * @date 15 June 2021
 * @author steven_lau
 */
@Component
@ServiceName(PalletService_.CDS_NAME)
public class PalletService extends ACPService implements EventHandler {

    /**
     * ---------------------------------------------------------------------------
     * Instance Field(s)
     * ---------------------------------------------------------------------------
     */
    @Autowired
    @Qualifier(PalletService_.CDS_NAME)
    CqnService eventMeshService;

    /**
     * ---------------------------------------------------------------------------
     * Constant(s)
     * ---------------------------------------------------------------------------
     */
    private static final String LABEL_PREFIX = "P";
    private static final String ERROR_PREFIX_BOXID = "Box ID(s) = ";
    List<PalletItems> palletItemsListForUpdate = new ArrayList<>();

    /**
     * ---------------------------------------------------------------------------
     * Constructor(s)
     * ---------------------------------------------------------------------------
     */
    PalletService() {
    }

    PalletService(PersistenceService db, @Qualifier(PalletService_.CDS_NAME) CqnService eventMeshService,
            List<PalletItems> palletItemsListForUpdate) {
        this.db = db;
        this.eventMeshService = eventMeshService;
        this.palletItemsListForUpdate = palletItemsListForUpdate;
    }

    /**
     * ---------------------------------------------------------------------------
     * Instance Method(s)
     * ---------------------------------------------------------------------------
     */
    /**
     * onBeforeCreatePallet - @Before event meant for creating newPalletID for
     * newPallet
     * 
     * @implSpec newPalletID will be generated for the below combination:
     *           LABEL_PREFIX,Pallet.Plant,Pallet.StrorageLocation,Today's date,
     *           Sequence generator
     * @param Pallets pallet
     * @return void - set newPalletID and Status=0 to Pallet object
     * @author steven_lau
     */
    @Before(event = CdsService.EVENT_CREATE, entity = Pallets_.CDS_NAME)
    public void onBeforeCreatePallet(Pallets pallet) {

        // validate user has access to Plant requested
        if (!hasPlantAccess(pallet.getPlant())) {
            throw new ServiceException("No Authorization for Plant: " + pallet.getPlant());
        }

        LocalDate today = LocalDate.now();

        NumberRanges palletNumberRange = incrementNumberRange(NUMBER_RANGE_TYPE_PALLET, pallet.getPlant());
        int nextNumber = palletNumberRange.getCurrentNumber();
        String nextNumberString = String.format(STRING_FORMAT_ZERO_PAD_LENGTH_5, nextNumber);

        String newPalletID = LABEL_PREFIX + pallet.getPlant() + pallet.getStorageLocation()
                + today.format(DateTimeFormatter.ofPattern(STRING_FORMAT_YEAR_LENGTH_2))
                + String.format(STRING_FORMAT_ZERO_PAD_LENGTH_2, today.getDayOfMonth())
                + String.format(STRING_FORMAT_ZERO_PAD_LENGTH_2, today.getMonthValue()) + nextNumberString;

        pallet.setPalletID(newPalletID);
        pallet.setStatus(STATUS_CREATED);
    }

    /**
     * onBeforeUpdatePallet - @Before event meant for validating Plant access during
     * pallet update and also fetch the BoxIds of the modifying PalletID.
     * 
     * @implSpec - Validate the plant requested is valid plant for the user. Fetch
     *           all the BoxIDs for the palletID before updating the Pallet.
     * 
     * @param Pallets object
     * @return void
     * @author steven_lau
     */
    @Before(event = { CdsService.EVENT_UPDATE, CdsService.EVENT_UPSERT }, entity = Pallets_.CDS_NAME)
    public void onBeforeUpdatePallet(Pallets pallet) {
        // validate user has access to Plant requested
        if (!pallet.isEmpty() && !hasPlantAccess(pallet.getPlant())) {
            throw new ServiceException("No Authorization for Plant: " + pallet.getPlant());
        }

        String palletID = pallet.getPalletID();
        // If Pallet Status = 3, then skip the update in T_BOXES tables
        if (!retrievePalletStatus(palletID).equals(PALLET_SHIPMENT_LINKED)) {
            CqnSelect sel = Select.from(PalletItems_.class).columns(PalletItems.BOX_ID_BOX_ID)
                    .where(piID -> piID.PalletID_PalletID().eq(palletID));
            palletItemsListForUpdate = db.run(sel).listOf(PalletItems.class);
        }
    }

    /**
     * onAfterUpdatePallet - @After update event on T_PALLETS table
     * 
     * @implSpec - If Pallet Status = 3, then skip the updates in T_BOXES and
     *           T_PALLETS tables. Update Box Status=2 for BoxIds present in Pallet
     *           if Box Status=1 in T_BOXES table AND Update Pallet Status=2 for
     *           Pallets if Status=0 in T_PALLETS table. And fetch all the missing
     *           BoxIDs by comparing Current and Previous BoxIDs during modify
     *           Pallet, and set the status of missing BoxIDs to 1 (Status = 1)
     * @param - Pallets pallets
     * @return - void
     * @author steven_lau
     */
    @After(event = CdsService.EVENT_UPDATE, entity = Pallets_.CDS_NAME)
    public void onAfterUpdatePallet(Pallets pallets) {
        String palletID = pallets.getPalletID();
        // If Pallet Status = 3, then skip the updates in T_BOXES and T_PALLETS tables
        if (!pallets.isEmpty() && !retrievePalletStatus(pallets.getPalletID()).equals(PALLET_SHIPMENT_LINKED)) {
            // Update Box Status=2 for BoxIds present in Pallet if Box Status=1 in T_BOXES
            // table
            Map<String, String> boxElements = new HashMap<>();
            boxElements.put(Boxes.STATUS, BOX_STATUS_ON_PALLET);

            CqnSelect sel = Select.from(PalletItems_.class).columns(PalletItems.BOX_ID_BOX_ID)
                    .where(piID -> piID.PalletID_PalletID().eq(pallets.getPalletID()));
            List<PalletItems> palletItemsList = db.run(sel).listOf(PalletItems.class);
            String[] boxIds = palletItemsList.stream().map(PalletItems::getBoxIDBoxID).toArray(String[]::new);
            db.run(Update.entity(Boxes_.class).data(boxElements)
                    .where(bID -> bID.BoxID().in(boxIds).and(bID.Status().eq(BOX_STATUS_COMPLETED))));

            // Update Pallet Status=2 for Pallets if Status=0 in T_PALLETS table
            Map<String, String> palletElements = new HashMap<>();
            palletElements.put(Pallets.STATUS, PALLET_STATUS_COMPLETED);

            db.run(Update.entity(Pallets_.class).data(palletElements).where(
                    pID -> pID.PalletID().eq(pallets.getPalletID()).and(pID.Status().eq(PALLET_STATUS_CREATED))));

            if (palletItemsListForUpdate != null && !palletItemsListForUpdate.isEmpty()) {
                // Delete or Replace BoxIds in Pallet
                revertBoxStatusForMissingBoxIds(palletItemsListForUpdate, palletItemsList);
            }

            // Fetch Type value from Pallet master table for a particular PalletID

            Pallets palletDetails = getPalletHeaderDetails(palletID);
            String type = palletDetails.getType();

            // Push message to event mesh LamsUpdate queue for Subs
            if (type != null && type.equals(STV_TYPE)) {
                lamsUpdatePushMessage(palletID);
            }
        }
    }

    /**
     * revertBoxStatusForMissingBoxIds - Method to update Status = 1 if the Box is
     * depalletized
     * 
     * @implSpec - Get the missing BoxIds by fetching the difference between
     *           palletItemsListForUpdate list from beforeUpdate event from DB and
     *           existing/current BoxIds from T_PALLET_ITEMS table for the palletID.
     *           For all the missing boxIds, set Status = 1, if Status = 2.
     * @param - List<PalletItems> palletItemsList
     * @param - List<PalletItems> palletItemsListForUpdate
     * @return - void
     * @author mvijetha
     */
    private void revertBoxStatusForMissingBoxIds(List<PalletItems> palletItemsListForUpdate,
            List<PalletItems> palletItemsList) {
        // Get the missing BoxIds by removing the current BoxIDs from previous BoxIDs
        // list
        List<PalletItems> missingBoxIdsDiff = new ArrayList<>(
                (CollectionUtils.removeAll(palletItemsListForUpdate, palletItemsList)));
        String[] missingBoxIds = missingBoxIdsDiff.stream().map(PalletItems::getBoxIDBoxID).toArray(String[]::new);
        Map<String, String> updateBoxElements = new HashMap<>();
        updateBoxElements.put(Boxes.STATUS, BOX_STATUS_COMPLETED);
        db.run(Update.entity(Boxes_.class).data(updateBoxElements)
                .where(bID -> bID.BoxID().in(missingBoxIds).and(bID.Status().eq(BOX_STATUS_ON_PALLET))));
    }

    /**
     * lamsUpdatePushMessage - Function to trigger LamsUpdate event to push the
     * message to queue
     * 
     * @implSpec - Trigger LamsUpdate event by setting PalletID. The LamsUpdate
     *           event will push the message which contains PalletID to eventMesh
     *           queue
     * @param String palletID
     * @return void
     * @author mvijetha
     */
    private void lamsUpdatePushMessage(String palletID) {
        LamsUpdate lamsUpdateEvent = LamsUpdate.create();
        lamsUpdateEvent.setPalletIDMessage(palletID);

        // Set event context to emit
        LamsUpdateContext eventContext = LamsUpdateContext.create();
        eventContext.setData(lamsUpdateEvent);

        // Emit event context
        eventMeshService.emit(eventContext);
    }

    /**
     * onGetPalletContents - onEvent action to validate and fetch Pallet contents
     * 
     * @implSpec - If palletID or boxIds are null, then throw ServiceException .
     *           Check for duplicate boxIds within the BoxId list . Validate if the
     *           BoxIds entered belong to the type and customer of Pallet, else
     *           throw ServiceException . For each PalletId and boxID get all the
     *           boxItems details including serialNumber,boxSequence,
     *           AsIsPartNumber, FinishedGoodsMPN,ModelNumber,CountryOfOrigin
     * @param GetPalletContentsContext context
     * @return set context Result with List<BoxItems>
     * @author steven_lau
     */
    @On(event = GetPalletContentsContext.CDS_NAME)
    public void onGetPalletContents(GetPalletContentsContext context) throws ServiceException {

        List<BoxItems> boxItemsDetails = new ArrayList<>();
        List<BoxItems> boxItemsList = null;
        List<Boxes> boxesHeaderList = null;

        String palletID = context.getPalletID();
        String boxIds = context.getBoxID();

        checkIfBoxOrPalletEmpty(palletID, boxIds);

        String[] splitBoxID = boxIds.split(BOXID_SEPARATOR);

        checkDuplicateBoxIDsWithinList(splitBoxID);

        // Fetch Type and Customer values from Pallet header table for a particular
        // PalletID
        Pallets palletHeaderDetails = getPalletHeaderDetails(palletID);

        // Validate if the BoxIds entered belongs to same type and customer as PalletId
        validateBoxIdsForCustomerAndType(splitBoxID, palletHeaderDetails);

        // To get header details for the boxIDs present in Boxes and PalletItems
        boxesHeaderList = this.getBoxesHeaderDetails(splitBoxID);

        // Validate if the BoxIds entered belongs to same Plant as PalletId
        validateBoxIdsForPlant(splitBoxID, palletHeaderDetails, boxesHeaderList);

        // Validate if the BoxIds entered belongs to same StorageLocation as PalletId
        validateBoxIdsForStorageLocation(splitBoxID, palletHeaderDetails, boxesHeaderList);

        checkDuplicateBoxIDs(palletID, splitBoxID);

        // To get common BoxItem details from first boxID
        boxItemsList = this.getBoxItemDetails(splitBoxID);

        Boolean validation = this.palletValidation(boxesHeaderList, splitBoxID, palletID);
        if (Boolean.TRUE.equals(validation)) {
            boxItemsDetails = generateBoxItemsDetails(boxesHeaderList, boxItemsList);
        }
        context.setResult(boxItemsDetails);

    }

    /**
     * getPalletHeaderDetails - Method to fetch Pallet header details for palletID
     * 
     * @implSpec - Method to fetch Pallet header details for palletID
     * @param String palletID
     * @return throw ServiceException if no data present for palletID
     * @author mvijetha
     */
    private Pallets getPalletHeaderDetails(String palletID) {
        // build query to get pallet Type and Customer
        CqnSelect sel = Select.from(Pallets_.class)
                .columns(Pallets.STORAGE_LOCATION, Pallets.TYPE, Pallets.CUSTOMER, Pallets.PLANT)
                .where(pID -> pID.PalletID().eq(palletID));
        Optional<Pallets> pallets = db.run(sel).first(Pallets.class);
        if (!pallets.isPresent()) {
            throw new ServiceException("Pallet ID = " + palletID + DOES_NOT_EXIST);
        }
        return pallets.get();
    }

    /**
     * validateBoxIdsForPlant - Method to validate the boxIds against Plant
     * 
     * @implSpec - Check if all the boxIds belong to a particular Plant as same as
     *           Pallet, else throw Service Exception
     * @param String[]        splitBoxID
     * @param Pallets         palletHeaderDetails
     * @param boxesHeaderList
     * @return void
     * @author mvijetha
     */
    private void validateBoxIdsForPlant(String[] splitBoxID, Pallets palletHeaderDetails, List<Boxes> boxesHeaderList) {
        String plant = palletHeaderDetails.getPlant();

        List<Boxes> boxesList = boxesHeaderList.stream().filter(boxIds -> boxIds.getPlant().equals(plant))
                .collect(Collectors.toList());

        List<String> invalidBoxIds = filterInvalidBoxIds(splitBoxID, boxesList);

        if (!invalidBoxIds.isEmpty()) {
            throw new ServiceException(ERROR_PREFIX_BOXID + invalidBoxIds + " doesn't belong to Plant : " + plant);
        }
    }

    /**
     * validateBoxIdsForStorageLocation - Method to validate the boxIds against
     * storageLocation
     * 
     * @implSpec - Check if all the boxIds belong to a particular StorageLocation as
     *           same as Pallet, else throw Service Exception
     * @param String[]        splitBoxID
     * @param Pallets         palletHeaderDetails
     * @param boxesHeaderList
     * @return void
     * @author mvijetha
     */
    private void validateBoxIdsForStorageLocation(String[] splitBoxID, Pallets palletHeaderDetails,
            List<Boxes> boxesHeaderList) {
        String storageLocation = palletHeaderDetails.getStorageLocation();

        List<Boxes> boxesList = boxesHeaderList.stream()
                .filter(boxIds -> boxIds.getStorageLocation().equals(storageLocation)).collect(Collectors.toList());

        List<String> invalidBoxIds = filterInvalidBoxIds(splitBoxID, boxesList);

        if (!invalidBoxIds.isEmpty()) {
            throw new ServiceException(
                    ERROR_PREFIX_BOXID + invalidBoxIds + " doesn't belong to Storage Location : " + storageLocation);
        }
    }

    /**
     * filterInvalidBoxIds - Method to filter Invalid BoxIds
     * 
     * @implSpec - Method to filter Invalid BoxIds from input BoxIds during
     *           Palletisation
     * @param String[]    splitBoxID
     * @param List<Boxes> boxesList
     * @return void
     * @author mvijetha
     */
    private List<String> filterInvalidBoxIds(String[] splitBoxID, List<Boxes> boxesList) {
        List<String> invalidBoxIds = null;
        List<String> filteredBoxIds = null;

        // To add box ids to the String Arraylist
        filteredBoxIds = boxesList.stream().map(Boxes::getBoxID).collect(Collectors.toList());

        final List<String> filteredBoxIdsFinal = filteredBoxIds;
        invalidBoxIds = Arrays.asList(splitBoxID).stream().filter(boxIds -> !filteredBoxIdsFinal.contains(boxIds))
                .collect(Collectors.toList());
        return invalidBoxIds;
    }

    /**
     * validateBoxIdsForCustomerAndType - Method to validate the boxIds against type
     * and customer
     * 
     * @implSpec - Check if all the boxIds belong to a particular type and customer,
     *           else throw Service Exception
     * @param String[] splitBoxID
     * @param Pallets  palletHeaderDetails
     * @return void
     * @author mvijetha
     */
    private void validateBoxIdsForCustomerAndType(String[] splitBoxID, Pallets palletHeaderDetails) {
        String type = palletHeaderDetails.getType();
        String customer = palletHeaderDetails.getCustomer();

        List<Boxes> boxesList = getCustomerAndTypeForBoxIds(splitBoxID, type, customer);

        List<String> invalidBoxIds = null;
        List<String> filteredBoxIds = null;

        // To add box ids to the String Arraylist
        filteredBoxIds = boxesList.stream().map(Boxes::getBoxID).collect(Collectors.toList());

        final List<String> filteredBoxIdsFinal = filteredBoxIds;
        invalidBoxIds = Arrays.asList(splitBoxID).stream().filter(boxIds -> !filteredBoxIdsFinal.contains(boxIds))
                .collect(Collectors.toList());

        if (!invalidBoxIds.isEmpty()) {
            if (type != null && type.equals(STV_TYPE)) {
                throw new ServiceException(
                        ERROR_PREFIX_BOXID + invalidBoxIds + " doesn't belong to customer: " + customer);
            } else {
                throw new ServiceException(ERROR_PREFIX_BOXID + invalidBoxIds + " are invalid");
            }
        }
    }

    /**
     * getCustomerAndTypeForBoxIds - Method to validate the boxIds against type and
     * customer
     * 
     * @implSpec - Fetch all the boxes details for boxIds, type and customer
     * @param String[] splitBoxID
     * @param type
     * @param customer
     * @return List<Boxes>
     * @author mvijetha
     */
    private List<Boxes> getCustomerAndTypeForBoxIds(String[] splitBoxID, String type, String customer) {
        // build query to get Boxes details from the Boxes table
        CqnSelect sel = Select.from(Boxes_.class).columns(Boxes.BOX_ID, Boxes.TYPE, Boxes.CUSTOMER)
                .where(box -> box.BoxID().in(splitBoxID).and(box.Type().eq(type)).and(box.Customer().eq(customer)));
        return db.run(sel).listOf(Boxes.class);
    }

    /**
     * generateBoxItemsDetails - Method to generate List of BoxItems
     * 
     * @implSpec - Method to generate List of BoxItems
     * @param List<Boxes>    boxesHeaderList
     * @param List<BoxItems> boxItemsList
     * @return List<BoxItems> boxItemsDetails
     * @author steven_lau
     */
    private List<BoxItems> generateBoxItemsDetails(List<Boxes> boxesHeaderList, List<BoxItems> boxItemsList) {
        List<BoxItems> boxItemsDetails = new ArrayList<>();
        for (Boxes headerDetails : boxesHeaderList) {
            BoxItems newBoxItem = BoxItems.create();
            newBoxItem.setBoxIDBoxID(headerDetails.getBoxID());
            newBoxItem.setPlant(headerDetails.getPlant());
            newBoxItem.setQuantity(headerDetails.getQuantity());
            newBoxItem.setStorageLocation(headerDetails.getStorageLocation());
            BoxItems boxItem = boxItemsList.stream().filter(bId -> bId.getBoxIDBoxID().equals(headerDetails.getBoxID()))
                    .findFirst().orElse(null);
            newBoxItem.setAsIsPartNumber(boxItem != null ? boxItem.getAsIsPartNumber() : "");
            newBoxItem.setFinishedGoodsMPN(boxItem != null ? boxItem.getFinishedGoodsMPN() : "");
            newBoxItem.setCountryOfOrigin(boxItem != null ? boxItem.getCountryOfOrigin() : "");
            boxItemsDetails.add(newBoxItem);
        }
        return boxItemsDetails;
    }

    /**
     * checkDuplicateBoxIDsWithinList - Method to check validate the boxIds
     * 
     * @implSpec - Check for duplicate boxIds within the list
     * @param String[] splitBoxID
     * @return throw ServiceException if duplicate boxIds are found
     * @author steven_lau
     */
    private void checkDuplicateBoxIDsWithinList(String[] splitBoxID) {
        // check duplicates within the list of BoxIds
        List<String> boxIdsList = Arrays.asList(splitBoxID);
        Set<String> boxIdsDuplicateSet = boxIdsList.stream().filter(bxId -> Collections.frequency(boxIdsList, bxId) > 1)
                .collect(Collectors.toSet());

        if (!boxIdsDuplicateSet.isEmpty()) {
            throw new ServiceException("Duplicate BoxId(s):" + boxIdsDuplicateSet.toString() + " exists!!");
        }
    }

    /**
     * checkIfBoxOrPalletEmpty - Method to check validate palletID or boxIds are
     * null or empty
     * 
     * @implSpec - Validate and throw exception if palletID or boxIds are null or
     *           empty
     * @param String palletID
     * @param String boxIds
     * @return throw ServiceException if palletID or boxIds are null or empty
     * @author steven_lau
     */
    private void checkIfBoxOrPalletEmpty(String palletID, String boxIds) {
        if (palletID == null || palletID.equals("") || boxIds == null || boxIds.equals("")) {
            throw new ServiceException("PalletId(s) and/or BoxId(s) cannot be empty!!");
        }
    }

    /**
     * palletValidation - Method to check validate the Pallet contents
     * 
     * @implSpec - Based on the input params, validate and throw ServiceException
     *           with appropriate messages: If Box Status = 2, Already Palletized If
     *           Box Status = 3, Already linked with Shipment If BoxIds are not
     *           present in Box table, Box/s not packed
     * @param String   List<Boxes> filteredBoxes
     * @param String[] actualBoxIDs
     * @param String   palletID
     * @return boolean true if successfully validated
     * @author steven_lau
     */
    private Boolean palletValidation(List<Boxes> filteredBoxes, String[] actualBoxIDs, String palletID)
            throws ServiceException {

        List<String> invalidBoxIds = null;
        List<String> filteredBoxIds = null;

        // To add box ids to the String Arraylist
        filteredBoxIds = filteredBoxes.stream().map(Boxes::getBoxID).collect(Collectors.toList());

        List<String> palletisedBoxIdsList = filteredBoxes.stream()
                .filter(bIds -> bIds.getStatus().equals(BOX_STATUS_ON_PALLET)).map(Boxes::getBoxID)
                .collect(Collectors.toList());
        String[] palletisedBoxIdsArr = palletisedBoxIdsList.stream().toArray(String[]::new);
        if (palletID != null && palletisedBoxIdsArr != null && palletisedBoxIdsArr.length > 0) {
            List<PalletItems> palletisedBoxIdsForPalletIdList = getExistingBoxNumbers(palletID, palletisedBoxIdsArr);
            if (!palletisedBoxIdsForPalletIdList.isEmpty()) {
                throw new ServiceException(
                        ERROR_PREFIX_BOXID + palletisedBoxIdsForPalletIdList + " already Palletized");
            }
        }

        final List<String> filteredBoxIdsFinal = filteredBoxIds;
        invalidBoxIds = Arrays.asList(actualBoxIDs).stream().filter(bxIds -> !filteredBoxIdsFinal.contains(bxIds))
                .collect(Collectors.toList());

        List<String> linkedWithShipmentList = filteredBoxes.stream()
                .filter(bIds -> bIds.getStatus().equals(STATUS_SHIPMENT_PACKED)).map(Boxes::getBoxID)
                .collect(Collectors.toList());

        if (!linkedWithShipmentList.isEmpty()) {
            throw new ServiceException(
                    ERROR_PREFIX_BOXID + linkedWithShipmentList + " is already linked with Shipment");
        } else if (!invalidBoxIds.isEmpty()) {
            throw new ServiceException(ERROR_PREFIX_BOXID + invalidBoxIds + " is not packed");
        }

        return true;

    }

    /**
     * getBoxItemDetails returns List of BoxItems for the BoxIDs
     * 
     * @implSpec Fetch all the BoxIds, AsIsPartNumber,FinishedGoodsMPN,
     *           CountryOfOrigin from BoxItems table for splitBoxID param
     * @param String[] splitBoxID
     * @return List of BoxItems
     * @author steven_lau
     */
    private List<BoxItems> getBoxItemDetails(String[] splitBoxID) {
        // build query to get BoxItems details from the BoxItems table
        CqnSelect sel = Select
                .from(BoxItems_.class).distinct().columns(BoxItems.BOX_ID_BOX_ID, BoxItems.AS_IS_PART_NUMBER,
                        BoxItems.FINISHED_GOODS_MPN, BoxItems.COUNTRY_OF_ORIGIN)
                .where(bID -> bID.BoxID_BoxID().in(splitBoxID));

        List<BoxItems> boxItemsList = db.run(sel).listOf(BoxItems.class);
        boxItemsList.parallelStream().filter(BoxItems::isEmpty)
                .forEach(boxItems -> throwServiceException(boxItems.getBoxIDBoxID()));
        return boxItemsList;
    }

    /**
     * throwServiceException method throws ServiceException
     * 
     * @implSpec Throw ServiceException with customised meesage with BoxItem
     * @param String boxItem
     * @throws ServiceException
     * @author steven_lau
     */
    private Object throwServiceException(String boxItem) {
        throw new ServiceException(ErrorStatuses.NOT_FOUND + " Box ID = " + boxItem + DOES_NOT_EXIST);
    }

    /**
     * getBoxesHeaderDetails returns List of Boxes for the BoxIDs
     * 
     * @implSpec Fetch all the BoxIds, Status,Plant, StorageLocation,Quantity from
     *           Boxes table for boxID param
     * @param String[] boxID
     * @return List of Boxes
     * @author steven_lau
     */
    private List<Boxes> getBoxesHeaderDetails(String[] boxID) {
        // build query to get Boxes details from the Boxes table
        CqnSelect sel = Select.from(Boxes_.class)
                .columns(Boxes.BOX_ID, Boxes.STATUS, Boxes.PLANT, Boxes.STORAGE_LOCATION, Boxes.QUANTITY)
                .where(bID -> bID.BoxID().in(boxID));

        return db.run(sel).listOf(Boxes.class);
    }

    /**
     * onCheckDuplicateBoxNumbers - onEvent action to check duplicate Box numbers
     * for a palletID
     * 
     * @implSpec - Check for duplicate boxIds with the list and also within DB for a
     *           PalletID
     * @param - CheckDuplicateBoxNumbersContext context
     * @return - Set context result = 0, if no duplicates found. Else throw Service
     *         Exception with error message
     * @author steven_lau
     */
    @On(event = CheckDuplicateBoxNumbersContext.CDS_NAME)
    public void onCheckDuplicateBoxNumbers(CheckDuplicateBoxNumbersContext context) throws ServiceException {

        String[] splitBoxNumber = context.getBoxID().split(BOXID_SEPARATOR);
        String palletID = context.getPalletID();

        // check duplicates within the list of BoxNumbers
        List<String> boxNumberList = Arrays.asList(splitBoxNumber);
        Set<String> boxNumberDuplicateSet = boxNumberList.stream()
                .filter(sn -> Collections.frequency(boxNumberList, sn) > 1).collect(Collectors.toSet());

        if (!boxNumberDuplicateSet.isEmpty()) {
            throw new ServiceException("Duplicate Box number(s):" + boxNumberDuplicateSet.toString() + " exists!!");
        }

        checkDuplicateBoxIDs(palletID, splitBoxNumber);

        context.setResult(0);

    }

    /**
     * getExistingBoxNumbers method to fetch BoxIds details of PalletID
     * 
     * @implSpec - Fetch all the box Ids for all splitBoxNumber[] from PalletItems
     *           table not in palletID for validation
     * @param String   palletId
     * @param String[] splitBoxNumber
     * @return List<PalletItems>
     * @author steven_lau
     */
    private List<PalletItems> getExistingBoxNumbers(String palletID, String[] splitBoxNumber) {
        // build query to get Boxes details from the PalletItems table
        CqnSelect sel = Select.from(PalletItems_.class).columns(PalletItems.BOX_ID_BOX_ID).where(
                boxItem -> boxItem.BoxID_BoxID().in(splitBoxNumber).and(boxItem.PalletID_PalletID().ne(palletID)));
        return db.run(sel).listOf(PalletItems.class);
    }

    /**
     * checkDuplicateBoxIDs - Method to check duplicate Box numbers for a palletID
     * 
     * @implSpec - Check for duplicate boxIds with the list and also within DB for a
     *           PalletID
     * @param String   palletID
     * @param String[] boxIDs
     * @return - Success, if no duplicates found. Else throw Service Exception with
     *         error message
     * @author steven_lau
     */
    private void checkDuplicateBoxIDs(String palletID, String[] boxIDs) throws ServiceException {
        List<PalletItems> palletItems = null;

        // check the DB for duplicates
        palletItems = getExistingBoxNumbers(palletID, boxIDs);

        if (!palletItems.isEmpty()) {
            StringBuilder duplicateBoxNumbers = new StringBuilder();
            String currentSeparator = "";
            String separator = ", ";

            // To add existing box numbers to the String Arraylist
            for (PalletItems boxItem : palletItems) {
                duplicateBoxNumbers.append(currentSeparator);
                duplicateBoxNumbers.append(boxItem.getBoxIDBoxID());
                currentSeparator = separator;
            }

            throw new ServiceException("Box Ids(s):" + duplicateBoxNumbers.toString() + " exists in another Pallet");
        }

    }

    /**
     * retrievePalletStatus returns PalletStatus for palletID
     * 
     * @implSpec Fetch Status of palletID from Pallets
     * @param String palletID
     * @return Pallet Status
     * @author steven_lau
     */
    private String retrievePalletStatus(String palletID) {
        // build query to get pallet status
        CqnSelect sel = Select.from(Pallets_.class).columns(Pallets.STATUS).where(pID -> pID.PalletID().eq(palletID));

        Pallets pallet = db.run(sel).first(Pallets.class).orElseThrow(
                () -> new ServiceException(ErrorStatuses.NOT_FOUND + " Pallet ID = " + palletID + DOES_NOT_EXIST));

        return pallet.getStatus();

    }

}
