sap.ui.define([
	"comapple.scp.ui./artsstv/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
