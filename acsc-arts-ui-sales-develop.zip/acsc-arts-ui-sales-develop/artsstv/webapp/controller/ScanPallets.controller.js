sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, BaseController, JSONModel, MessageBox) {
	"use strict";

	return BaseController.extend("com.apple.scp.ui.artsstv.controller.ScanPallets", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.apple.scp.ui.artsstv.view.ScanPallets
		 */
		onInit: function () {
			this.getRouter().attachRouteMatched(this._onRouteMatched, this);
			this.bHide = false;
		},

		_onRouteMatched: function (oEvent) {
			var sRoute = oEvent.getParameter("name");
			if (sRoute === "ScanPallets") {
				this.getView().byId("inp_palletId").setValue("");
				this.getModel("oGlobalModel").setProperty("/aScannedPalletIDs", []);
				this.getModel("oGlobalModel").setProperty("/totalCount", 0);
				this.getModel("oGlobalModel").setProperty("/bSOCreated", false);
			}
		},

		onBackPress: function () {
			this.getRouter().navTo("Main");
		},

		onSubmitPress: function () {
			var that = this;
			var aPalletIds = this.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs");
			var sPalletIDs = "";
			if (aPalletIds.length === 0) {
				MessageBox.error("Please Scan at least one Pallet ID to Create SO Request");
				return;
			} else if (aPalletIds.length === 1) {
				sPalletIDs = aPalletIds[0].PalletID;
			} else {
				for (var x = 0; x < aPalletIds.length; x++) {
					if (sPalletIDs.trim().length === 0) {
						sPalletIDs = aPalletIds[x].PalletID;
					} else {
						sPalletIDs = sPalletIDs + "," + aPalletIds[x].PalletID;
					}
				}
			}
			var oCreateSOPayload = {
				"Plant": this.getModel("oGlobalModel").getProperty("/sPlantSelKey"),
				"SalesOrg": this.getModel("oGlobalModel").getProperty("/sSalesOrgSelKey"),
				"SoldTo": this.getModel("oGlobalModel").getProperty("/sSoldToPartySelKey"),
				"ShipTo": this.getModel("oGlobalModel").getProperty("/sShipToPartySelKey"),
				"StorageLoc": this.getModel("oGlobalModel").getProperty("/sShipFromLocSelKey"),
				"PalletID": sPalletIDs,
				"SORequestNumber": ""
			};
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel().create("/SalesOrderRequestSet", oCreateSOPayload, {
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					that.getModel("oGlobalModel").setProperty("/bSOCreated", true);
					that.getModel("oGlobalModel").setProperty("/sSOReqNum", oData.SORequestNumber);
					that.onBackPress();
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					that.getModel("oGlobalModel").setProperty("/bSOCreated", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});

		},

		onAfterRendering: function () {
			var that = this;
			this.MyControl = this.getView().byId("inp_palletId");
			document.onkeydown = function (event) {
				that.selKey = event.keyCode;
				var inp = that.MyControl.getValue();
				if (that.selKey === 9 && event.target.getAttribute("id").includes("inp_palletId")) {
					that.onPalletIdSubmit(inp);
					that.selKey = "";
					that.bHide = true;
				}
				that.MyControl.focus();
			};

		},

		onPalletIdSubmit: function (sPallet) {
			
			var sPalletId = sPallet;

			if (this.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs").length > 0) {
				if (this.checkForDuplicatePalletIDs(sPalletId)) {
					MessageBox.error("Pallet ID:" + sPalletId + " is already scanned");
					this.MyControl.focus();
					return;
				}

			}

			if (sPalletId.trim().length === 0) {
				MessageBox.error("Pallet ID cannot be blank");
				this.MyControl.focus();
				return;
			}
			this.getView().byId("inp_palletId").setValue("");

			if (sPalletId.trim().length === 0) {
				MessageBox.error("Pallet ID cannot be blank");
				this.MyControl.focus();
				return;
			}
			var temp = {};
			temp.PalletID = sPalletId;
			temp.Customer = this.getModel("oGlobalModel").getProperty("/sSoldToPartySelKey");
			temp.Type = "B";
			var that = this;
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel().setDeferredGroups(["ScanPalletID"]);
			this.getModel().callFunction("/ValidatePalletID", {
				urlParameters: temp,
				method: "GET",
				batchGroupId: "ScanPalletID"
			});
			this.getModel().submitChanges({
				batchGroupId: "ScanPalletID",
				changeSetId: 1,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					var oPalletData = {
						PalletID: sPalletId,
						Status: false
					};
					if (oData.__batchResponses[0].data.results[0].Type === "S") {
						oPalletData.Status = true;
					} else if(oData.__batchResponses[0].data.results[0].Type === "E") {
						MessageBox.show("Not a SUBS Pallet, please check. Pallet not added.", {
                            icon: MessageBox.Icon.ERROR,
                            title: "Error",
                            actions: [MessageBox.Action.OK],
                            onClose: function (oAction) {
                                if (oAction === "OK") {
                                    that.MyControl.focus();
                                }
                            }
                        });
                        return;
					}
					var aPalletIds = that.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs");
					aPalletIds.push(oPalletData);
					that.calTotalCount();
					that.getView().getModel("oGlobalModel").refresh(true);
					that.MyControl.focus();
				},
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		checkForDuplicatePalletIDs: function (sPalletId) {
			var aPalletIds = this.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs");
			for (var x = 0; x < aPalletIds.length; x++) {
				if (sPalletId === aPalletIds[x].PalletID) {
					return true;
				}
			}
			return false;

		},

		calTotalCount: function () {
			var iCount = 0;
			var aPalletIds = this.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs");
			for (var z = 0; z < aPalletIds.length; z++) {
				if ((aPalletIds[z].PalletID).length > 0) {
					iCount++;
				}
			}
			this.getView().getModel("oGlobalModel").setProperty("/totalCount", iCount);
		},
		deletePallet: function (oEvent) {
			var aPalletIDs = this.getView().getModel("oGlobalModel").getProperty("/aScannedPalletIDs");
			var sBindingPath = oEvent.getSource().getParent().getParent().getParent().getBindingContextPath();
			var iLastIndex = sBindingPath.lastIndexOf("/");
			var iSelIndex = sBindingPath.substr(iLastIndex + 1);
			aPalletIDs.splice(iSelIndex, 1);
			this.calTotalCount();
			this.getView().getModel("oGlobalModel").refresh(true);
		}
	});

});