sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"./BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageBox"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, BaseController, JSONModel, MessageBox) {
		"use strict";

		return BaseController.extend("com.apple.scp.ui.artsstv.controller.Main", {
			onInit: function () {
				this.getRouter().attachRouteMatched(this._onRouteMatched, this);
			},

			_onRouteMatched: function (oEvent) {
				var sRoute = oEvent.getParameter("name");
				if (sRoute === "Main") {
					this.bCheck = false;
					var that = this;
					if(this.getModel("oGlobalModel").getProperty("/bSOCreated")) {
						MessageBox.success("Sales Request "+this.getModel("oGlobalModel").getProperty("/sSOReqNum")+" created successfully");
						this.getModel("oGlobalModel").setProperty("/sSOReqNum", "");
						this.getModel("oGlobalModel").setProperty("/bSOCreated", false);
					} else {
						this.getModel("oGlobalModel").setProperty("/sSOReqNum", "");
					}
					this.getModel("appModel").setProperty("/busy", true);
					this.getModel("stvModel").read("/SoldToVendorSet", {
						success: function (oData, resp) {
							that.getModel("appModel").setProperty("/busy", false);
							if (oData.results.length > 0) {
								that.setModel(new JSONModel({
									aInitData: oData.results
								}), "initDataModel");
								that.createDDItems(oData.results);
							}
						},
						error: function (oError) {
							that.getModel("appModel").setProperty("/busy", false);
							MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						}
					});
				}

			},

			createDDItems: function (aData) {
				var aPlants = [];
				var aSoldToParty = [];
				var aShipToParty = [];
				var aShipFromLoc = [];
				this.getModel("oGlobalModel").setProperty("/aCtrlTableData", aData);
				this.getModel("oGlobalModel").setProperty("/sSalesOrgSelKey", aData[0].SalesOrg);
				for (var z = 0; z < aData.length; z++) {
					var oPlants = {
						sPlantSelKey: aData[z].Plant
					};
					aPlants.push(oPlants);

					var oSoldToParty = {
						sPlantSelKey: aData[z].Plant,
						sSoldToPartyKey: aData[z].SoldTo,
						sSoldToPartyName: aData[z].SoldToName
					};
					aSoldToParty.push(oSoldToParty);

					var oShipToParty = {
						sPlantSelKey: aData[z].Plant,
						sSoldToPartyKey: aData[z].SoldTo,
						sShipToPartyKey: aData[z].ShipTo,
						sShipToPartyName: aData[z].ShipToName
					};
					aShipToParty.push(oShipToParty);

					var oShipFromLoc = {
						sPlantSelKey: aData[z].Plant,
						sSoldToPartyKey: aData[z].SoldTo,
						sShipToPartyKey: aData[z].ShipTo,
						sShipFromLoc: aData[z].ShipFromLocation
					};
					aShipFromLoc.push(oShipFromLoc);
				}

				this.soldToParty = aSoldToParty;

				aPlants = aPlants.sort(function (x, y) {
					var nX = x.sPlantSelKey;
					var nY = y.sPlantSelKey;

					if (nX < nY)
						return -1;
					else if (nX > nY)
						return 1;
					return 0;
				});

				var iPlantsLength = aPlants.length - 1;

				var aUnqPlants = [];
				if (iPlantsLength >= 0) {
					for (var j = 0; j < iPlantsLength; j++) {

						if (aPlants[j].sPlantSelKey != aPlants[j + 1].sPlantSelKey) {

							aUnqPlants.push(aPlants[j]);
						}
					}

					aUnqPlants.push(aPlants[iPlantsLength]);

				}

				this.getModel("oGlobalModel").setProperty("/sPlantSelKey", aUnqPlants[0].sPlantSelKey);

				var aUnqSoldToParty = this.setSoldToParty(aSoldToParty);

				this.shipToParty = aShipToParty;
				this.shipFromLoc = aShipFromLoc;

				this.setModel(new JSONModel({
					aPlants: aUnqPlants,
					aSoldToParty: aUnqSoldToParty,
					aShipToParty: [],
					aShipFromLoc: []
				}), "oInitModel");

				this.getModel("oGlobalModel").setProperty("/sSoldToPartySelKey", "");

			},

			setSoldToParty: function (aSoldToParty) {
				var aPlantsSoldToParty = [];
				for (var g = 0; g < aSoldToParty.length; g++) {
					if (this.getModel("oGlobalModel").getProperty("/sPlantSelKey") === aSoldToParty[g].sPlantSelKey) {
						aPlantsSoldToParty.push(aSoldToParty[g]);
					}
				}

				aSoldToParty = aPlantsSoldToParty;

				aSoldToParty = aSoldToParty.sort(function (a, b) {
					var nA = a.sSoldToPartyKey;
					var nB = b.sSoldToPartyKey;

					if (nA < nB)
						return -1;
					else if (nA > nB)
						return 1;
					return 0;
				});

				var iSoldToPartyLength = aSoldToParty.length - 1;

				var aUnqSoldToParty = [];
				if (iSoldToPartyLength >= 0) {
					for (var i = 0; i < iSoldToPartyLength; i++) {

						if (aSoldToParty[i].sSoldToPartyKey != aSoldToParty[i + 1].sSoldToPartyKey) {

							aUnqSoldToParty.push(aSoldToParty[i]);
						}
					}

					aUnqSoldToParty.push(aSoldToParty[iSoldToPartyLength]);

				}
				return aUnqSoldToParty;
			},

			onPlantChange: function (oEvent) {
				this.getModel("oGlobalModel").setProperty("/sSoldToPartySelKey", "");
				var aUnqSoldToParty = this.setSoldToParty(this.soldToParty);
				if (this.getModel("oInitModel")) {
					this.getModel("oInitModel").setProperty("/aSoldToParty", aUnqSoldToParty);
				} else {
					this.setModel(new JSONModel({
						aSoldToParty: aUnqSoldToParty
					}), "oInitModel");
				}
			},

			onSoldToPartyChange: function (oEvent) {
				var selKey = oEvent.getSource().getSelectedKey();
				var aSTPFilterData = [];
				for (var a = 0; a < this.shipToParty.length; a++) {
					if (selKey === this.shipToParty[a].sSoldToPartyKey && this.getModel("oGlobalModel").getProperty("/sPlantSelKey") === this.shipToParty[
							a].sPlantSelKey) {
						aSTPFilterData.push(this.shipToParty[a]);
					}
				}

				aSTPFilterData = aSTPFilterData.sort(function (b, c) {
					var nA = b.sShipToPartyKey;
					var nB = c.sShipToPartyKey;

					if (nA < nB)
						return -1;
					else if (nA > nB)
						return 1;
					return 0;
				});

				var iSoldToPartyLength = aSTPFilterData.length - 1;

				var aUnqShipToParty = [];
				if (iSoldToPartyLength >= 0) {
					for (var i = 0; i < iSoldToPartyLength; i++) {

						if (aSTPFilterData[i].sShipToPartyKey != aSTPFilterData[i + 1].sShipToPartyKey) {

							aUnqShipToParty.push(aSTPFilterData[i]);
						}
					}

					aUnqShipToParty.push(aSTPFilterData[iSoldToPartyLength]);

				}

				if (aUnqShipToParty.length > 0) {
					this.getModel("oInitModel").setProperty("/aShipToParty", aUnqShipToParty);
					this.getModel("oGlobalModel").setProperty("/sShipToPartySelKey", aUnqShipToParty[0].sShipToPartyKey);
					this.onShipToPartyChange();
				} else {
					this.getModel("oInitModel").setProperty("/aShipToParty", []);
					this.getModel("oGlobalModel").setProperty("/sShipToPartySelKey", "");
					this.getModel("oInitModel").setProperty("/aShipFromLoc", []);
					this.getModel("oGlobalModel").setProperty("/sShipFromLocSelKey", "");
				}
				this.getModel("oInitModel").refresh(true);
			},

			onShipToPartyChange: function (oEvent) {
				var selKey = this.getModel("oGlobalModel").getProperty("/sShipToPartySelKey");
				var aSTPFilterData = [];
				for (var a = 0; a < this.shipFromLoc.length; a++) {
					if (selKey === this.shipFromLoc[a].sShipToPartyKey && this.shipFromLoc[a].sSoldToPartyKey === this.getModel("oGlobalModel").getProperty(
							"/sSoldToPartySelKey") && this.getModel("oGlobalModel").getProperty("/sPlantSelKey") === this.shipFromLoc[a].sPlantSelKey) {
						aSTPFilterData.push(this.shipFromLoc[a]);
					}
				}

				aSTPFilterData = aSTPFilterData.sort(function (a, b) {
					var nA = a.sShipFromLoc;
					var nB = b.sShipFromLoc;

					if (nA < nB)
						return -1;
					else if (nA > nB)
						return 1;
					return 0;
				});

				var iShipFromLocLength = aSTPFilterData.length - 1;

				var aUnqShipFromLoc = [];
				if (iShipFromLocLength >= 0) {
					for (var i = 0; i < iShipFromLocLength; i++) {

						if (aSTPFilterData[i].sShipFromLoc != aSTPFilterData[i + 1].sShipFromLoc) {

							aUnqShipFromLoc.push(aSTPFilterData[i]);
						}
					}

					aUnqShipFromLoc.push(aSTPFilterData[iShipFromLocLength]);

				}

				if (aUnqShipFromLoc.length > 0) {
					this.getModel("oInitModel").setProperty("/aShipFromLoc", aUnqShipFromLoc);
					this.getModel("oGlobalModel").setProperty("/sShipFromLocSelKey", aUnqShipFromLoc[0].sShipFromLoc);
				} else {
					this.getModel("oInitModel").setProperty("/aShipFromLoc", []);
					this.getModel("oGlobalModel").setProperty("/sShipFromLocSelKey", "");
				}
				this.getModel("oInitModel").refresh(true);
			},

			onNextPress: function (oEvent) {
				if (this.getModel("oGlobalModel").getProperty("/sPlantSelKey") === "") {
					MessageBox.error("Please select Plant");
				} else if (this.getModel("oGlobalModel").getProperty("/sSoldToPartySelKey") === "") {
					MessageBox.error("Please select Sold To Party");
				} else if (this.getModel("oGlobalModel").getProperty("/sShipToPartySelKey") === "") {
					MessageBox.error("Please select Ship To Party");
				} else if (this.getModel("oGlobalModel").getProperty("/sShipFromLocSelKey") === "") {
					MessageBox.error("Please select Ship From Location");
				} else {
					this.getModel("oGlobalModel").setProperty("/sCustomer", this.byId("id_SoldTP").getSelectedItem().getText());
					this.getRouter().navTo("ScanPallets");
				}

			}

		});
	});