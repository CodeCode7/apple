sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library"
], function (Controller, BaseController, JSONModel, MessageBox, Spreadsheet, exportLibrary) {
	"use strict";
	var EdmType = exportLibrary.EdmType;
	return BaseController.extend("com.apple.acp.ui.artsdash.controller.Shipment", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.apple.scp.ui.artsdash.view.Shipment
		 */
		onInit: function () {
			this.getRouter().attachRouteMatched(this._onRouteMatched, this);
			this.getModel().sDefaultUpdateMethod = "PUT";
			this.getModel("shipmentModel").sDefaultUpdateMethod = "PUT";
		},

		_onRouteMatched: function (oEvent) {
			var sRoute = oEvent.getParameter("name");
			if (sRoute === "Shipment") {
				this.btnPressed = "";
				this.setModel(new JSONModel({
					sShipmentNo: oEvent.getParameter("arguments").ShipmentNo
				}), "oShipmentModel");
				if (this.getModel("oGlobalModel").getProperty("/bShipmentLinked")) {
					this.getModel("oGlobalModel").setProperty("/bShipmentLinked", false);
					MessageBox.success("Shipment linked successfully");
				}
				this.getShipmentData("Init");
			}
		},

		getShipmentData: function (sParam) {
			var that = this;
			var sExpand = "";
			this.sParam = sParam;
			this.bAll = true;
			if (sParam === "Init" || sParam === "" || sParam === undefined) {
				sExpand = "PackHeader,PackItem,ControlFlags";
			} else if (sParam === "TMS") {
				this.bAll = false;
				sExpand = "TMSData";
			}
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").read("/ShipmentHeaderSet(ShipmentNumber='" + this.getModel("oGlobalModel").getProperty(
				"/sShipmentNum") + "')", {
				urlParameters: {
					"$expand": sExpand
				},
				success: function (oData, oResponse) {
					
					that.getModel("oGlobalModel").setProperty("/bSuccess", true);
					if (that.bAll) {
						that.setDynamicShipmentHeaderData(oData);
						that.setShipmentHeaderTableData(oData);
						that.setShipmentItemTableData(oData);
					} else if (!that.bAll) {
						that.setTMSData(oData);
					}
					that.getModel("appModel").setProperty("/busy", false);
				},
				error: function (oError) {
					
					that.getModel("oGlobalModel").setProperty("/bSuccess", false);
					that.setDynamicShipmentHeaderData("");
					that.setShipmentHeaderTableData("");
					that.setShipmentItemTableData("");
					that.setTMSData("");
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		setDynamicShipmentHeaderData: function (oData) {
			if (!this.oDynamicShipmentHdrModel) {
				this.setDynamicShipmentHeaderModel();
			}
			if (oData !== "" && oData !== null) {
				this.oDynamicShipmentHdrModel.setData(oData);
			} else {
				this.oDynamicShipmentHdrModel.setData("");
			}

			this.oDynamicShipmentHdrModel.refresh(true);
			this.getModel("oShipmentModel").refresh(true);
			if (!isNaN(parseInt(oData.TotalPalletsCount, 10)) && parseInt(oData.TotalPalletsCount, 10) > 0) {
				var TotalPalletsCount = new sap.m.Label({
					text: " " + oData.TotalPalletsCount
				});
				var TotalPalletsQuantity = new sap.m.Label({
					text: " " + oData.TotalPalletsQuantity
				});
				var TotalPalletsGrossWeight = new sap.m.Label({
					text: " " + oData.TotalPalletsGrossWeight
				});
				var TotalPalletsGrossWeightUnit = new sap.m.Label({
					text: " " + oData.TotalPalletsGrossWeightUnit
				});
				this.getView().byId("id_packedHdrTbl").getColumns()[1].setFooter(TotalPalletsCount);
				this.getView().byId("id_packedHdrTbl").getColumns()[2].setFooter(TotalPalletsQuantity);
				this.getView().byId("id_packedHdrTbl").getColumns()[3].setFooter(TotalPalletsGrossWeight);
				this.getView().byId("id_packedHdrTbl").getColumns()[4].setFooter(TotalPalletsGrossWeightUnit);
			} else {
				this.getView().byId("id_packedHdrTbl").getColumns()[1].destroyFooter();
				this.getView().byId("id_packedHdrTbl").getColumns()[2].destroyFooter();
				this.getView().byId("id_packedHdrTbl").getColumns()[3].destroyFooter();
				this.getView().byId("id_packedHdrTbl").getColumns()[4].destroyFooter();
			}

		},

		setDynamicShipmentHeaderModel: function () {
			this.oDynamicShipmentHdrModel = new JSONModel();
			this.getView().setModel(this.oDynamicShipmentHdrModel, "oDynamicShipmentHdrModel");
		},

		setShipmentHeaderTableData: function (oData) {
			if (!this.oShipmentHdrModel) {
				this.setShipmentHeaderTableModel();
			}
			if (oData !== "" && oData !== null) {
				this.oShipmentHdrModel.setData(oData.PackHeader.results);
			} else {
				this.oShipmentHdrModel.setData("");
			}

			this.oShipmentHdrModel.refresh(true);
		},

		setShipmentHeaderTableModel: function () {
			this.oShipmentHdrModel = new JSONModel();
			this.getView().setModel(this.oShipmentHdrModel, "oShipmentHdrModel");
		},

		setShipmentItemTableData: function (oData) {
			if (!this.oShipmentItemModel) {
				this.setShipmentItemTableModel();
			}
			if (oData !== "" && oData !== null) {
				this.oShipmentItemModel.setData(oData.PackItem.results);
			} else {
				this.oShipmentItemModel.setData("");
			}

			this.oShipmentItemModel.refresh(true);
		},

		setShipmentItemTableModel: function () {
			this.oShipmentItemModel = new JSONModel();
			this.getView().setModel(this.oShipmentItemModel, "oShipmentItemModel");
		},

		setTMSData: function (oData) {
			if (!this.oTMSDataModel) {
				this.setTMSModel();
			}
			if (oData !== "" && oData !== null) {
				this.oTMSDataModel.setData(oData.TMSData);
			} else {
				this.oTMSDataModel.setData("");
			}
			this.oTMSDataModel.refresh(true);
		},

		setTMSModel: function () {
			this.oTMSDataModel = new JSONModel();
			this.getView().setModel(this.oTMSDataModel, "oTMSDataModel");
		},

		setConfirmationButtonStatus: function(sShipmentStatus, sTenderStatus) {
			if (sShipmentStatus === "5" && (sTenderStatus !== "RJ" && sTenderStatus !== "EX") || (sTenderStatus === "CF")) {
				return true;
			} else {
				return false;
			}
		},
	
		setReconfirmationButtonStatus: function (sTenderStatus) {
			if (sTenderStatus === "RJ" || sTenderStatus === "EX") {
				return true;
			} else {
				return false;
			}
		},
		
		

		onBackPress: function () {
			this.byId("id_packedHdrTbl").removeSelections();
			this.getModel("oGlobalModel").setProperty("/bNav", true);
			this.getRouter().navTo("Main");
		},

		onCarrierDet: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["DetermineCarrierGroup"]);
			this.getModel("shipmentModel").callFunction("/DetermineCarrier", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "DetermineCarrierGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "DetermineCarrierGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						var sMessage = "Carrier Determination Initiated";
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							sMessage = oData.__batchResponses[0].__changeResponses[0].data.MessageText;
						}
						MessageBox.show(sMessage, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								if (oAction === "OK") {
									that.getShipmentData("");
								}
							}
						});
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}

				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onConfirmPress: function () {
			this.btnPressed = "Confirm";
			this.getPrinterDetails();
		},

		getPrinterDetails: function () {
			var that = this;
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").read("/PrinterPreferencesSet('')", {
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					that.receivedPrinterDets = JSON.stringify(oData);
					if (!that._oPrinterLocaleDialog) {
						that._oPrinterLocaleDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.Printer_LocaleDetails", that);
					}
					that.getView().getModel("oGlobalModel").setProperty("/sUser", oData.SAPUserID);
					that.getView().getModel("oGlobalModel").setProperty("/sPrinter", oData.SAPPrinter);
					that.getView().getModel("oGlobalModel").setProperty("/sTMSLocale", oData.TMSPrinter);
					that.getView().addDependent(that._oPrinterLocaleDialog);
					that._oPrinterLocaleDialog.open();
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		onPrinterDetsOkPress: function () {
			if (this.getView().getModel("oGlobalModel").getProperty("/sPrinter").trim() === "") {
				MessageBox.error("Please enter SAP Printer Name");
				return;
			} else if (this.getView().getModel("oGlobalModel").getProperty("/sTMSLocale").trim() === "") {
				MessageBox.error("Please enter TMS Locale");
				return;
			} else {
				this.checkIfPrinterDetsChanged();
			}
		},

		checkIfPrinterDetsChanged: function () {
			this.receivedPrinterDets = JSON.parse(this.receivedPrinterDets);
			if (this.receivedPrinterDets.SAPPrinter === this.getView().getModel("oGlobalModel").getProperty("/sPrinter").trim() &&
				this.receivedPrinterDets.TMSPrinter === this.getView().getModel("oGlobalModel").getProperty("/sTMSLocale").trim()) {
				this.onUserPrefCancel();
				if (this.btnPressed === "Confirm") {
					this.confirmShipment();
				} else if(this.btnPressed === "ReConfirm") {
					this.reconfirmShipment()
				}
			} else {
				this.updatePrinterDets();
			}
		},

		updatePrinterDets: function () {
			var that = this;
			var oPrinterPayload = {
				SAPPrinter: this.getView().getModel("oGlobalModel").getProperty("/sPrinter"),
				TMSPrinter: this.getView().getModel("oGlobalModel").getProperty("/sTMSLocale")
			}
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").update("/PrinterPreferencesSet('')", oPrinterPayload, {
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					that.onUserPrefCancel();
					if (that.btnPressed === "Confirm") {
						that.confirmShipment();
					} else if(that.btnPressed === "ReConfirm") {
						that.reconfirmShipment()
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					that.onUserPrefCancel();
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		onUserPrefCancel: function () {
			this._oPrinterLocaleDialog.close();
		},

		confirmShipment: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["ConfirmGroup"]);
			this.getModel("shipmentModel").callFunction("/Confirmation", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "ConfirmGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "ConfirmGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Confirmation Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onReconfirmPress: function () {
			this.btnPressed = "ReConfirm";
			this.getPrinterDetails();
		},

		reconfirmShipment: function () {
			var that = this;
			var shipmentData = {
				ShipmentNumber: this.getModel("oShipmentModel").getProperty("/sShipmentNo")
			};
			this.getModel("shipmentModel").setDeferredGroups(["ReConfirmGroup"]);
			this.getModel("shipmentModel").callFunction("/ReprocessConfirmation", {
				urlParameters: shipmentData,
				method: "POST",
				batchGroupId: "ReConfirmGroup"
			});
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "ReConfirmGroup",
				async: false,
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Re-Confirmation Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);

				}
			});
		},

		onTMSDataPress: function () {

			this.getShipmentData("TMS");
			if (this.getModel("oGlobalModel").getProperty("/bSuccess")) {
				if (!this._oTMSDataDialog) {
					this._oTMSDataDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.TMSData", this);
				}
				this.getView().addDependent(this._oTMSDataDialog);
				this._oTMSDataDialog.open();
			}

		},

		onTMSViewDialogClose: function () {
			this._oTMSDataDialog.close();
		},

		onWtDimOverridePress: function (oEvent) {
			var selContextPath = this.byId("id_packedHdrTbl").getSelectedContextPaths();
			if (selContextPath.length === 0) {
				MessageBox.error("Please select atleast one row to do Weight Dimension Override");
			} else {
				var aWtDimOverrideData = [];
				for (var a = 0; a < selContextPath.length; a++) {
					var oWtDimOverrideData = {};

					oWtDimOverrideData.ShipmentNumber = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).ShipmentNumber;
					oWtDimOverrideData.PackID = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).PackedID;
					oWtDimOverrideData.NewWeight = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).GrossWeight.trim();
					oWtDimOverrideData.NewWidth = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).Width.trim();
					oWtDimOverrideData.NewLength = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).Length.trim();
					oWtDimOverrideData.NewHeight = this.getModel("oShipmentHdrModel").getProperty(selContextPath[a]).Height.trim();
					aWtDimOverrideData.push(oWtDimOverrideData);
				}
				this.oWtDimOverrideModel = new JSONModel();
				this.setModel(this.oWtDimOverrideModel, "oWtDimOverrideModel");
				this.oWtDimOverrideModel.setData(aWtDimOverrideData);
				if (!this._oWtDimOverrideDialog) {
					this._oWtDimOverrideDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.WeightDimensionOverride", this);
				}
				this.getView().addDependent(this._oWtDimOverrideDialog);
				this._oWtDimOverrideDialog.open();
			}
		},

		onWtDimClose: function () {
			this._oWtDimOverrideDialog.close();
			this.byId("id_packedHdrTbl").removeSelections();
		},

		onWtDimOverrideSubmit: function () {
			var that = this;
			var oWtDimOverrideData = this.getModel("oWtDimOverrideModel").getData();
			this.getModel("shipmentModel").setDeferredGroups(["WtDimensionOverrideGrp"]);
			for (var x = 0; x < oWtDimOverrideData.length; x++) {
				var oWtDimOverrideData1 = {};

				oWtDimOverrideData1.ShipmentNumber = oWtDimOverrideData[x].ShipmentNumber;
				oWtDimOverrideData1.PackID = oWtDimOverrideData[x].PackID;
				oWtDimOverrideData1.NewWeight = oWtDimOverrideData[x].NewWeight;
				oWtDimOverrideData1.NewWidth = oWtDimOverrideData[x].NewWidth;
				oWtDimOverrideData1.NewLength = oWtDimOverrideData[x].NewLength;
				oWtDimOverrideData1.NewHeight = oWtDimOverrideData[x].NewHeight;

				this.getModel("shipmentModel").callFunction("/SetPalletWeightAndDimensions", {
					urlParameters: oWtDimOverrideData1,
					method: "POST",
					batchGroupId: "WtDimensionOverrideGrp"
				});
			}
			this.getModel("appModel").setProperty("/busy", true);
			this.getModel("shipmentModel").submitChanges({
				batchGroupId: "WtDimensionOverrideGrp",
				async: false,
				changeSetId: "WtDimChangeSetID",
				success: function (oData, oResponse) {
					that.getModel("appModel").setProperty("/busy", false);
					if (oData.__batchResponses[0].__changeResponses !== undefined && oData.__batchResponses[0].__changeResponses[0].data.MessageType ===
						"S") {
						if (oData.__batchResponses[0].__changeResponses[0].data.MessageText.length > 0) {
							MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
						} else {
							MessageBox.success("Wt Dimension Override Successful");
						}
						that.getShipmentData("");
					} else {
						MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
					}
					that.byId("id_packedHdrTbl").removeSelections();
					that.onWtDimClose();
				},
				error: function (oError) {
					that.getModel("appModel").setProperty("/busy", false);
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					that.onWtDimClose();
				}
			});
		},

		handleDimensions: function (oEvent) {
			var decimal1 = /^\d*(\.\d{0,3})?$/;
			var enteredvalue = oEvent.getParameters().value;
			if (!enteredvalue.match(decimal1) && enteredvalue.length > 0) {
				oEvent.getSource().setValue(enteredvalue.substr(0, enteredvalue.length - 1));
			}
		},

		onPackedItemExportPress: function () {
			var aCols, oSettings, oSheet;

			aCols = this.createColumnConfig();
			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level'
				},
				dataSource: this.getView().getModel("oShipmentItemModel").getProperty("/"),
				fileName: 'Packed Items.xlsx',
				worker: false
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},

		createColumnConfig: function () {
			var aCols1 = [];
			aCols1.push({
				property: 'PackedID',
				label: 'Pack ID',
				type: EdmType.String
			});

			aCols1.push({
				type: EdmType.String,
				label: 'Count',
				property: 'Count'
			});

			aCols1.push({
				property: 'PalletID',
				label: 'Pallet ID',
				type: EdmType.String
			});

			aCols1.push({
				property: 'BoxID',
				label: 'Box ID',
				type: EdmType.String
			});

			aCols1.push({
				property: 'BoxQty',
				label: 'Box Quantity',
				type: EdmType.String
			});

			aCols1.push({
				property: 'Material',
				label: 'Material',
				type: EdmType.String
			});

			aCols1.push({
				type: EdmType.String,
				label: 'Serial Number',
				property: 'SerialNumber'
			});

			aCols1.push({
				type: EdmType.String,
				label: 'COO',
				property: 'Country'
			});

			aCols1.push({
				property: 'DeliveryNumber',
				label: 'Delivery No.',
				type: EdmType.String
			});

			aCols1.push({
				property: 'DeliveryItemNumber',
				label: 'Delivery Item No.',
				type: EdmType.String
			});

			aCols1.push({
				property: 'TransferOrder',
				label: 'Transfer Order',
				type: EdmType.String
			});

			aCols1.push({
				property: 'TransferOrderItem',
				label: 'TransferOrder Item',
				type: EdmType.String
			});

			aCols1.push({
				property: 'Plant',
				label: 'Plant',
				type: EdmType.String
			});

			return aCols1;
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.apple.scp.ui.artsdash.view.Shipment
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.apple.scp.ui.artsdash.view.Shipment
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.apple.scp.ui.artsdash.view.Shipment
		 */
		//	onExit: function() {
		//
		//	}

	});

});