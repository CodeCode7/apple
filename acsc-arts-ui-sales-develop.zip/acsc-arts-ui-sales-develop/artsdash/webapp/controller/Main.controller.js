sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"./BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageBox",
		"sap/ui/model/type/String",
		"sap/ui/export/Spreadsheet",
		"sap/ui/export/library",
		"sap/ui/model/Filter"

	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, BaseController, JSONModel, MessageBox, typeString, Spreadsheet, exportLibrary, Filter) {
		"use strict";
		var EdmType = exportLibrary.EdmType;
		return BaseController.extend("com.apple.acp.ui.artsdash.controller.Main", { 
			onInit: function () {
				this.getModel("oGlobalModel").setProperty("/bNav", false);
				this.getRouter().attachRouteMatched(this._onRouteMatched, this);
				this.getModel().sDefaultUpdateMethod = "PUT";
			},

			_onRouteMatched: function (oEvent) {
				var sRoute = oEvent.getParameter("name");
				if (sRoute === "Main") {
					this._oMultiInputSOReq = this.getView().byId("multiInputSOReq");
					if (!this.getModel("oGlobalModel").getProperty("/bNav")) {
						this.dToDate = new Date();
						this.dFromDate = new Date();
						this.dFromDate.setDate(this.dFromDate.getDate() - 20);
						this.dFromDate = new Date(this.dFromDate);
						this.oDateFormatUTC = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "yyyy-MM-dd",
							UTC: false
						});
						var that = this;
						this.getModel("appModel").setProperty("/busy", true);
						this.getModel("stvModel").read("/SoldToVendorSet", {
							success: function (oData, resp) {
								that.getModel("appModel").setProperty("/busy", false);
								if (oData.results.length > 0) {
									that.setModel(new JSONModel({
										aInitData: oData.results
									}), "initDataModel");
									that.createDDItems(oData.results);
								}
							},
							error: function (oError) {
								that.getModel("appModel").setProperty("/busy", false);
								MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}
						});
						this.setModel(new JSONModel({
							aRequestData: [],
							dFromDate: this.dFromDate,
							dToDate: this.dToDate,
							sSOStatusSelKey: "",
							aStatusData: [],
							aShipFromLoc: [],
							sShipFromLocSelKey: "",
							aSoldToParty: [],
							sSoldToPartySelKey: ""
						}), "oDBModel");
						this.getStatusData();
						this.byId("multiCB").removeAllSelectedItems();
					}

					this.onSearchPress();
				}

			},

			createDDItems: function (aData) {
				var aSoldToParty = [];
				var aShipFromLoc = [];

				for (var a = 0; a < aData.length; a++) {

					var oSoldToParty = {
						sSoldToPartyKey: aData[a].SoldTo,
						sSoldToPartyValue: aData[a].SoldToName
					};
					aSoldToParty.push(oSoldToParty);

					var oShipFromLoc = {
						sShipFromLocKey: aData[a].ShipFromLocation
					};
					aShipFromLoc.push(oShipFromLoc);

				}

				var aUnqSoldToParty = [];

				//To sort the array in descending order
				aSoldToParty = aSoldToParty.sort(function (a, b) {
					var nA = a.sSoldToPartyKey;
					var nB = b.sSoldToPartyKey;

					if (nA > nB)
						return -1;
					else if (nA < nB)
						return 1;
					return 0;
				});
				for (var i = 0; i < aSoldToParty.length - 1; i++) {

					if (aSoldToParty[i].sSoldToPartyKey !== aSoldToParty[i + 1].sSoldToPartyKey) {

						aUnqSoldToParty.push(aSoldToParty[i]);
					}
				}

				aUnqSoldToParty.push(aSoldToParty[aSoldToParty.length - 1]);

				var aUnqShipFromLoc = [];

				//To sort the array in descending order
				aShipFromLoc = aShipFromLoc.sort(function (a, b) {
					var nA = a.sShipFromLocKey;
					var nB = b.sShipFromLocKey;

					if (nA > nB)
						return -1;
					else if (nA < nB)
						return 1;
					return 0;
				});
				for (var i = 0; i < aShipFromLoc.length - 1; i++) {

					if (aShipFromLoc[i].sShipFromLocKey !== aShipFromLoc[i + 1].sShipFromLocKey) {

						aUnqShipFromLoc.push(aShipFromLoc[i]);
					}
				}

				aUnqShipFromLoc.push(aShipFromLoc[aShipFromLoc.length - 1]);

				this.getModel("oDBModel").setProperty("/aShipFromLoc", aUnqShipFromLoc);
				this.getModel("oDBModel").setProperty("/aSoldToParty", aUnqSoldToParty);

			},

			getStatusData: function () {
				var that = this;
				this.getModel("appModel").setProperty("/busy", true);
				this.getModel().read("/SalesOrderRequestStatusSet", {
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						if (oData.results.length > 0) {
							that.getModel("oDBModel").setProperty("/aStatusData", oData.results);
						} else {
							that.getModel("oDBModel").setProperty("/sSOStatusSelKey", "");
							that.getModel("oDBModel").setProperty("/aStatusData", []);
						}
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			},

			onSOReqValueHelpRequested: function () {
				this._oSOReqValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(), "com.apple.acp.ui.artsdash.fragment.SOReqValueHelpDialog",
					this);
				this.getView().addDependent(this._oSOReqValueHelpDialog);
				this._oSOReqValueHelpDialog.setRangeKeyFields([{
					label: "SO Request",
					key: "SOReq",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 23
					})
				}]);

				this._oSOReqValueHelpDialog.setTokens(this._oMultiInputSOReq.getTokens());
				this._oSOReqValueHelpDialog.open();
			},

			onSOReqValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				this._oMultiInputSOReq.setTokens(aTokens);
				this._oSOReqValueHelpDialog.close();
			},

			onSOReqValueHelpCancelPress: function () {
				this._oSOReqValueHelpDialog.close();
			},

			onSOReqValueHelpAfterClose: function () {
				this._oSOReqValueHelpDialog.destroy();
			},

			setIcon: function (status) {
				if (status === "00") {
					return "sap-icon://decline";
				} else if (status === "06") {
					return "sap-icon://accept";
				} else {
					return "sap-icon://pending";
				}
			},

			onReqNoPress: function (oEvent) {
				var that = this;
				this.getModel("appModel").setProperty("/busy", true);
				if (!this._oSOReqDetailsDialog) {
					this._oSOReqDetailsDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.SOReqDetailsDialog", this);
				}
				this.setModel(new JSONModel({
					sSelReqNum: oEvent.getSource().getText(),
					aReqDetails: [],
					bTogglePressed: true,
					togBtnText: "Error Data"
				}), "oReqDetailsModel");
				this.getModel().read("/SalesReqHdrDashboardSet('" + oEvent.getSource().getText() + "')", {
					urlParameters: {
						"$expand": "SalesReqHdrItmDashboard"
					},
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						if (oData.SalesReqHdrItmDashboard.results.length > 0) {
							that.getModel("oReqDetailsModel").setProperty("/aReqDetails", oData.SalesReqHdrItmDashboard.results);
							that._oSOReqDetailsDialog.open();
							that.getModel("oReqDetailsModel").refresh(true);
						}
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
				this.getView().addDependent(this._oSOReqDetailsDialog);

			},

			onReqCancel: function () {
				var that = this;
				var sSOReqNum = this.getModel("oReqDetailsModel").getProperty("/sSelReqNum");
				this.getModel("appModel").setProperty("/busy", true);
				this.getModel().remove("/SalesOrderRequestSet('" + sSOReqNum + "')", {
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						that.onReqDetsDialogClose();
						if (oResponse.headers.message !== undefined) {
							MessageBox.success(oResponse.headers.message);
							that.onClearPress(false);
						}
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			},

			onReqResubmit: function (oEvent) {
				var that = this;
				var sSOReqNum = this.getModel("oReqDetailsModel").getProperty("/sSelReqNum");
				var temp = {};
				temp.SORequestNumber = sSOReqNum;
				this.getModel("appModel").setProperty("/busy", true);
				this.getModel().update("/SalesOrderRequestSet('" + sSOReqNum + "')", temp, {
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						that.onReqDetsDialogClose();
						if (oResponse.headers.message !== undefined) {
							MessageBox.success(oResponse.headers.message);
							that.onClearPress(false);
						}
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			},

			onReqDetsDialogClose: function () {
				this._oSOReqDetailsDialog.close();
			},

			onErrorDetailsPress: function (oEvent) {
				if (!this._errorPopover) {
					this._errorPopover = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.ErrorPopover", this);
				}
				this.getView().addDependent(this._errorPopover);
				var sPath = oEvent.getSource().getBindingContext("oReqDetailsModel").getPath();
				var selRow = this.getModel("oReqDetailsModel").getProperty(sPath);
				this.getModel("oReqDetailsModel").setProperty("/sDetailedError", selRow.Message);
				this._errorPopover.openBy(oEvent.getSource());
			},

			onErrorPopoverClose: function (oEvent) {
				this._errorPopover.close();
			},

			onExportToExcelPress: function () {
				this.exportTableData();
			},

			exportTableData: function () {
				var aCols, oRowBinding, oSettings, oSheet, oTable;

				oTable = sap.ui.getCore().byId("reqDetailsTable");
				oRowBinding = oTable.getBinding('rows');
				aCols = this.createColumnConfig();
				var oModel = oRowBinding.getModel();
				oSettings = {
					workbook: {
						columns: aCols,
						hierarchyLevel: 'Level'
					},
					dataSource: this.getView().getModel("oReqDetailsModel").getProperty("/aReqDetails"),
					fileName: 'Detailed Errors.xlsx',
					worker: false
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
			},

			createColumnConfig: function () {
				var aCols1 = [];
				aCols1.push({
					property: 'PalletID',
					label: 'Pallet ID',
					type: EdmType.String
				});

				aCols1.push({
					type: EdmType.String,
					label: 'Box ID',
					property: 'BoxID'
				});

				aCols1.push({
					property: 'BoxSeqNum',
					label: 'Box Sequence No.',
					type: EdmType.String
				});

				aCols1.push({
					property: 'RMANumber',
					label: 'RMA No.',
					type: EdmType.String
				});

				aCols1.push({
					property: 'SerialNumber',
					label: 'Serial No.',
					type: EdmType.String
				});

				aCols1.push({
					property: 'SORequestNumber',
					label: 'SO Request No.',
					type: EdmType.String
				});

				aCols1.push({
					type: EdmType.String,
					label: 'Error Message',
					property: 'Message'
				});

				return aCols1;
			},

			onSwitchOnOff: function (oEvent) {
				if (oEvent.getSource().getState()) {
					this.filterTableData([], "Error Data");
				} else {
					var oFilter2 = new sap.ui.model.Filter("Message", sap.ui.model.FilterOperator.EQ, "");
					this.filterTableData(oFilter2, "All Data");
				}
			},

			filterTableData: function (aFilter, btnText) {
				var oTable = sap.ui.getCore().byId("reqDetailsTable");
				var filters = [];
				var oFilter1 = new sap.ui.model.Filter("Message", sap.ui.model.FilterOperator.NE, "");
				filters.push(oFilter1);
				if (aFilter !== []) {
					filters.push(aFilter);
				}
				oTable.getBinding("rows").filter(filters, sap.ui.model.FilterType.Application);
				this.getModel("oReqDetailsModel").setProperty("/togBtnText", btnText);
				this.getModel("oReqDetailsModel").refresh(true);
			},

			errorMessage: function (sError) {
				if (sError !== null && sError !== undefined && sError.length > 25) {
					return sError.substr(0, 25) + "...";
				} else {
					return sError;
				}
			},

			onSearchPress: function () {
				var that = this;
				var aFilter = [];
				var aSOReqBetween = [];
				if (this.getModel("oDBModel").getProperty("/dFromDate") !== null &&
					this.getModel("oDBModel").getProperty("/dToDate") !== null) {
					var dFromDate = this.oDateFormatUTC.format(this.getModel("oDBModel").getProperty("/dFromDate"));
					var dToDate = this.oDateFormatUTC.format(this.getModel("oDBModel").getProperty("/dToDate"));
					var fromDate = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("CreatedOn", sap.ui.model.FilterOperator.GE, dFromDate + "T00:00:00Z"),
							new sap.ui.model.Filter("CreatedOn", sap.ui.model.FilterOperator.LE, dToDate + "T00:00:00Z"),
						],
						and: true,
					});
					aFilter.push(fromDate);
				} else {
					MessageBox.error("Date Range is mandatory");
					return;
				}

				if (this._oMultiInputSOReq.getTokens().length > 0) {
					var aSOReqTokens = this._oMultiInputSOReq.getTokens();
					for (var b of aSOReqTokens) {
						var sSOReqText = b.getText();
						if (sSOReqText.includes('=')) {
							sSOReqText = sSOReqText.substring(1);
							aFilter.push(new sap.ui.model.Filter("SORequestNumber", sap.ui.model.FilterOperator.EQ, sSOReqText));
						}
						if (sSOReqText.includes('...')) {
							aSOReqBetween = sSOReqText.split("...");
							aFilter.push(new sap.ui.model.Filter("SORequestNumber", sap.ui.model.FilterOperator.BT, aSOReqBetween[0], aSOReqBetween[1]));
						}
					}

				}
				var sSelStatusKeys = this.byId("multiCB").getSelectedKeys();
				if (sSelStatusKeys.length > 0) {
					var aStatusFilter = [];
					for (var a = 0; a < sSelStatusKeys.length; a++) {
						aStatusFilter.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, sSelStatusKeys[a]));
					}
					var oStatusFilter = new sap.ui.model.Filter({
						filters: aStatusFilter,
						and: false,
					});
					aFilter.push(oStatusFilter);
				}

				if (this.getModel("oDBModel").getProperty("/sShipFromLocSelKey") !== "") {
					var sShipFromLoc = new Filter("ShipFromLoc", "EQ", this.getModel("oDBModel").getProperty("/sShipFromLocSelKey"));
					aFilter.push(sShipFromLoc);
				}

				if (this.getModel("oDBModel").getProperty("/sSoldToPartySelKey") !== "") {
					var sSoldToParty = new Filter("SoldTo", "EQ", this.getModel("oDBModel").getProperty("/sSoldToPartySelKey"));
					aFilter.push(sSoldToParty);
				}

				this.getModel("appModel").setProperty("/busy", true);
				this.getModel().read("/SalesReqHdrDashboardSet", {
					filters: aFilter,
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						that.getModel("oDBModel").setProperty("/aRequestData", oData.results);
						that.getModel().refresh(true);
					},
					error: function (oError) {
						that.getModel("appModel").setProperty("/busy", false);
						that.getModel("oDBModel").setProperty("/aRequestData", []);
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			},
			
			onClearPress: function (bReset) {
				this.getModel("oDBModel").setProperty("/dFromDate", this.dFromDate);
				this.getModel("oDBModel").setProperty("/dToDate", this.dToDate); //
				if (bReset) {
					this.getModel("oDBModel").setProperty("/sSOStatusSelKey", "");
					this.byId("multiCB").removeAllSelectedItems();
					this._oMultiInputSOReq.removeAllTokens();
					this.getModel("oDBModel").setProperty("/sShipFromLocSelKey", "");
					this.getModel("oDBModel").setProperty("/sSoldToPartySelKey", "");
				}
				this.getModel("oDBModel").setProperty("/aRequestData", []);
				this.onSearchPress();
				this.getModel("oDBModel").refresh(true);
			},

			formatDate: function (dDate) {
				this.oDateFormatterUTC = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy",
					UTC: false
				});
				return this.oDateFormatterUTC.format(dDate);
			},

			onShipmentPress: function (oEvent) {
				var that = this;
				this.getModel("appModel").setProperty("/busy", true);
				var sShipmentNo = oEvent.getSource().getText();
				this.getModel("oGlobalModel").setProperty("/sShipmentNum", sShipmentNo);
				var sPath = oEvent.getSource().getBindingContext("oDBModel").getPath();
				var selRow = this.getModel("oDBModel").getProperty(sPath);
				if (!this.oShipmentHdrModel) {
					this.oShipmentHdrModel = new JSONModel();
					this.getView().setModel(this.oShipmentHdrModel, "oShipmentHdrModel");
				}
				this.getModel("oShipmentHdrModel").setProperty("/Port", "");
				this.sSONumber = selRow.SalesOrder;
				if (parseInt(selRow.ShipmentStatus) !== 1) {
					this.getView().getModel("oGlobalModel").setProperty("/sSONumber", this.sSONumber);
					this.getRouter().navTo("Shipment", {
						ShipmentNo: this.getModel("oGlobalModel").getProperty("/sShipmentNum")
					});
				} else {
					this.getModel("appModel").setProperty("/busy", true);
					this.getModel("shipmentModel").read("/ShipmentHeaderSet(ShipmentNumber='" + sShipmentNo + "')", {
						urlParameters: {
							"$expand": "PackHeader,PackItem,TMSData,ControlFlags"
						},
						success: function (oData, oResponse) {
							that.getModel("appModel").setProperty("/busy", false);

							that.oShipmentHdrModel.setData(oData.PackHeader.results[0]);

							that.oShipmentItemModel = new JSONModel();
							that.getView().setModel(that.oShipmentItemModel, "oShipmentItemModel");
							that.oShipmentItemModel.setData(oData.PackItem.results);
							that.getModel("oShipmentHdrModel").setProperty("/Port", "");
							that._oShipmentDetailsDialog.open();
						},
						error: function (oError) {
							that.getModel("appModel").setProperty("/busy", false);
							MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						}
					});

					if (!this._oShipmentDetailsDialog) {
						this._oShipmentDetailsDialog = sap.ui.xmlfragment("com.apple.acp.ui.artsdash.fragment.ShipmentDetails", this);
					}
					this.getView().addDependent(this._oShipmentDetailsDialog);
					
					
				}

			},

			onCancel: function (oEvent) {
				if (this._oShipmentDetailsDialog) {
					this._oShipmentDetailsDialog.close();
				}
			},

			onShipmentLinkPress: function () {
				var that = this;
				this.getModel("shipmentModel").setDeferredGroups(["linkShipmentGrp"]);
				var oPayload = {
					ShipmentNumber: this.getModel("oGlobalModel").getProperty("/sShipmentNum"),
					Port: this.getModel("oShipmentHdrModel").getProperty("/Port")
				}
				this.getModel("shipmentModel").callFunction("/LinkShipmentPallets", {
					urlParameters: oPayload,
					method: "POST",
					batchGroupId: "linkShipmentGrp"
				});
				this.getModel("appModel").setProperty("/busy", true);
				this.getModel("shipmentModel").submitChanges({
					batchGroupId: "linkShipmentGrp",
					async: false,
					success: function (oData, oResponse) {
						that.getModel("appModel").setProperty("/busy", false);
						if (oData.__batchResponses[0].__changeResponses !== undefined &&
							oData.__batchResponses[0].__changeResponses[0].data.MessageType === "S") {
							that.getModel("oGlobalModel").setProperty("/bShipmentLinked", true);
							that.onCancel();
							that.getView().getModel("oGlobalModel").setProperty("/sSONumber", that.sSONumber);
							that.getRouter().navTo("Shipment", {
								ShipmentNo: that.getModel("oGlobalModel").getProperty("/sShipmentNum")
							});
						} else {
							that.sSONumber = "";
							that.getModel("oGlobalModel").setProperty("/bShipmentLinked", false);
							MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
						}
					},
					error: function (oError) {
						that.sSONumber = "";
						that.getModel("appModel").setProperty("/busy", false);
						that.getModel("oGlobalModel").setProperty("/bShipmentLinked", false);
						MessageBox.error("Shipment linking failed");
					}
				});

			},

			onExportHeaderData: function () {
				var aCols, oRowBinding, oSettings, oSheet, oTable;

				oTable = this.byId("headerData");
				oRowBinding = oTable.getBinding('items');
				aCols = this.createHeaderDataColumnConfig();

				oSettings = {
					workbook: {
						columns: aCols,
						hierarchyLevel: 'Level'
					},
					dataSource: this.getView().getModel("oDBModel").getProperty("/aRequestData"),
					fileName: 'Header Data.xlsx',
					worker: false
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
			},

			createHeaderDataColumnConfig: function () {
				var aCols1 = [];
				aCols1.push({
					property: 'SORequestNumber',
					label: 'Request Number',
					type: EdmType.String
				});
				aCols1.push({
					property: 'CreatedOn',
					label: 'Creation Date',
					type: EdmType.String
				});
				aCols1.push({
					property: 'CreatedBy',
					label: 'Created By',
					type: EdmType.String
				});
				aCols1.push({
					property: 'Plant',
					label: 'Plant',
					type: EdmType.String
				});
				aCols1.push({
					property: 'SoldTo',
					label: 'Sold To',
					type: EdmType.String
				});
				aCols1.push({
					property: 'ShipTo',
					label: 'Ship To',
					type: EdmType.String
				});
				aCols1.push({
					property: 'ShipFromLoc',
					label: 'Ship From Location',
					type: EdmType.String
				});

				aCols1.push({
					type: EdmType.String,
					label: 'Sales Order',
					property: 'SalesOrder'
				});

				aCols1.push({
					property: 'ShipmentNumber',
					label: 'Shipment',
					type: EdmType.String
				});

				aCols1.push({
					type: EdmType.String,
					label: 'Description',
					property: 'SoRequestStatus'
				});

				return aCols1;
			},

			setSOReq: function (SOReqErrStatus) {
				var bShowHyperLink = false;
				if(SOReqErrStatus === "E") {
					bShowHyperLink = true;
				}
				return bShowHyperLink;
			},

			setAcceptIconVisibility: function (sStatus) {
				if (!isNaN(parseInt(sStatus))) {
					if (parseInt(sStatus) >= 8 && parseInt(sStatus) <= 11) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			},

			setDeclineIconVisibility: function (sStatus) {
				if (!isNaN(parseInt(sStatus))) {
					if (parseInt(sStatus) !== 1 && (parseInt(sStatus) <= 7 || parseInt(sStatus) >= 12)) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			},

			setPendingIconVisibility: function (sStatus) {
				if (!isNaN(parseInt(sStatus))) {
					if (parseInt(sStatus) === 1) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		});
	});