sap.ui.define([
	"comapple.acp.ui./artsdash/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
