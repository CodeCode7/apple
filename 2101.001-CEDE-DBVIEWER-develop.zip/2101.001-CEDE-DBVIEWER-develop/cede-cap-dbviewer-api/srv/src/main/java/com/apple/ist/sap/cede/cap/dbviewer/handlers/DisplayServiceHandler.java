package com.apple.ist.sap.cede.cap.dbviewer.handlers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.authentication.JwtTokenAuthenticationInfo;
import com.sap.cds.services.cds.CdsReadEventContext;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.Before;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.UserInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cds.gen.CvSapOpenPo;
import cds.gen.TstSapOpenPOInput_;
import cds.gen.displayservice.DisplayService_;
import cds.gen.displayservice.SapOpenPOInput_;
import cds.gen.displayservice.TstOpenPO_;

@Component
@ServiceName(DisplayService_.CDS_NAME)
public class DisplayServiceHandler implements EventHandler {

    @Autowired
    PersistenceService db;

    Logger logger = LoggerFactory.getLogger(DisplayServiceHandler.class);
    /**
     * Example Before method for SapOpenPOInput entity which takes input parameters.
     * This example hows how you migth validate the input parameters to the entity
     * before sending on to the underlying calc view
     * @param context
     */
    @Before(event = CdsService.EVENT_READ, entity = SapOpenPOInput_.CDS_NAME)
    public void onBeforeReadSapOpenPO(CdsReadEventContext context) {
        Map<String, Object> cqnNamedValues = context.getCqnNamedValues();
       
        final String paramPlant = "plant";
        final String paramProgram = "program";
        String plant;
        String program;
        
        if (cqnNamedValues.containsKey(paramPlant)){
            plant = (String)cqnNamedValues.get(paramPlant);
            logger.info("Input Plant: " + plant);
           // plant = cqnNamedValues.get(paramPlant);
        }
        if (cqnNamedValues.containsKey(paramProgram)){
            program = (String)cqnNamedValues.get(paramProgram);
            logger.info("Input Program: " + program);
        }
        // call some validation logic on the two parameters
        // raise an service exception upon failure
        
    }
    /**
     * In this example On method I have overwitten the default implemenation provided by the framework
     * The definition of TstSapOpenPOInput (in db cds) should return no results as it is declared 
     * with plant V331, program D10. But this implementation will change the parameters to be sent to the calculation view.
     * This is an example of possibly how to  not expose the input parameters to the odata interface but determie the 
     * values to be sent to calc view. 
     * @param context
     */
    @On(event = CdsService.EVENT_READ, entity = TstOpenPO_.CDS_NAME)
    public void onBeforeReadTstOpenPo(CdsReadEventContext context) {
        //String cqn = context.getCqn().toString();
        //CqnSelect cqnSel = context.getCqn();
        
        // Below lines will allow you to get JWT if needed
        
        JwtTokenAuthenticationInfo jwtAuthInfo = (JwtTokenAuthenticationInfo)
        context.getCdsRuntime().getProvidedAuthenticationInfo(); 
        String jwt = jwtAuthInfo.getToken();
        //the below will decode the JWT
        DecodedJWT jwtToken = JWT.decode(jwt);

        Map<String, Claim> claims = jwtToken.getClaims();
        
        Claim emailClaim = jwtToken.getClaim("email");
        String jwtEmail = emailClaim.asString();
        

        // Below lines of code will get user xsuaa information
        UserInfo userInfo = context.getUserInfo();

        if (userInfo != null) {
            // email address is in name field
            String name = userInfo.getName();

            // roles
            Set<String> roles = userInfo.getRoles();

            // user info also has methods to get attributes
            Map<String, List<String>> attributes = userInfo.getAttributes();
            Set<String> unrestrictedAttributes = userInfo.getUnrestrictedAttributes();
            userInfo.getAdditionalAttributes(); // not clear what additional attributes are...
        }



        // create query for the view on top of the  calcview
        CqnSelect sel = Select.from(TstSapOpenPOInput_.class);
        
        //fill in the input parameters of the view
        //you could call a routine to determine access values
        Map paramValues = new HashMap<>();
            paramValues.put("plant", "V331");
            paramValues.put("program", "D42");
         List<CvSapOpenPo> results =  db.run(sel, paramValues).listOf(CvSapOpenPo.class);

        context.setResult(results);
    }
}
