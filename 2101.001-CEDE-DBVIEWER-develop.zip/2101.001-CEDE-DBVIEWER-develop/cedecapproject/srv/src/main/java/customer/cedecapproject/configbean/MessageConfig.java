/**
 * The MessageConfig  class is used for mapping the MessageConfig configurations from properties file
 * 
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-27
 */
package customer.cedecapproject.configbean;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
@ConfigurationProperties(prefix = "message")
public class MessageConfig {
    private String missingPlantProgram;
    private String missingGeo;
    private String invalidPlantProgram;

    public String getMissingPlantProgram() {
        return missingPlantProgram;
    }

    public void setMissingPlantProgram(String missingPlantProgram) {
        this.missingPlantProgram = missingPlantProgram;
    }

    public String getMissingGeo() {
        return missingGeo;
    }

    public void setMissingGeo(String missingGeo) {
        this.missingGeo = missingGeo;
    }

    public String getInvalidPlantProgram() {
        return invalidPlantProgram;
    }

    public void setInvalidPlantProgram(String invalidPlantProgram) {
        this.invalidPlantProgram = invalidPlantProgram;
    }

}
