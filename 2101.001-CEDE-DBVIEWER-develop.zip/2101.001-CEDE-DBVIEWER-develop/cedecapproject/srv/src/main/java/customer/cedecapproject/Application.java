/**
 * The Application class is starting point of Spring boot application
 * 
 *
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-21
 */
package customer.cedecapproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
