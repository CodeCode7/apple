/**
 * The Handler class Intercepts API calls and filters data
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-21
 */

package customer.cedecapproject.handlers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Set;
import com.sap.cds.Result;
import com.sap.cds.ql.CQL;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.StructuredTypeRef;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.ql.cqn.CqnStructuredTypeRef;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.cds.CdsReadEventContext;
import com.sap.cds.services.cds.CdsService;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.UserInfo;
import static com.sap.cds.ResultBuilder.selectedRows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cds.gen.APIOEMDATASETSUMMARYInput_;
import cds.gen.ApiInputPackOut_;
import cds.gen.ApiL2PrepData_;
import cds.gen.Apidatasetinput_;
import cds.gen.OEMDASHBOARDInput_;
import cds.gen.SAPL1DNInput_;
import cds.gen.SAPL1POInput_;
import cds.gen.SapL2Input_;
import cds.gen.SapOpenDNInput_;
import cds.gen.SapOpenPOInput_;
import cds.gen.cedeservice.ApiInventory_;
import cds.gen.cedeservice.ApiPackout_;
import cds.gen.cedeservice.BrowserDataObjects_;
import cds.gen.cedeservice.Datasetsummary_;

import cds.gen.cedeservice.L1SapDataDn_;
import cds.gen.cedeservice.L1SapDataPo_;
import cds.gen.cedeservice.L2OemData_;
import cds.gen.cedeservice.L2SapData_;
import cds.gen.cedeservice.Oemdashboardui_;
import cds.gen.cedeservice.Oemdatasetsummaryui_;
import cds.gen.cedeservice.Oemdn_;
import cds.gen.cedeservice.Oempo_;
import cds.gen.cedeservice.PlantData_;
import cds.gen.cedeservice.ProductProgram_;
import cds.gen.cedeservice.ProfileData_;
import cds.gen.cedeservice.ProgramData_;
import cds.gen.cedeservice.RunAction_;
import cds.gen.cedeservice.RunDisposition_;
import cds.gen.cedeservice.RunFilterData_;
import cds.gen.cedeservice.RunOrderCv_;
import cds.gen.cedeservice.RunOrderItem_;
import cds.gen.cedeservice.Sapdn_;
import cds.gen.cedeservice.Sappo_;
import cds.gen.cedeservice.ScopeConfig_;
import cds.gen.cedeservice.ViewSapDn_;
import cds.gen.cedeservice.ViewSapPo_;
import cds.gen.cedeservice.WorkflowConfig_;
import customer.cedecapproject.configbean.MessageConfig;
import customer.cedecapproject.util.HandlerUtils;


import com.sap.cds.ql.cqn.CqnModifier;

@Component
@ServiceName("CedeService")
public class DatasetSummaryHandler implements EventHandler {

    @Autowired
    PersistenceService db;

    @Autowired
    private HandlerUtils handlerUtils;

    @Autowired
    private MessageConfig messageConfig;

    private static final Logger LOGGER = LoggerFactory.getLogger(DatasetSummaryHandler.class);
    public static final String PLANT = "plant";
    public static final String PROGRAM = "program";
    public static final String GEO = "geo";
    public static final String PROFILEID = "profileid";
    public static final String EMAIL = "email";
    public static final String WW = "WW";

    public static final String FILTER = "$filter";
    public static final String SUPPLYING_PLANT = "SUPPLYING_PLANT";

    public static final String L2_PROGRAM = "PROGRAM";
    public static final String L2_PLANT = "PLANT";
    public static final String L2_PO_CLASS = "SapOpenPOInput";

    @On(event = CdsService.EVENT_READ, entity = PlantData_.CDS_NAME)
    public void onResultFilterplantData(CdsReadEventContext context) {

        final String geoData;
        CqnSelect sel = null;
        UserInfo userInfo = context.getUserInfo();
        if (userInfo != null) {
            Map<String, List<String>> attributes = userInfo.getAttributes();
            List<String> geo = attributes.get("Geo");
            String list1 = String.join(",", geo);
            geoData = geo.stream().map(Object::toString).collect(Collectors.joining(","));
            String[] splitgeo = geoData.split(",");
            if (list1.contentEquals("WW")) {
                sel = Select.from(PlantData_.class).orderBy(c -> c.get(L2_PLANT).asc());
                LOGGER.info("if condition");
            } else {
                LOGGER.info("else if conditon");
                sel = Select.from(PlantData_.class).where(nr -> nr.REGION().in(splitgeo)).orderBy(c -> c.get(L2_PLANT).asc());
            }

        }

        context.setResult(db.run(sel));

    }

    @On(event = CdsService.EVENT_READ, entity = ProgramData_.CDS_NAME)
    public void onResultFilterprogramData(CdsReadEventContext context) {
        String jwtEmail = handlerUtils.getValueFromContextToken(context, EMAIL);
        CqnSelect sel = Select.from(ProgramData_.class)
                .where(nr -> nr.USER_EMAIL().eq(jwtEmail).and(nr.get("DEACT_FLAG").eq(true))).orderBy(c -> c.get("ATTRIBUTE_VALUE").asc());
        context.setResult(db.run(sel));
    }

    @On(event = CdsService.EVENT_READ, entity = ProfileData_.CDS_NAME)
    public void onResultFilterProfileData(CdsReadEventContext context) {
        String[] splitGeo;
        String list1 = "";
        String jwtEmail = handlerUtils.getValueFromContextToken(context, EMAIL);
        List<String> programList = handlerUtils.getProgramListFromEmail(jwtEmail);
        String geoData = "";
        UserInfo userInfo = context.getUserInfo();
        if (userInfo != null) {
            Map<String, List<String>> attributes = userInfo.getAttributes();
            List<String> geo = attributes.get("Geo");
            list1 = String.join(",", geo);
            geoData = geo.stream().map(Object::toString).collect(Collectors.joining(","));
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingGeo());
        }
        CqnSelect profileSel = null;
        if (list1.contentEquals("WW")) {
            profileSel = Select.from(ProfileData_.class).where(nr -> nr.get(L2_PROGRAM).in(programList)).orderBy(c -> c.get("PROFILE_NAME").asc());
        } else {
            splitGeo = geoData.split(",");
            profileSel = Select.from(ProfileData_.class)
                    .where(nr -> nr.GEO().in(splitGeo).and(nr.get(L2_PROGRAM).in(programList))).orderBy(c -> c.get("PROFILE_NAME").asc());
        }

        context.setResult(db.run(profileSel));

    }

    @On(event = CdsService.EVENT_READ, entity = ApiInventory_.CDS_NAME)
    public void onAPIInventory(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromPlantAndProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("Select modifiedSelectQuery : {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }

    @On(event = CdsService.EVENT_READ, entity = ApiPackout_.CDS_NAME)
    public void onAPIPackout(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(ApiInputPackOut_.CDS_NAME).asRef();
            }

        });

        if (filter != null) {
           
            String plant = handlerUtils.getDNPlantFromFilter(filter);
            String program = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.plantCheck(context, plant) && handlerUtils.programCheck(context, program)) {
                Map<String, Object> paramValues = new HashMap<>();
                paramValues.put(PLANT, plant);
                paramValues.put(PROGRAM, program);
                context.setResult(db.run(select, paramValues));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }

        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
       
    }

    @On(event = CdsService.EVENT_READ, entity = Sappo_.CDS_NAME)
    public void onBeforeReadTstOpenPo(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(SapOpenPOInput_.CDS_NAME).asRef();
            }

        });

        if (filter != null) {
            LOGGER.info("Filter list: {}", filter);
            String plant = handlerUtils.getPlantFromFilter(filter);
            String program = handlerUtils.getProgramFromFilter(filter);
            String profilename = handlerUtils.getProfileFromFilter(filter);
            int profileId = handlerUtils.getProfileIdFromPlantAndProgram(profilename);
            if (handlerUtils.plantCheck(context, plant) && handlerUtils.programCheck(context, program)) {
                Map<String, Object> paramValues = new HashMap<>();
                paramValues.put(PLANT, plant);
                paramValues.put(PROGRAM, program);
                paramValues.put(PROFILEID, profileId);
                context.setResult(db.run(select, paramValues));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }

        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }

    @On(event = CdsService.EVENT_READ, entity = Sapdn_.CDS_NAME)
    public void onBeforeReadTstOpenDn(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(SapOpenDNInput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("Filter list is: {}", filter);
            String plant = handlerUtils.getDNPlantFromFilter(filter);
            String program = handlerUtils.getProgramFromFilter(filter);
            String profilename = handlerUtils.getProfileFromFilter(filter);
            int profileId = handlerUtils.getProfileIdFromPlantAndProgram(profilename);
            if (handlerUtils.plantCheck(context, plant) && handlerUtils.programCheck(context, program)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plant);
                paramValues1.put(PROGRAM, program);
                paramValues1.put(PROFILEID, profileId);

                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }


    @On(event = CdsService.EVENT_READ, entity = L2OemData_.CDS_NAME)
    public void onL2PrepAPIData(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(ApiL2PrepData_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("Filterlist is: {}", filter);
            String plant = handlerUtils.getDNPlantFromFilter(filter);
            String program = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.plantCheck(context, plant) && handlerUtils.programCheck(context, program)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plant);
                paramValues1.put(PROGRAM, program);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }


    @On(event = CdsService.EVENT_READ, entity = L2SapData_.CDS_NAME)
    public void onBeforeReadL2PrepSapOpenDn(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(SapL2Input_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("Filter is: {}", filter);
            String plantL2Sap = handlerUtils.getDNPlantFromFilter(filter);
            String programL2Sap = handlerUtils.getProgramFromFilter(filter);
            String profilename = handlerUtils.getProfileFromFilter(filter);
            int profileId = handlerUtils.getProfileIdFromPlantAndProgram(profilename);
           if (handlerUtils.plantCheck(context, plantL2Sap) && handlerUtils.programCheck(context, programL2Sap)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plantL2Sap);
                paramValues1.put(PROGRAM, programL2Sap);
                paramValues1.put(PROFILEID, profileId);

                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }

    @On(event = CdsService.EVENT_READ, entity = Oempo_.CDS_NAME)
    public void onOEMAPIPo(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromPlantAndProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info(" Query: {}", modifiedSelectQuery);
            context.setResult(result);
        }
       
    }


    @On(event = CdsService.EVENT_READ, entity = Oemdn_.CDS_NAME)
    public void onOEMAPIDn(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromPlantAndProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info(" The modifiedSelectQuery is : {}", modifiedSelectQuery);
            context.setResult(result);
        }
       
    }
    @On(event = CdsService.EVENT_READ, entity = BrowserDataObjects_.CDS_NAME)
    public void onResultDataBrowser(CdsReadEventContext context) {
        String[] splitGeo;
        
          CqnSelect selectStmt = null;
        UserInfo userInfo = context.getUserInfo();
        if (userInfo != null) {
            Set<String> roles = userInfo.getRoles();
            LOGGER.info("Role  List: {}", roles);
           
            String geoData = "";
            geoData = roles.stream().map(Object::toString).collect(Collectors.joining(","));
            splitGeo = geoData.split(",");
            selectStmt = Select.from(BrowserDataObjects_.class)
                    .where(nr -> nr.SCOPE().in(splitGeo));
            
        }

        context.setResult(db.run(selectStmt));

    }
    @On(event = CdsService.EVENT_READ, entity = RunOrderCv_.CDS_NAME)
    public void onRunOrderCV(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("modified Query is: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }


    @On(event = CdsService.EVENT_READ, entity = ProductProgram_.CDS_NAME)
    public void onProductProgram(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info(" ModifiedSelectQuery is: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }

    @On(event = CdsService.EVENT_READ, entity = RunAction_.CDS_NAME)
    public void onRunAction(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } 
    }


    @On(event = CdsService.EVENT_READ, entity = RunDisposition_.CDS_NAME)
    public void onRunDisposition(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("Printing the Query: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }

    @On(event = CdsService.EVENT_READ, entity = RunOrderItem_.CDS_NAME)
    public void onRunOrderItem(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info(" Printing the modifiedSelectQuery : {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }


    @On(event = CdsService.EVENT_READ, entity = RunFilterData_.CDS_NAME)
    public void onRunData(CdsReadEventContext context) {
      
       
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info(" Printing the modifiedSelectQuery Result : {}", modifiedSelectQuery);
            context.setResult(result);
        
    }

    @On(event = CdsService.EVENT_READ, entity = L1SapDataDn_.CDS_NAME)
    public void onL1SAPDataDN(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(SAPL1DNInput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("FilterList : {}", filter);
            String geo = handlerUtils.getGeoPlantFromFilter(filter);
            String program = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.geoCheck(context, geo) && handlerUtils.programCheck(context, program)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(GEO, geo);
                paramValues1.put(PROGRAM, program);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }


    @On(event = CdsService.EVENT_READ, entity = L1SapDataPo_.CDS_NAME)
    public void onL1SAPDataPO(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(SAPL1POInput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("Filterlist is: {}", filter);
            String geo1 = handlerUtils.getGeoFromFilter(filter);
            String program1 = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.geoCheck(context, geo1) && handlerUtils.programCheck(context, program1)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(GEO, geo1);
                paramValues1.put(PROGRAM, program1);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }


    @On(event = CdsService.EVENT_READ, entity = Datasetsummary_.CDS_NAME)
    public void onDatasetSummary(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(Apidatasetinput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("The filterList is: {}", filter);
            String plant1 = handlerUtils.getDNPlantFromFilter(filter);
            String program1 = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.plantCheck(context, plant1) && handlerUtils.programCheck(context, program1)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plant1);
                paramValues1.put(PROGRAM, program1);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }


    @On(event = CdsService.EVENT_READ, entity = Oemdashboardui_.CDS_NAME)
    public void onOemDashboard(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(OEMDASHBOARDInput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("filterlist : {}", filter);
            String plant2 = handlerUtils.getDNPlantFromFilter(filter);
            String program2 = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.plantCheck(context, plant2) && handlerUtils.programCheck(context, program2)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plant2);
                paramValues1.put(PROGRAM, program2);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }



    @On(event = CdsService.EVENT_READ, entity = Oemdatasetsummaryui_.CDS_NAME)
    public void onOemDatasetSummary(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        CqnSelect select = CQL.copy(context.getCqn(), new CqnModifier() {

            @Override
            public CqnStructuredTypeRef ref(StructuredTypeRef ref) {
                return CQL.entity(APIOEMDATASETSUMMARYInput_.CDS_NAME).asRef();
            }

        });
        if (filter != null) {
            LOGGER.info("filterlist : {}", filter);
            String plant3 = handlerUtils.getDNPlantFromFilter(filter);
            String program3 = handlerUtils.getProgramFromFilter(filter);
          
            if (handlerUtils.plantCheck(context, plant3) && handlerUtils.programCheck(context, program3)) {
                Map<String, Object> paramValues1 = new HashMap<>();
                paramValues1.put(PLANT, plant3);
                paramValues1.put(PROGRAM, program3);
               
                context.setResult(db.run(select, paramValues1));
            } else {
                throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getInvalidPlantProgram());
            }
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        }
    }

    

    @On(event = CdsService.EVENT_READ, entity = ViewSapDn_.CDS_NAME)
    public void onViewSapDN(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("SelectQuery is: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }


    @On(event = CdsService.EVENT_READ, entity = ViewSapPo_.CDS_NAME)
    public void onViewSapPO(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("modifiedSelectQuery : {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }


    @On(event = CdsService.EVENT_READ, entity = ScopeConfig_.CDS_NAME)
    public void onScopeConfig(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("Query is: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }



    @On(event = CdsService.EVENT_READ, entity = WorkflowConfig_.CDS_NAME)
    public void onWorkflowConfig(CdsReadEventContext context) {
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);
        if (filter == null) {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingPlantProgram());
        } else {
            Result result = handlerUtils.getFilteredResultFromProgram(context);
            CqnSelect cqn = context.getCqn();
            String modifiedSelectQuery = cqn.toString();
            LOGGER.info("query is: {}", modifiedSelectQuery);
            context.setResult(result);
        }
    }
}