/**
 * The Utilities class for the HandlersUtils
 * 
 *
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-27
 */

package customer.cedecapproject.util;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.cds.Result;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.persistence.PersistenceService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import customer.cedecapproject.exception.HandleException;

@Component
public class SharedUtilities {

    @Autowired
    PersistenceService db;

    public static final String EMAIL = "email";

    private static final Logger LOGGER = LoggerFactory.getLogger(SharedUtilities.class);

    public boolean plantCheck(String plant, String program, String token) throws HandleException {

        boolean isValid = false;
        try {

            Map<String, List<String>> tokenData = decryptToken(token);
            List<String> geoData = tokenData.get("geo");
            List<String> siteData = tokenData.get("site");
            List<String> emailData = tokenData.get(SharedUtilities.EMAIL);

            boolean isPgmValid = programCheck(program, emailData.get(0));

            if (isPgmValid) {
                isValid = siteAndGeoCheck(siteData, geoData, plant);
            }

        } catch (HandleException e) {
            throw new HandleException(e.getMessage(), e);
        }
        return isValid;

    }

    public Map<String, List<String>> decryptToken(String token) throws HandleException {
        Map<String, List<String>> mapData = new HashMap<>();

        ObjectMapper objectMapper = new ObjectMapper();
        String updatedString = token.substring(7, token.length() - 1);
        Base64.Decoder decoder = Base64.getDecoder();
        String[] chunks = updatedString.split("\\.");

        String body = new String(decoder.decode(chunks[1]), Charset.forName("US-ASCII"));

        Map<String, Object> map;
        List<String> authorisationList = new ArrayList<>();
        List<String> auth = new ArrayList<>();

        try {
            map = objectMapper.readValue(body, Map.class);
            if (map.containsKey("scope")) {
                auth = (List<String>) map.get("scope");
                authorisationList = auth.stream().map(e -> {
                    int position = e.indexOf('.');
                    return e.substring(position + 1).trim();
                }).collect(Collectors.toList());
            }
            mapData.put("roles", authorisationList);

            if (map.containsKey(SharedUtilities.EMAIL)) {
                String email = (String) map.get(SharedUtilities.EMAIL);
                List<String> emailList = new ArrayList<>();
                emailList.add(email);
                mapData.put(SharedUtilities.EMAIL, emailList);

            }
            if (map.containsKey("xs.user.attributes")) {
                HashMap<String, Object> userAttribute = (HashMap<String, Object>) map.get("xs.user.attributes");
                LOGGER.info("Inside userattribute is  {}", userAttribute);
                if (userAttribute.containsKey("Site") && userAttribute.get("Site") != null) {
                    List<String> siteList = (List<String>) userAttribute.get("Site");
                    LOGGER.info("sitelist is : {}", siteList);
                    mapData.put("site", siteList);

                }
                if (userAttribute.containsKey("Geo") && userAttribute.get("Geo") != null) {
                    List<String> geoList = (List<String>) userAttribute.get("Geo");
                    LOGGER.info("geolist is  {}", geoList);
                    mapData.put("geo", geoList);
                }

            }
        } catch (JsonProcessingException e) {
            throw new HandleException(e.getMessage(), e);

        }
        LOGGER.info("Print mapData {}", mapData);
        return mapData;
    }

    public boolean programCheck(String progarm, String email) throws HandleException {
        boolean isValid = false;

        List<String> dbProgramList = new ArrayList<>();

        try {

            CqnSelect sel = Select.from("T_CEDE_USER_ATTRIBUTE").columns(b -> b.get("ATTRIBUTE_VALUE"))
                    .where(c -> c.get("ATTRIBUTE").eq("CEDE_PROGRAM").and(c.get("USER_EMAIL").eq(email)));
            Result result = db.run(sel);

            LOGGER.info(" Program List is {}", dbProgramList);
            if (!dbProgramList.isEmpty() && result.stream().anyMatch(e -> e.get("program").equals(progarm))) {
                isValid = true;
                return isValid;
            }
        }

        catch (Exception e) {
            throw new HandleException(e.getMessage(), e);
        } finally {

            LOGGER.info("##### Ending SharedUtilities.programCheck  #####");
        }
        return isValid;
    }

    // In-Progress
    private boolean siteAndGeoCheck(List<String> siteList, List<String> geoList, String plant) {
        LOGGER.info("##### Starting SharedUtilities.siteCheckDB()  #####");

        boolean isSuccess = false;
        String site = "";
        String geo = "";

        if (siteList != null && !siteList.isEmpty()) {
            site = String.join(",", siteList);
        }

        if (geoList != null && !geoList.isEmpty()) {
            geo = String.join(",", geoList);
        }
        LOGGER.info("# Prinitng site {}", site);
        LOGGER.info("# Prinitng geo {}", geo);
        LOGGER.info("# Prinitng plant {}", plant);

        return isSuccess;
    }

}
