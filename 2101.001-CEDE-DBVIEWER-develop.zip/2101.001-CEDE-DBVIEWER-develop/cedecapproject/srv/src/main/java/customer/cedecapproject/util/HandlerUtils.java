/**
 * The Utils class for the Handlers
 * 
 *
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-27
 */

package customer.cedecapproject.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.stream.Collectors;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import com.sap.cds.Result;
import com.sap.cds.Row;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.authentication.JwtTokenAuthenticationInfo;
import com.sap.cds.services.cds.CdsReadEventContext;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cds.services.request.UserInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cds.gen.TCedeGeoMaster;
import cds.gen.TCedeGeoMaster_;
import cds.gen.TCedePlantMaster;
import cds.gen.TCedePlantMaster_;
import cds.gen.TCedeUserAttribute;
import cds.gen.TCedeUserAttribute_;
import cds.gen.cedeservice.ProfileData_;
import customer.cedecapproject.configbean.MessageConfig;
import customer.cedecapproject.exception.HandleException;

@Component
public class HandlerUtils {
    @Autowired
    PersistenceService db;

    @Autowired
    private SharedUtilities utils;

    @Autowired
    private MessageConfig messageConfig;

    private static final Logger LOGGER = LoggerFactory.getLogger(HandlerUtils.class);
    public static final String PLANT = "plant";
    public static final String PROGRAM = "program";
    public static final String EMAIL = "email";
    public static final String WW = "WW";
    public static final String FILTER = "$filter";
    private static final String PROGRAM_EQ_NULL = "PROGRAM eq null";
    private static final String SUPPLYING_PLANT_EQ_NULL = "SUPPLYING_PLANT eq null";
    public static final String SUPPLYING_PLANT = "SUPPLYING_PLANT";
    public static final String L2_PROGRAM = "PROGRAM";
    public static final String GEO = "GEO";
    public static final String GEO_PLANT = "GEO_PLANT";
    private static final String AND_OR = "and|or";
    private static final String FILTER_COMPARISON_SYMBOLS = "eq|ge|le|ne|gt|lt|bt";
    private static final String PROFILE_NAME_EQ_NULL = "PROFILE_NAME eq null";
    public static final String L2_PROFILE_NAME = "PROFILE_NAME";
    public static final String L2_PLANT = "PLANT";
    private static final String PLANT_EQ_NULL = "PLANT eq null";
    private static final String GEO_EQ_NULL = "GEO eq null";
    private static final String GEO_PLANT_EQ_NULL = "GEO_PLANT eq null";


    public Map<String, List<String>> getGeoPlantProgramList(CdsReadEventContext context) throws HandleException {
        Map<String, List<String>> returnMap = new HashMap<>();
        Map<String, List<String>> tokenData = new HashMap<>();

        // Fetching JWT Token
        JwtTokenAuthenticationInfo jwtAuthInfo = (JwtTokenAuthenticationInfo) context.getCdsRuntime()
                .getProvidedAuthenticationInfo();
        String jwt = jwtAuthInfo.getToken();
        // JWT Token for local testing

        try {
            // Decrypting Token and setting values from token
            tokenData = utils.decryptToken(jwt);
            List<String> geoInputList = tokenData.get("geo");
            String email = tokenData.get(EMAIL).get(0);
            String geoData = tokenData.get("geo").stream().map(Object::toString).collect(Collectors.joining(","));
            LOGGER.info("geoData: {}", geoData);

            // Fetching plant, GEO, program
            List<String> plantList = this.getPlantListFromGeo(geoInputList);
            List<String> geoList = this.getGeoListFromGeo(geoInputList);
            List<String> programList = this.getProgramListFromEmail(email);

            // Setting Return Params
            returnMap.put("geoList", geoList);
            returnMap.put("plantList", plantList);
            returnMap.put("programList", programList);
        } catch (Exception e) {
            throw new HandleException(e.getMessage(), e);
        }
        return returnMap;
    }

    public Map<String, Object> getParamMap(CdsReadEventContext context) {
        String plant = "";
        String program = "";
        Map<String, Object> cqnNamedValues = context.getCqnNamedValues();
        if (cqnNamedValues.containsKey(PLANT)) {
            plant = (String) cqnNamedValues.get(PLANT);
            LOGGER.info("Input Plant: {}", plant);
        }
        if (cqnNamedValues.containsKey(PROGRAM)) {
            program = (String) cqnNamedValues.get(PROGRAM);
            LOGGER.info("Input Program: {}", program);
        }
        Map<String, Object> paramValues = new HashMap<>();
        paramValues.put(PLANT, plant);
        paramValues.put(PROGRAM, program);
        return paramValues;
    }

    // Fetches plant List from DB based on Geo location
    public List<String> getPlantListFromGeo(List<String> geoInputList) {
        List<String> plantList;
        Result plantListRes;
        if (geoInputList.contains(WW)) {
            CqnSelect plantSel = Select.from(TCedePlantMaster_.class).columns(TCedePlantMaster.PLANT);
            plantListRes = db.run(plantSel);
        } else {
            CqnSelect plantRegSel = Select.from(TCedePlantMaster_.class).columns(TCedePlantMaster.PLANT)
                    .where(b -> b.get("REGION").in(geoInputList));
            plantListRes = db.run(plantRegSel);
        }
        plantList = plantListRes.stream().map(row -> row.get(L2_PLANT).toString()).collect(Collectors.toList());
        return plantList;
    }

    // Fetches Geo List from DB based on Geo location
    public List<String> getGeoListFromGeo(List<String> geoInputList) {
        List<String> geoList;
        Result geoListRes;
        if (geoInputList.contains(WW)) {
            CqnSelect geoSel = Select.from(TCedeGeoMaster_.class).columns(TCedeGeoMaster.GEO);
            geoListRes = db.run(geoSel);
        } else {
            CqnSelect geoRegSel = Select.from(TCedeGeoMaster_.class).columns(TCedeGeoMaster.GEO)
                    .where(b -> b.get("GEO").in(geoInputList));
            geoListRes = db.run(geoRegSel);
        }
        geoList = geoListRes.stream().map(row -> row.get("GEO").toString()).collect(Collectors.toList());
        return geoList;
    }

    // Fetch Program List from Email ID
    public List<String> getProgramListFromEmail(String email) {
        List<String> programList;
        CqnSelect programSel = Select.from(TCedeUserAttribute_.class).columns(TCedeUserAttribute.ATTRIBUTE_VALUE)
                .where(c -> c.get("ATTRIBUTE").eq("CEDE_PROGRAM").and(c.get("USER_EMAIL").eq(email)).and(c.get("DEACT_FLAG").eq(true)));
        Result programListRes = db.run(programSel);
        programList = programListRes.stream().map(row -> row.get("ATTRIBUTE_VALUE").toString())
                .collect(Collectors.toList());
        return programList;
    }

    public Map<String, Object> getPlantAndProgramParam(String plant, String program) {
        Map<String, Object> paramValues = new HashMap<>();
        paramValues.put(PLANT, plant);
        paramValues.put(PROGRAM, program);
        return paramValues;
    }

    public String getPlantFromFilter(String filter) {
        String plantData;
        List<String> filteredPlant = null;
        if (filter.contains(SUPPLYING_PLANT) && !filter.contains(SUPPLYING_PLANT_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            filteredPlant = map.get(SUPPLYING_PLANT);
            LOGGER.info("Filter Plant List: {}", filteredPlant);
        }
        plantData = String.join(",", filteredPlant);
        return plantData;
    }

    public String getDNPlantFromFilter(String filter) {
        String plantData;
        List<String> filteredPlant = null;
        if (filter.contains(L2_PLANT) && !filter.contains(PLANT_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            filteredPlant = map.get(L2_PLANT);
            LOGGER.info("Filter Plant List: {}", filteredPlant);
        }
        plantData = String.join(",", filteredPlant);
        return plantData;
    }

    public String getProgramFromFilter(String filter) {
        List<String> filteredProgram = null;
        String programData;
        if (filter.contains(L2_PROGRAM) && !filter.contains(PROGRAM_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            filteredProgram = map.get(L2_PROGRAM);
            LOGGER.info("Filter Program List: {}", filteredProgram);

        }
        programData = String.join(",", filteredProgram);
        return programData;
    }

    public String getGeoFromFilter(String filter) {
        List<String> filteredGeo = null;
        String geoData;
        if (filter.contains(GEO) && !filter.contains(GEO_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            filteredGeo = map.get(GEO);
            LOGGER.info("Filter GEO List: {}", filteredGeo);

        }
        geoData = String.join(",", filteredGeo);
        return geoData;
    }
    public String getGeoPlantFromFilter(String filter) {
        List<String> filteredGeo = null;
        String geoData;
        LOGGER.info("Filter1", filter);
        if (filter.contains(GEO_PLANT) && !filter.contains(GEO_PLANT_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            LOGGER.info("Filter1", filter);
            filteredGeo = map.get(GEO_PLANT);
           
            LOGGER.info("Filter GEO List: {}", filteredGeo);

        }
        geoData = String.join(",", filteredGeo);
        return geoData;
    }

    public String getProfileFromFilter(String filter) {
        List<String> filteredProfile = null;
        final String ProfileData;
        if (filter.contains(L2_PROFILE_NAME) && !filter.contains(PROFILE_NAME_EQ_NULL)) {
            Map<String, List<String>> map = convertStringTokenizerToMap(filter);
            filteredProfile = map.get(L2_PROFILE_NAME);
            LOGGER.info("Filter Profile List: {}", filteredProfile);

        }
        ProfileData = String.join(",", filteredProfile);
        return ProfileData;
    }

    public int getProfileIdFromPlantAndProgram(String profilename) {
        CqnSelect selprofilid = Select.from(ProfileData_.class).columns("PROFILE_ID")
                .where(nr -> nr.PROFILE_NAME().eq(profilename));
        Result profileRes = db.run(selprofilid);
        String first = profileRes.stream().findFirst().toString();
        LOGGER.info("Profile Id for plant and program  {}", first);
        List<String> profileLst = profileRes.stream().map(row -> row.get("PROFILE_ID").toString())
                .collect(Collectors.toList());
        LOGGER.info("Profile  {}", profileLst);
        int profileId = Integer.parseInt(first.substring(first.indexOf('=') + 1, first.indexOf('}')));
        LOGGER.info("profileId: {}", profileId);
        return profileId;
    }

    /**
     * convertStringTokenizerToMap - method for String Tokenizing filter
     * 
     * 
     */
    private Map<String, List<String>> convertStringTokenizerToMap(String filter) {
        String str = filter.replaceAll("['()]", "").trim();

        Map<String, List<String>> map = new HashMap<>();
        String key = null;
        String value = null;

        for (String actualElement : str.split(AND_OR)) {
            List<String> myList = null;
            key = actualElement.split(FILTER_COMPARISON_SYMBOLS)[0].trim();
            value = actualElement.split(FILTER_COMPARISON_SYMBOLS)[1].trim();
            if (value.contains("...")) {
                myList = new ArrayList<>(Arrays.asList(value.replace("...", ",").split(",")));
            } else {
                myList = new ArrayList<>(Arrays.asList(value));
            }

            if (map.containsKey(key)) {
                List<String> valueList = map.get(key);
                valueList.addAll(myList);
                map.put(key, valueList);
            } else {
                map.put(key, myList);
            }
        }
        return map;
    }

    public String getValueFromContextToken(CdsReadEventContext context, String key) {
        String outputValue = "";
        JwtTokenAuthenticationInfo jwtAuthInfo = (JwtTokenAuthenticationInfo) context.getCdsRuntime()
                .getProvidedAuthenticationInfo();
        String jwt = jwtAuthInfo.getToken();
        DecodedJWT jwtToken = JWT.decode(jwt);
        Claim emailClaim = jwtToken.getClaim(key);
        outputValue = emailClaim.asString();
        return outputValue;
    }

    public Result getFilteredResultFromPlantAndProgram(CdsReadEventContext context) {
        List<String> geoInputList;
        String email = getValueFromContextToken(context, EMAIL);
        UserInfo userInfo = context.getUserInfo();
        CqnSelect query = context.getCqn();
        LOGGER.info("Last stmt : {}", query);
        String filter = context.getParameterInfo().getQueryParams().get(FILTER);

        if (userInfo != null) {
            Map<String, List<String>> attributes = userInfo.getAttributes();
            geoInputList = attributes.get("Geo");
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingGeo());
        }

        List<String> plantList = getPlantListFromGeo(geoInputList);
        List<String> programList = getProgramListFromEmail(email);
        LOGGER.info("Input Plant Filter: {}", filter);
        Result result = db.run(query);
        for (Iterator<Row> i = result.iterator(); i.hasNext();) {
            Row row = i.next();
            if (!(plantList.contains(row.get(L2_PLANT)) && programList.contains(row.get(L2_PROGRAM)))) {
                i.remove();
            }
        }
        return result;
    }

    public boolean programCheck( CdsReadEventContext context, String program) {
        LOGGER.info("##### Strating HandlerUtils.programCheck  #####");
        boolean isValid = false;
        String email = getValueFromContextToken(context, EMAIL);
        List<String> dbProgramList = getProgramListFromEmail(email);
        LOGGER.info(" Program list is {}", dbProgramList);
        if (!dbProgramList.isEmpty() && dbProgramList.stream().anyMatch(e -> e.equals(program))) {
            isValid = true;
        }
        LOGGER.info("##### Ending HandlerUtils.programCheck  #####");
        return isValid;
    }

    public boolean plantCheck(CdsReadEventContext context, String plant) {
        LOGGER.info("##### Strating HandlerUtils.plantCheck  #####");
        boolean isValid = false;
        List<String> dbPlantList = getPlantfromContext(context);
        LOGGER.info(" Program List {}", dbPlantList);
        if (!dbPlantList.isEmpty() && dbPlantList.stream().anyMatch(e -> e.equals(plant))) {
            isValid = true;
        }
        LOGGER.info("##### Ending HandlerUtils.plantCheck  #####");
        return isValid;
    }


    public boolean geoCheck(CdsReadEventContext context, String geo) {
        LOGGER.info("##### Strating HandlerUtils.geoCheck  #####");
        boolean isValid = false;

        UserInfo userInfo = context.getUserInfo();
        List<String> geoInputList;
        Map<String, List<String>> attributes = userInfo.getAttributes();
        geoInputList = attributes.get("Geo");
        List<String> dbGeoList = this.getGeoListFromGeo(geoInputList);
        
       
        LOGGER.info(" Pgm list is {}", dbGeoList);
        if (!dbGeoList.isEmpty() && dbGeoList.stream().anyMatch(e -> e.equals(geo))) {
            isValid = true;
        }
        LOGGER.info("##### Ending HandlerUtils.geoCheck  #####");
        return isValid;
    }

    public List<String> getPlantfromContext(CdsReadEventContext context) {
        UserInfo userInfo = context.getUserInfo();
        List<String> plantList = null;
        List<String> geoInputList;
        if (userInfo != null) {
            Map<String, List<String>> attributes = userInfo.getAttributes();
            geoInputList = attributes.get("Geo");
            plantList = getPlantListFromGeo(geoInputList);
        } else {
            throw new ServiceException(ErrorStatuses.BAD_REQUEST, messageConfig.getMissingGeo());
        }
        return plantList;
    }


    public Result getFilteredResultFromProgram(CdsReadEventContext context) {
       
        String email = getValueFromContextToken(context, EMAIL);
        CqnSelect query = context.getCqn();
        LOGGER.info("Last stmt : {}", query);
        List<String> programList = getProgramListFromEmail(email);
        
        Result result = db.run(query);
        LOGGER.info("Last result : {}", result);
        for (Iterator<Row> i = result.iterator(); i.hasNext();) {
            Row row = i.next();
            if (!( programList.contains(row.get(L2_PROGRAM)))) {
                i.remove();
            }
        }
        LOGGER.info("Last result : {}", result);
        return result;
    }
   
}
