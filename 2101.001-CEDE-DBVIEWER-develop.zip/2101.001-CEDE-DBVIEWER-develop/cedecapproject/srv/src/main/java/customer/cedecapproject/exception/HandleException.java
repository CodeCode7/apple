/**
 * The HandleException exposes methods to handle the exception
 * 
 * 
 *
 * @author Sucharitha Rampally
 * @version 1.0
 * @since 2021-10-27
 */

package customer.cedecapproject.exception;



public class HandleException extends Exception{
    private static final long serialVersionUID = 1L;
    public HandleException(String message) {
        super(message);
    }
    public HandleException(String message, Throwable cause) {
        super(message);
    }
}
