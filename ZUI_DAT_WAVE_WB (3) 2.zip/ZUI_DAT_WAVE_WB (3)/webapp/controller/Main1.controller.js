sap.ui.jsview("ZUI_DAT_WORKBENCH_WAVES.view.ZUI_DAT_WORKBENCH_WAVES", {
	createContent: function (oController) {

		if (typeof neptune === "undefined") neptune = {};
		if (typeof sap.nep === "undefined") sap.nep = {};
		var localAppID = "ZUI_DAT_WORKBENCH_WAVES";
		var sapNepAppID = "ZUI_DAT_WORKBENCH_WAVES-" + Date.now();
		if (!neptune.app) neptune.app = {};
		neptune.app[sapNepAppID] = {};
		neptune.app[sapNepAppID].id = sapNepAppID;
		var sapNepApp = neptune.app[sapNepAppID];
		if (!neptune.Formatter) {
			neptune.Formatter = {
				getTimePattern: function () {
					return "HH:mm"
				},
				getArabicDate: function (d) {
					return this.getDate(d);
				},
				getJapaneseDate: function (d) {
					return this.getDate(d);
				},
				getDateOData: function (d) {
					return this.getDate(d);
				},
				getDate: function (d) {
					if (typeof (d) === "undefined" || +d === 0) return "";
					jQuery.sap.require("sap.ui.core.format.DateFormat");
					var sapFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyyMMdd"
					});
					var outFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd.MM.yyyy",
						relative: false
					});
					var date = sapFormat.parse(d);
					return outFormat.format(date);
				},
				getNumber: function (n) {
					if (typeof (n) === "undefined" || +n === 0) return "";
					jQuery.sap.require("sap.ui.core.format.NumberFormat");
					var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
						maxFractionDigits: 1,
						minFractionDigits: 1,
						groupingEnabled: true,
						groupingSeparator: " ",
						decimalSeparator: "."
					});
					return numberFormat.format(n);
				},
				getTime: function (t) {
					if (typeof (t) === "undefined" || +t === 0) return "";
					if (typeof (t) === "undefined") return;
					jQuery.sap.require("sap.ui.core.format.DateFormat");
					var sapFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "HHmmss"
					});
					var outFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "HH:mm",
						relative: false
					});
					var date = sapFormat.parse(t);
					return outFormat.format(date);
				},
				setDisplayFormatType: function () {}
			}
		}
		if (!neptune.Formatter.getNumberType) {
			neptune.Formatter.getNumberType = function () {
				new sap.ui.model.type.Float({
					maxFractionDigits: 1,
					minFractionDigits: 1,
					groupingEnabled: true,
					groupingSeparator: " ",
					decimalSeparator: "."
				})
			}
		}

		sapNepApp.onAjaxError = function (code, reason, responseText) {};
		var localViewID = this.getId();
		//GLOBAL SCRIPT
		// ************************************************************************
		// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
		// * TITLE           : Workbench Wave App                                 *
		// * CREATED BY      : Valluru Sivaprasad                                 *
		// * CREATION DATE   : 02-Jul-2020                                        *
		// * BHU#            : BHU26843                                           *
		// * DESCRIPTION     : Workbench Wave App                                 *
		// ************************************************************************
		// *-----------------------********************---------------------------*
		// * Date        Programmer      Ticket     Description     Correction    *
		// *-----------  ------------    --------   ------------    -----------   *
		// * 22/05/2020  C5170694AG      60780390   Initial          DV5K927345   *
		// * 07/07/2020  C5162473NS      64699425   Initial          DV5K929086   *
		// * Last selected Week n profile  changes                                *
		// * 07/30/2020  C5162473NS      64699425   Initial          DV5K930002   *
		// * Default profile busy indicator issue                                 *
		// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
		// * Adding ZTDATUI_FLAG support to DAT6 portal UI                                                       *
		// * 03/24/2021  C5191496DJ     75419527    DAT-FY21         DV5K934693   *
		// * Populate only error messages for wave creation job status log        *
		// * 75636871 - Select All option for Sales Org                           *
		// * 75583227 - Display Multi Start Time  on Wave Summary and workbench   *
		// * 20/04/2021  C8805215PR     75206871    DAT-FY21         DV5K934693   *
		// * CVC Cross profile variant
		//*06/07/2021  C5191496DJ DV5K935147
		// * 11/06/2021  C8805215PR     78974891  Cross Profile Fix  DV5K935147  *
		// * 22/06/2021  C8805215PR     79487989    DAT-FY21         DV5K935444   *
		// * Default Variant flag
		//*04/19/2022  C8852945SN DV5K938119
		// * 04/19/2022   C8852945SN     90318902    DAT-FY22        DV5K938119   *
		// * Changes for PLA
		// * 05/27/2022. C8852945SN.    93965772.   DAT-FY22         DV5K938858
		// ************************************************************************
		String.prototype.trim = function () {
			return this.replace(/^\s+|\s+$/g, '');
		}
		var url = "/sap/opu/odata/SAP/ZSRV_VARIANT_DETAILS_SRV";
		var aVariantData = [];
		var aVariantvalue = {};
		var gDDMap = new Map([]);
		var gHelpLink = '';
		var gVflg = 'X'; // DV5K934693
		/*
		    Define Global variables

		*/
		var gSelTblProfile;
		var gSelTblWeek;
		var gSelTblSchGuid;
		var gSelTblScheduleAt;
		var gSelTblRegion;
		var gSelTblCvcVariant;
		var gDispVariant = [];

		var gMPNIncIdx;
		var gMPNExcIdx;
		var gCVCSTIncIdx;
		var gCVCSTExcIdx;
		var gWBMode;
		var gWBProfile;
		var gWBProfileValue;
		var gWBRegion;
		var gWBWeek;
		var gWBWeekValue;
		var gWBSchGuid;

		var gdefault_cvc_var = "";
		var global_cvc_var = "";
		var gVariantDesc = '';
		var gMPNWhichPaste = '';
		var gCVCSoldToWhichPaste = '';
		var gWaveModel;
		var gMPNBasicTblList;
		var gWaveProfileSelRegion;
		// var gWeekData = [];
		var gWaveProfile = [];
		var gUploadErrorType;
		let gConfig = {
			metadataUrlParams: {},
			json: true,
			defaultBindingMode: "TwoWay",
			defaultCountMode: "Inline",
			useBatch: true
		};
		var gCVCOpsSubclassMap = new Map([]);
		var gCVCMPNMap = new Map([]);
		var gCVCSalesOrgMap = new Map([]);
		var gCVCChannelMap = new Map([]);
		var gCVCSoldToMap = new Map([]);
		var gRegionVals = new sap.m.Select();

		function onInit() {
			sap.ui.core.BusyIndicator.show(0);
			_initODataModel();
			mpnAndSoldToPopupAdvSelDD();
			//Wave_InfoLabel.setText('Total - 0');
			WaveCount_Text.setText('Total - 0');
			//WS_InfoLabel.setText('Total - 0');
			WSCount_Text.setText('Total - 0');
			gWaveProfileSelRegion = gWBRegion;
			getWeekDD();
			get_variant("X");
			// getVarient("WS_Table");
			// getVarient_wave("Wave_Table");
			setVariantOptions();
			gMainMRef.getData().CVCSTIncListData = [];
			gMainMRef.getData().CVCSTExcListData = [];
			gMainMRef.getData().MPNIncListData = [];
			gMainMRef.getData().MPNExcListData = [];
			// Region for UBP
			get_region();
			wave_rel();
			waveDDData();
		}

		/*
		    Define oData and JSON Models.
		*/
		function _initODataModel(sModelName) {
			//Wave Service
			gWaveModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZOD_DAT_CVC_WAVE_SRV', gConfig);
			gWaveModel.setSizeLimit(2000);
			//Define the variant service here only once
			gVarModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZOD_NAD_SCREEN_VARIANT_SRV', gConfig);
			gVarModel.setSizeLimit(2000);

			gWBModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZOD_DAT_WAVE_WORKBENCH_SRV', gConfig);
			gWBModel.setSizeLimit(2000);

			gMainMRef = new sap.ui.model.json.JSONModel();
			gMainMRef.setSizeLimit(10000);

			gMainMRef.getData().oa = {};
			goa = gMainMRef.getData().oa;

			gRollModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZOD_DAT_RCA_BY_PROFILE_SRV', gConfig);
			gRollModel.setSizeLimit(2000);
		}

		/*
		    Get Week
		*/
		function getWeekDD() {
			oProfileForm_Week.removeAllItems();
			//var aWeekData = [];
			var fwPromise = $.Deferred();
			gWaveModel.read('/WaveWeekSet', {
				success: function (oData, resp) {
					fwPromise.resolve();
					gWeekData = oData;
				},
				error: function (oError) {
					fwPromise.resolve();
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					fwPromise
				]
			).then($.proxy(function () {
				var len = gWeekData.results.length;
				var currWeekKey = '';
				var profile = '';
				var region = '';
				for (var i = 0; i < len; i++) {
					var wd = gWeekData.results[i];
					oProfileForm_Week.addItem(new sap.ui.core.Item({
						key: wd.FiscWeek,
						text: wd.Description
					}));
					if (wd.CurrentWeek) {
						currWeekKey = wd.FiscWeek;
						profile = wd.Secprofile;
						region = wd.Region;
					}
					gHelpLink = wd.HelpLink;
				}
				if (gWBMode == 'C' || gWBMode == 'E') {
					oProfileForm_Week.setSelectedKey(gWBWeek);
					_getWeekDesc(gWBWeek);
					getWeekProfile(gWBWeek, '', '');
				} else {
					oProfileForm_Week.setSelectedKey(currWeekKey);
					_getWeekDesc(currWeekKey);
					getWeekProfile(currWeekKey, profile, region);
				}

			}));
		}

		function _getWeekDesc(iWeekSel) {

			for (var i = 0; i < gWeekData.results.length; i++) {
				var wd = gWeekData.results[i];
				if (wd.FiscWeek == iWeekSel) {
					gWBWeekValue = wd.Description;
				}
			}
		}
		/*
		    Wave Profile Drop down
		*/

		function getWeekProfile(iFiscWeek, Profile, Region) {
			oProfileForm_Profile.removeAllItems();
			var profData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, iFiscWeek));
			var wpPromise = $.Deferred();
			gWaveModel.read('/ProfileListSet', {
				filters: aFilters,
				urlParameters: {
					'$expand': 'NAVWeekProfile'
				},
				success: function (oData, resp) {
					if (oData.results.length > 0) {
						if (oData.results[0].NAVWeekProfile != undefined) {
							gWaveProfile = oData.results[0].NAVWeekProfile.results;
							var len = gWaveProfile.length;
							for (var i = 0; i < len; i++) {
								var pd = gWaveProfile[i];
								oProfileForm_Profile.addItem(new sap.ui.core.Item({
									key: pd.Secprofile,
									text: pd.Prof_Desc
								}));
								if (Profile) {
									if (Profile == pd.Secprofile && Region == pd.Region) {
										var xKey = pd.Secprofile;
									}
								}
							}
							if (xKey) {
								oProfileForm_Profile.setSelectedKey(xKey);
								onProfileChange();
							} else {
								//in case no default profile
								sap.ui.core.BusyIndicator.hide();
							}
						}
					} else {
						sap.ui.core.BusyIndicator.hide(); //DV5K935147
					}
					wpPromise.resolve();
				},
				error: function (oError) {
					wpPromise.resolve();
					sap.m.MessageToast.show('error week profile');
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					wpPromise
				]
			).then($.proxy(function () {

				if (gWBMode == 'C' || gWBMode == 'E') {
					oProfileForm_Profile.setSelectedKey(gWBProfile);
					//Has to be called here only because of aSync calls
					onProfileChange();
				}
			}));
		}

		function mpnAndSoldToPopupAdvSelDD() {
			//Include drop down
			MPNAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'CP',
				text: 'contains'
			}));
			MPNAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'EQ',
				text: 'equals'
			}));
			MPNAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'BW',
				text: 'begins with'
			}));
			MPNAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'EW',
				text: 'ends with'
			}));
			CVCSTAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'CP',
				text: 'contains'
			}));
			CVCSTAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'EQ',
				text: 'equals'
			}));
			CVCSTAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'BW',
				text: 'begins with'
			}));
			CVCSTAdvInc_Select.addItem(new sap.ui.core.Item({
				key: 'EW',
				text: 'ends with'
			}));
			//Include Sold To Popup drop downs
			MPNAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'CP',
				text: 'contains'
			}));
			MPNAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'EQ',
				text: 'equals'
			}));
			MPNAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'BW',
				text: 'begins with'
			}));
			MPNAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'EW',
				text: 'ends with'
			}));
			CVCSTAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'CP',
				text: 'contains'
			}));
			CVCSTAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'EQ',
				text: 'equals'
			}));
			CVCSTAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'BW',
				text: 'begins with'
			}));
			CVCSTAdvExc_Select.addItem(new sap.ui.core.Item({
				key: 'EW',
				text: 'ends with'
			}));
		}

		/*
		    Popup for any question marks ?
		*/
		function getF4Values(oEvent, iType, iTitle, iHeader) {
			PopoverList.setBusy(true);
			var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
			var tData = WS_Table.getModel().getData()[index];
			var oSchGuid = tData.SchGuid;
			//Reset model first.
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData([]);
			PopoverList.setModel(jModel);
			PopoverList.getModel().refresh();
			var xData = [];
			var ppData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, iType));
			aFilters.push(new sap.ui.model.Filter("SchGuid", sap.ui.model.FilterOperator.EQ, oSchGuid));
			var xPromise = $.Deferred();
			gWBModel.read('/WavePopDetSet', {
				filters: aFilters,
				success: function (oData, resp) {
					xPromise.resolve();
					xData = oData.results;

				},
				error: function (oError) {
					xPromise.resolve();
					PopoverList.setBusy(false);
				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {
				for (var i = 0; i < xData.length; i++) {
					var xd = xData[i];
					var yd = {
						Low: xd.Key,
						Txtsh: xd.Text
					}
					ppData.push(yd);
				}
				jModel.setData(ppData);
				PopoverList.setModel(jModel);
				PopoverList.getModel().refresh();
				PopoverList.setBusy(false);
			}));
			oPopoverNew.setTitle(iTitle);
			PopoverNew_Id.setText(iHeader);
			PopoverDemo_SearchField.setValue('');
			oPopoverNew.openBy(oEvent.getSource());
		}

		function _getWorkBenchData() {
			if (lz_cvcValidate()) {
				//sap.ui.core.BusyIndicator.show(0);
				var aCVC = [];
				//Ops Subclass
				var ops = oinpoSFormCVCOPS.getSelectedKeys();
				if (ops.length > 0) {
					for (var i = 0; i < ops.length; i++) {
						var xops = {
							Selname: 'OPSSUBCLASS',
							Kind: 'S',
							Sign: 'I',
							Option: 'EQ',
							Low: ops[i],
							High: '',
							Txtsh: ''
						};
						aCVC.push(xops);
					}
				}
				//MPN
				var len = oinpoSFormCVCMPN.getTokens().length;
				if (len > 0) {
					var mpnInc = false;
					var mpnExc = false;
					for (var i = 0; i < len; i++) {
						var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
						if (oToken == 'Include') {
							mpnInc = true;
						}
						if (oToken == 'Exclude') {
							mpnExc = true;
						}
					}
					if (mpnInc) {
						var len = gMainMRef.getData().MPNIncListData.length;
						if (len > 0) {
							for (var i = 0; i < len; i++) {
								var iData = gMainMRef.getData().MPNIncListData[i];

								var xops = {
									Selname: 'MPN',
									Kind: 'S',
									Sign: 'I',
									Option: iData.Option,
									Low: iData.Low,
									High: '',
									Txtsh: ''
								};
								aCVC.push(xops);
							}
						}
					}
					if (mpnExc) {
						var len = gMainMRef.getData().MPNExcListData.length;
						if (len > 0) {
							for (var i = 0; i < len; i++) {
								var eData = gMainMRef.getData().MPNExcListData[i];

								var xops = {
									Selname: 'MPN',
									Kind: 'S',
									Sign: 'E',
									Option: eData.Option,
									Low: eData.Low,
									High: '',
									Txtsh: ''
								};
								aCVC.push(xops);
							}
						}
					}
				}
				//Sales Org
				var so = oinpoSFormCVCSales.getSelectedKeys();
				if (so.length > 0) {
					for (var i = 0; i < so.length; i++) {
						var xops = {
							Selname: 'SALESORG',
							Kind: 'S',
							Sign: 'I',
							Option: 'EQ',
							Low: so[i],
							High: '',
							Txtsh: ''
						};
						aCVC.push(xops);
					}
				}
				//Channel
				var channel = oinpoSFormCVCChan.getSelectedKeys();
				if (channel.length > 0) {
					for (var i = 0; i < channel.length; i++) {
						var xops = {
							Selname: 'CHANNEL',
							Kind: 'S',
							Sign: 'I',
							Option: 'EQ',
							Low: channel[i],
							High: '',
							Txtsh: ''
						};
						aCVC.push(xops);
					}
				}
				//Sold To - We have to add the logic here.
				var len = oinpoSFormCVCSoldTo.getTokens().length;
				if (len > 0) {
					var stInc = false;
					var stExc = false;
					for (var i = 0; i < len; i++) {
						var oToken = oinpoSFormCVCSoldTo.getTokens()[i].getProperty('key');
						if (oToken == 'Include') {
							stInc = true;
						}
						if (oToken == 'Exclude') {
							stExc = true;
						}
					}
					if (stInc) {
						var len = gMainMRef.getData().CVCSTIncListData.length;
						if (len > 0) {
							for (var i = 0; i < len; i++) {
								var iData = gMainMRef.getData().CVCSTIncListData[i];

								var xops = {
									Selname: 'SOLDTO',
									Kind: 'S',
									Sign: 'I',
									Option: iData.Option,
									Low: iData.Low,
									High: '',
									Txtsh: ''
								};
								aCVC.push(xops);
							}
						}
					}
					if (stExc) {
						var len = gMainMRef.getData().CVCSTExcListData.length;
						if (len > 0) {
							for (var i = 0; i < len; i++) {
								var eData = gMainMRef.getData().CVCSTExcListData[i];

								var xops = {
									Selname: 'SOLDTO',
									Kind: 'S',
									Sign: 'E',
									Option: eData.Option,
									Low: eData.Low,
									High: '',
									Txtsh: ''
								};
								aCVC.push(xops);
							}
						}
					}
				}

				var aObj = {
					Secprofile: oProfileForm_Profile.getSelectedKey(),
					FiscWeek: oProfileForm_Week.getSelectedKey(),
					Region: gWaveProfileSelRegion,
					NAVWorkBWaveSch: [],
					NAVWorkBCVC: aCVC,
					NAVWorkBWaves: []
				};

				var wbResData = [];
				if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
					'') {
					sap.m.MessageToast.show('Please select the wave profile.');
					sap.ui.core.BusyIndicator.hide();
				} else {
					var xPromise = $.Deferred();
					gWBModel.create('/WaveWorkBenchSet', aObj, {
						success: function (oData, resp) {
							xPromise.resolve();
							wbResData = oData;
						},
						error: function (oError) {
							sap.m.MessageToast.show('Error');
							sap.ui.core.BusyIndicator.hide();
						}
					});
					Promise.all(
						[
							xPromise
						]
					).then($.proxy(function () {
						//Set workschedule data
						var jModel = new sap.ui.model.json.JSONModel();
						jModel.setSizeLimit(10000);
						jModel.setData([]);
						if (wbResData.NAVWorkBWaveSch != undefined) {
							if (wbResData.NAVWorkBWaveSch.results != undefined) {
								jModel.setData(wbResData.NAVWorkBWaveSch.results);
								if (wbResData.NAVWorkBWaveSch.results.length == 0) {
									// WS_InfoLabel.setText('Total - 0');
									WSCount_Text.setText('Total - 0');
								} else {
									// WS_InfoLabel.setText('Total - ' + wbResData.NAVWorkBWaveSch.results.length);
									WSCount_Text.setText('Total - ' + wbResData.NAVWorkBWaveSch.results.length);
								}
							}
						}
						WS_Table.setModel(jModel);
						WS_Table.getModel().refresh();

						//Set Wave data.
						var waveModel = new sap.ui.model.json.JSONModel();
						waveModel.setData([]);
						if (wbResData.NAVWorkBWaves != undefined) {
							if (wbResData.NAVWorkBWaves.results != undefined) {
								waveModel.setData(wbResData.NAVWorkBWaves.results);
								if (wbResData.NAVWorkBWaves.results.length == 0) {
									WaveCount_Text.setText('Total - 0');
									//Wave_InfoLabel.setText('Total - 0');
								} else {
									WaveCount_Text.setText('Total - ' + wbResData.NAVWorkBWaves.results.length);
									//Wave_InfoLabel.setText('Total - ' + wbResData.NAVWorkBWaves.results.length);
								}
							}
						}
						Wave_Table.setModel(waveModel);
						Wave_Table.getModel().refresh();

						sap.ui.core.BusyIndicator.hide();
					}));
				}
			}

		}

		function lz_cvcValidate() {
			var bReturn = true;
			var mpnRet = chgMPN();
			var soldToRet = chgSoldTo();
			if (mpnRet == false || soldToRet == false) {
				bReturn = false;
				if (mpnRet == false && soldToRet == false) {
					sap.m.MessageToast.show('Manual entry is not allowed - MPN & Sold To');
				} else {
					if (mpnRet == false) {
						sap.m.MessageToast.show('Manual entry is not allowed - MPN');
					} else if (soldToRet == false) {
						sap.m.MessageToast.show('Manual entry is not allowed - Sold To');
					}
				}

			}
			return bReturn;
		}

		function _saveEVariant(variant, vtext) {
			// * * * * * * * * * * * * * * * * * * * * Check Existing variant * * * * * * *
			// Boc Cross profile variant DV5K934693
			var sVariant;
			if (CVCSel_Label.getText() == undefined ||
				CVCSel_Label.getText() == null ||
				CVCSel_Label.getText() == '') {
				sVariant = variant;
			} else {
				sVariant = variant.split('(')[0]
				var xVarPrf = CVCSel_Label.getText().split('(')[1];
				var Profile = xVarPrf.split(')')[0];
			}
			// Eoc Cross profile variant DV5K934693
			var EaVARData = [];
			var EaFiltersvar = [];
			EaFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
			EaFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile.getSelectedKey()));
			EaFiltersvar.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, sVariant)); // Cross profile variant DV5K934693
			var EvarPromise = $.Deferred();
			gVarModel.read('/VariantDtlSet', {
				filters: EaFiltersvar,
				success: function (oData, resp) {
					EvarPromise.resolve();
					EaVARData = oData.results;
				},
				error: function (oError) {

					EvarPromise.resolve();
					sap.m.MessageToast.show(txtVariantODer);
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					EvarPromise
				]
			).then($.proxy(function () {
				// Boc Cross profile variant DV5K934693
				if (EaVARData.length > 0) {
					VSave_MessageStrip.setVisible(true);
					if (Profile == oProfileForm_Profile.getSelectedKey()) {
						VSave_MessageStrip.setText('Do you want to overwrite variant ' + sVariant + '?');
					} else {
						VSave_MessageStrip.setText('Do you want to overwrite variant ' + sVariant + ' under Profile ' + oProfileForm_Profile.getSelectedKey() +
							'?');
					}
					informVariantVARIANT.setEnabled(false);
					informVariantVTEXT.setEnabled(false);
					butVariantSaveOK.setVisible(false);
					butVariantProceed.setVisible(true);
					cb_cvc_global.setEnabled(false);
					cb_cvc_Default.setEnabled(false);
					sap.ui.core.BusyIndicator.hide();

				} else {
					if (Profile == oProfileForm_Profile.getSelectedKey() || // Insert  	DV5K935147	
						Profile == undefined || Profile == null ||
						Profile == '') {
						_saveVariant(sVariant, vtext);
					} else {
						VSave_MessageStrip.setVisible(true);
						VSave_MessageStrip.setText('Do you want to save variant ' + sVariant + ' under Profile ' + oProfileForm_Profile.getSelectedKey() +
							'?');
						informVariantVARIANT.setEnabled(false);
						informVariantVTEXT.setEnabled(false);
						butVariantSaveOK.setVisible(false);
						butVariantProceed.setVisible(true);
						cb_cvc_global.setEnabled(false);
						cb_cvc_Default.setEnabled(false);
						sap.ui.core.BusyIndicator.hide();
					}
				}
				// Eoc Cross profile variant
			}));
			// * * * * * * * * * * * * * * * * * * * * Check Existing variant * * * * * * *
		}

		function _saveVariant(variant, vtext) {
			var error = false;
			var s_output;

			var items = [];

			//OPS_SUBCLASS
			var tabOPS = oinpoSFormCVCOPS.getSelectedKeys();
			for (i = 0; i < tabOPS.length; i++) {
				items.push({
					"Selname": "OPS_SUBCLASS",
					"Kind": "S",
					"Sign": "I",
					"Zoption": "EQ",
					"Low": tabOPS[i],
					"High": " ",
				});

			}
			//Sales Org
			var tabVKO = oinpoSFormCVCSales.getSelectedKeys();
			for (i = 0; i < tabVKO.length; i++) {
				items.push({
					"Selname": "VKORG",
					"Kind": "S",
					"Sign": "I",
					"Zoption": "EQ",
					"Low": tabVKO[i],
					"High": " ",
				});

			}

			//Distribution Channel
			var tabDCH = oinpoSFormCVCChan.getSelectedKeys();
			for (i = 0; i < tabDCH.length; i++) {
				items.push({
					"Selname": "ZDISTC",
					"Kind": "S",
					"Sign": "I",
					"Zoption": "EQ",
					"Low": tabDCH[i],
					"High": " ",
				});

			}
			//MPN
			var len = oinpoSFormCVCMPN.getTokens().length;
			if (len > 0) {
				var mpnInc = false;
				var mpnExc = false;
				for (var i = 0; i < len; i++) {
					var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
					if (oToken == 'Include') {
						mpnInc = true;
					}
					if (oToken == 'Exclude') {
						mpnExc = true;
					}
				}
				if (mpnInc) {
					var len = gMainMRef.getData().MPNIncListData.length;
					if (len > 0) {
						for (var i = 0; i < len; i++) {
							var iData = gMainMRef.getData().MPNIncListData[i];
							var selnam = 'RULE_MATNR';
							if (iData.Type == "A") {
								selnam = 'RULE_MATNRA';
							}

							var xops = {
								Selname: selnam,
								Kind: 'S',
								Sign: 'I',
								Zoption: iData.Option,
								Low: iData.Low,
								High: '',

							};
							items.push(xops);
						}
					}
				}
				if (mpnExc) {
					var len = gMainMRef.getData().MPNExcListData.length;
					if (len > 0) {
						for (var i = 0; i < len; i++) {
							var eData = gMainMRef.getData().MPNExcListData[i];

							var selnam = 'RULE_MATNR';
							if (iData.Type == "A") {
								selnam = 'RULE_MATNRA';
							}
							var xops = {
								Selname: selnam,
								Kind: 'S',
								Sign: 'E',
								Zoption: eData.Option,
								Low: eData.Low,
								High: '',
							};
							items.push(xops);
						}
					}
				}
			}
			//SOLD TO
			var incList = gMainMRef.getData().CVCSTIncListData;
			var excList = gMainMRef.getData().CVCSTExcListData;
			for (var i = 0; i < incList.length; i++) {
				if (incList[i].Type == 'B') {
					var Binc = {
						Selname: 'KUNNR',
						Kind: incList[i].Kind,
						Sign: incList[i].Sign,
						Zoption: incList[i].Option,
						Low: incList[i].Low,
						High: incList[i].High,
					};
					items.push(Binc);
				} else if (incList[i].Type == 'A') { //Advance

					var Ainc = {
						Selname: 'KUNNR_A',
						Kind: incList[i].Kind,
						Sign: incList[i].Sign,
						Zoption: incList[i].Option,
						Low: incList[i].Low,
						High: incList[i].High,
					};
					items.push(Ainc);

				}
			}
			for (var i = 0; i < excList.length; i++) {
				if (excList[i].Type == 'A') { //Advance
					var Ainc = {
						Selname: 'KUNNR_A',
						Kind: excList[i].Kind,
						Sign: excList[i].Sign,
						Zoption: excList[i].Option,
						Low: excList[i].Low,
						High: excList[i].High,
					};
					items.push(Ainc);

				}
			}
			var lv_global = '';
			var lv_default = '';
			if (cb_cvc_Default.getSelected()) {
				lv_default = 'X';
			}
			if (cb_cvc_global.getSelected()) {
				lv_global = 'X';
			}
			var xVarObj = {
				Action: "SAVE",
				NAV_SESSHDR_VARHDR: [{
					"Applid": "ZUI_DAT",
					"Report": oProfileForm_Profile.getSelectedKey(),
					"Variant": variant,
					"Vtext": vtext,
					"Default_Flg": lv_default,
					"Global_Flg": lv_global,
					"NAV_VARHDR_VARDTL": items,
					"NAV_VARHDR_VARLST": [],
					"NAV_VARHDR_MSGDTL": []
				}],
			};
			var xPromise = $.Deferred();
			var agVarData = [];
			gVarModel.create('/SessionHdrSet', xVarObj, {
				success: function (oData, resp) {
					xPromise.resolve();
					agVarData = oData;
				},
				error: function (oError) {
					sap.m.MessageToast.show('Error');
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {
				s_output = agVarData.NAV_SESSHDR_VARHDR.results[0];
				//get message
				if (s_output.NAV_VARHDR_MSGDTL.results.length > 0) {
					var v_sucmsg = s_output.NAV_VARHDR_MSGDTL.results[0].Message;
					if (v_sucmsg) {
						jQuery.sap.require("sap.m.MessageToast");
						sap.m.MessageToast.show(v_sucmsg);
						getVariant();
						diaVariantSave.close();
					}
				}
				gESOPSSublassLength = oinpoSFormCVCOPS.getSelectedKeys().length;
				gESMPNLength = oinpoSFormCVCMPN.getTokens().length;
				gESSalesOrgLength = oinpoSFormCVCSales.getSelectedKeys().length;
				gESChannelLength = oinpoSFormCVCChan.getSelectedKeys().length;
				gESSoldToLength = oinpoSFormCVCSoldTo.getTokens().length;
				//prasad
				variant = variant + '(' + oProfileForm_Profile.getSelectedKey() + ')'; // DV5K934693
				CVCSel_Label.setText(variant);
				gVariantDesc = vtext;
				sap.ui.core.BusyIndicator.hide();
			}));

		}
		/*
		    UPLOAD LOGIC
		*/

		function createUpload(iErrorType, iWaveCreate) {
			goa.uploadHasErrors = false;
			Create_MessageStrip.setVisible(false);
			var l_secprofile = oProfileForm_Profile.getSelectedKey();
			var l_fiscweek = oProfileForm_Week.getSelectedKey();
			var l_value = "SchGuid:" + l_secprofile;
			l_value = l_value + "," + "FiscWeek:" + l_fiscweek;
			l_value = l_value + "," + "WaveCreate:" + iWaveCreate;
			l_value = l_value + "," + "ErrorType:" + iErrorType;

			var file = gWaveUploadFile;
			var oHeaders = {
				"x-csrf-token": ODataWS.getSecurityToken(),
				"slug": l_value,
				"Accept": "application/json",
				"content-type": "application/json"
			};
			jQuery.ajax({
				async: true,
				type: 'POST',
				url: "/sap/opu/odata/sap/ZOD_DAT_CVC_WAVE_SRV/WaveUploadSet",
				headers: oHeaders,
				cache: false,
				processData: false,
				data: file,
				success: function (data) {
					oWaveFileUpCr.setValue('');
					_checkUpdReturn(data);
				},
				error: function (oerror) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show('Error in Upload');
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}

		function _checkUpdReturn(data) {
			Create_MessageStrip.setVisible(true);
			/*
			New code below
			*/
			oIconTabBarSdwnload.setVisible(false); //Icon tab bar
			WUError_Panel.setVisible(true); //Panel is visible now.

			if (data.d.ErrorCount > 0) {
				goa.uploadHasErrors = true;
				Create_MessageStrip.setType('Error');
				gUploadErrorType = data.d.ErrorType;
				if (data.d.ErrorType == 'DATA') {
					Create_MessageStrip.setText('Upload wave has ' + data.d.ErrorCount + ' erorrs');
					WUProceed_Button.setVisible(false);
					_getUploadErrors(data.d.ErrorCount);

				}
				if (data.d.ErrorType == 'CUM' || data.d.ErrorType == 'LOT') {
					Create_MessageStrip.setText('Upload wave has ' + data.d.ErrorCount + ' erorrs, click on proceed to save changes.');
					WUProceed_Button.setVisible(true);
					_getUploadErrors(data.d.ErrorCount);
				}
			} else {
				_getUploadErrors(data.d.ErrorCount);
			}
		}

		function _getUploadErrors(iErrorCount) {
			WUError_Table.setBusy(true);
			var errData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Secprofile",
				sap.ui.model.FilterOperator.EQ,
				oProfileForm_Profile.getSelectedKey()));
			aFilters.push(new sap.ui.model.Filter("FiscWeek",
				sap.ui.model.FilterOperator.EQ,
				oProfileForm_Week.getSelectedKey()));
			var errPromise = $.Deferred();
			gWaveModel.read('/WaveUpMsgSet', {
				filters: aFilters,
				success: function (oData, resp) {
					errData = oData.results;
					errPromise.resolve();
				},
				error: function (oError) {
					WUError_Table.setBusy(false);
					errPromise.resolve();
					sap.m.MessageToast.show('error while getting upload error data');
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					errPromise
				]
			).then($.proxy(function () {
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);
				jModel.setData(errData);
				WUError_Table.setModel(jModel);
				WUError_Table.getModel().refresh();
				WUError_Table.setBusy(false);
				if (iErrorCount > 0) {
					sap.ui.core.BusyIndicator.hide();
				} else {
					goa.uploadHasErrors = false;
					WUProceed_Button.setVisible(false);
					Create_MessageStrip.setType('Success');
					Create_MessageStrip.setText('Successfully uploaded the file');
					gWaveUploadFile = '';
					_getWorkBenchData();
					sap.ui.core.BusyIndicator.hide();
				}
			}));
		}
		/*


		*/

		function clear() {
			//oSelectCVCVariant.setSelectedKey("");
			oinpoSFormCVCOPS.setSelectedKeys([]);
			oinpoSFormCVCSales.setSelectedKeys([]);
			oinpoSFormCVCChan.setSelectedKeys([]);
			oinpoSFormCVCMPN.destroyTokens();
			oinpoSFormCVCSoldTo.destroyTokens();
			Sorg_CheckBox.setSelected(false); // Insert DV5K934693
		}

		/*
		            GET VARIANT
		*/
		function getVariant() {
			var aVARData = [];
			var aVarData1 = [];
			var aFiltersvar = [];
			aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
			// BoC Wave Cross Variant DV5K934693
			aFiltersvar.push(new sap.ui.model.Filter("vFlg", sap.ui.model.FilterOperator.EQ, gVflg));
			// EoC Wave Cross Variant
			var varPromise = $.Deferred();
			gVarModel.read('/VariantListSet', {
				filters: aFiltersvar,
				success: function (oData, resp) {
					varPromise.resolve();
					for (var i = 0; i < oData.results.length; i++) {
						aVARData.push(oData.results[i]);
					}
				},
				error: function (oError) {
					varPromise.resolve();
					sap.m.MessageToast.show("Error");
				}
			});
			Promise.all(
				[
					varPromise
				]
			).then($.proxy(function () {
				var jModel = new sap.ui.model.json.JSONModel();
				// BoC Wave Cross Variant DV5K934693
				for (var i = 0; i < aVARData.length; i++) {
					if (aVARData[i].Applid.split("")[0].toUpperCase() + aVARData[i].Applid.split("")[1] === "W_") {} else {
						aVARData[i].Variant = aVARData[i].Variant + '(' + aVARData[i].Report + ')'
						aVarData1.push(aVARData[i]);
					}
				}
				jModel.setData(aVarData1);
				CVCSel_List.setModel(jModel);
				// EoC Wave Cross Variant
				var cvcData = CVCSel_List.getModel().getData();
				for (var i = 0; i < cvcData.length; i++) {
					var cd = cvcData[i];
					if (cd.Default_Flg == 'X') {
						cd.StarV = '#e69900';
					} else {
						cd.StarV = '#ffffff';
					}
					if (cd.Global_Flg == 'X') {
						cd.DelV = '#0070b1';
					} else {
						cd.DelV = '#ffffff';
					}
				}

				CVCSel_List.getModel().refresh();
			}));
		}

		function setStar() {
			var vtext = '';
			var defVar = '';
			CVCSel_Label.setText('');
			var cvcData = CVCSel_List.getModel().getData();
			for (var i = 0; i < cvcData.length; i++) {
				var cd = cvcData[i];
				if (cd.Default_Flg == 'X') {
					// Begin of DV5K935444
					var xVarPrf = cd.Variant.split('(')[1];
					var Profile = xVarPrf.split(')')[0];
					if (Profile === oProfileForm_Profile.getSelectedKey()) {
						CVCSel_Label.setText(cd.Variant);
						defVar = cd.Variant;
						vtext = cd.Vtext;
					} // End of DV5K935444
					cd.StarV = '#e69900';
				} else {
					cd.StarV = '#ffffff';
				}
				if (cd.Global_Flg == 'X') {
					cd.DelV = '#0070b1';
				} else {
					cd.DelV = '#ffffff';
				}
			}
			if (defVar != '') {
				gdefault_cvc_var = 'X';
				gVariantDesc = vtext;
				_setVariant(defVar);
			}
			CVCSel_List.getModel().refresh();
		}

		function _setVariant(iSelVar) {
			// BoC Wave Cross Variant DV5K934693
			var sProfile;
			var sVariant;
			if (CVCSel_Label.getText() == undefined ||
				CVCSel_Label.getText() == null ||
				CVCSel_Label.getText() == '') {
				sProfile = oProfileForm_Profile.getSelectedKey();
				sVariant = iSelVar;
			} else {
				sVariant = iSelVar.split('(')[0]
				var xVarPrf = iSelVar.split('(')[1];
				var Profile = xVarPrf.split(')')[0];
				sProfile = Profile;
			}
			// EoC Wave Cross Variant DV5K934693
			oinpoSFormCVCOPS.setBusy(true);
			oinpoSFormCVCMPN.setBusy(true);
			oinpoSFormCVCSales.setBusy(true);
			oinpoSFormCVCChan.setBusy(true);
			oinpoSFormCVCSoldTo.setBusy(true);
			var aVARData = [];
			var aFiltersvar = [];

			aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
			aFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, sProfile)); //DV5K934693
			aFiltersvar.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, sVariant)); //DV5K934693

			var varPromise = $.Deferred();
			gVarModel.read('/VariantDtlSet', {
				filters: aFiltersvar,
				success: function (oData, resp) {
					varPromise.resolve();
					aVARData = oData.results;
				},
				error: function (oError) {
					oinpoSFormCVCOPS.setBusy(false);
					oinpoSFormCVCMPN.setBusy(false);
					oinpoSFormCVCSales.setBusy(false);
					oinpoSFormCVCChan.setBusy(false);
					oinpoSFormCVCSoldTo.setBusy(false);
					varPromise.resolve();
					sap.m.MessageToast.show(txtVariantODer);
				}
			});
			Promise.all(
				[
					varPromise
				]
			).then($.proxy(function () {
				var tabval = aVARData;
				_setVariantToCVC(tabval);

				oinpoSFormCVCOPS.setBusy(false);
				oinpoSFormCVCMPN.setBusy(false);
				oinpoSFormCVCSales.setBusy(false);
				oinpoSFormCVCChan.setBusy(false);
				oinpoSFormCVCSoldTo.setBusy(false);

			}));
		}

		/*
		        ON PROFILE SELECTION CHANGE
		*/
		function onProfileChange() {
			var l_secprof = oProfileForm_Profile.getSelectedKey();

			if (l_secprof == undefined || l_secprof == null || l_secprof == '') {
				oProfileForm_Profile.setValueState('Error');
			} else {
				oProfileForm_Profile.setValueState('None');
			}

			//Derive Region
			for (var i = 0; i < gWaveProfile.length; i++) {
				var wpd = gWaveProfile[i];
				if (wpd.Secprofile == l_secprof) {
					gWaveProfileSelRegion = wpd.Region;
					gWBProfileValue = wpd.Prof_Desc;
				}
			}

			resetData();

			datui_lock_check(gWaveProfileSelRegion);
			/*Refresh models and instances for each selection or else old data is retained*/
			oinpoSFormCVCOPS.removeAllItems(); //OPS Drop down
			oinpoSFormCVCSales.removeAllItems(); //Sales Org Drop down
			oinpoSFormCVCChan.removeAllItems(); //Channel Drop down
			gCVCOpsSubclassMap = new Map([]);
			gCVCSalesOrgMap = new Map([]);
			gCVCChannelMap = new Map([]);
			gCVCMPNMap = new Map([]);
			gCVCSoldToMap = new Map([]);

			//Clear table data.
			WS_Table.getModel().setData([]);
			Wave_Table.getModel().setData([]);
			Tables_IconTabBar.setSelectedKey('WS');

			var aCVCData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, l_secprof));
			aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, oProfileForm_Week.getSelectedKey()));
			aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

			var cvcPromise = $.Deferred();
			gWaveModel.read('/SecprofileCVCSet', {
				filters: aFilters,
				urlParameters: {
					'$expand': 'NavSecprofCVC'
				},
				success: function (oData, resp) {
					cvcPromise.resolve();
					aCVCData = oData.results[0].NavSecprofCVC.results;
				},
				error: function (oError) {
					cvcPromise.resolve();
					sap.m.MessageToast.show('error week profile');
				}
			});
			Promise.all(
				[
					cvcPromise
				]
			).then($.proxy(function () {
				for (var i = 0; i < aCVCData.length; i++) {
					var cvc = aCVCData[i];
					if (cvc.Selname == 'OPSSUBCLASS')
						gCVCOpsSubclassMap.set(cvc.Low, cvc.Low);
					if (cvc.Selname == 'MPN')
						gCVCMPNMap.set(cvc.Low, cvc.Txtsh);
					if (cvc.Selname == 'VKORG')
						gCVCSalesOrgMap.set(cvc.Low, cvc.Txtsh);
					if (cvc.Selname == 'ZDISTC')
						gCVCChannelMap.set(cvc.Low, cvc.Low);
					if (cvc.Selname == 'KUNNR')
						gCVCSoldToMap.set(cvc.Low, cvc.Txtsh);

				}
				//OPS Subclass
				const mapSClass = new Map([...gCVCOpsSubclassMap.entries()].sort());
				for (let [key, value] of mapSClass) {
					oinpoSFormCVCOPS.addItem(new sap.ui.core.Item({
						key: key,
						text: value
					}));
				}
				//Sales Org
				//const mapSort2 = new Map([...gCVCSalesOrgMap.entries()].sort((a, b) => a[1] - b[1])); //sort by value
				const mapSalesOrg = new Map([...gCVCSalesOrgMap.entries()].sort());
				for (let [key, value] of mapSalesOrg) {
					oinpoSFormCVCSales.addItem(new sap.ui.core.ListItem({
						key: key,
						text: key,
						additionalText: value
					}));
				}
				oinpoSFormCVCSales.setShowSecondaryValues(true);

				//Channel
				const mapChannel = new Map([...gCVCChannelMap.entries()].sort());
				for (let [key, value] of mapChannel) {
					oinpoSFormCVCChan.addItem(new sap.ui.core.Item({
						key: key,
						text: value
					}));
				}
				/*
				    Fill MPN data.
				*/
				var mpnData = [];
				for (let [key, value] of gCVCMPNMap) {
					var xd = {
						Selname: '',
						Kind: '',
						Sign: '',
						Option: 'EQ',
						Low: key,
						High: '',
						Txtsh: value,
						Type: 'B'
					};
					mpnData.push(xd);
				}
				var stModel = new sap.ui.model.json.JSONModel();
				stModel.setSizeLimit(10000);
				stModel.setData(mpnData);
				MPNBasic_Table.setModel(stModel);
				var tbBinding = MPNBasic_Table.getBinding('items');
				var aSorter = [];
				var oSortKey = 'Low';
				var oDescending = false;
				var oGroup = false;
				aSorter.push(new sap.ui.model.Sorter(oSortKey, oDescending, oGroup))
				tbBinding.sort(aSorter);
				MPNBasic_Table.getModel().refresh();

				//Sold To - CVC Selection
				var soldToData = [];
				for (let [key, value] of gCVCSoldToMap) {
					var xd = {
						Selname: '',
						Kind: '',
						Sign: 'I',
						Option: 'EQ',
						Low: key,
						High: '',
						Txtsh: value,
						Type: 'B'
					};
					soldToData.push(xd);
				}
				var stModel = new sap.ui.model.json.JSONModel();
				stModel.setSizeLimit(10000);
				stModel.setData([]);
				stModel.setData(soldToData);
				CVCSTBasic_Table.setModel(stModel);
				var tbBinding = CVCSTBasic_Table.getBinding('items');
				var aSorter = [];
				var oSortKey = 'Low';
				var oDescending = false;
				var oGroup = false;
				aSorter.push(new sap.ui.model.Sorter(oSortKey, oDescending, oGroup))
				tbBinding.sort(aSorter);
				CVCSTBasic_Table.getModel().refresh();

				/*GET VARIANT DROP DOWN DATA.*/
				var aVARData = [];
				var aVarData1 = [];
				var aFiltersvar = [];
				aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
				aFiltersvar.push(new sap.ui.model.Filter("vFlg", sap.ui.model.FilterOperator.EQ, gVflg)); //DV5K934693

				var varPromise = $.Deferred();
				gVarModel.read('/VariantListSet', {
					filters: aFiltersvar,
					success: function (oData, resp) {
						varPromise.resolve();
						for (var i = 0; i < oData.results.length; i++) {
							aVARData.push(oData.results[i]);
						}
					},
					error: function (oError) {
						varPromise.resolve();
						sap.m.MessageToast.show("Error");
					}
				});
				Promise.all(
					[
						varPromise
					]
				).then($.proxy(function () {
					var jModel = new sap.ui.model.json.JSONModel();
					// BoC Wave Cross Variant DV5K934693
					for (var i = 0; i < aVARData.length; i++) {
						if (aVARData[i].Applid.split("")[0].toUpperCase() + aVARData[i].Applid.split("")[1] === "W_") {} else {
							aVARData[i].Variant = aVARData[i].Variant + '(' + aVARData[i].Report + ')'
							aVarData1.push(aVARData[i]);
						}
					}
					jModel.setData(aVarData1);
					CVCSel_List.setModel(jModel);
					// EoC Wave Cross Variant
					setStar();
					_getWorkBenchData();
				}));
			}));
		}

		function resetData() {
			oinpoSFormCVCOPS.removeAllItems(); //OPS Drop down
			oinpoSFormCVCOPS.destroyItems();
			//MPN
			oinpoSFormCVCMPN.setValue() == '';
			oinpoSFormCVCMPN.setValueState('None');
			oinpoSFormCVCMPN.setValueStateText('');
			oinpoSFormCVCMPN.removeAllTokens(); //remove all items MPN
			modelMPNBasic_Table.setData([]); //MPN basic table
			MPNBasic_Table.setModel(modelMPNBasic_Table);
			gMainMRef.getData().MPNIncListData = [];
			gMainMRef.getData().MPNExcListData = [];
			//Sales Org
			oinpoSFormCVCSales.removeAllItems();
			//Channel
			oinpoSFormCVCChan.removeAllItems();
			//Sold To
			oinpoSFormCVCSoldTo.setValue() == '';
			oinpoSFormCVCSoldTo.setValueState('None');
			oinpoSFormCVCSoldTo.setValueStateText('');
			oinpoSFormCVCSoldTo.removeAllTokens();
			gMainMRef.getData().CVCSTIncListData = [];
			gMainMRef.getData().CVCSTExcListData = [];
			//reset selection text
			MPNBasicInfoTB_Text.setText('');
			CVCSTBasicInfoTB_Text.setText('');
		}

		/*
		            CALL BACK FUNCTION COMING FROM WAVE CREATE
		*/
		function callBackCW() {
			sap.ui.core.BusyIndicator.show(0);
			_getWorkBenchData();
		}

		function callBack() {

		}

		function _setVariantToCVC(tabval) {
			if (tabval.length > 0) {

				var tabops = [];
				var tabvko = [];
				var tabdch = [];
				var mpnBasic = [];
				var mpnAdvInc = [];
				var mpnAdvExc = [];
				var soldToBasic = [];
				var soldToAdvInc = [];
				var soldToAdvExc = [];

				//reset values
				oinpoSFormCVCOPS.setSelectedKeys(tabops);
				oinpoSFormCVCSales.setSelectedKeys(tabvko);
				oinpoSFormCVCChan.setSelectedKeys(tabdch);
				oinpoSFormCVCSoldTo.destroyTokens();
				//MPN
				oinpoSFormCVCMPN.destroyTokens();
				gMainMRef.getData().CVCSTIncListData = [];
				gMainMRef.getData().CVCSTExcListData = [];

				//CVC Sold To
				gMainMRef.getData().MPNIncListData = [];
				gMainMRef.getData().MPNExcListData = [];

				$.each(tabval, function (i, data) {
					switch (data.Selname) {
					case "OPS_SUBCLASS":
						if (gCVCOpsSubclassMap.has(data.Low))
							tabops.push(data.Low);
						break;

					case "VKORG":
						if (gCVCSalesOrgMap.has(data.Low))
							tabvko.push(data.Low);
						break;

					case "ZDISTC":
						if (gCVCChannelMap.has(data.Low))
							tabdch.push(data.Low);

						break;

					case "RULE_MATNR":
						if (gCVCMPNMap.has(data.Low)) {
							var xd = {
								Selname: '',
								Kind: '',
								Sign: data.Sign,
								Option: data.Zoption,
								Low: data.Low,
								High: data.High,
								Txtsh: '',
								Type: 'B'
							};
							if (data.Sign == "I") {
								gMainMRef.getData().MPNIncListData.push(xd);
							} else {
								gMainMRef.getData().MPNExcListData.push(xd);
							}
							mpnBasic.push(xd);
							xd = {};
						}
						break;

					case "RULE_MATNRA":
						var xd = {
							Selname: '',
							Kind: '',
							Sign: data.Sign,
							Option: data.Zoption,
							Low: data.Low,
							High: '',
							Txtsh: '',
							Type: 'A'
						};
						// if (data.Zoption == 'CP') {
						//     var xLow = data.Low;
						//     var fLow = xLow.substring(1, xLow.length);
						//     var lLow = fLow.substring(0, fLow.length - 1);
						//     xd.Low = lLow;
						// }
						if (data.Sign == "I") {
							mpnAdvInc.push(xd);
							gMainMRef.getData().MPNIncListData.push(xd);
						} else {
							mpnAdvExc.push(xd);
							gMainMRef.getData().MPNExcListData.push(xd);
						}
						xd = {};
						break;

					case "KUNNR": //basic
						if (gCVCSoldToMap.has(data.Low)) {
							var xd = {
								Selname: '',
								Kind: '',
								Sign: data.Sign,
								Option: data.Zoption,
								Low: data.Low,
								High: '',
								Txtsh: '',
								Type: 'B'
							};
							if (data.Sign == "I") {
								gMainMRef.getData().CVCSTIncListData.push(xd);
							} else {
								gMainMRef.getData().CVCSTExcListData.push(xd);
							}
							soldToBasic.push(xd);
							xd = {};
						}
						break;
					case "KUNNR_A": //Advance
						var xd = {
							Selname: '',
							Kind: '',
							Sign: data.Sign,
							Option: data.Zoption,
							Low: data.Low,
							High: '',
							Txtsh: '',
							Type: 'A'
						};
						// if (data.Zoption == 'CP') {
						//     var xLow = data.Low;
						//     var fLow = xLow.substring(1, xLow.length);
						//     var lLow = fLow.substring(0, fLow.length - 1);
						//     xd.Low = lLow;
						// }
						if (data.Sign == "I") {
							soldToAdvInc.push(xd);
							gMainMRef.getData().CVCSTIncListData.push(xd);
						} else {
							soldToAdvExc.push(xd);
							gMainMRef.getData().CVCSTExcListData.push(xd);
						}
						xd = {};
						break;
					default:
						//execute code default
						break;
					} // Switch
				});

				oinpoSFormCVCOPS.setSelectedKeys(tabops);
				oinpoSFormCVCSales.setSelectedKeys(tabvko);
				oinpoSFormCVCChan.setSelectedKeys(tabdch);
				Sorg_Select(); // Insert DV5K934693
				/*
				    New MPN - begin

				*/
				var bItems = MPNBasic_Table.getItems();
				for (var i = 0; i < bItems.length; i++) {
					bItems[i].setSelected(false);
				}
				var incList = gMainMRef.getData().MPNIncListData;
				var excList = gMainMRef.getData().MPNExcListData;

				if (mpnBasic.length > 0) {
					var txtin = 'Inc(' + mpnBasic.length + ')';
					oinpoSFormCVCMPN.addToken(new sap.m.Token({
						key: 'Include',
						text: txtin,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalst = gMainMRef.getData().MPNIncListData;
							for (var i in datalst) {
								var newmatlst = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: datalst[i].Option,
									Low: datalst[i].Low,
									High: '',
									Txtsh: datalst[i].Txtsh,
									Type: 'B'
								};
								objArray.push(newmatlst);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('MPN');
							// PopoverNew_Id.setText('MPN');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('MPN');
							MPNSTPO_Id.setText('MPN');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				}

				//advance tab include
				if (mpnAdvInc.length > 0) {
					var txtin = 'Inc(' + mpnAdvInc.length + ')';
					oinpoSFormCVCMPN.addToken(new sap.m.Token({
						key: 'Include',
						text: txtin,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalst = gMainMRef.getData().MPNIncListData;
							for (var i in datalst) {
								var newmatlst = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: datalst[i].Option,
									Low: datalst[i].Low,
									High: '',
									Txtsh: datalst[i].Txtsh,
									Type: 'A'
								};
								objArray.push(newmatlst);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('MPN');
							// PopoverNew_Id.setText('MPN');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('MPN');
							MPNSTPO_Id.setText('MPN');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				} else {
					setMPNTitle('Initial', 'I');
					MPNAdvInclude_List.setModel(setMPNInitial('I'));
				}

				if (mpnAdvExc.length > 0) {
					var txtex = 'Exc(' + mpnAdvExc.length + ')';
					oinpoSFormCVCMPN.addToken(new sap.m.Token({
						key: 'Exclude',
						text: txtex,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalstex = gMainMRef.getData().MPNExcListData;
							for (var i in datalstex) {
								var newmatlstex = {
									Selname: '',
									Kind: '',
									Sign: 'E',
									Option: datalstex[i].Option,
									Low: datalstex[i].Low,
									High: '',
									Txtsh: datalstex[i].Txtsh,
									Type: 'A'

								};
								objArray.push(newmatlstex);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('MPN');
							// PopoverNew_Id.setText('MPN');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('MPN');
							MPNSTPO_Id.setText('MPN');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				} else {
					setMPNTitle('Initial', 'E');
					MPNAdvExclude_List.setModel(setMPNInitial('E'));
				}
				/*
				        SOLD - TO
				*/
				var bItems = CVCSTBasic_Table.getItems();
				for (var i = 0; i < bItems.length; i++) {
					bItems[i].setSelected(false);
				}
				var incList = gMainMRef.getData().IncListData;
				var excList = gMainMRef.getData().ExcListData;

				if (soldToBasic.length > 0) {
					var txtin = 'Inc(' + soldToBasic.length + ')';
					oinpoSFormCVCSoldTo.addToken(new sap.m.Token({
						key: 'Include',
						text: txtin,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalst = gMainMRef.getData().CVCSTIncListData;
							for (var i in datalst) {
								var newmatlst = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: datalst[i].Option,
									Low: datalst[i].Low,
									High: '',
									Txtsh: datalst[i].Txtsh,
									Type: 'B'
								};
								objArray.push(newmatlst);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('Sold To');
							// PopoverNew_Id.setText('Sold To');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('Sold To');
							MPNSTPO_Id.setText('Sold To');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				}

				//advance tab include
				if (soldToAdvInc.length > 0) {
					var txtin = 'Inc(' + soldToAdvInc.length + ')';
					oinpoSFormCVCSoldTo.addToken(new sap.m.Token({
						key: 'Include',
						text: txtin,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalst = gMainMRef.getData().CVCSTIncListData;
							for (var i in datalst) {
								var newmatlst = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: datalst[i].Option,
									Low: datalst[i].Low,
									High: '',
									Txtsh: datalst[i].Txtsh,
									Type: 'A'
								};
								objArray.push(newmatlst);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('Sold To');
							// PopoverNew_Id.setText('Sold To');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('Sold To');
							MPNSTPO_Id.setText('Sold To');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				} else {
					setCVCSTTitle('Initial', 'I');
					CVCSTAdvInclude_List.setModel(setCVCSTInitial('I'));
				}

				if (soldToAdvExc.length > 0) {
					var txtex = 'Exc(' + soldToAdvExc.length + ')';
					oinpoSFormCVCSoldTo.addToken(new sap.m.Token({
						key: 'Exclude',
						text: txtex,
						select: function (oEvent) {
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData([]);
							var objArray = [];
							datalstex = gMainMRef.getData().CVCSTExcListData;
							for (var i in datalstex) {
								var newmatlstex = {
									Selname: '',
									Kind: '',
									Sign: 'E',
									Option: datalstex[i].Option,
									Low: datalstex[i].Low,
									High: '',
									Txtsh: datalstex[i].Txtsh,
									Type: 'A'

								};
								objArray.push(newmatlstex);
							}
							jModel.setData(objArray);
							// PopoverList.setModel(jModel);
							// oPopoverNew.setTitle('Sold To');
							// PopoverNew_Id.setText('Sold To');
							// PopoverDemo_SearchField.setValue('');
							// oPopoverNew.openBy(this);
							MPNSTPOList.setModel(jModel);
							MPNSTPopover.setTitle('Sold To');
							MPNSTPO_Id.setText('Sold To');
							MPNSTPO_SearchField.setValue('');
							MPNSTPopover.openBy(this);
						},
						press: function (oEvent) {

						},
						deselect: function (oEvent) {

						}
					}));
				} else {
					setCVCSTTitle('Initial', 'E');
					CVCSTAdvExclude_List.setModel(setCVCSTInitial('E'));
				}
			}
			oinpoSFormCVCOPS.setBusy(false);
			oinpoSFormCVCMPN.setBusy(false);
			oinpoSFormCVCSales.setBusy(false);
			oinpoSFormCVCChan.setBusy(false);
			oinpoSFormCVCSoldTo.setBusy(false);

		}

		function loadApp(appName, tableName, table) {
			var oTableColumnsData = [];
			var aColumns = [];
			aColumns = table.getColumns();
			var oTableRow = {};
			oTableRow.column = appName;
			oTableColumnsData.push(oTableRow.column);
			var oTableRow = {};
			oTableRow.column = tableName;
			oTableColumnsData.push(oTableRow.column);
			for (i = 0; i < aColumns.length; i++) {
				oTableRow = {};
				oTableRow.column = aColumns[i].getLabel().mProperties.text;
				oTableColumnsData.push(oTableRow.column);
			}
			var arrStr = oTableColumnsData.join(",");
			// Load App as Dialog
			AppCache.Load("ZUI_NAD_PERSONALIZATION_APP", {
				dialogShow: true,
				dialogHeight: "600px",
				dialogWidth: "600px",
				startParams: {
					arrStr: arrStr,
				}
			});
		}

		function processVariant(tableName) {
			lv_table = "WS_Table"; //Replace with actual table name
			var odataModel = new sap.ui.model.odata.ODataModel(url);
			if (selectVariant.getSelectedKey() == undefined || selectVariant.getSelectedKey() == null || selectVariant.getSelectedKey() == " " ||
				selectVariant.getSelectedKey() == "") {} else {
				var l_url_parm = "/ColumnSet?$filter=AppName eq '" + AppCache.CurrentApp + "'" + "and TableName eq '" + lv_table + "'" +
					"and Variant eq '" + selectVariant.getSelectedKey() + "'";
				odataModel.read(l_url_parm, {
					success: function (oRetrievedResult, ResultoData) {
						resultModel = oRetrievedResult;
						//Get default or global variant columnsData
						columnsData = oRetrievedResult.results[0].Columns.split("-");
						$.each(tableName.getColumns(), function (i, item) {
							tableName.getColumns()[i].setVisible(false);
						});
						$.each(columnsData, function (i, item1) {
							$.each(tableName.getColumns(), function (j, item2) {
								if (item1 === item2.getLabel().mProperties.text) {
									WS_Table.getColumns()[j].setVisible(true);
								}
							});
						});
					},
				});
			}
		}

		function processVariant_wave(tableName) {
			lv_table = "Wave_Table"; //Replace with actual table name
			var odataModel = new sap.ui.model.odata.ODataModel(url);
			if (selectVariant_wave.getSelectedKey() == undefined || selectVariant_wave.getSelectedKey() == null || selectVariant_wave.getSelectedKey() ==
				" " || selectVariant_wave.getSelectedKey() == "") {} else {
				var l_url_parm = "/ColumnSet?$filter=AppName eq '" + AppCache.CurrentApp + "'" + "and TableName eq '" + lv_table + "'" +
					"and Variant eq '" + selectVariant_wave.getSelectedKey() + "'";
				odataModel.read(l_url_parm, {
					success: function (oRetrievedResult, ResultoData) {
						resultModel = oRetrievedResult;
						//Get default or global variant columnsData
						columnsData = oRetrievedResult.results[0].Columns.split("-");
						$.each(tableName.getColumns(), function (i, item) {
							tableName.getColumns()[i].setVisible(false);
						});
						$.each(columnsData, function (i, item1) {
							$.each(tableName.getColumns(), function (j, item2) {
								if (item1 === item2.getLabel().mProperties.text) {
									Wave_Table.getColumns()[j].setVisible(true);
								}
							});
						});
					},

				});
			}
		}

		//Call back
		if (sap.n) {
			sap.n[AppCache.CurrentApp] = {};
			sap.n[AppCache.CurrentApp].callback = function (data) {
				var l_tab = Tables_IconTabBar.getSelectedKey();
				var l_sel;
				var oColumns = data.split(",");
				//Wave Tab
				if (l_tab == "Wave") {
					l_sel = selectVariant_wave.getSelectedKey();
					$.each(Wave_Table.getColumns(), function (i, item) {
						Wave_Table.getColumns()[i].setVisible(false);
					});
					$.each(oColumns, function (i, item1) {
						$.each(Wave_Table.getColumns(), function (j, item2) {
							if (item1 === item2.getLabel().mProperties.text) {
								Wave_Table.getColumns()[j].setVisible(true);
							}
						});
					});
					selectVariant_wave.removeAllItems();
				} else {
					//Wave Schedule
					l_sel = selectVariant.getSelectedKey();
					$.each(WS_Table.getColumns(), function (i, item) {
						WS_Table.getColumns()[i].setVisible(false);
					});
					$.each(oColumns, function (i, item1) {
						$.each(WS_Table.getColumns(), function (j, item2) {
							if (item1 === item2.getLabel().mProperties.text) {
								WS_Table.getColumns()[j].setVisible(true);
							}
						});
					});
					selectVariant.removeAllItems();
				}
				refreshVariant(l_tab, l_sel);
			}
		}

		function setVariantOptions() {
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setData([]);
			var xData = [];
			xData.push({
				Low: "Save Filter"
			});
			xData.push({
				Low: "Delete Filter"
			});
			xData.push({
				Low: "Clear Filter"
			});
			jModel.setData(xData);
			CVCOptions_List.setModel(jModel);
			// CVCOptions_List.getModel().refresh();
		}

		function get_variant(val) {
			var l_default_wave, l_default;
			var odataModel = new sap.ui.model.odata.ODataModel(url);
			var l_url_parm = "/LayoutSet?$filter=( AppName eq" + "'" + AppCache.CurrentApp + "'" + ")";
			selectVariant_wave.removeAllItems();
			selectVariant.removeAllItems();

			odataModel.read(l_url_parm, {
				success: function (oRetrievedResult, ResultoData) {
					aVariantData = [];
					for (a = 0; a < oRetrievedResult.results.length; a++) {
						if (oRetrievedResult.results[a].TableName === "Wave_Table") {
							selectVariant_wave.addItem(new sap.ui.core.Item({
								key: oRetrievedResult.results[a].Variant,
								text: oRetrievedResult.results[a].Variant
							}));
							if (oRetrievedResult.results[a].Default === "X" && val === "X") {
								selectVariant_wave.setSelectedKey(oRetrievedResult.results[a].Variant);
							}
						} else {
							selectVariant.addItem(new sap.ui.core.Item({
								key: oRetrievedResult.results[a].Variant,
								text: oRetrievedResult.results[a].Variant
							}));
							if (oRetrievedResult.results[a].Default === "X" && val === "X") {
								selectVariant.setSelectedKey(oRetrievedResult.results[a].Variant);
							}
						}
					}
					if (val === "X") {
						processVariant_wave(Wave_Table);
						processVariant(WS_Table);
					}
				},
			});
		}

		function refreshVariant(tab, sel) {
			var odataModel = new sap.ui.model.odata.ODataModel(url);
			var l_url_parm = "/LayoutSet?$filter=( AppName eq" + "'" + AppCache.CurrentApp + "'" + ")";
			odataModel.read(l_url_parm, {
				success: function (oRetrievedResult, ResultoData) {
					aVariantData = [];
					if (tab === "WS") {
						selectVariant.destroyItems();
					} else if (tab === "Wave") {
						selectVariant_wave.destroyItems();
					}
					for (a = 0; a < oRetrievedResult.results.length; a++) {
						if (oRetrievedResult.results[a].TableName === "Wave_Table" && tab === "Wave") {
							selectVariant_wave.addItem(new sap.ui.core.Item({
								key: oRetrievedResult.results[a].Variant,
								text: oRetrievedResult.results[a].Variant
							}));
						} else {
							if (oRetrievedResult.results[a].TableName === "WS_Table" && tab === "WS") {
								selectVariant.addItem(new sap.ui.core.Item({
									key: oRetrievedResult.results[a].Variant,
									text: oRetrievedResult.results[a].Variant
								}));
							}
						}
					}
					if (tab === "Wave") {
						selectVariant_wave.setSelectedKey(sel);
					} else {
						selectVariant.setSelectedKey(sel);
					}
				},

			});
		}

		//****USB Upload***

		function createUploadUBP(iErrorType) {

			oDialogUBP.setBusy(true);
			goa.uploadHasErrors = false;
			UBP_MessageStrip.setVisible(false);
			var l_Region = oPOR_Region.getSelectedKey();
			if (oUBPRBplan1.getSelected()) {
				var l_plan = "1";
			} else {
				l_plan = "2";
			}

			var l_value = "Region:" + l_Region;
			l_value = l_value + "," + "Plan:" + l_plan;
			l_value = l_value + "," + "ErrorType:" + iErrorType;
			l_value = l_value + "," + "Func:" + "RC";

			var file = gUBPUploadFile;
			var oHeaders = {
				"x-csrf-token": ODataWS.getSecurityToken(),
				"slug": l_value,
				"Accept": "application/json",
				"content-type": "application/json"
			};
			jQuery.ajax({
				async: true,
				type: 'POST',
				url: "/sap/opu/odata/sap/ZOD_DAT_RCA_BY_PROFILE_SRV/UBPUploadSet",
				headers: oHeaders,
				cache: false,
				processData: false,
				data: file,
				success: function (data) {
					oUBPFileUploader.setValue('');
					_checkUpdReturn_UBP(data);
				},
				error: function (oerror) {
					oDialogUBP.setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show('Error in Upload');
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}

		function _checkUpdReturn_UBP(data) {
			UBP_MessageStrip.setVisible(true);
			/*
			New code below
			*/
			Panel_UBP.setVisible(false);
			UBPError_Panel.setVisible(true); //Panel is visible now.

			if (data.d.ErrorCount > 0) {
				goa.uploadHasErrors = true;
				UBP_MessageStrip.setType('Error');
				gUBPUploadErrorType = data.d.ErrorType;
				if (data.d.ErrorType == '') {
					UBP_MessageStrip.setText('Unknown Error');
					oUBPProceed_Button.setVisible(false);
					_getUploadErrors_UBP(data.d.Guid);

				} else if (data.d.ErrorType == 'UBPGTPOR') {
					UBP_MessageStrip.setText('Upload wave has ' + data.d.ErrorCount + ' errors, click on proceed to save changes.');
					oUBPProceed_Button.setVisible(true);
					_getUploadErrors_UBP(data.d.Guid);
				} else if (data.d.ErrorType == 'AUTH') {
					UBP_MessageStrip.setText('No Authorization');
					oUBPProceed_Button.setVisible(false);
					UBPError_Table.setBusy(false);
					oDialogUBP.setBusy(false);
					sap.ui.core.BusyIndicator.hide();
				} else {
					UBP_MessageStrip.setText(data.d.ErrorCount + 'Errors: ' + data.d.Message);
					oUBPProceed_Button.setVisible(false);
					_getUploadErrors_UBP(data.d.Guid);
				}

			} else {
				_getUploadErrors_UBP(data.d.Guid);
				goa.uploadHasErrors = false;
				oUBPProceed_Button.setVisible(false);
				UBP_MessageStrip.setType('Success');
				UBP_MessageStrip.setText('Successfully uploaded the file');
				gUBPUploadFile = '';
				oDialogUBP.setBusy(false);
			}
		}

		function _getUploadErrors_UBP(iGuid) {
			UBPError_Table.setBusy(true);
			var errData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Guid",
				sap.ui.model.FilterOperator.EQ, iGuid));
			var errPromise = $.Deferred();
			gRollModel.read('/UBPMsgSet', {
				filters: aFilters,
				success: function (oData, resp) {
					errData = oData.results;
					errPromise.resolve();
				},
				error: function (oError) {
					UBPError_Table.setBusy(false);
					oDialogUBP.setBusy(false);
					errPromise.resolve();
					sap.m.MessageToast.show('error while getting upload error data');
				}
			});
			Promise.all(
				[
					errPromise
				]
			).then($.proxy(function () {
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);
				jModel.setData(errData);
				UBPError_Table.setModel(jModel);
				UBPError_Table.getModel().refresh();
				UBPError_Table.setBusy(false);
				oDialogUBP.setBusy(false);
				_getWorkBenchData();
				sap.ui.core.BusyIndicator.hide();
			}));
		}

		function get_region() {

			gRegionVals.removeAllItems();
			var fwPromise = $.Deferred();
			gRollModel.read('/PORRegionSet', {
				success: function (oData, resp) {
					fwPromise.resolve();
					var len = oData.results.length;
					var currWeekKey = '';
					for (var i = 0; i < len; i++) {
						var lv_region = oData.results[i];
						gRegionVals.addItem(new sap.ui.core.Item({
							key: lv_region.Region,
							text: lv_region.Region
						}));
					}
				},
				error: function (oError) {
					fwPromise.resolve();
				}
			});
			Promise.all(
				[
					fwPromise
				]
			).then($.proxy(function () {}));

		}

		function chgMPN() {
			var bReturn = true;
			if (oinpoSFormCVCMPN.getValue() == undefined || oinpoSFormCVCMPN.getValue() == null || oinpoSFormCVCMPN.getValue() == '') {
				oinpoSFormCVCMPN.setValueState('None');
				oinpoSFormCVCMPN.setValueStateText('');
			} else {
				oinpoSFormCVCMPN.setValueState('Error');
				oinpoSFormCVCMPN.setValueStateText('Manual entry is not allowed.');
				bReturn = false;
			}
			return bReturn;
		}

		function chgSoldTo() {
			var bReturn = true;
			if (oinpoSFormCVCSoldTo.getValue() == undefined || oinpoSFormCVCSoldTo.getValue() == null || oinpoSFormCVCSoldTo.getValue() == '') {
				oinpoSFormCVCSoldTo.setValueState('None');
				oinpoSFormCVCSoldTo.setValueStateText('');
			} else {
				oinpoSFormCVCSoldTo.setValueState('Error');
				oinpoSFormCVCSoldTo.setValueStateText('Manual entry is not allowed.');
				bReturn = false;
			}
			return bReturn;
		}
		/*

		*/

		function saveDefProfile(Profile, Region, Week) {

			var xData = {
				Bname: AppCache.CurrentUname,
				Secprofile: Profile,
				Region: Region,
				FiscWeek: Week,
			};
			//sap.ui.core.BusyIndicator.show(0)
			var rData = []
			var xPromise = $.Deferred();
			gWaveModel.create('/SysConfigSet', xData, {
				success: function (oData, resp) {
					//sap.ui.core.BusyIndicator.hide();
					xPromise.resolve();
					rData = oData;
				},
				error: function (oError) {
					xPromise.resolve();
					sap.m.MessageToast.show('Error in saving Profile');
					sap.ui.core.BusyIndicator.hide();

				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {

			}));
		}

		function wave_rel() {
			wave_rel_type.addItem(new sap.ui.core.Item({
				key: 'D',
				text: 'Dependency Release',
			}));
			wave_rel_type.addItem(new sap.ui.core.Item({
				key: 'T',
				text: 'Time Release',
			}));

			wave_rel_type.addItem(new sap.ui.core.Item({
				key: 'M',
				text: 'Manual Release',
			}));
		}

		function waveDDData() {
			var ddData = [];
			var wDDPromise = $.Deferred();
			gWaveModel.read('/WaveDDSet', {
				success: function (oData, resp) {
					ddData = oData.results;
					wDDPromise.resolve();
				},
				error: function (oError) {
					sap.m.MessageToast.show('error while getting drop down data');
				}
			});
			Promise.all(
				[
					wDDPromise
				]
			).then($.proxy(function () {
				for (var i = 0; i < ddData.length; i++) {
					var dd = ddData[i];
					gDDMap.set(dd.Key, dd.Value);
				}
			}));
		}

		function getF4log(oEvent, iTitle, icall) {
			PopoverList_job.setBusy(true);
			var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
			var tData = Wave_Table.getModel().getData()[index];
			var jobId = tData.JobId;
			var jobName = tData.JobName;
			//Reset model first.
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData([]);
			PopoverList_job.setModel(jModel);
			PopoverList_job.getModel().refresh();
			var xData = [];
			var ppData = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("JobName", sap.ui.model.FilterOperator.EQ, jobName));
			aFilters.push(new sap.ui.model.Filter("JobId", sap.ui.model.FilterOperator.EQ, jobId));
			var xPromise = $.Deferred();
			gWBModel.read('/JobLogSet', {
				filters: aFilters,
				success: function (oData, resp) {
					xPromise.resolve();
					xData = oData.results;

				},
				error: function (oError) {
					xPromise.resolve();
					PopoverList_job.setBusy(false);
				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {
				if (xData.length != undefined) {
					var xTimezone = xData[0].UserTimezone;
					Popover_Time_Column3.setHeader(new sap.m.Label({
						text: 'Time(' + xTimezone + ')'
					}));
					for (var i = 0; i < xData.length; i++) {
						var xd = xData[i];
						var yd = {
							Entertime: xd.Entertime,
							Enterdate: xd.Enterdate,
							Msgtype: xd.Msgtype,
							Text: xd.Text
						}
						ppData.push(yd);
					}
				}
				//Begin of Insert DV5K934693
				// 75419527 Populate only error messages for wave creation job status log
				if (icall == 'WaveCreateStatus') {
					let ppDataf = ppData.filter(item => !(item.Msgtype == 'S'));
					ppData = [];
					ppData = ppDataf;
				}
				//End of Insert DV5K934693

				jModel.setData(ppData);
				PopoverList_job.setModel(jModel);
				PopoverList_job.getModel().refresh();
				PopoverList_job.setBusy(false);
			}));
			oPopoverNew_job.setTitle(iTitle);
			oPopoverNew_job.openBy(oEvent.getSource());
		}

		//Begin of DV5K931077
		function datui_lock_check(Region) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, Region));

			var xData = [];
			var dPromise = $.Deferred();
			gWaveModel.read('/DATUILockSet', {
				filters: aFilters,
				success: function (oData, resp) {
					dPromise.resolve();
					xData = oData.results;
				},
				error: function (oError) {
					dPromise.resolve();
				}
			});
			Promise.all(
				[
					dPromise
				]
			).then($.proxy(function () {
				if (xData.length != undefined) {
					var xLock = xData[0].LockCheck;
					if (xLock == 'X') {
						//if DAT UI Lock is set disable buttons
						Create_Button.setEnabled(false);
						WCreate_Button.setEnabled(false);
						WRelease_Button.setEnabled(false);
						wave_param.setEnabled(false);
						WUP_Wave.setEnabled(false);
						UP_Wave.setEnabled(false);
						WaveDel_Button.setEnabled(false);
					} else {
						Create_Button.setEnabled(true);
						WCreate_Button.setEnabled(true);
						WRelease_Button.setEnabled(true);
						wave_param.setEnabled(true);
						WUP_Wave.setEnabled(true);
						UP_Wave.setEnabled(true);
						WaveDel_Button.setEnabled(true);
					}
				}
			}));
		}
		//End of DV5K931077

		//Begin of Insert DV5K934693
		// * 75636871 - Select All option for Sales Org
		function Sorg_Select() {
			var allsorg = oinpoSFormCVCSales.getKeys().valueOf().length;
			var selsorg = oinpoSFormCVCSales.getSelectedKeys().length;

			if (allsorg > selsorg) {
				// Deselect   Sorg_CheckBox when items removed from    oinpoSFormCVCSales
				if (Sorg_CheckBox.getSelected()) {
					Sorg_CheckBox.setSelected(false);
				}

			} else if (allsorg == selsorg) {
				Sorg_CheckBox.setSelected(true);
			}
		}
		//End of Insert DV5K934693

		//Begin of Insert DV5K938119
		// * Add new feature to update PLA and GATP
		function createUploadPP(iErrorType) {

			oDialogPLAPOR_UPD.setBusy(true);
			goa.uploadHasErrors = false;
			PPU_MessageStrip.setVisible(false);
			var l_Region = oPPOR_Region.getSelectedKey();
			var l_week = oPPU_Week.getSelectedKey();

			var l_value = "Region:" + l_Region;
			l_value = l_value + "," + "Fisweek:" + l_week;
			l_value = l_value + "," + "ErrorType:" + iErrorType;
			l_value = l_value + "," + "Func:" + "RC";

			var file = gPPUploadFile;
			var oHeaders = {
				"x-csrf-token": ODataWS.getSecurityToken(),
				"slug": l_value,
				"Accept": "application/json",
				"content-type": "application/json"
			};
			jQuery.ajax({
				async: true,
				type: 'POST',
				url: "/sap/opu/odata/sap/ZOD_DAT_RCA_BY_PROFILE_SRV/PLAUploadSet",
				headers: oHeaders,
				cache: false,
				processData: false,
				data: file,
				success: function (data) {
					oPPUFileUploader.setValue('');
					sap.m.MessageToast.show(data.d.Message, {
						duration: 5000
					});
					//          _checkUpdReturn_UBP(data);
					oDialogPLAPOR_UPD.setBusy(false);
					sap.ui.core.BusyIndicator.hide();

					//Close the PLA POR dialog - #93965772
					if (data.d.ErrorType === 'S') {
						gPPUploadFile = '';
						oDialogPLAPOR_UPD.close();
					}
				},
				error: function (oerror) {
					oDialogPLAPOR_UPD.setBusy(false);
					//sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show('Error in Upload', {
						duration: 5000
					});
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}

		function createUploadPG(iErrorType) {

			oDialogPLAGATP_UPD.setBusy(true);
			goa.uploadHasErrors = false;
			PGU_MessageStrip.setVisible(false);
			var l_Region = oPGU_Region.getSelectedKey();
			var l_week = oPGU_Week.getSelectedKey();

			var l_value = "Region:" + l_Region;
			l_value = l_value + "," + "Fisweek:" + l_week;
			l_value = l_value + "," + "ErrorType:" + iErrorType;
			l_value = l_value + "," + "Func:" + "RC";
			l_value = Switch_Coms_status.getState() ? l_value + "," + "Consumption Status:" + "X" : l_value;
			l_value = Switch_Release_POR.getState() ? l_value + "," + "Release_POR:" + "X" : l_value;

			var file = gPGUploadFile;
			var oHeaders = {
				"x-csrf-token": ODataWS.getSecurityToken(),
				"slug": l_value,
				"Accept": "application/json",
				"content-type": "application/json"
			};
			jQuery.ajax({
				async: true,
				type: 'POST',
				url: "/sap/opu/odata/sap/ZOD_DAT_RCA_BY_PROFILE_SRV/PLAGATPUploadSet",
				headers: oHeaders,
				cache: false,
				processData: false,
				data: file,
				success: function (data) {
					oPGUFileUploader.setValue('');
					sap.m.MessageToast.show(data.d.Message, {
						duration: 5000
					});
					//          _checkUpdReturn_UBP(data);
					oDialogPLAGATP_UPD.setBusy(false);
					sap.ui.core.BusyIndicator.hide();

					//Close the PLA POR dialog - #93965772
					if (data.d.ErrorType === 'S') {
						gPGUploadFile = '';
						oDialogPLAGATP_UPD.close();
					}
				},
				error: function (oerror) {
					oDialogPLAGATP_UPD.setBusy(false);
					//sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show('Error in Upload', {
						duration: 5000
					});
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}
		//Enf  of Insert DV5K938119

		;
		if (sap.n && sap.n.Shell && sap.n.Shell.getAppsObject) {
			var appGUID = sap.n.Shell.getAppsObject(localAppID);
			if (typeof sap.n.Apps[appGUID] !== "undefined") {
				sap.n.Apps[appGUID].cache = {
					objects: {},
					ready: function (element) {
						sap.n.Apps[appGUID].cache.objects[element] = true;
						var loaded = true;
						$.each(sap.n.Apps[appGUID].cache.objects, function (i, obj) {
							if (!obj) loaded = false;
						});
						if (loaded) {
							if (sap.n.Apps[appGUID].cacheLoaded) {
								$.each(sap.n.Apps[appGUID].cacheLoaded, function (i, func) {
									func(AppCache.LoadOptions.startParams);
								});
							}
						}
					}
				}
			};
		}
		if (typeof AppCache === "undefined") {
			var sapUname = "C8831246BS";
		} else {
			var sapUname = AppCache.CurrentUname;
		}
		if (!sap.ui.table.Table) {
			sap.ui.getCore().loadLibrary("sap.ui.table");
		}
		var Shell = new sap.m.Shell(this.createId("Shell"), {
			appWidthLimited: false,
			title: ""
		});
		var oApp = new sap.m.App(this.createId("oApp"), {
			afterNavigate: function (oEvent) {
				false
			}
		});
		Shell.setApp(oApp);
		var WBPage = new sap.m.Page(this.createId("WBPage"), {})
		oApp.addPage(WBPage);
		var PageCustomHdr_bar = new sap.m.Bar(this.createId("PageCustomHdr_bar"), {});
		WBPage.setCustomHeader(PageCustomHdr_bar);
		var HDR_Icon = new sap.ui.core.Icon(this.createId("HDR_Icon"), {
			color: "white",
			size: "1.5rem",
			src: "sap-icon://fa-brands/apple",
			visible: false
		});
		PageCustomHdr_bar.addContentLeft(HDR_Icon);
		var HDR_L_Text = new sap.m.Text(this.createId("HDR_L_Text"), {
			text: "Dynamic Allocation Tool"
		});
		PageCustomHdr_bar.addContentLeft(HDR_L_Text);
		var HDR_M_Text1 = new sap.m.Text(this.createId("HDR_M_Text1"), {
			text: "Workbench Waves"
		});
		PageCustomHdr_bar.addContentMiddle(HDR_M_Text1);
		var InfoH_Icon = new sap.ui.core.Icon(this.createId("InfoH_Icon"), {
			size: "1.5rem",
			src: "sap-icon://message-information",
			tooltip: "Click here to open help document",
			press: function (oEvent) {
				//var url = "https://sosdevelopment.apple.com/course/a7190480-cafe-11ea-a5a7-c1bf25875dc9";
				var aTag = document.createElement('a');
				aTag.setAttribute("href", gHelpLink);
				aTag.setAttribute("target", '_blank');
				aTag.innerHTML = "Click Here to open help document";
				aTag.click();
				aTag.remove();
			}
		});
		PageCustomHdr_bar.addContentRight(InfoH_Icon);
		var VBox2 = new sap.m.VBox(this.createId("VBox2"), {
			width: "100%"
		});
		WBPage.addContent(VBox2);
		var oPanelProfile = new sap.m.Panel(this.createId("oPanelProfile"), {
			backgroundDesign: "Transparent",
			width: "55%"
		});
		VBox2.addItem(oPanelProfile);
		var oSFormProfile = new sap.ui.layout.form.SimpleForm(this.createId("oSFormProfile"), {
			adjustLabelSpan: false,
			breakpointL: 1200,
			breakpointM: 400,
			columnsL: 3,
			columnsM: 3,
			columnsXL: 3,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 3,
			title: "Profile",
			width: "100%"
		});
		oPanelProfile.addContent(oSFormProfile);
		var oTitleP_Date = new sap.ui.core.Title(this.createId("oTitleP_Date"), {});
		oSFormProfile.addContent(oTitleP_Date);
		var prof_week_Label = new sap.m.Label(this.createId("prof_week_Label"), {
			required: true,
			text: "Week"
		});
		oSFormProfile.addContent(prof_week_Label);
		var oProfileForm_Week = new sap.m.Select(this.createId("oProfileForm_Week"), {
			selectedKey: "{WA_FISC_WEEK-WEEK}",
			change: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 07/07/2020  C5162473NS      64699425   Initial          DV5K929086   *
				// * Last selected Week n profile  changes                                *
				// ************************************************************************
				var l_week = oProfileForm_Week.getSelectedKey();
				_getWeekDesc(l_week);
				getWeekProfile(l_week, '', '');
				oProfileForm_Profile.setSelectedKey('');
				var stModel = new sap.ui.model.json.JSONModel();
				stModel.setData([]);
				WS_Table.setModel(stModel);
				Wave_Table.setModel(stModel);
				resetData();

				CVCSel_Label.setText('');
			}
		});
		oSFormProfile.addContent(oProfileForm_Week);
		var oTitle = new sap.ui.core.Title(this.createId("oTitle"), {});
		oSFormProfile.addContent(oTitle);
		var prof_prof_Label2 = new sap.m.Label(this.createId("prof_prof_Label2"), {
			required: true,
			text: "Wave Profile"
		});
		oSFormProfile.addContent(prof_prof_Label2);
		var oProfileForm_Profile = new sap.m.Select(this.createId("oProfileForm_Profile"), {
			forceSelection: false,
			change: function (oEvent) {
				sap.ui.core.BusyIndicator.show(0);
				onProfileChange();
				//Save profile on Change event
				saveDefProfile(oProfileForm_Profile.getSelectedKey(), gWaveProfileSelRegion, oProfileForm_Week.getSelectedKey());
			}
		});
		oSFormProfile.addContent(oProfileForm_Profile);
		var oPanelCVC = new sap.m.Panel(this.createId("oPanelCVC"), {
			expandable: true,
			backgroundDesign: "Transparent"
		});
		VBox2.addItem(oPanelCVC);
		var CVCHeader_Toolbar = new sap.m.Toolbar(this.createId("CVCHeader_Toolbar"), {});
		oPanelCVC.setHeaderToolbar(CVCHeader_Toolbar);
		var oLabelCVC = new sap.m.Label(this.createId("oLabelCVC"), {
			text: "CVC Selection",
			textAlign: "Left",
			textDirection: "Inherit",
			wrapping: true
		});
		CVCHeader_Toolbar.addContent(oLabelCVC);
		var CVCSel_Label = new sap.m.Label(this.createId("CVCSel_Label"), {});
		CVCHeader_Toolbar.addContent(CVCSel_Label);
		var CVCSel_Icon = new sap.ui.core.Icon(this.createId("CVCSel_Icon"), {
			src: "sap-icon://dropdown",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WAVE_CREATION                              *
				// * TITLE           : Wave Creation                                      *
				// * CREATED BY      : Deepika jain                                       *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Wave Creation.                              *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5191496DJ      61741285   Initial          DV5K927719   *
				// ************************************************************************
				CVCSel_Popover.openBy(this);
				// if(CVCSel_Label.getText() == 'Default'){
				//     setStar('Default');
				// }else{
				//    setStar(CVCSel_Label.getText());
				//}
			}
		});
		CVCHeader_Toolbar.addContent(CVCSel_Icon);
		var CVCHdr_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("CVCHdr_ToolbarSpacer"), {});
		CVCHeader_Toolbar.addContent(CVCHdr_ToolbarSpacer);
		var CVCHdrSelVar_Icon = new sap.ui.core.Icon(this.createId("CVCHdrSelVar_Icon"), {
			color: "#0070b1",
			src: "sap-icon://fa-solid/ellipsis-v",
			press: function (oEvent) {
				var items = CVCOptions_List.getItems();
				for (var i = 0; i < items.length; i++) {
					var item = items[i];
					item.setSelected(false);
				}
				CVCOptions_Popover.openBy(oEvent.getSource());
			}
		});
		CVCHeader_Toolbar.addContent(CVCHdrSelVar_Icon);
		var oHBoxCVC = new sap.m.HBox(this.createId("oHBoxCVC"), {
			width: "100%"
		});
		oPanelCVC.addContent(oHBoxCVC);
		var oVBoxCVC = new sap.m.VBox(this.createId("oVBoxCVC"), {
			width: "96%"
		});
		oHBoxCVC.addItem(oVBoxCVC);
		var oCVCForm = new sap.ui.layout.form.SimpleForm(this.createId("oCVCForm"), {
			columnsL: 6,
			columnsM: 4,
			editable: true,
			labelSpanL: 6,
			labelSpanM: 4,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 6,
			width: "100%"
		});
		oVBoxCVC.addItem(oCVCForm);
		var Title1 = new sap.ui.core.Title(this.createId("Title1"), {
			text: "OPS Subclass"
		});
		oCVCForm.addContent(Title1);
		var oinpoSFormCVCOPS = new sap.m.MultiComboBox(this.createId("oinpoSFormCVCOPS"));
		oCVCForm.addContent(oinpoSFormCVCOPS);
		var Title2 = new sap.ui.core.Title(this.createId("Title2"), {
			text: "MPN"
		});
		oCVCForm.addContent(Title2);
		var oinpoSFormCVCMPN = new sap.m.MultiInput(this.createId("oinpoSFormCVCMPN"), {
			fieldWidth: "100%",
			showSuggestion: true,
			valueHelpRequest: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				/*
				    Add Methods coming Dialog scrip - MPNScript
				*/
				if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
					'') {
					sap.m.MessageToast.show('Please select valid wave profile');
				} else {
					MPNInclude_Panel.setExpanded(true);
					MPNExclude_Panel.setExpanded(false);
					if (oinpoSFormCVCMPN.getTokens().length == 0) {
						//Basic Tab
						var bItems = MPNBasic_Table.getItems();
						for (var i = 0; i < bItems.length; i++) {
							bItems[i].setSelected(false);
						}

						//advance tab
						setMPNTitle('Initial', 'I');
						setMPNTitle('Initial', 'E');
						MPNAdvInclude_List.setModel(setMPNInitial('I'));
						MPNAdvExclude_List.setModel(setMPNInitial('E'));
						MPN_IconTabBar.setSelectedKey('Basic');
						MPNBasicInfoTB_Text.setText('');
					} else {
						var len = oinpoSFormCVCMPN.getTokens().length;
						var incTokenExists = false;
						var excTokenExists = false;
						for (var i = 0; i < len; i++) {
							var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								incTokenExists = true;
							}
							if (oToken == 'Exclude') {
								excTokenExists = true;
							}
						}

						//Now populate based on token - Include token exists then
						var incList = gMainMRef.getData().MPNIncListData;
						var excList = gMainMRef.getData().MPNExcListData;
						if (incTokenExists) { //token inc exists
							var firstRow = incList[0];
							var incMap = new Map([]);
							for (var i = 0; i < incList.length; i++) {
								incMap.set(incList[i].Low, incList[i].Low);
							}
							if (firstRow.Type == 'B') { //Basic
								var basicTable = MPNBasic_Table.getModel().oData;
								var basicItems = MPNBasic_Table.getItems();
								for (var i = 0; i < basicTable.length; i++) {
									var bi = basicItems[i];
									var index = bi.getBindingContext().sPath.split('/')[1];
									var bd = MPNBasic_Table.getModel().getData()[index];
									if (incMap.has(bd.Low)) {
										bi.setSelected(true);
									} else {
										bi.setSelected(false);
									}
								}
								MPN_IconTabBar.setSelectedKey('Basic');
							} else if (firstRow.Type == 'A') { //Advance
								var val_tab = [];
								for (var i = 0; i < incList.length; i++) {
									var incd = incList[i];
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: incd.Option,
										Low: incd.Low,
										High: '',
										Txtsh: incd.Txtsh,
										Type: 'A'
									};
									val_tab.push(xd);
								}
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData(val_tab);
								MPNAdvInclude_List.setModel(jModel);
								MPN_IconTabBar.setSelectedKey('Advanced');
							}
							setMPNTitle('NotInitial', 'I');
						} else {
							MPNAdvInclude_List.setModel(setMPNInitial('I'));
						}

						if (excTokenExists) {
							var val_tab = [];
							for (var i = 0; i < excList.length; i++) {
								var excd = excList[i];
								var xd = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: excd.Option,
									Low: excd.Low,
									High: '',
									Txtsh: excd.Txtsh,
									Type: 'A'
								};
								val_tab.push(xd);
							}
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData(val_tab);
							MPNAdvExclude_List.setModel(jModel);
							MPN_IconTabBar.setSelectedKey('Advanced');
							setMPNTitle('NotInitial', 'E');
						} else {

						}
					}

					MPN_Dialog.open();
				}
			},
			liveChange: function (oEvent) {
				chgMPN();
			},
			tokenUpdate: function (oEvent) {
				// var val = oEvent.getParameters().removedTokens[0].getKey();
				// //delete inclusion data / final data
				// if (val === c_inc) {
				//     $.each(modeloListMPNin.getData(), function(i, data) {
				//         ModelData.Delete(oTableMPNF, "LOW", data.LOW, "EQ");
				//     }); // for each

				//     modeloListMPNin.setData([]);
				//     oButtonMPNin.setText(c_inc);
				// }

				// //delete exclusion data / final data
				// if (val === c_exc) {
				//     $.each(modeloListMPNex.getData(), function(i, data) {
				//         ModelData.Delete(oTableMPNF, "LOW", data.LOW, "EQ");
				//     }); // for each

				//     modeloListMPNex.setData([]);
				//     oButtonMPNex.setText(c_exc);
				// }
			}
		});
		oCVCForm.addContent(oinpoSFormCVCMPN);
		var Title5 = new sap.ui.core.Title(this.createId("Title5"), {
			text: "Sales Org"
		});
		oCVCForm.addContent(Title5);
		var VBoxSales = new sap.m.VBox(this.createId("VBoxSales"), {});
		oCVCForm.addContent(VBoxSales);
		var oinpoSFormCVCSales = new sap.m.MultiComboBox(this.createId("oinpoSFormCVCSales"), {
			selectionChange: function (oEvent) {
				//Begin of Insert DV5K934693
				// * 75636871 - Select All option for Sales Org
				Sorg_Select();

				//End of Insert DV5K934693
			}
		});
		VBoxSales.addItem(oinpoSFormCVCSales);
		var Sorg_CheckBox = new sap.m.CheckBox(this.createId("Sorg_CheckBox"), {
			text: "Select All",
			select: function (oEvent) {
				//Begin of Insert DV5K934693
				// * 75636871 - Select All option for Sales Org
				var isSelected = oEvent.getParameters().selected;
				if (isSelected === true) {
					var newsorg = [];
					newsorg = oinpoSFormCVCSales.getKeys().valueOf();
					oinpoSFormCVCSales.setSelectedKeys(newsorg);
				} else {
					res = null;
					oinpoSFormCVCSales.setSelectedKeys(res);
				}
				//End of Insert DV5K934693
			}
		});
		VBoxSales.addItem(Sorg_CheckBox);
		var Title3 = new sap.ui.core.Title(this.createId("Title3"), {
			text: "Channel"
		});
		oCVCForm.addContent(Title3);
		var oinpoSFormCVCChan = new sap.m.MultiComboBox(this.createId("oinpoSFormCVCChan"));
		oCVCForm.addContent(oinpoSFormCVCChan);
		var Title4 = new sap.ui.core.Title(this.createId("Title4"), {
			text: "Sold To"
		});
		oCVCForm.addContent(Title4);
		var oinpoSFormCVCSoldTo = new sap.m.MultiInput(this.createId("oinpoSFormCVCSoldTo"), {
			showSuggestion: true,
			liveChange: function (oEvent) {
				chgSoldTo();
			},
			valueHelpRequest: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				/*
				    Add Methods coming Dialog scrip - CVCSTScript
				*/
				if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
					'') {
					sap.m.MessageToast.show('Please select valid wave profile');
				} else {
					CVCSTInclude_Panel.setExpanded(true);
					CVCSTExclude_Panel.setExpanded(false);
					oPopoverNew.setTitle('Sold To');
					PopoverNew_Id.setText('Sold To');
					PopoverDemo_SearchField.setValue('');

					if (oinpoSFormCVCSoldTo.getTokens().length == 0) {
						//Basic Tab
						var bItems = CVCSTBasic_Table.getItems();
						for (var i = 0; i < bItems.length; i++) {
							bItems[i].setSelected(false);
						}

						//advance tab
						setCVCSTTitle('Initial', 'I');
						setCVCSTTitle('Initial', 'E');
						CVCSTAdvInclude_List.setModel(setCVCSTInitial('I'));
						CVCSTAdvExclude_List.setModel(setCVCSTInitial('E'));
						CVCST_IconTabBar.setSelectedKey('Basic');
						CVCSTBasicInfoTB_Text.setText('');
					} else {
						var len = oinpoSFormCVCSoldTo.getTokens().length;
						var incTokenExists = false;
						var excTokenExists = false;
						for (var i = 0; i < len; i++) {
							var oToken = oinpoSFormCVCSoldTo.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								incTokenExists = true;
							}
							if (oToken == 'Exclude') {
								excTokenExists = true;
							}
						}

						//Now populate based on token - Include token exists then
						var incList = gMainMRef.getData().CVCSTIncListData;
						var excList = gMainMRef.getData().CVCSTExcListData;
						if (incTokenExists) { //token inc exists
							var firstRow = incList[0];
							var incMap = new Map([]);
							for (var i = 0; i < incList.length; i++) {
								incMap.set(incList[i].Low, incList[i].Low);
							}
							if (firstRow.Type == 'B') { //Basic
								var basicTable = CVCSTBasic_Table.getModel().oData;
								var basicItems = CVCSTBasic_Table.getItems();
								for (var i = 0; i < basicTable.length; i++) {
									var bi = basicItems[i];
									var index = bi.getBindingContext().sPath.split('/')[1];
									var bd = CVCSTBasic_Table.getModel().getData()[index];
									if (incMap.has(bd.Low)) {
										bi.setSelected(true);
									} else {
										bi.setSelected(false);
									}
								}
								CVCST_IconTabBar.setSelectedKey('Basic');
							} else if (firstRow.Type == 'A') { //Advance
								var val_tab = [];
								for (var i = 0; i < incList.length; i++) {
									var incd = incList[i];
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: incd.Option,
										Low: incd.Low,
										High: '',
										Txtsh: incd.Txtsh,
										Type: 'A'
									};
									val_tab.push(xd);
								}
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData(val_tab);
								CVCSTAdvInclude_List.setModel(jModel);
								CVCST_IconTabBar.setSelectedKey('Advanced');
							}
							setCVCSTTitle('NotInitial', 'I');
						} else {
							CVCSTAdvInclude_List.setModel(setCVCSTInitial('I'));
						}

						if (excTokenExists) {
							var val_tab = [];
							for (var i = 0; i < excList.length; i++) {
								var excd = excList[i];
								var xd = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: excd.Option,
									Low: excd.Low,
									High: '',
									Txtsh: excd.Txtsh,
									Type: 'A'
								};
								val_tab.push(xd);
							}
							var jModel = new sap.ui.model.json.JSONModel();
							jModel.setData(val_tab);
							CVCSTAdvExclude_List.setModel(jModel);
							CVCST_IconTabBar.setSelectedKey('Advanced');
							setCVCSTTitle('NotInitial', 'E');
						}
					}

					CVCST_Dialog.open();
				}
			}
		});
		oCVCForm.addContent(oinpoSFormCVCSoldTo);
		var Title6 = new sap.ui.core.Title(this.createId("Title6"), {});
		oCVCForm.addContent(Title6);
		var oCVCSearch_Button = new sap.m.Button(this.createId("oCVCSearch_Button"), {
			icon: "sap-icon://sys-find",
			type: "Emphasized",
			width: "2rem",
			press: function (oEvent) {
				_getWorkBenchData();
			}
		});
		oCVCForm.addContent(oCVCSearch_Button);
		var Tables_Panel = new sap.m.Panel(this.createId("Tables_Panel"), {});
		VBox2.addItem(Tables_Panel);
		var WS_MPN_Popover = new sap.m.Popover(this.createId("WS_MPN_Popover"), {});
		var WS_MPN_List1 = new sap.m.List(this.createId("WS_MPN_List1"), {});
		WS_MPN_Popover.addContent(WS_MPN_List1);
		var CustomListItem = new sap.m.CustomListItem(this.createId("CustomListItem"), {});
		WS_MPN_List1.addItem(CustomListItem);
		var Text = new sap.m.Text(this.createId("Text"), {});
		CustomListItem.addContent(Text);
		var Tables_IconTabBar = new sap.m.IconTabBar(this.createId("Tables_IconTabBar"), {
			headerMode: "Inline",
			select: function (oEvent) {
				Tables_IconTabBar.setExpanded(true);
			}
		});
		Tables_Panel.addContent(Tables_IconTabBar);
		var WSSchedule_IconTabFilter = new sap.m.IconTabFilter(this.createId("WSSchedule_IconTabFilter"), {
			text: "Wave Schedule",
			key: "WS"
		});
		Tables_IconTabBar.addItem(WSSchedule_IconTabFilter);
		var WSTable_VBox = new sap.m.VBox(this.createId("WSTable_VBox"), {
			fitContainer: true
		});
		WSSchedule_IconTabFilter.addContent(WSTable_VBox);
		var WS_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("WS_OverflowToolbar"), {});
		WSTable_VBox.addItem(WS_OverflowToolbar);
		var WSCount_Text = new sap.m.Text(this.createId("WSCount_Text"), {});
		WS_OverflowToolbar.addContent(WSCount_Text);
		var WSClearFilter_Icon = new sap.ui.core.Icon(this.createId("WSClearFilter_Icon"), {
			visible: false,
			tooltip: "Clear Filters",
			src: "sap-icon://clear-filter",
			size: "1.25rem",
			color: "#006ab3",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var tbBinding = WS_Table.getBinding();
				WS_Table.clearSelection();
				tbBinding.aSorters = null;
				tbBinding.aFilters = null;
				tbBinding.sFilterParams = null;
				tbBinding.sSortParams = null;

				var iTotalCols = WS_Table.getColumns().length;
				for (var i = 0; i < iTotalCols; i++) {
					WS_Table.getColumns()[i].setSorted(false);
					WS_Table.getColumns()[i].setFilterValue("");
					WS_Table.getColumns()[i].setFiltered(false);
				}

				var aSorter = [];
				var oSortKey = 'StartDateN';
				var oDescending = false;
				var oGroup = false;
				aSorter.push(new sap.ui.model.Sorter(oSortKey, oDescending, oGroup))
				tbBinding.sort(aSorter);
				WS_Table.getModel().refresh();
			}
		});
		WS_OverflowToolbar.addContent(WSClearFilter_Icon);
		var WS_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("WS_ToolbarSpacer"), {});
		WS_OverflowToolbar.addContent(WS_ToolbarSpacer);
		var WS_SearchField = new sap.m.SearchField(this.createId("WS_SearchField"), {
			placeholder: "Search by Wave Desc, User Id,  Start Date, Last Changed By",
			width: "30rem",
			liveChange: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = WS_Table.getBinding("rows");
				var aFilters = [];
				var orFilter = new sap.ui.model.Filter(
					[new sap.ui.model.Filter("WaveDescr", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("UserId", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("StartDateN", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("Aenam", sap.ui.model.FilterOperator.Contains, usrtxt)
					], false);
				aFilters.push(orFilter);
				oBinding.filter(aFilters);
			}
		});
		WS_OverflowToolbar.addContent(WS_SearchField);
		var WSRefresh_Button = new sap.m.Button(this.createId("WSRefresh_Button"), {
			type: "Emphasized",
			icon: "sap-icon://refresh",
			press: function (oEvent) {
				_getWorkBenchData();
			}
		});
		WS_OverflowToolbar.addContent(WSRefresh_Button);
		var Upload_MenuButton = new sap.m.MenuButton(this.createId("Upload_MenuButton"), {
			type: "Emphasized",
			icon: "sap-icon://upload"
		});
		WS_OverflowToolbar.addContent(Upload_MenuButton);
		var Uplaod_Menu = new sap.m.Menu(this.createId("Uplaod_Menu"), {});
		Upload_MenuButton.setMenu(Uplaod_Menu);
		var UP_Wave = new sap.m.MenuItem(this.createId("UP_Wave"), {
			text: "Wave Upload",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI                        *
				// ************************************************************************
				if (oProfileForm_Profile.getSelectedKey()) {
					//begin of DV5K931077
					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								UP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								//end of DV5K931077
								//Tab
								oIconTabBarSdwnload.setVisible(true);
								oIconTabBarSdwnload.setSelectedKey('Create');
								//Create tab
								WUCreateUpload_Btn.setVisible(true);
								Create_MessageStrip.setVisible(false);
								Create_MessageStrip.setText('Upload has 200 errors');
								//Create Upload field
								oWaveFileUpCr.setValue('');

								//Change tab
								Change_MessageStrip.setVisible(false);
								//Error Panel
								WUError_Panel.setVisible(false);
								//Dialog footer buttons
								WUProceed_Button.setVisible(false);
								oWaveFileUpChange.setValue('');
								WaveFromInp.setValue('');
								WaveToInp.setValue('');

								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								WUError_Table.setModel(jModel);
								WUError_Table.getModel().refresh();

								diaWaveUP.open();
								//begin of DV5K931077
							}
						}
					}));
					//end of DV5K931077

					//WUError_Table.getModel().setData([]);
				} else {
					sap.m.MessageToast.show('Please select Wave Profile');
				}
			}
		});
		Uplaod_Menu.addItem(UP_Wave);
		var UPUBP_MenuItem = new sap.m.MenuItem(this.createId("UPUBP_MenuItem"), {
			text: "User Base Plan",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Vishwas KN                                         *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				Panel_UBP.setVisible(true);
				oUBPUpload.setVisible(true);
				UBP_MessageStrip.setVisible(false);
				UBP_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				UBPError_Panel.setVisible(false);

				oUBPFileUploader.setValue('');

				//Dialog footer buttons
				oUBPProceed_Button.setVisible(false);
				oUBPFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				UBPError_Table.setModel(jModel);
				UBPError_Table.getModel().refresh();

				oPOR_Region.removeAllItems();

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPOR_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPOR_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPOR_Region.setSelectedKey('APAC');
					} else {
						oPOR_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oDialogUBP.open();
			}
		});
		Uplaod_Menu.addItem(UPUBP_MenuItem);
		var UP_PLAPOR = new sap.m.MenuItem(this.createId("UP_PLAPOR"), {
			text: "PLA POR upload",
			press: function (oEvent) {
				Panel_PPU.setVisible(true);
				oPPUUpload.setVisible(true);
				PPU_MessageStrip.setVisible(false);
				//PPU_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				PPUError_Panel.setVisible(false);

				oPPUFileUploader.setValue('');

				//Dialog footer buttons
				oPPUProceed_Button.setVisible(false);
				oPPUFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				PPUError_Table.setModel(jModel);
				PPUError_Table.getModel().refresh();

				oPPOR_Region.removeAllItems();
				oPPU_Week.removeAllItems();
				debugger;
				var vlen = oProfileForm_Week.getItems().length;
				for (var i = 0; i < vlen; i++) {
					var lv_week = oProfileForm_Week.getItems()[i];

					if (oProfileForm_Week.getItems()[i].getKey() !== 'PAST') {
						oPPU_Week.addItem(new sap.ui.core.Item({
							key: lv_week.getKey(),
							text: lv_week.getText()
						}));
					}
				}
				oPPU_Week.setSelectedKey(oProfileForm_Week.getSelectedKey());

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPPOR_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPPOR_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPPOR_Region.setSelectedKey('APAC');
					} else {
						oPPOR_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oPPOR_Region.setEnabled(false);
				oDialogPLAPOR_UPD.open();
			}
		});
		Uplaod_Menu.addItem(UP_PLAPOR);
		var UP_PLAGATP = new sap.m.MenuItem(this.createId("UP_PLAGATP"), {
			text: "PLA GATP upload",
			press: function (oEvent) {
				Panel_PGU.setVisible(true);
				oPGUUpload.setVisible(true);
				PGU_MessageStrip.setVisible(false);
				//PGU_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				PGUError_Panel.setVisible(false);

				oPGUFileUploader.setValue('');

				//Dialog footer buttons
				oPGUProceed_Button.setVisible(false);
				oPGUFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				PGUError_Table.setModel(jModel);
				PGUError_Table.getModel().refresh();

				oPPOR_Region.removeAllItems();
				oPGU_Week.removeAllItems();
				debugger;
				var vlen = oProfileForm_Week.getItems().length;
				for (var i = 0; i < vlen; i++) {
					var lv_week = oProfileForm_Week.getItems()[i];

					if (oProfileForm_Week.getItems()[i].getKey() !== 'PAST') {
						oPGU_Week.addItem(new sap.ui.core.Item({
							key: lv_week.getKey(),
							text: lv_week.getText()
						}));
					}
				}
				oPGU_Week.setSelectedKey(oProfileForm_Week.getSelectedKey());

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPGU_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPGU_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPGU_Region.setSelectedKey('APAC');
					} else {
						oPGU_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oPPOR_Region.setEnabled(false);
				//#94170129 - By default set the check consumption flag to true as Release PLA POR will be set to false by default
				Switch_Coms_status.setState(true);
				Switch_Release_POR.setState(false);
				oDialogPLAGATP_UPD.open();
			}
		});
		Uplaod_Menu.addItem(UP_PLAGATP);
		var Create_Button = new sap.m.Button(this.createId("Create_Button"), {
			text: "Wave Create",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI
				// ************************************************************************
				if (lz_createValidate()) {

					// AppCache.Load("ZUI_DAT_WAVE_CREATION", {
					//     startParams: {
					//         mode: "CREATE",
					//         wbProfile: oProfileForm_Profile.getSelectedKey(),
					//         wbWeek: oProfileForm_Week.getSelectedKey(),
					//         wbWeekValue: gWBWeekValue,
					//         wbProfileValue: gWBProfileValue,
					//         wbRegion: gWaveProfileSelRegion,
					//         initFn: function(param) {
					//             console.log("Reciever message: " + param);
					//         }
					//     }
					// });
					//begin of DV5K931077
					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								UP_Wave.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								_waveCreate();
							}
						}
					}));

					// AppCache.Load("ZUI_DAT_WAVE_CREATION", {
					// parentObject: CWPage,
					//         startParams: {
					//         mode: "CREATE",
					//         wbProfile: oProfileForm_Profile.getSelectedKey(),
					//         wbWeek: oProfileForm_Week.getSelectedKey(),
					//         wbRegion: gWaveProfileSelRegion,
					//         wbWeekValue: gWBWeekValue,
					//         wbProfileValue: gWBProfileValue,
					//         initFn: function(param) {
					//             console.log("Reciever message: " + param);
					//         }
					//     }
					// });
					// CWPage.setShowFooter(false);
					// oApp.to(CWPage);
					// CWPage.setShowFooter(false);
					//end of DV5K931077
				} else {
					if (oProfileForm_Week.getSelectedKey() == "PAST") {
						sap.m.MessageToast.show('Wave creation not allowed for past week');
					} else {
						sap.m.MessageToast.show('Select valid week and wave profile');
					}
				}
				//begin of DV5K931077
				function _waveCreate() {
					AppCache.Load("ZUI_DAT_WAVE_CREATION", {
						parentObject: CWPage,
						startParams: {
							mode: "CREATE",
							wbProfile: oProfileForm_Profile.getSelectedKey(),
							wbWeek: oProfileForm_Week.getSelectedKey(),
							wbRegion: gWaveProfileSelRegion,
							wbWeekValue: gWBWeekValue,
							wbProfileValue: gWBProfileValue,
							initFn: function (param) {
								console.log("Reciever message: " + param);
							}
						}
					});
					CWPage.setShowFooter(false);
					oApp.to(CWPage);
					CWPage.setShowFooter(false);
				}
				//end of DV5K931077
				function lz_createValidate() {
					var bReturn = true;
					if (oProfileForm_Week.getSelectedKey() == undefined || oProfileForm_Week.getSelectedKey() == null || oProfileForm_Week.getSelectedKey() ==
						'') {
						bReturn = false;
					}
					if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
						'') {
						bReturn = false;
					}
					if (oProfileForm_Week.getSelectedKey() == "PAST") {
						bReturn = false;
					}
					return bReturn;
				}
			}
		});
		WS_OverflowToolbar.addContent(Create_Button);
		var Change_Button = new sap.m.Button(this.createId("Change_Button"), {
			type: "Emphasized",
			tooltip: "Edit Wave Schedule",
			icon: "sap-icon://edit-outside",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				//Siva Change Icon Click
				var indices = WS_Table.getSelectedIndices();
				if (indices.length > 1) {
					sap.m.MessageToast.show('Multiple selection not allowed');
				} else {
					if (indices.length > 0) {
						var index = indices[0];
						var tdData = WS_Table.getContextByIndex(index).getObject();
						if (tdData.WaveSchMode == 'IMME') {
							sap.m.MessageToast.show('Schedule mode: Immediate. Change not allowed.');
						} else {
							AppCache.Load("ZUI_DAT_WAVE_CREATION", {
								parentObject: CWPage,
								startParams: {
									mode: "CHANGE",
									wbSchGuid: tdData.SchGuid,
									wbWeek: oProfileForm_Week.getSelectedKey(),
									wbProfile: oProfileForm_Profile.getSelectedKey(),
									wbRegion: gWaveProfileSelRegion,
									wbWeekValue: gWBWeekValue,
									wbProfileValue: gWBProfileValue,
								}
							});
							oApp.to(CWPage);
							CWPage.setShowFooter(false);
						}
					} else {
						sap.m.MessageToast.show('Please select a schedule to change');
					}
				}
			}
		});
		WS_OverflowToolbar.addContent(Change_Button);
		var Delete_Button = new sap.m.Button(this.createId("Delete_Button"), {
			type: "Emphasized",
			icon: "sap-icon://delete",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var indices = WS_Table.getSelectedIndices();
				if (indices.length > 0) {
					$.sap.require("sap.m.Dialog");
					$.sap.require("sap.m.Text");
					$.sap.require("sap.m.Button");
					var dialog = new sap.m.Dialog({
						title: 'Confirm',
						type: 'Message',
						content: new sap.m.Text({
							text: 'Are you sure you want to delete the selected schedules'
						}),
						beginButton: new sap.m.Button({
							text: 'OK',
							press: function () {
								_okScheduleDeleteNow();
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						endButton: new sap.m.Button({
							text: 'Cancel',
							press: function () {
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						afterClose: function () {
							dialog.close();
						}
					}).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
					dialog.open();
				} else {
					sap.m.MessageToast.show('Select one or more schedules to delete');
				}

				function _okScheduleDeleteNow() {
					var indices = WS_Table.getSelectedIndices();
					var oresp;
					if (indices.length > 0) {
						var xdData = {
							ActionId: 'DELETE',
							Message: '',
							Function: 'WW',
							NAVActionWaves: [],
							NAVActionSch: []
						};
						for (var i = 0; i < indices.length; i++) {
							var index = WS_Table.getSelectedIndices()[i];
							var tData = WS_Table.getContextByIndex(index).getObject();
							var xd = {
								SchGuid: tData.SchGuid
							}
							xdData.NAVActionSch.push(xd);
						}
						var dPromise = $.Deferred();
						gWBModel.create('/ActionSet', xdData, {
							success: function (oData, resp) {
								oresp = oData;
								dPromise.resolve();
							},
							error: function (oError) {
								dPromise.resolve();
								sap.m.MessageToast.show('Error');
							}
						});
						Promise.all(
							[
								dPromise
							]).then($.proxy(function () {
							$.sap.require("sap.m.MessageToast");
							if (oresp.Function == "") {

								sap.m.MessageToast.show('No Authorization');
							} else {
								sap.m.MessageToast.show('Deleted schedule scuccesfully');
								_getWorkBenchData();
							}
						}));
					}
				}

				/*

				*/
			}
		});
		WS_OverflowToolbar.addContent(Delete_Button);
		var selectVariant = new sap.m.Select(this.createId("selectVariant"), {
			forceSelection: false,
			change: function (oEvent) {
				processVariant(WS_Table);
			}
		});
		WS_OverflowToolbar.addContent(selectVariant);
		var Variant_Button = new sap.m.Button(this.createId("Variant_Button"), {
			icon: "sap-icon://key-user-settings",
			tooltip: "Personalization setting",
			type: "Emphasized",
			press: function (oEvent) {
				loadApp("ZUI_DAT_WORKBENCH_WAVES", "WS_Table", WS_Table);
				//getVarient("WS_Table");
			}
		});
		WS_OverflowToolbar.addContent(Variant_Button);
		var WS_Table = new sap.ui.table.Table(this.createId("WS_Table"), {
			fixedColumnCount: 2,
			selectionMode: "Multi",
			visibleRowCount: 14
		});
		WSTable_VBox.addItem(WS_Table);
		var modelWS_Table = new sap.ui.model.json.JSONModel();
		WS_Table.setModel(modelWS_Table);
		WS_Table.bindRows("/");
		var WaveDesc_Column = new sap.ui.table.Column(this.createId("WaveDesc_Column"), {
			label: new sap.m.Label({
				text: "Wave Description"
			}),
			filterOperator: "Contains",
			filterProperty: "WaveDescr",
			sortProperty: "WaveDescr",
			width: "15rem"
		});
		WS_Table.addColumn(WaveDesc_Column);
		var WaveDesc_Text = new sap.m.Link(this.createId("WaveDesc_Text"), {
			text: "{WaveDescr}",
			press: function (oEvent) {
				sap.ui.core.BusyIndicator.show(0);
				var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
				var tData = WS_Table.getModel().getData()[index];
				_getDisplayData();

				/*Edit Scenario*/
				function _getDisplayData() {
					var aFilters = [];
					var localTimeZone = new Date().toString().split(" ")[5];

					gSelTblProfile = '';
					gSelTblWeek = '';
					gSelTblSchGuid = '';
					gSelTblScheduleAt = '';
					gSelTblRegion = '';
					gSelTblCvcVariant = '';

					gSelTblWeek = tData.FiscWeek;
					gSelTblProfile = tData.Secprofile;
					gSelTblSchGuid = tData.SchGuid;
					gSelTblScheduleAt = localTimeZone;
					gSelTblRegion = tData.Region;
					gSelTblCvcVariant = tData.CvcVariant;

					gDisplayData = '';
					aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, tData.FiscWeek));
					aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, tData.Secprofile));
					aFilters.push(new sap.ui.model.Filter("SchGuid", sap.ui.model.FilterOperator.EQ, tData.SchGuid));
					aFilters.push(new sap.ui.model.Filter("ScheduleAt", sap.ui.model.FilterOperator.EQ, localTimeZone));
					aFilters.push(new sap.ui.model.Filter("DisplayCall", sap.ui.model.FilterOperator.EQ, 'X'));

					var displayPromise = $.Deferred();
					gWaveModel.read('/WaveDataSet', {
						filters: aFilters,
						urlParameters: {
							'$expand': 'NAVWaveCVCList,NAVWaveCumPer,NAVWaveCumBase,NAVWaveProdQty,NAVWaveWeekDay,NAVWaveSourcPlant,NAVWaveSratSales,NAVWaveSratSold,NAVWaveGridSel,NAVWaveMulsch'
						},
						success: function (oData, resp) {
							gDisplayData = oData.results[0];
							displayPromise.resolve();
						},
						error: function (oError) {
							sap.m.MessageToast.show('error week profile');
							sap.ui.core.BusyIndicator.hide(); //Edit Busy
						}
					});
					Promise.all(
						[
							displayPromise
						]
					).then($.proxy(function () {
						_setDisplayData(gDisplayData);
					}));
				}
			}
		});
		WaveDesc_Column.setTemplate(WaveDesc_Text);
		var OpsSubClass_Column = new sap.ui.table.Column(this.createId("OpsSubClass_Column"), {
			label: new sap.m.Label({
				text: "Ops SubClass"
			}),
			width: "8rem",
			sortProperty: "OpsSubclass",
			filterProperty: "OpsSubclass",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(OpsSubClass_Column);
		var OpsSubClass_HBox = new sap.m.HBox(this.createId("OpsSubClass_HBox"), {});
		OpsSubClass_Column.setTemplate(OpsSubClass_HBox);
		var OpsSubClass_Text1 = new sap.m.Text(this.createId("OpsSubClass_Text1"), {
			text: "{OpsSubclass}",
			width: "6rem"
		});
		OpsSubClass_HBox.addItem(OpsSubClass_Text1);
		var OpsSubClass_Icon = new sap.ui.core.Icon(this.createId("OpsSubClass_Icon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{OpsSubclassV}",
			width: "8px",
			press: function (oEvent) {
				getF4Values(oEvent, 'OPS_SUBCLASS', 'OPS SubClass', 'OPS Subclass');
			}
		});
		OpsSubClass_HBox.addItem(OpsSubClass_Icon);
		var MPNSel_Column = new sap.ui.table.Column(this.createId("MPNSel_Column"), {
			label: new sap.m.Label({
				text: "MPN"
			}),
			filterOperator: "Contains",
			filterProperty: "MPN",
			sortProperty: "MPN",
			width: "8rem"
		});
		WS_Table.addColumn(MPNSel_Column);
		var MPNSel_HBox = new sap.m.HBox(this.createId("MPNSel_HBox"), {});
		MPNSel_Column.setTemplate(MPNSel_HBox);
		var MPNSel_Text2 = new sap.m.Text(this.createId("MPNSel_Text2"), {
			text: "{MPN}",
			width: "6rem"
		});
		MPNSel_HBox.addItem(MPNSel_Text2);
		var MPNSel_Icon = new sap.ui.core.Icon(this.createId("MPNSel_Icon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{RuleMatnrV}",
			width: "8px",
			press: function (oEvent) {
				getF4Values(oEvent, 'RULE_MATNR', 'MPN', 'MPN');
			}
		});
		MPNSel_HBox.addItem(MPNSel_Icon);
		var SalesOrg_Column = new sap.ui.table.Column(this.createId("SalesOrg_Column"), {
			label: new sap.m.Label({
				text: "Sales Org."
			}),
			width: "8rem",
			sortProperty: "SalesOrg",
			filterProperty: "SalesOrg",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(SalesOrg_Column);
		var SalesOrg_HBox = new sap.m.HBox(this.createId("SalesOrg_HBox"), {});
		SalesOrg_Column.setTemplate(SalesOrg_HBox);
		var SalesOrg_Text3 = new sap.m.Text(this.createId("SalesOrg_Text3"), {
			width: "6rem",
			text: "{SalesOrg}"
		});
		SalesOrg_HBox.addItem(SalesOrg_Text3);
		var SalesOrg_Icon = new sap.ui.core.Icon(this.createId("SalesOrg_Icon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{VkorgV}",
			width: "8px",
			press: function (oEvent) {
				getF4Values(oEvent, 'VKORG', 'Sales Org', 'Sales Org');
			}
		});
		SalesOrg_HBox.addItem(SalesOrg_Icon);
		var Channel_Column = new sap.ui.table.Column(this.createId("Channel_Column"), {
			label: new sap.m.Label({
				text: "Channel"
			}),
			width: "8rem",
			sortProperty: "Channel",
			filterProperty: "Channel",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(Channel_Column);
		var Channel_HBox = new sap.m.HBox(this.createId("Channel_HBox"), {});
		Channel_Column.setTemplate(Channel_HBox);
		var Channel_Text4 = new sap.m.Text(this.createId("Channel_Text4"), {
			text: "{Channel}",
			width: "6rem"
		});
		Channel_HBox.addItem(Channel_Text4);
		var Channel_Icon = new sap.ui.core.Icon(this.createId("Channel_Icon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{ZdistcV}",
			width: "8px",
			press: function (oEvent) {
				getF4Values(oEvent, 'ZDISTC', 'Channel', 'Channel');
			}
		});
		Channel_HBox.addItem(Channel_Icon);
		var SoldToSel_Column = new sap.ui.table.Column(this.createId("SoldToSel_Column"), {
			label: new sap.m.Label({
				text: "Sold To"
			}),
			filterOperator: "Contains",
			filterProperty: "SoldTo",
			sortProperty: "SoldTo",
			width: "8.5rem"
		});
		WS_Table.addColumn(SoldToSel_Column);
		var SoldToSel_HBox = new sap.m.HBox(this.createId("SoldToSel_HBox"), {});
		SoldToSel_Column.setTemplate(SoldToSel_HBox);
		var SoldToSel_Text5 = new sap.m.Text(this.createId("SoldToSel_Text5"), {
			text: "{SoldTo}",
			width: "6rem"
		});
		SoldToSel_HBox.addItem(SoldToSel_Text5);
		var SoldToSel_Icon = new sap.ui.core.Icon(this.createId("SoldToSel_Icon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{KunnrV}",
			width: "8px",
			press: function (oEvent) {
				getF4Values(oEvent, 'KUNNR', 'Sold To', 'Sold To');
			}
		});
		SoldToSel_HBox.addItem(SoldToSel_Icon);
		var NextStartDate_Column = new sap.ui.table.Column(this.createId("NextStartDate_Column"), {
			label: new sap.m.Label({
				text: "Next Start Time"
			}),
			filterOperator: "Contains",
			filterProperty: "StartDateN",
			sortProperty: "StartDateN",
			width: "13rem"
		});
		WS_Table.addColumn(NextStartDate_Column);
		var NextStartDate_Text6 = new sap.m.Text(this.createId("NextStartDate_Text6"), {
			text: "{StartDateN}"
		});
		NextStartDate_Column.setTemplate(NextStartDate_Text6);
		var WaveStrategy_Column = new sap.ui.table.Column(this.createId("WaveStrategy_Column"), {
			label: new sap.m.Label({
				text: "Wave Strategy"
			}),
			filterOperator: "Contains",
			filterProperty: "WaveStrat",
			sortProperty: "WaveStrat",
			width: "15rem"
		});
		WS_Table.addColumn(WaveStrategy_Column);
		var WaveStrategy_Text8 = new sap.m.Text(this.createId("WaveStrategy_Text8"), {
			text: "{WaveStrat}"
		});
		WaveStrategy_Column.setTemplate(WaveStrategy_Text8);
		var WaveRelease_Column = new sap.ui.table.Column(this.createId("WaveRelease_Column"), {
			label: new sap.m.Label({
				text: "Wave Release"
			}),
			filterOperator: "Contains",
			filterProperty: "WaveRelMech",
			sortProperty: "WaveRelMech",
			width: "11rem"
		});
		WS_Table.addColumn(WaveRelease_Column);
		var WaveRelease_Text9 = new sap.m.Text(this.createId("WaveRelease_Text9"), {
			text: "{WaveRelMech}"
		});
		WaveRelease_Column.setTemplate(WaveRelease_Text9);
		var WaveRelDT_Column = new sap.ui.table.Column(this.createId("WaveRelDT_Column"), {
			label: new sap.m.Label({
				text: "Planned Release Time"
			}),
			width: "14rem",
			sortProperty: "WaveRelDate",
			filterProperty: "WaveRelDate",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(WaveRelDT_Column);
		var WaveRelDT_Text10 = new sap.m.Text(this.createId("WaveRelDT_Text10"), {
			text: "{WaveRelDate}"
		});
		WaveRelDT_Column.setTemplate(WaveRelDT_Text10);
		var WeekDays_Column = new sap.ui.table.Column(this.createId("WeekDays_Column"), {
			label: new sap.m.Label({
				text: "Week Days"
			}),
			filterProperty: "WeekDays",
			sortProperty: "WeekDays",
			width: "15rem"
		});
		WS_Table.addColumn(WeekDays_Column);
		var WeekDays_Text2 = new sap.m.Text(this.createId("WeekDays_Text2"), {
			text: "{WeekDays}"
		});
		WeekDays_Column.setTemplate(WeekDays_Text2);
		var CreatedBy_Column3 = new sap.ui.table.Column(this.createId("CreatedBy_Column3"), {
			label: new sap.m.Label({
				text: "Created By"
			}),
			filterOperator: "Contains",
			filterProperty: "UserId",
			sortProperty: "UserId",
			width: "12rem"
		});
		WS_Table.addColumn(CreatedBy_Column3);
		var CreatedBy_Text11 = new sap.m.Text(this.createId("CreatedBy_Text11"), {
			text: "{UserId}"
		});
		CreatedBy_Column3.setTemplate(CreatedBy_Text11);
		var FrequencyType_Column = new sap.ui.table.Column(this.createId("FrequencyType_Column"), {
			label: new sap.m.Label({
				text: "Frequency Type"
			}),
			width: "10rem",
			sortProperty: "FreqType",
			filterProperty: "FreqType",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(FrequencyType_Column);
		var FrequencyType_Text12 = new sap.m.Text(this.createId("FrequencyType_Text12"), {
			text: "{FreqType}"
		});
		FrequencyType_Column.setTemplate(FrequencyType_Text12);
		var Frequency_Column = new sap.ui.table.Column(this.createId("Frequency_Column"), {
			label: new sap.m.Label({
				text: "Frequency"
			}),
			filterOperator: "Contains",
			filterProperty: "Frequency",
			sortProperty: "Frequency",
			width: "7rem"
		});
		WS_Table.addColumn(Frequency_Column);
		var Frequency_Text13 = new sap.m.Text(this.createId("Frequency_Text13"), {
			text: "{Frequency}"
		});
		Frequency_Column.setTemplate(Frequency_Text13);
		var TillDate_Column1 = new sap.ui.table.Column(this.createId("TillDate_Column1"), {
			label: new sap.m.Label({
				text: "Till Time"
			}),
			width: "14rem",
			sortProperty: "EndDate",
			filterProperty: "EndDate"
		});
		WS_Table.addColumn(TillDate_Column1);
		var Text1 = new sap.m.Text(this.createId("Text1"), {
			text: "{EndDate}"
		});
		TillDate_Column1.setTemplate(Text1);
		var CVCVariant_Column = new sap.ui.table.Column(this.createId("CVCVariant_Column"), {
			label: new sap.m.Label({
				text: "CVC Variant"
			}),
			filterProperty: "CvcVariant",
			sortProperty: "CvcVariant",
			width: "15rem"
		});
		WS_Table.addColumn(CVCVariant_Column);
		var Text3 = new sap.m.Text(this.createId("Text3"), {
			text: "{CvcVariant}"
		});
		CVCVariant_Column.setTemplate(Text3);
		var StrategyVar_Column3 = new sap.ui.table.Column(this.createId("StrategyVar_Column3"), {
			label: new sap.m.Label({
				text: "Strategy Variant"
			}),
			filterProperty: "StratVariant",
			sortProperty: "StratVariant",
			width: "15rem"
		});
		WS_Table.addColumn(StrategyVar_Column3);
		var Text4 = new sap.m.Text(this.createId("Text4"), {
			text: "{StratVariant}"
		});
		StrategyVar_Column3.setTemplate(Text4);
		var SchGuid_Column = new sap.ui.table.Column(this.createId("SchGuid_Column"), {
			label: new sap.m.Label({
				text: "Sch Guid"
			}),
			width: "15rem",
			sortProperty: "SchGuid",
			filterProperty: "SchGuid"
		});
		WS_Table.addColumn(SchGuid_Column);
		var SchGuid_Text2 = new sap.m.Text(this.createId("SchGuid_Text2"), {
			text: "{SchGuid}"
		});
		SchGuid_Column.setTemplate(SchGuid_Text2);
		var CreatedDT_Column = new sap.ui.table.Column(this.createId("CreatedDT_Column"), {
			label: new sap.m.Label({
				text: "Created Time"
			}),
			width: "13rem",
			sortProperty: "CreateDate",
			filterProperty: "CreateDate"
		});
		WS_Table.addColumn(CreatedDT_Column);
		var CreatedDT_Text5 = new sap.m.Text(this.createId("CreatedDT_Text5"), {
			text: "{CreateDate}"
		});
		CreatedDT_Column.setTemplate(CreatedDT_Text5);
		var LastChangedBy_Column = new sap.ui.table.Column(this.createId("LastChangedBy_Column"), {
			label: new sap.m.Label({
				text: "Last Changed By"
			}),
			filterProperty: "Aenam",
			sortProperty: "Aenam",
			width: "10rem"
		});
		WS_Table.addColumn(LastChangedBy_Column);
		var LastChangedBy_Text5 = new sap.m.Text(this.createId("LastChangedBy_Text5"), {
			text: "{Aenam}"
		});
		LastChangedBy_Column.setTemplate(LastChangedBy_Text5);
		var LastChangedDate_Column = new sap.ui.table.Column(this.createId("LastChangedDate_Column"), {
			label: new sap.m.Label({
				text: "Last Changed Time"
			}),
			width: "15rem",
			filterProperty: "Aedat",
			sortProperty: "Aedat"
		});
		WS_Table.addColumn(LastChangedDate_Column);
		var LastChangeDate_Text5 = new sap.m.Text(this.createId("LastChangeDate_Text5"), {
			text: "{Aedat}"
		});
		LastChangedDate_Column.setTemplate(LastChangeDate_Text5);
		var ScheduleMode_Column = new sap.ui.table.Column(this.createId("ScheduleMode_Column"), {
			label: new sap.m.Label({
				text: "Schedule Mode"
			}),
			width: "10rem",
			sortProperty: "WaveSchMode",
			filterProperty: "WaveSchMode"
		});
		WS_Table.addColumn(ScheduleMode_Column);
		var ScheduleMode_Text = new sap.m.Text(this.createId("ScheduleMode_Text"), {
			text: "{WaveSchMode}"
		});
		ScheduleMode_Column.setTemplate(ScheduleMode_Text);
		var StartTime1_Column = new sap.ui.table.Column(this.createId("StartTime1_Column"), {
			label: new sap.m.Label({
				text: "Start Time1"
			}),
			filterOperator: "Contains",
			filterProperty: "StartTime1",
			sortProperty: "StartTime1",
			width: "8rem"
		});
		WS_Table.addColumn(StartTime1_Column);
		var StarTime1_Text1 = new sap.m.Text(this.createId("StarTime1_Text1"), {
			text: "{StartTime1}"
		});
		StartTime1_Column.setTemplate(StarTime1_Text1);
		var StartTime2_Column = new sap.ui.table.Column(this.createId("StartTime2_Column"), {
			label: new sap.m.Label({
				text: "Start Time2"
			}),
			width: "8rem",
			sortProperty: "StartTime2",
			filterProperty: "StartTime2",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(StartTime2_Column);
		var StarTime2_Text1 = new sap.m.Text(this.createId("StarTime2_Text1"), {
			text: "{StartTime2}"
		});
		StartTime2_Column.setTemplate(StarTime2_Text1);
		var StartTime3_Column = new sap.ui.table.Column(this.createId("StartTime3_Column"), {
			label: new sap.m.Label({
				text: "Start Time3"
			}),
			filterOperator: "Contains",
			filterProperty: "StartTime3",
			sortProperty: "StartTime3",
			width: "8rem"
		});
		WS_Table.addColumn(StartTime3_Column);
		var StarTime3_Text1 = new sap.m.Text(this.createId("StarTime3_Text1"), {
			text: "{StartTime3}"
		});
		StartTime3_Column.setTemplate(StarTime3_Text1);
		var StartTime4_Column = new sap.ui.table.Column(this.createId("StartTime4_Column"), {
			label: new sap.m.Label({
				text: "Start Time4"
			}),
			width: "8rem",
			sortProperty: "StartTime4",
			filterProperty: "StartTime4",
			filterOperator: "Contains"
		});
		WS_Table.addColumn(StartTime4_Column);
		var StarTime1_Text4 = new sap.m.Text(this.createId("StarTime1_Text4"), {
			text: "{StartTime4}"
		});
		StartTime4_Column.setTemplate(StarTime1_Text4);
		var Wave_IconTabFilter = new sap.m.IconTabFilter(this.createId("Wave_IconTabFilter"), {
			key: "Wave",
			text: "Wave"
		});
		Tables_IconTabBar.addItem(Wave_IconTabFilter);
		var Wave_VBox = new sap.m.VBox(this.createId("Wave_VBox"), {});
		Wave_IconTabFilter.addContent(Wave_VBox);
		var Wave_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("Wave_OverflowToolbar"), {});
		Wave_VBox.addItem(Wave_OverflowToolbar);
		var WaveCount_Text = new sap.m.Text(this.createId("WaveCount_Text"), {});
		Wave_OverflowToolbar.addContent(WaveCount_Text);
		var Wave_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("Wave_ToolbarSpacer"), {});
		Wave_OverflowToolbar.addContent(Wave_ToolbarSpacer);
		var Wave_SearchField = new sap.m.SearchField(this.createId("Wave_SearchField"), {
			width: "35rem",
			placeholder: "Search by Wave Nbr, Desc, Job Name, Status, Create Date, Wave Release Time",
			liveChange: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = Wave_Table.getBinding("rows");
				var aFilters = [];
				var orFilter = new sap.ui.model.Filter(
					[new sap.ui.model.Filter("WaveNr", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("WaveDescr", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("JobName", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("CreateDate", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("WaveRelTime", sap.ui.model.FilterOperator.Contains, usrtxt)
					], false);
				aFilters.push(orFilter);
				oBinding.filter(aFilters);
			}
		});
		Wave_OverflowToolbar.addContent(Wave_SearchField);
		var WRefresh_Button = new sap.m.Button(this.createId("WRefresh_Button"), {
			type: "Emphasized",
			icon: "sap-icon://refresh",
			press: function (oEvent) {
				_getWorkBenchData();
			}
		});
		Wave_OverflowToolbar.addContent(WRefresh_Button);
		var WUpload_MenuButton = new sap.m.MenuButton(this.createId("WUpload_MenuButton"), {
			icon: "sap-icon://upload",
			type: "Emphasized"
		});
		Wave_OverflowToolbar.addContent(WUpload_MenuButton);
		var WUplaod_Menu = new sap.m.Menu(this.createId("WUplaod_Menu"), {});
		WUpload_MenuButton.setMenu(WUplaod_Menu);
		var WUP_Wave = new sap.m.MenuItem(this.createId("WUP_Wave"), {
			text: "Wave Upload",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI                        *
				// ************************************************************************
				if (oProfileForm_Profile.getSelectedKey()) {
					//begin of DV5K931077
					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								UP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								//end of DV5K931077
								//Tab
								oIconTabBarSdwnload.setVisible(true);
								oIconTabBarSdwnload.setSelectedKey('Create');
								//Create tab
								WUCreateUpload_Btn.setVisible(true);
								Create_MessageStrip.setVisible(false);
								Create_MessageStrip.setText('Upload has 200 errors');
								//Create Upload field
								oWaveFileUpCr.setValue('');

								//Change tab
								Change_MessageStrip.setVisible(false);
								//Error Panel
								WUError_Panel.setVisible(false);
								//Dialog footer buttons
								WUProceed_Button.setVisible(false);
								oWaveFileUpChange.setValue('');
								WaveFromInp.setValue('');
								WaveToInp.setValue('');

								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								WUError_Table.setModel(jModel);
								WUError_Table.getModel().refresh();

								diaWaveUP.open();
								//begin of DV5K931077
							}
						}
					}));
					//end of DV5K931077
					//WUError_Table.getModel().setData([]);
				} else {
					sap.m.MessageToast.show('Please select Wave Profile');
				}
			}
		});
		WUplaod_Menu.addItem(WUP_Wave);
		var WUPUBP_MenuItem = new sap.m.MenuItem(this.createId("WUPUBP_MenuItem"), {
			text: "User Base Plan",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Vishwas KN                                         *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				Panel_UBP.setVisible(true);
				oUBPUpload.setVisible(true);
				UBP_MessageStrip.setVisible(false);
				UBP_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				UBPError_Panel.setVisible(false);

				oUBPFileUploader.setValue('');

				//Dialog footer buttons
				oUBPProceed_Button.setVisible(false);
				oUBPFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				UBPError_Table.setModel(jModel);
				UBPError_Table.getModel().refresh();

				oPOR_Region.removeAllItems();

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPOR_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPOR_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPOR_Region.setSelectedKey('APAC');
					} else {
						oPOR_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oDialogUBP.open();
			}
		});
		WUplaod_Menu.addItem(WUPUBP_MenuItem);
		var WUP_PLAPOR = new sap.m.MenuItem(this.createId("WUP_PLAPOR"), {
			text: "PLA POR Upload",
			press: function (oEvent) {
				Panel_PPU.setVisible(true);
				oPPUUpload.setVisible(true);
				PPU_MessageStrip.setVisible(false);
				//PPU_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				PPUError_Panel.setVisible(false);

				oPPUFileUploader.setValue('');

				//Dialog footer buttons
				oPPUProceed_Button.setVisible(false);
				oPPUFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				PPUError_Table.setModel(jModel);
				PPUError_Table.getModel().refresh();

				oPPOR_Region.removeAllItems();
				oPPU_Week.removeAllItems();
				debugger;
				var vlen = oProfileForm_Week.getItems().length;
				for (var i = 0; i < vlen; i++) {
					var lv_week = oProfileForm_Week.getItems()[i];

					if (oProfileForm_Week.getItems()[i].getKey() !== 'PAST') {

						oPPU_Week.addItem(new sap.ui.core.Item({
							key: lv_week.getKey(),
							text: lv_week.getText()
						}));
					}
				}
				oPPU_Week.setSelectedKey(oProfileForm_Week.getSelectedKey());

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPPOR_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPPOR_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPPOR_Region.setSelectedKey('APAC');
					} else {
						oPPOR_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oPPOR_Region.setEnabled(false);
				oDialogPLAPOR_UPD.open();
			}
		});
		WUplaod_Menu.addItem(WUP_PLAPOR);
		var WUP_PLAGATP = new sap.m.MenuItem(this.createId("WUP_PLAGATP"), {
			text: "PLA GATP upload",
			press: function (oEvent) {
				Panel_PGU.setVisible(true);
				oPGUUpload.setVisible(true);
				PGU_MessageStrip.setVisible(false);
				//PGU_MessageStrip.setText('Upload has 200 errors');

				//Error Panel
				PGUError_Panel.setVisible(false);

				oPGUFileUploader.setValue('');

				//Dialog footer buttons
				oPGUProceed_Button.setVisible(false);
				oPGUFileUploader.setValue('');

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData([]);

				PGUError_Table.setModel(jModel);
				PGUError_Table.getModel().refresh();

				oPPOR_Region.removeAllItems();
				oPGU_Week.removeAllItems();
				debugger;
				var vlen = oProfileForm_Week.getItems().length;
				for (var i = 0; i < vlen; i++) {
					var lv_week = oProfileForm_Week.getItems()[i];

					if (oProfileForm_Week.getItems()[i].getKey() !== 'PAST') {
						oPGU_Week.addItem(new sap.ui.core.Item({
							key: lv_week.getKey(),
							text: lv_week.getText()
						}));
					}
				}
				oPGU_Week.setSelectedKey(oProfileForm_Week.getSelectedKey());

				var len = gRegionVals.getItems().length;
				for (var i = 0; i < len; i++) {
					var lv_region = gRegionVals.getItems()[i];

					oPGU_Region.addItem(new sap.ui.core.Item({
						key: lv_region.getKey(),
						text: lv_region.getText()
					}));
				}
				if (gWaveProfileSelRegion == 'EURO' || gWaveProfileSelRegion == 'EMEA') {
					oPGU_Region.setSelectedKey('EMEA_MPN');
				} else {
					if (gWaveProfileSelRegion == 'PAC' || gWaveProfileSelRegion == 'APAC') {
						oPGU_Region.setSelectedKey('APAC');
					} else {
						oPGU_Region.setSelectedKey(gWaveProfileSelRegion);
					}
				}
				oPPOR_Region.setEnabled(false);
				//#94170129 - By default set the check consumption flag to true as Release PLA POR will be set to false by default
				Switch_Coms_status.setState(true);
				Switch_Release_POR.setState(false);
				oDialogPLAGATP_UPD.open();
			}
		});
		WUplaod_Menu.addItem(WUP_PLAGATP);
		var WCreate_Button = new sap.m.Button(this.createId("WCreate_Button"), {
			text: "Wave Create",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI                        *
				// ************************************************************************
				if (lz_createValidate()) {

					// AppCache.Load("ZUI_DAT_WAVE_CREATION", {
					//     startParams: {
					//         mode: "CREATE",
					//         wbProfile: oProfileForm_Profile.getSelectedKey(),
					//         wbWeek: oProfileForm_Week.getSelectedKey(),
					//         wbWeekValue: gWBWeekValue,
					//         wbProfileValue: gWBProfileValue,
					//         wbRegion: gWaveProfileSelRegion,
					//         initFn: function(param) {
					//             console.log("Reciever message: " + param);
					//         }
					//     }
					// });
					//Begin of DV5K931077
					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								UP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								_waveCreate();
							}
						}
					}));

					// AppCache.Load("ZUI_DAT_WAVE_CREATION", {
					// parentObject: CWPage,
					//         startParams: {
					//         mode: "CREATE",
					//         wbProfile: oProfileForm_Profile.getSelectedKey(),
					//         wbWeek: oProfileForm_Week.getSelectedKey(),
					//         wbRegion: gWaveProfileSelRegion,
					//         wbWeekValue: gWBWeekValue,
					//         wbProfileValue: gWBProfileValue,
					//         initFn: function(param) {
					//             console.log("Reciever message: " + param);
					//         }
					//     }
					// });
					// CWPage.setShowFooter(false);
					// oApp.to(CWPage);
					// CWPage.setShowFooter(false);
					//End of DV5K931077
				} else {
					if (oProfileForm_Week.getSelectedKey() == "PAST") {
						sap.m.MessageToast.show('Wave creation not allowed for past week');
					} else {
						sap.m.MessageToast.show('Select valid week and wave profile');
					}
				}

				//Begin of DV5K931077
				function _waveCreate() {
					AppCache.Load("ZUI_DAT_WAVE_CREATION", {
						parentObject: CWPage,
						startParams: {
							mode: "CREATE",
							wbProfile: oProfileForm_Profile.getSelectedKey(),
							wbWeek: oProfileForm_Week.getSelectedKey(),
							wbRegion: gWaveProfileSelRegion,
							wbWeekValue: gWBWeekValue,
							wbProfileValue: gWBProfileValue,
							initFn: function (param) {
								console.log("Reciever message: " + param);
							}
						}
					});
					CWPage.setShowFooter(false);
					oApp.to(CWPage);
					CWPage.setShowFooter(false);
				}
				//End of DV5K931077
				function lz_createValidate() {
					var bReturn = true;
					if (oProfileForm_Week.getSelectedKey() == undefined || oProfileForm_Week.getSelectedKey() == null || oProfileForm_Week.getSelectedKey() ==
						'') {
						bReturn = false;
					}
					if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
						'') {
						bReturn = false;
					}
					if (oProfileForm_Week.getSelectedKey() == "PAST") {
						bReturn = false;
					}
					return bReturn;
				}
			}
		});
		Wave_OverflowToolbar.addContent(WCreate_Button);
		var WRelease_Button = new sap.m.Button(this.createId("WRelease_Button"), {
			text: "Wave Release",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI
				// ************************************************************************
				var indices = Wave_Table.getSelectedIndices();

				if (indices.length == 0) {
					sap.m.MessageToast.show('Select a wave to release.');
				} else if (indices.length > 1) {
					sap.m.MessageToast.show('Multiple wave selection not allowed.');
				} else if (indices.length == 1) {
					//Begin of DV5K931077
					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								UP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								_dialog_release();
							}
						}
					}));
					//End of DV5K931077
				}
				//Begin of DV5K931077
				function _dialog_release() {
					var index = Wave_Table.getSelectedIndices()[0];
					var tData = Wave_Table.getModel().getData()[index];
					$.sap.require("sap.m.Dialog");
					$.sap.require("sap.m.Text");
					$.sap.require("sap.m.Button");
					var dialog = new sap.m.Dialog({
						title: 'Confirm',
						type: 'Message',
						content: new sap.m.Text({
							text: 'Are you sure you want to release a wave (' + tData.WaveNr + ')?'
						}),
						beginButton: new sap.m.Button({
							text: 'OK',
							press: function () {
								_okReleaseNow();
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						endButton: new sap.m.Button({
							text: 'Cancel',
							press: function () {
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						afterClose: function () {
							dialog.close();
						}
					}).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
					dialog.open();
				}
				//End of DV5K931077
				function _okReleaseNow() {
					sap.ui.core.BusyIndicator.show(0);
					var indices = Wave_Table.getSelectedIndices();

					if (indices.length > 0) {
						var xdData = {
							ActionId: 'RELEASE',
							Message: '',
							Function: 'WW',
							NAVActionWaves: [],
							NAVActionSch: []
						};
						for (var i = 0; i < indices.length; i++) {
							var index = Wave_Table.getSelectedIndices()[i];
							var tData = Wave_Table.getContextByIndex(index).getObject();
							var xd = {
								SchGuid: tData.SchGuid,
								RunId: tData.RunId,
								WaveNr: tData.WaveNr,
								Secprofile: oProfileForm_Profile.getSelectedKey(),
								Fisweek: oProfileForm_Week.getSelectedKey()
							}
							xdData.NAVActionWaves.push(xd);
						}
						var dPromise = $.Deferred();
						var retData = '';
						gWBModel.create('/ActionSet', xdData, {
							success: function (oData, resp) {
								dPromise.resolve();
								retData = oData;
							},
							error: function (oError) {
								dPromise.resolve();
								sap.m.MessageToast.show('Error');
								sap.ui.core.BusyIndicator.hide();
							}
						});
						Promise.all(
							[
								dPromise
							]).then($.proxy(function () {
							$.sap.require("sap.m.MessageToast");
							if (retData.Function == "") {
								sap.m.MessageToast.show('No Authorization');
							} else {
								if (retData.Message != '') {
									sap.m.MessageToast.show(retData.Message);
								} else {
									sap.m.MessageToast.show('Wave successfully released');
								}
								_getWorkBenchData();
							}
						}));
					}
				}

				/*

				*/
			}
		});
		Wave_OverflowToolbar.addContent(WRelease_Button);
		var wave_param = new sap.m.Button(this.createId("wave_param"), {
			text: "Wave Parameter",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench wave                                     *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench                                   *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 14/07/2020  C5107535SA      65269905   Initial         DV5K927483    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI
				// ************************************************************************
				oWavenr.setValue('');
				oInputDisc.setValue('');
				wave_rel_type.setSelectedKey('');
				oinpoWaveRelTime.setValue('');
				var indices = Wave_Table.getSelectedIndices();
				if (indices.length == 0) {
					sap.m.MessageToast.show('Select a wave');
				} else if (indices.length > 1) {
					sap.m.MessageToast.show('Multiple wave selection not allowed.');
				} else if (indices.length == 1) {
					//begin of DV5K931077
					// var index = Wave_Table.getSelectedIndices()[0];
					// var tData = Wave_Table.getModel().getData()[index];
					// oWavenr.setValue(tData.WaveNr);
					// oInputDisc.setValue(tData.WaveDescr);
					// wave_rel_type.setSelectedKey(tData.WaveRelMech);
					// if(tData.WaveRelMech == 'T'){
					//     oinpoWaveRelTime.setVisible(true);
					//     oSchFormWaveReld.setVisible(true);
					//     if(tData.TimeStamp){
					//         var arrDate = tData.TimeStamp.split(' ');
					//         var rdate = arrDate[0].split('/');
					//         var rtime = arrDate[1].split(':');
					//         var timezone = arrDate[2];
					//         if(timezone){
					//             timezone = 'Date & Time (' +timezone+ ')';
					//             oLblWaveRelTime.setText(timezone);
					//         }
					//         var timestamp = rdate[2]+rdate[0]+rdate[1];
					//         timestamp = timestamp+':'+rtime[0]+rtime[1]+rtime[2];
					//         oinpoWaveRelTime.setValue(timestamp);
					//     }
					// }else{
					//     oinpoWaveRelTime.setVisible(false);
					//     oSchFormWaveReld.setVisible(false);
					// }
					// oWavenr.setEnabled(false);
					// update_wave_property.open();

					//check if DATUI is lock for editing
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

					var xData = [];
					var dPromise = $.Deferred();
					gWaveModel.read('/DATUILockSet', {
						filters: aFilters,
						success: function (oData, resp) {
							dPromise.resolve();
							xData = oData.results;
						},
						error: function (oError) {
							dPromise.resolve();
						}
					});
					Promise.all(
						[
							dPromise
						]
					).then($.proxy(function () {
						if (xData.length != undefined) {
							var xLock = xData[0].LockCheck;
							if (xLock == 'X') {
								//if DAT UI Lock is set disable buttons
								Create_Button.setEnabled(false);
								WCreate_Button.setEnabled(false);
								WRelease_Button.setEnabled(false);
								wave_param.setEnabled(false);
								WUP_Wave.setEnabled(false);
								UP_Wave.setEnabled(false);
								WaveDel_Button.setEnabled(false);
								sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
							} else {
								Create_Button.setEnabled(true);
								WCreate_Button.setEnabled(true);
								WRelease_Button.setEnabled(true);
								wave_param.setEnabled(true);
								WUP_Wave.setEnabled(true);
								UP_Wave.setEnabled(true);
								WaveDel_Button.setEnabled(true);
								_wave_param();
							}
						}
					}));
					//End of DV5K931077
				};
				//Begin of DV5K931077
				function _wave_param() {
					var index = Wave_Table.getSelectedIndices()[0];
					var tData = Wave_Table.getModel().getData()[index];
					oWavenr.setValue(tData.WaveNr);
					oInputDisc.setValue(tData.WaveDescr);
					wave_rel_type.setSelectedKey(tData.WaveRelMech);
					if (tData.WaveRelMech == 'T') {
						oinpoWaveRelTime.setVisible(true);
						oSchFormWaveReld.setVisible(true);
						if (tData.TimeStamp) {
							var arrDate = tData.TimeStamp.split(' ');
							var rdate = arrDate[0].split('/');
							var rtime = arrDate[1].split(':');
							var timezone = arrDate[2];
							if (timezone) {
								timezone = 'Date & Time (' + timezone + ')';
								oLblWaveRelTime.setText(timezone);
							}
							var timestamp = rdate[2] + rdate[0] + rdate[1];
							timestamp = timestamp + ':' + rtime[0] + rtime[1] + rtime[2];
							oinpoWaveRelTime.setValue(timestamp);
						}
					} else {
						oinpoWaveRelTime.setVisible(false);
						oSchFormWaveReld.setVisible(false);
					}
					oWavenr.setEnabled(false);
					update_wave_property.open();
				}
				//End of DV5K931077
			}
		});
		Wave_OverflowToolbar.addContent(wave_param);
		var WaveDel_Button = new sap.m.Button(this.createId("WaveDel_Button"), {
			icon: "sap-icon://delete",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 09/16/2020  C5162473NS  INC076536919   Warranty Change  DV5K931077   *
				// * Adding ZTDATUI_FLAG support to DAT6 portal UI
				// ************************************************************************
				var indices = Wave_Table.getSelectedIndices();
				if (indices.length > 0) {
					if (checkWaveNumber()) {
						sap.m.MessageToast.show('One of more selected entries without wave number. Wave deletion is not allowed.');
					} else {
						//Begin of DV5K931077
						//check if DATUI is lock for editing
						var aFilters = [];
						aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));

						var xData = [];
						var dPromise = $.Deferred();
						gWaveModel.read('/DATUILockSet', {
							filters: aFilters,
							success: function (oData, resp) {
								dPromise.resolve();
								xData = oData.results;
							},
							error: function (oError) {
								dPromise.resolve();
							}
						});
						Promise.all(
							[
								dPromise
							]
						).then($.proxy(function () {
							if (xData.length != undefined) {
								var xLock = xData[0].LockCheck;
								if (xLock == 'X') {
									//if DAT UI Lock is set disable buttons
									Create_Button.setEnabled(false);
									WCreate_Button.setEnabled(false);
									WRelease_Button.setEnabled(false);
									wave_param.setEnabled(false);
									WUP_Wave.setEnabled(false);
									UP_Wave.setEnabled(false);
									WaveDel_Button.setEnabled(false);
									sap.m.MessageToast.show('Rollover is in progress,Please try after some time');
								} else {
									Create_Button.setEnabled(true);
									WCreate_Button.setEnabled(true);
									WRelease_Button.setEnabled(true);
									wave_param.setEnabled(true);
									WUP_Wave.setEnabled(true);
									UP_Wave.setEnabled(true);
									WaveDel_Button.setEnabled(true);
									_wave_del_open();
								}
							}
						}));

						//     $.sap.require("sap.m.Dialog");
						//     $.sap.require("sap.m.Text");
						//     $.sap.require("sap.m.Button");
						//   var dialog = new sap.m.Dialog({
						//     title: 'Confirm',
						//     type: 'Message',
						//     content: new sap.m.Text({text: 'Are you sure you want to delete the selected waves'}),
						//     beginButton: new sap.m.Button({
						//       text:'OK',
						//       press: function(){
						//                 _okDeleteWavesNow();
						//           dialog.close();
						//       },
						//       type: 'Emphasized'
						//     }).addStyleClass(''),
						//     endButton: new sap.m.Button({
						//       text: 'Cancel',
						//       press: function(){
						//         dialog.close();
						//       },
						//       type: 'Emphasized'
						//     }).addStyleClass(''),
						//     afterClose: function(){
						//       dialog.close();
						//     }
						//   }).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
						//   dialog.open();
						//End of DV5K931077
					}
				} else {
					sap.m.MessageToast.show('Select one or more waves to delete');
				}

				function _wave_del_open() {
					$.sap.require("sap.m.Dialog");
					$.sap.require("sap.m.Text");
					$.sap.require("sap.m.Button");
					var dialog = new sap.m.Dialog({
						title: 'Confirm',
						type: 'Message',
						content: new sap.m.Text({
							text: 'Are you sure you want to delete the selected waves'
						}),
						beginButton: new sap.m.Button({
							text: 'OK',
							press: function () {
								_okDeleteWavesNow();
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						endButton: new sap.m.Button({
							text: 'Cancel',
							press: function () {
								dialog.close();
							},
							type: 'Emphasized'
						}).addStyleClass(''),
						afterClose: function () {
							dialog.close();
						}
					}).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
					dialog.open();
				}

				function _okDeleteWavesNow() {
					var indices = Wave_Table.getSelectedIndices();
					if (indices.length > 0) {
						var xdData = {
							ActionId: 'DELETE',
							Message: '',
							Function: 'WW',
							NAVActionWaves: [],
							NAVActionSch: []
						};
						var errMsg = '';
						var oresp;
						for (var i = 0; i < indices.length; i++) {
							var index = Wave_Table.getSelectedIndices()[i];
							var tData = Wave_Table.getContextByIndex(index).getObject();
							var xd = {
								SchGuid: tData.SchGuid,
								RunId: tData.RunId,
								WaveNr: tData.WaveNr,
								Secprofile: oProfileForm_Profile.getSelectedKey(),
								Fisweek: oProfileForm_Week.getSelectedKey()
							}
							xdData.NAVActionWaves.push(xd);
						}
						var dPromise = $.Deferred();
						gWBModel.create('/ActionSet', xdData, {
							success: function (oData, resp) {
								oresp = oData;
								dPromise.resolve();
								if (oData.Message != '') {
									errMsg = oData.Message;
								}
							},
							error: function (oError) {
								dPromise.resolve();
								sap.m.MessageToast.show('Error');
							}
						});
						Promise.all(
							[
								dPromise
							]).then($.proxy(function () {
							$.sap.require("sap.m.MessageToast");
							if (oresp.Function == "") {
								sap.m.MessageToast.show('No Authorization');
							} else {
								if (errMsg == '') {
									sap.m.MessageToast.show('Deleted waves successfully');
									_getWorkBenchData();
								} else {
									sap.m.MessageToast.show(errMsg);
								}
							}
						}));
					}
				}

				function checkWaveNumber() {
					var anyWaveNbrBlank = false;
					for (var i = 0; i < indices.length; i++) {
						var index = Wave_Table.getSelectedIndices()[i];
						var tData = Wave_Table.getContextByIndex(index).getObject();
						if (tData.WaveNr == '') {
							anyWaveNbrBlank = true;
						}
					}
					return anyWaveNbrBlank;
				}
				/*

				*/
			}
		});
		Wave_OverflowToolbar.addContent(WaveDel_Button);
		var selectVariant_wave = new sap.m.Select(this.createId("selectVariant_wave"), {
			forceSelection: false,
			change: function (oEvent) {
				processVariant_wave(Wave_Table);
			}
		});
		Wave_OverflowToolbar.addContent(selectVariant_wave);
		var WaveVariant_Button = new sap.m.Button(this.createId("WaveVariant_Button"), {
			icon: "sap-icon://key-user-settings",
			tooltip: "Personalization setting",
			type: "Emphasized",
			press: function (oEvent) {
				loadApp("ZUI_DAT_WORKBENCH_WAVES", "Wave_Table", Wave_Table);

				//getVarient_wave("Wave_Table");
			}
		});
		Wave_OverflowToolbar.addContent(WaveVariant_Button);
		var Wave_Table = new sap.ui.table.Table(this.createId("Wave_Table"), {
			fixedColumnCount: 2,
			selectionMode: "Multi",
			visibleRowCount: 14
		});
		Wave_VBox.addItem(Wave_Table);
		var modelWave_Table = new sap.ui.model.json.JSONModel();
		Wave_Table.setModel(modelWave_Table);
		Wave_Table.bindRows("/");
		var WN_Column = new sap.ui.table.Column(this.createId("WN_Column"), {
			label: new sap.m.Label({
				text: "Wave Number"
			}),
			filterOperator: "Contains",
			filterProperty: "WaveNr",
			sortProperty: "WaveNr",
			width: "10rem"
		});
		Wave_Table.addColumn(WN_Column);
		var WN_Text2 = new sap.m.Text(this.createId("WN_Text2"), {
			text: "{WaveNr}"
		});
		WN_Column.setTemplate(WN_Text2);
		var WDesc_Column = new sap.ui.table.Column(this.createId("WDesc_Column"), {
			label: new sap.m.Label({
				text: "Wave Description"
			}),
			filterOperator: "Contains",
			filterProperty: "WaveDescr",
			sortProperty: "WaveDescr",
			width: "15rem"
		});
		Wave_Table.addColumn(WDesc_Column);
		var WDesc_Text = new sap.m.Text(this.createId("WDesc_Text"), {
			text: "{WaveDescr}"
		});
		WDesc_Column.setTemplate(WDesc_Text);
		var TWQ_Column5 = new sap.ui.table.Column(this.createId("TWQ_Column5"), {
			label: new sap.m.Label({
				text: "Total Wave Quantity"
			}),
			width: "10rem",
			sortProperty: "TotWaveQty",
			filterProperty: "TotWaveQty",
			filterOperator: "Contains"
		});
		Wave_Table.addColumn(TWQ_Column5);
		var TWQ_Text = new sap.m.Text(this.createId("TWQ_Text"), {
			text: "{TotWaveQty}"
		});
		TWQ_Column5.setTemplate(TWQ_Text);
		var TRWQ_Column = new sap.ui.table.Column(this.createId("TRWQ_Column"), {
			label: new sap.m.Label({
				text: "Total Released Quantity"
			}),
			filterOperator: "Contains",
			filterProperty: "TotalRelQty",
			sortProperty: "TotalRelQty",
			width: "10rem"
		});
		Wave_Table.addColumn(TRWQ_Column);
		var TRWQ_Text = new sap.m.Text(this.createId("TRWQ_Text"), {
			text: "{TotalRelQty}"
		});
		TRWQ_Column.setTemplate(TRWQ_Text);
		var WCDate_Column = new sap.ui.table.Column(this.createId("WCDate_Column"), {
			label: new sap.m.Label({
				text: "Wave Created Time"
			}),
			width: "13rem",
			sortProperty: "CreateDate",
			filterProperty: "CreateDate",
			filterOperator: "Contains"
		});
		Wave_Table.addColumn(WCDate_Column);
		var WCDate_Text = new sap.m.Text(this.createId("WCDate_Text"), {
			text: "{CreateDate}"
		});
		WCDate_Column.setTemplate(WCDate_Text);
		var WRTime_Column = new sap.ui.table.Column(this.createId("WRTime_Column"), {
			label: new sap.m.Label({
				text: "Wave Release Time"
			}),
			width: "14rem",
			sortProperty: "WaveRelTime",
			filterProperty: "WaveRelTime",
			filterOperator: "Contains"
		});
		Wave_Table.addColumn(WRTime_Column);
		var WRTime_Text1 = new sap.m.Text(this.createId("WRTime_Text1"), {
			text: "{WaveRelTime}"
		});
		WRTime_Column.setTemplate(WRTime_Text1);
		var Status_Column = new sap.ui.table.Column(this.createId("Status_Column"), {
			label: new sap.m.Label({
				text: "Wave Status"
			}),
			filterOperator: "Contains",
			filterProperty: "Status",
			sortProperty: "Status",
			width: "15rem"
		});
		Wave_Table.addColumn(Status_Column);
		var Status_Text = new sap.m.Text(this.createId("Status_Text"), {
			text: "{Status}"
		});
		Status_Column.setTemplate(Status_Text);
		var FisicalWeek_Column = new sap.ui.table.Column(this.createId("FisicalWeek_Column"), {
			label: new sap.m.Label({
				text: "Fiscal Week"
			}),
			filterProperty: "Fisweek",
			sortProperty: "Fisweek",
			width: "10rem"
		});
		Wave_Table.addColumn(FisicalWeek_Column);
		var FisicalWeek_Text5 = new sap.m.Text(this.createId("FisicalWeek_Text5"), {
			text: "{Fisweek}"
		});
		FisicalWeek_Column.setTemplate(FisicalWeek_Text5);
		var WaveCreateStatus_Column = new sap.ui.table.Column(this.createId("WaveCreateStatus_Column"), {
			label: new sap.m.Label({
				text: "Wave Creation Status"
			}),
			filterProperty: "WaveCreatStatus",
			sortProperty: "WaveCreatStatus",
			width: "10rem"
		});
		Wave_Table.addColumn(WaveCreateStatus_Column);
		var Joblog_HBoxstatus = new sap.m.HBox(this.createId("Joblog_HBoxstatus"), {});
		WaveCreateStatus_Column.setTemplate(Joblog_HBoxstatus);
		var WaveCreateStatus_Text5 = new sap.m.Text(this.createId("WaveCreateStatus_Text5"), {
			text: "{WaveCreatStatus}"
		});
		Joblog_HBoxstatus.addItem(WaveCreateStatus_Text5);
		var jobLogIconstatus = new sap.ui.core.Icon(this.createId("jobLogIconstatus"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{WaveStatusJobV}",
			press: function (oEvent) {
				getF4log(oEvent, 'Job Log', 'WaveCreateStatus');
			}
		});
		Joblog_HBoxstatus.addItem(jobLogIconstatus);
		var LastChangedBy_Column3 = new sap.ui.table.Column(this.createId("LastChangedBy_Column3"), {
			label: new sap.m.Label({
				text: "Last Changed By"
			}),
			filterProperty: "Aenam",
			sortProperty: "Aenam",
			width: "10rem"
		});
		Wave_Table.addColumn(LastChangedBy_Column3);
		var LCBy_Text5 = new sap.m.Text(this.createId("LCBy_Text5"), {
			text: "{Aenam}"
		});
		LastChangedBy_Column3.setTemplate(LCBy_Text5);
		var LastChangeDate_Column4 = new sap.ui.table.Column(this.createId("LastChangeDate_Column4"), {
			label: new sap.m.Label({
				text: "Last Changed Time"
			}),
			filterProperty: "Aedat",
			sortProperty: "Aedat",
			width: "14rem"
		});
		Wave_Table.addColumn(LastChangeDate_Column4);
		var LCOn_Text5 = new sap.m.Text(this.createId("LCOn_Text5"), {
			text: "{Aedat}"
		});
		LastChangeDate_Column4.setTemplate(LCOn_Text5);
		var JobName_Column = new sap.ui.table.Column(this.createId("JobName_Column"), {
			label: new sap.m.Label({
				text: "Job Name"
			}),
			width: "16rem",
			sortProperty: "JobName",
			filterProperty: "JobName"
		});
		Wave_Table.addColumn(JobName_Column);
		var Joblog_HBox = new sap.m.HBox(this.createId("Joblog_HBox"), {});
		JobName_Column.setTemplate(Joblog_HBox);
		var JobName_Text5 = new sap.m.Text(this.createId("JobName_Text5"), {
			text: "{JobName}"
		});
		Joblog_HBox.addItem(JobName_Text5);
		var jobLogIcon = new sap.ui.core.Icon(this.createId("jobLogIcon"), {
			src: "sap-icon://fa-regular/question-circle",
			visible: "{JobNameV}",
			press: function (oEvent) {
				// getF4log(oEvent, 'Job Log'); // Comment DV5K934693
				// 75419527 Populate only error messages for wave creation job status log
				getF4log(oEvent, 'Job Log', ''); // Insert DV5K934693
			}
		});
		Joblog_HBox.addItem(jobLogIcon);
		var colWaveRelMech = new sap.ui.table.Column(this.createId("colWaveRelMech"), {
			label: new sap.m.Label({
				text: "Wave Release Mechanism"
			}),
			width: "11rem",
			sortProperty: "WaveRelMech",
			filterProperty: "WaveRelMech",
			filterOperator: "Contains",
			autoResizable: true
		});
		Wave_Table.addColumn(colWaveRelMech);
		var txtWaveRelMech = new sap.m.Text(this.createId("txtWaveRelMech"), {
			text: "{WaveRelMech}"
		});
		colWaveRelMech.setTemplate(txtWaveRelMech);
		var waveSchRelTime = new sap.ui.table.Column(this.createId("waveSchRelTime"), {
			label: new sap.m.Label({
				text: "Wave Sch Release Time"
			}),
			width: "15rem"
		});
		Wave_Table.addColumn(waveSchRelTime);
		var txtwaveSchRelTime = new sap.m.Text(this.createId("txtwaveSchRelTime"), {
			text: "{TimeStamp}"
		});
		waveSchRelTime.setTemplate(txtwaveSchRelTime);
		var oPageDialog = new sap.m.Page(this.createId("oPageDialog"), {})
		var CVCOptions_Popover = new sap.m.Popover(this.createId("CVCOptions_Popover"), {
			bounce: true,
			contentHeight: "100px",
			contentMinWidth: "100px",
			placement: "Bottom",
			showHeader: false
		});
		var CVCOptions_List = new sap.m.List(this.createId("CVCOptions_List"), {
			mode: "SingleSelectMaster",
			selectionChange: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				var cData = CVCOptions_List.getModel().getData()[index];
				VSave_MessageStrip.setVisible(false);
				butVariantProceed.setVisible(false);
				butVariantSaveOK.setVisible(true);
				VSave_MessageStrip.setText('');
				informVariantVARIANT.setEnabled(true);
				informVariantVTEXT.setEnabled(true);
				cb_cvc_global.setEnabled(true);
				cb_cvc_global.setSelected(false);
				cb_cvc_Default.setEnabled(true);
				cb_cvc_Default.setSelected(false);
				if (cData.Low == 'Save Filter') {
					informVariantVARIANT.setValueState('None');
					informVariantVTEXT.setValueState('None');
					if (CVCSel_Label.getText() == undefined || CVCSel_Label.getText() == null || CVCSel_Label.getText() == '') {

						informVariantVARIANT.setValue('');
						informVariantVTEXT.setValue('');
					} else {
						// Boc Cross profile variant DV5K934693
						var variant = CVCSel_Label.getText().split('(')[0]
						informVariantVARIANT.setValue(variant);
						// Eoc Cross profile variant DV5K934693
						informVariantVTEXT.setValue(gVariantDesc);
						if (global_cvc_var == 'X') {
							cb_cvc_global.setSelected(true);
							cb_cvc_Default.setEnabled(false);
						}
						if (gdefault_cvc_var == 'X') {
							cb_cvc_global.setEnabled(false);
							cb_cvc_Default.setSelected(true);
						}
					}
					diaVariantSave.open();
					CVCOptions_Popover.close();
				} else if (cData.Low == 'Delete Filter') {
					if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
						'') {
						sap.m.MessageToast.show('Select a profile before select');
					} else {
						if (CVCSel_Label.getText() == undefined || CVCSel_Label.getText() == null || CVCSel_Label.getText() == '') {
							sap.m.MessageToast.show('Select a variant to delete');
						} else {
							// Boc Cross profile variant DV5K934693
							var xVarPrf = CVCSel_Label.getText().split('(')[1];
							var Profile = xVarPrf.split(')')[0];
							// Eoc Cross profile variant
							if (Profile == oProfileForm_Profile.getSelectedKey()) {
								$.sap.require("sap.m.Dialog");
								$.sap.require("sap.m.Text");
								$.sap.require("sap.m.Button");
								var dialog = new sap.m.Dialog({
									title: 'Confirm',
									type: 'Message',
									content: new sap.m.Text({
										text: 'Are you sure you want to delete variant?'
									}),
									beginButton: new sap.m.Button({
										text: 'OK',
										press: function () {
											okDeleteVar();
											clear();
											dialog.close();
										},
										type: 'Emphasized'
									}).addStyleClass('zBtnBlue'),
									endButton: new sap.m.Button({
										text: 'Cancel',
										press: function () {
											dialog.close();
										},
										type: 'Emphasized'
									}).addStyleClass('zBtnBlue'),
									afterClose: function () {
										dialog.close();
									}
								}).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
								dialog.open();
								// Boc Cross profile variant DV5K934693
							} else {
								jQuery.sap.require("sap.m.MessageToast");
								sap.m.MessageToast.show('Profile does not Matched'); //DV5K935549
							}
							// Eoc Cross profile variant DV5K934693
						}
					}
					CVCOptions_Popover.close();
				} else if (cData.Low == 'Clear Filter') {
					clear();
					if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
						'') {
						CVCSel_Label.setText('');
					} else {
						CVCSel_Label.setText('');
						//setStar('Default');
					}
					CVCOptions_Popover.close();
					getVariant();
				}

				function okDeleteVar() {
					var varnt = CVCSel_Label.getText().split('(')[0] //  Cross profile variant DV5K934693
					var varntdesc = gVariantDesc;
					if (varnt == "") {
						jQuery.sap.require("sap.m.MessageToast");
						sap.m.MessageToast.show(txtVariantsaveas.getText());
					} else {
						var aVARData = [];
						var xVarObj = {
							Action: "DEL",
							NAV_SESSHDR_VARHDR: [{
								"Applid": "ZUI_DAT",
								"Report": oProfileForm_Profile.getSelectedKey(),
								"Variant": varnt,
								"Vtext": varntdesc,
								"Default_Flg": "",
								"Global_Flg": "",
								"NAV_VARHDR_VARDTL": [],
								"NAV_VARHDR_VARLST": [],
								"NAV_VARHDR_MSGDTL": []
							}],
						};
						var varPromise = $.Deferred();
						gVarModel.create('/SessionHdrSet', xVarObj, {
							success: function (oData, resp) {
								varPromise.resolve();
								aVARData = oData;
							},
							error: function (oError) {
								varPromise.resolve();
								sap.m.MessageToast.show(txtVariantODer);
							}
						});
						Promise.all(
							[
								varPromise
							]
						).then($.proxy(function () {
							s_output = aVARData.NAV_SESSHDR_VARHDR.results[0];
							//get message
							if (s_output.NAV_VARHDR_MSGDTL.results.length > 0) {
								clear();
								var v_sucmsg = s_output.NAV_VARHDR_MSGDTL.results[0].Message;
								if (v_sucmsg) {
									jQuery.sap.require("sap.m.MessageToast");
									sap.m.MessageToast.show(v_sucmsg);
									getVariant();
									CVCSel_Label.setText('');
									//setStar('Default');
								}
							}
							sap.ui.core.BusyIndicator.hide();
						}));
					}
				}
				/*



				*/
			}
		});
		CVCOptions_Popover.addContent(CVCOptions_List);
		var modelCVCOptions_List = new sap.ui.model.json.JSONModel();
		CVCOptions_List.setModel(modelCVCOptions_List);
		var CVCOptions_CustomListItem = new sap.m.CustomListItem(this.createId("CVCOptions_CustomListItem"), {});
		CVCOptions_List.bindAggregation("items", "/", CVCOptions_CustomListItem);
		var CVCOptions_Text = new sap.m.Text(this.createId("CVCOptions_Text"), {
			text: "{Low}"
		});
		CVCOptions_CustomListItem.addContent(CVCOptions_Text);
		var VarOK_Button = new sap.m.Button(this.createId("VarOK_Button"), {
			type: "Emphasized",
			width: "4rem",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				if (CV_IconTabBar.getSelectedKey() == 'Create') {

				} else {

				}

				function lz_v_validate() {
					var bReturn = true;
					if (VName_Input == undefined || VName_Input == null || VName_Input == '') {
						bReturn = false;
						VName_Input.setValueState('Error');
					}
					if (ChangeVD_Text == undefined || ChangeVD_Text == null || ChangeVD_Text == '') {
						bReturn = false;
						ChangeVD_Text.setValueState('Error');
					}
					return bReturn;
				}
			}
		});
		oPageDialog.addContent(VarOK_Button);
		var VarClose_Button = new sap.m.Button(this.createId("VarClose_Button"), {
			type: "Emphasized",
			width: "3rem",
			press: function (oEvent) {
				Variant_Dialog.close();
			}
		});
		oPageDialog.addContent(VarClose_Button);
		var Variant_Dialog = new sap.m.Dialog(this.createId("Variant_Dialog"), {
			contentHeight: "500px",
			contentWidth: "500px",
			title: "Manage Variant",
			beginButton: VarClose_Button,
			endButton: VarOK_Button
		});
		var CV_IconTabBar = new sap.m.IconTabBar(this.createId("CV_IconTabBar"), {
			select: function (oEvent) {
				if (CV_IconTabBar.getSelectedKey() == 'Create') {
					VarOK_Button.setText('Save');
				} else {
					VarOK_Button.setText('Update');
				}
			}
		});
		Variant_Dialog.addContent(CV_IconTabBar);
		var Create_IconTabFilter = new sap.m.IconTabFilter(this.createId("Create_IconTabFilter"), {
			key: "Create",
			text: "Create"
		});
		CV_IconTabBar.addItem(Create_IconTabFilter);
		var CreateM_VBox = new sap.m.VBox(this.createId("CreateM_VBox"), {});
		Create_IconTabFilter.addContent(CreateM_VBox);
		var VName_Label1 = new sap.m.Label(this.createId("VName_Label1"), {
			required: true,
			text: "Name"
		});
		CreateM_VBox.addItem(VName_Label1);
		var VName_Input = new sap.m.Input(this.createId("VName_Input"), {});
		CreateM_VBox.addItem(VName_Input);
		var VDesc_Label = new sap.m.Label(this.createId("VDesc_Label"), {
			required: true,
			text: "Description"
		});
		CreateM_VBox.addItem(VDesc_Label);
		var VDesc_Input = new sap.m.Input(this.createId("VDesc_Input"), {});
		CreateM_VBox.addItem(VDesc_Input);
		var Change_IconTabFilter = new sap.m.IconTabFilter(this.createId("Change_IconTabFilter"), {
			key: "Manage",
			text: "Manage"
		});
		CV_IconTabBar.addItem(Change_IconTabFilter);
		var ChangeM_VBox1 = new sap.m.VBox(this.createId("ChangeM_VBox1"), {});
		Change_IconTabFilter.addContent(ChangeM_VBox1);
		var CV_Toolbar = new sap.m.Toolbar(this.createId("CV_Toolbar"), {});
		ChangeM_VBox1.addItem(CV_Toolbar);
		var CV_SearchField = new sap.m.SearchField(this.createId("CV_SearchField"), {
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = VariantChange_Table.getBinding("items");

				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Variant", "Contains", usrtxt),
						new sap.ui.model.Filter("Vtext", "Contains", usrtxt)
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		CV_Toolbar.addContent(CV_SearchField);
		var CV_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("CV_ToolbarSpacer"), {});
		CV_Toolbar.addContent(CV_ToolbarSpacer);
		var CVDel_Icon = new sap.ui.core.Icon(this.createId("CVDel_Icon"), {
			color: "#006ab3",
			size: "1.25rem",
			src: "sap-icon://delete",
			press: function (oEvent) {
				var index = VariantChange_Table.getSelectedContextPaths()[0].split('/')[1];
				var tData = VariantChange_Table.getModel().getData()[index];
			}
		});
		CV_Toolbar.addContent(CVDel_Icon);
		var VariantChange_Table = new sap.m.Table(this.createId("VariantChange_Table"), {
			mode: "SingleSelectLeft"
		});
		ChangeM_VBox1.addItem(VariantChange_Table);
		var modelVariantChange_Table = new sap.ui.model.json.JSONModel();
		VariantChange_Table.setModel(modelVariantChange_Table);
		var ChangeVN_Column = new sap.m.Column(this.createId("ChangeVN_Column"), {
			header: new sap.m.Label({
				text: "Name"
			})
		});
		VariantChange_Table.addColumn(ChangeVN_Column);
		var ChangeVD_Column = new sap.m.Column(this.createId("ChangeVD_Column"), {
			header: new sap.m.Label({
				text: "Description"
			})
		});
		VariantChange_Table.addColumn(ChangeVD_Column);
		var Change_ColumnListItem = new sap.m.ColumnListItem(this.createId("Change_ColumnListItem"), {});
		VariantChange_Table.bindAggregation("items", "/", Change_ColumnListItem);
		var ChangeVN_Text = new sap.m.Text(this.createId("ChangeVN_Text"), {
			text: "{Variant}"
		});
		Change_ColumnListItem.addCell(ChangeVN_Text);
		var ChangeVD_Text = new sap.m.Text(this.createId("ChangeVD_Text"), {
			text: "{Vtext}"
		});
		Change_ColumnListItem.addCell(ChangeVD_Text);
		// ************************************************************************
		// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
		// * TITLE           : Workbench Waves                                    *
		// * CREATED BY      : Sivaprasad Valluru                                 *
		// * CREATION DATE   : 22-May-2020                                        *
		// * BHU#            : BHU26843                                           *
		// * DESCRIPTION     : UI for Workbench waves                             *
		// *                   Desiger                                            *
		// ************************************************************************
		// *-----------------------********************---------------------------*
		// * Date        Programmer      Ticket     Description     Correction    *
		// *-----------  ------------    --------   ------------    -----------   *
		// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
		// ************************************************************************
		function setMPNInitial(iType) {
			var jModel = new sap.ui.model.json.JSONModel();
			var idL = [{
				Selname: '',
				Kind: '',
				Sign: iType,
				Option: 'CP',
				Low: '',
				High: '',
				Txtsh: ''
			}];
			jModel.setData(idL);
			return jModel;
		}

		function setMPNTitle(iState, iType) {
			if (iState == 'Initial') {
				if (iType == 'I')
					MPNInc_Title.setText('Include');
				if (iType == 'E')
					MPNAdvExc_Title.setText('Exclude');
			} else {
				//Advance Include
				if (iType == 'I') {
					var incCount = 0;
					var incList = MPNAdvInclude_List.getModel().oData;
					if (incList.length > 0) {
						for (var i = 0; i < incList.length; i++) {
							var il = incList[i];
							if (il.Low == undefined || il.Low == null || il.Low == '') {

							} else {
								incCount++;
							}
						}
						if (incCount > 0) {
							var fText = 'Include(' + incCount + ')';
							MPNInc_Title.setText(fText);
						} else {
							MPNInc_Title.setText('Include');
						}
					} else {
						MPNInc_Title.setText('Include');
					}
				}
				if (iType == 'E') {
					var excCount = 0;
					var excList = MPNAdvExclude_List.getModel().oData;
					if (excList.length > 0) {
						for (var i = 0; i < excList.length; i++) {
							var il = excList[i];
							if (il.Low == undefined || il.Low == null || il.Low == '') {

							} else {
								excCount++;
							}
						}
						if (excCount > 0) {
							var fText = 'Exclude(' + excCount + ')';
							MPNAdvExc_Title.setText(fText);
						} else {
							MPNAdvExc_Title.setText('Exclude');
						}
					} else {
						MPNAdvExc_Title.setText('Exclude');
					}
				}
			}
		}
		var MPN_Ok_Button = new sap.m.Button(this.createId("MPN_Ok_Button"), {
			text: "Ok",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var basicData = MPNBasic_Table.getSelectedContextPaths();
				var advIncData = MPNAdvInclude_List.getModel().oData;
				var advExcData = MPNAdvExclude_List.getModel().oData;
				var addTokens = false;

				//Check if advance Inc has data
				var advIncHasData = false,
					advExcHasData = false;

				if (lz_MPNValidate()) {
					// if((basicData.length > 0)
					// && (advIncHasData || advExcHasData)){//both has data
					//     sap.m.MessageToast.show('Please use either Basic or Advanced Selection');
					// }else{
					addTokens = true;
					gMainMRef.getData().MPNIncListData = [];
					gMainMRef.getData().MPNExcListData = [];
					if (basicData.length == 0 && advIncHasData == false && advExcHasData == false) { //both does not have data
					} else {
						if (basicData.length > 0) {
							for (var i = 0; i < basicData.length; i++) {
								var index = parseInt(basicData[i].split('/')[1]);
								var td = MPNBasic_Table.getModel().oData[index];
								var xd = {
									Selname: '',
									Kind: '',
									Sign: 'I',
									Option: 'EQ',
									Low: td.Low,
									High: '',
									Txtsh: td.Txtsh,
									Type: 'B'
								};
								gMainMRef.getData().MPNIncListData.push(xd);
							}
						} else {
							if (advIncHasData) {
								for (var i = 0; i < advIncData.length; i++) {
									var incD = advIncData[i];
									if (incD.Low == undefined || incD.Low == null || incD.Low == '') {} else {
										var xd = {
											Selname: '',
											Kind: '',
											Sign: 'I',
											Option: incD.Option,
											Low: incD.Low,
											High: '',
											Txtsh: incD.Txtsh,
											Type: 'A'
										};
										gMainMRef.getData().MPNIncListData.push(xd);
									}
								}
							}
							if (advExcHasData) {
								for (var i = 0; i < advExcData.length; i++) {
									var excD = advExcData[i];
									if (excD.Low == undefined || excD.Low == null || excD.Low == '') {} else {
										var xd = {
											Selname: '',
											Kind: '',
											Sign: 'E',
											Option: excD.Option,
											Low: excD.Low,
											High: '',
											Txtsh: excD.Txtsh,
											Type: 'A'
										};
										gMainMRef.getData().MPNExcListData.push(xd);
									}
								}
							}
						}
					}

					//Destroy TOKENS
					oinpoSFormCVCMPN.destroyTokens();
					var incD = gMainMRef.getData().MPNIncListData;
					var incE = gMainMRef.getData().MPNExcListData;
					var lTxtin = 'Inc(' + incD.length + ')';
					var lTxtex = 'Exc(' + incE.length + ')';
					if (incD.length > 0) {
						oinpoSFormCVCMPN.addToken(new sap.m.Token("oTokenWBMPNINC1", {
							key: 'Include',
							text: lTxtin,
							select: function (oEvent) {
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								var objArray = [];
								datalst = gMainMRef.getData().MPNIncListData;
								for (var i in datalst) {
									var newmatlst = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: datalst[i].Option,
										Low: datalst[i].Low,
										High: '',
										Txtsh: datalst[i].Txtsh,
										Type: 'A'
									};
									objArray.push(newmatlst);
								}
								jModel.setData(objArray);
								// PopoverList.setModel(jModel);
								// oPopoverNew.setTitle('MPN');
								// PopoverNew_Id.setText('MPN');
								// PopoverDemo_SearchField.setValue('');
								// oPopoverNew.openBy(this);
								MPNSTPOList.setModel(jModel);
								MPNSTPopover.setTitle('MPN');
								MPNSTPO_Id.setText('MPN');
								MPNSTPO_SearchField.setValue('');
								MPNSTPopover.openBy(this);

							},
							press: function (oEvent) {

							},
							deselect: function (oEvent) {

							}
						}));
					}
					if (incE.length > 0) {
						oinpoSFormCVCMPN.addToken(new sap.m.Token("oTokenWBMPNEXC1", {
							key: 'Exclude',
							text: lTxtex,
							select: function (oEvent) {
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								var objArray = [];
								datalstex = gMainMRef.getData().MPNExcListData;
								for (var i in datalstex) {
									var newmatlstex = {
										Selname: '',
										Kind: '',
										Sign: 'E',
										Option: datalstex[i].Option,
										Low: datalstex[i].Low,
										High: '',
										Txtsh: datalstex[i].Txtsh,
										Type: 'A'

									};
									objArray.push(newmatlstex);
								}
								jModel.setData(objArray);
								// PopoverList.setModel(jModel);
								// oPopoverNew.setTitle('MPN');
								// PopoverNew_Id.setText('MPN');
								// PopoverDemo_SearchField.setValue('');
								// oPopoverNew.openBy(this);
								MPNSTPOList.setModel(jModel);
								MPNSTPopover.setTitle('MPN');
								MPNSTPO_Id.setText('MPN');
								MPNSTPO_SearchField.setValue('');
								MPNSTPopover.openBy(this);
							},
							press: function (oEvent) {

							},
							deselect: function (oEvent) {

							}
						}));
					}

					var oBinding = MPNBasic_Table.getBinding("items");

					var filter = [];
					oBinding.filter(filter);
					MPNBasic_SearchField.setValue('');

					if (addTokens)
						MPN_Dialog.close();
				}

				function lz_MPNValidate() {
					var bReturn = true;
					var advIncAnyAstic = false,
						advExcAnyAstic = false;
					for (var i = 0; i < advIncData.length; i++) {
						var incData = advIncData[i];
						if (incData.Low == undefined || incData.Low == null || incData.Low == '') {} else {
							advIncHasData = true;
							if (incData.Low.includes('*')) {
								advIncAnyAstic = true;
							}
						}
					}
					//Check if advance Exc has data.
					for (var i = 0; i < advExcData.length; i++) {
						var excData = advExcData[i];
						if (excData.Low == undefined || excData.Low == null || excData.Low == '') {} else {
							advExcHasData = true;
							if (excData.Low.includes('*')) {
								advExcAnyAstic = true;
							}
						}
					}
					if ((basicData.length > 0) && (advIncHasData || advExcHasData)) {
						sap.m.MessageToast.show('Please use either Basic or Advanced Selection');
						bReturn = false;
					}
					if (bReturn) {
						if (advIncAnyAstic || advExcAnyAstic) {
							sap.m.MessageToast.show('* not allowed');
							bReturn = false;
						}
					}
					return bReturn;
				}
				/*

				*/
			}
		});
		oPageDialog.addContent(MPN_Ok_Button);
		var MPN_Close_Button = new sap.m.Button(this.createId("MPN_Close_Button"), {
			text: "Close",
			type: "Emphasized",
			press: function (oEvent) {
				var oBinding = MPNBasic_Table.getBinding("items");

				var filter = [];
				oBinding.filter(filter);
				MPNBasic_SearchField.setValue('');
				MPN_Dialog.close();
			}
		});
		oPageDialog.addContent(MPN_Close_Button);
		var MPN_Dialog = new sap.m.Dialog(this.createId("MPN_Dialog"), {
			contentHeight: "480px",
			contentWidth: "600px",
			draggable: true,
			title: "MPN",
			beginButton: MPN_Ok_Button,
			endButton: MPN_Close_Button
		});
		var MPN_IconTabBar = new sap.m.IconTabBar(this.createId("MPN_IconTabBar"), {
			headerMode: "Inline",
			select: function (oEvent) {
				MPN_IconTabBar.setExpanded(true);
			}
		});
		MPN_Dialog.addContent(MPN_IconTabBar);
		var MPNBasic_IconTabFilter = new sap.m.IconTabFilter(this.createId("MPNBasic_IconTabFilter"), {
			key: "Basic",
			text: "Basic"
		});
		MPN_IconTabBar.addItem(MPNBasic_IconTabFilter);
		var MPNBasic_Panel = new sap.m.Panel(this.createId("MPNBasic_Panel"), {
			width: "580px",
			height: "405px"
		});
		MPNBasic_IconTabFilter.addContent(MPNBasic_Panel);
		var MPNBasicHdr_Toolbar = new sap.m.Toolbar(this.createId("MPNBasicHdr_Toolbar"), {});
		MPNBasic_Panel.setHeaderToolbar(MPNBasicHdr_Toolbar);
		var MPNBasic_SearchField = new sap.m.SearchField(this.createId("MPNBasic_SearchField"), {
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = MPNBasic_Table.getBinding("items");

				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Low", "Contains", usrtxt),
						new sap.ui.model.Filter("Txtsh", "Contains", usrtxt)
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		MPNBasicHdr_Toolbar.addContent(MPNBasic_SearchField);
		var MPN_ToolbarSpacer1 = new sap.m.ToolbarSpacer(this.createId("MPN_ToolbarSpacer1"), {});
		MPNBasicHdr_Toolbar.addContent(MPN_ToolbarSpacer1);
		var MPNBasicClear_Button = new sap.m.Button(this.createId("MPNBasicClear_Button"), {
			text: "Clear",
			type: "Emphasized",
			width: "3.5rem",
			press: function (oEvent) {
				if (MPNBasic_Table.getItems().length > 0) {
					for (var i = 0; i < MPNBasic_Table.getItems().length; i++) {
						MPNBasic_Table.getItems()[i].setSelected(false);
					}
				}
				MPNBasicInfoTB_Text.setText("Selected " + MPNBasic_Table.getSelectedContextPaths().length);
			}
		});
		MPNBasicHdr_Toolbar.addContent(MPNBasicClear_Button);
		var MPNBasicSel_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("MPNBasicSel_OverflowToolbar"), {});
		MPNBasic_Panel.setInfoToolbar(MPNBasicSel_OverflowToolbar);
		var MPNBasicInfoTB_Text = new sap.m.Text(this.createId("MPNBasicInfoTB_Text"), {});
		MPNBasicSel_OverflowToolbar.addContent(MPNBasicInfoTB_Text);
		var MPNBasic_Table = new sap.m.Table(this.createId("MPNBasic_Table"), {
			mode: "MultiSelect",
			selectionChange: function (oEvent) {
				MPNBasicInfoTB_Text.setText("Selected " + MPNBasic_Table.getSelectedContextPaths().length);
			}
		});
		MPNBasic_Panel.addContent(MPNBasic_Table);
		var modelMPNBasic_Table = new sap.ui.model.json.JSONModel();
		MPNBasic_Table.setModel(modelMPNBasic_Table);
		var MPNSoldTo_Column = new sap.m.Column(this.createId("MPNSoldTo_Column"), {
			header: new sap.m.Label({
				text: "MPN"
			}),
			width: "6rem"
		});
		MPNBasic_Table.addColumn(MPNSoldTo_Column);
		var MPNDesc_Column = new sap.m.Column(this.createId("MPNDesc_Column"), {
			header: new sap.m.Label({
				text: "Description"
			})
		});
		MPNBasic_Table.addColumn(MPNDesc_Column);
		var MPN_ColumnListItem = new sap.m.ColumnListItem(this.createId("MPN_ColumnListItem"), {});
		MPNBasic_Table.bindAggregation("items", "/", MPN_ColumnListItem);
		var MPNBasicST_Text = new sap.m.Text(this.createId("MPNBasicST_Text"), {
			text: "{Low}"
		});
		MPN_ColumnListItem.addCell(MPNBasicST_Text);
		var MPNBasicDesc_Text = new sap.m.Text(this.createId("MPNBasicDesc_Text"), {
			text: "{Txtsh}"
		});
		MPN_ColumnListItem.addCell(MPNBasicDesc_Text);
		var MPNAdv_IconTabFilter = new sap.m.IconTabFilter(this.createId("MPNAdv_IconTabFilter"), {
			key: "Advance",
			text: "Advanced"
		});
		MPN_IconTabBar.addItem(MPNAdv_IconTabFilter);
		var MPNAdv_VBox = new sap.m.VBox(this.createId("MPNAdv_VBox"), {
			height: "396px",
			width: "570px"
		});
		MPNAdv_IconTabFilter.addContent(MPNAdv_VBox);
		var MPNInclude_Panel = new sap.m.Panel(this.createId("MPNInclude_Panel"), {
			expandable: true,
			expanded: true
		});
		MPNAdv_VBox.addItem(MPNInclude_Panel);
		var MPNInc_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("MPNInc_OverflowToolbar"), {});
		MPNInclude_Panel.setHeaderToolbar(MPNInc_OverflowToolbar);
		var MPNInc_Title = new sap.m.Title(this.createId("MPNInc_Title"), {});
		MPNInc_OverflowToolbar.addContent(MPNInc_Title);
		var MPN_ToolbarSpacer4 = new sap.m.ToolbarSpacer(this.createId("MPN_ToolbarSpacer4"), {});
		MPNInc_OverflowToolbar.addContent(MPN_ToolbarSpacer4);
		var MPNAdvIncAdd_Button = new sap.m.Button(this.createId("MPNAdvIncAdd_Button"), {
			icon: "sap-icon://add",
			type: "Emphasized",
			press: function (oEvent) {
				var xd = {
					Selname: '',
					Kind: '',
					Sign: 'I',
					Option: 'CP',
					Low: '',
					High: '',
					Txtsh: '',
					Type: 'A'
				};
				MPNAdvInclude_List.getModel().getData().push(xd);
				MPNAdvInclude_List.getModel().refresh();
			}
		});
		MPNInc_OverflowToolbar.addContent(MPNAdvIncAdd_Button);
		var MPNAdvClearInc_Button = new sap.m.Button(this.createId("MPNAdvClearInc_Button"), {
			text: "Clear",
			tooltip: "Clear Selection",
			type: "Emphasized",
			width: "3.5rem",
			press: function (oEvent) {
				MPNAdvInclude_List.setModel(setMPNInitial('I'));
				setMPNTitle('Initial', 'I');
				MPNAdvInclude_List.getModel().refresh();
			}
		});
		MPNInc_OverflowToolbar.addContent(MPNAdvClearInc_Button);
		var MPNAdvInclude_List = new sap.m.List(this.createId("MPNAdvInclude_List"), {
			mode: "Delete",
			delete: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				MPNAdvInclude_List.getModel().getData().splice(index, 1);
				MPNAdvInclude_List.getModel().refresh();
				setMPNTitle('NotInitial', 'I');
			}
		});
		MPNInclude_Panel.addContent(MPNAdvInclude_List);
		var modelMPNAdvInclude_List = new sap.ui.model.json.JSONModel();
		MPNAdvInclude_List.setModel(modelMPNAdvInclude_List);
		var MPNAdvInc_CustomListItem = new sap.m.CustomListItem(this.createId("MPNAdvInc_CustomListItem"), {});
		MPNAdvInclude_List.bindAggregation("items", "/", MPNAdvInc_CustomListItem);
		var MPNAdvInc_HBox = new sap.m.HBox(this.createId("MPNAdvInc_HBox"), {});
		MPNAdvInc_CustomListItem.addContent(MPNAdvInc_HBox);
		var MPNAdvInc_Select = new sap.m.Select(this.createId("MPNAdvInc_Select"), {
			selectedKey: "{Option}",
			width: "8rem"
		});
		MPNAdvInc_HBox.addItem(MPNAdvInc_Select);
		var MPNAdvInc_Input = new sap.m.Input(this.createId("MPNAdvInc_Input"), {
			fieldWidth: "100%",
			maxLength: 255,
			placeholder: "Value",
			value: "{Low}",
			width: "23.5rem",
			change: function (oEvent) {
				setMPNTitle('NotInitial', 'I');
				var uc = oEvent.getParameter('newValue');
				var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
				MPNAdvInclude_List.getModel().getData()[index].Low = uc.toUpperCase();
			}
		});
		MPNAdvInc_HBox.addItem(MPNAdvInc_Input);
		var MPNExclude_Panel = new sap.m.Panel(this.createId("MPNExclude_Panel"), {
			expandable: true
		});
		MPNAdv_VBox.addItem(MPNExclude_Panel);
		var MPNAdvExc_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("MPNAdvExc_OverflowToolbar"), {});
		MPNExclude_Panel.setHeaderToolbar(MPNAdvExc_OverflowToolbar);
		var MPNAdvExc_Title = new sap.m.Title(this.createId("MPNAdvExc_Title"), {});
		MPNAdvExc_OverflowToolbar.addContent(MPNAdvExc_Title);
		var MPNAdvEx_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("MPNAdvEx_ToolbarSpacer"), {});
		MPNAdvExc_OverflowToolbar.addContent(MPNAdvEx_ToolbarSpacer);
		var MPNAdvExcAdd_Button = new sap.m.Button(this.createId("MPNAdvExcAdd_Button"), {
			icon: "sap-icon://add",
			type: "Emphasized",
			press: function (oEvent) {
				var xd = {
					Selname: '',
					Kind: '',
					Sign: 'E',
					Option: 'CP',
					Low: '',
					High: '',
					Txtsh: '',
					Type: 'A'
				};
				MPNAdvExclude_List.getModel().getData().push(xd);
				MPNAdvExclude_List.getModel().refresh();
			}
		});
		MPNAdvExc_OverflowToolbar.addContent(MPNAdvExcAdd_Button);
		var MPNAdvExcClear_Button = new sap.m.Button(this.createId("MPNAdvExcClear_Button"), {
			text: "Clear",
			type: "Emphasized",
			width: "3.5rem",
			press: function (oEvent) {
				MPNAdvExclude_List.setModel(setMPNInitial('E'));
				setMPNTitle('Initial', 'E');
				MPNAdvExclude_List.getModel().refresh();
			}
		});
		MPNAdvExc_OverflowToolbar.addContent(MPNAdvExcClear_Button);
		var MPNAdvExclude_List = new sap.m.List(this.createId("MPNAdvExclude_List"), {
			mode: "Delete",
			delete: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				MPNAdvExclude_List.getModel().getData().splice(index, 1);
				MPNAdvExclude_List.getModel().refresh();
				setMPNTitle('NotInitial', 'E');
			}
		});
		MPNExclude_Panel.addContent(MPNAdvExclude_List);
		var modelMPNAdvExclude_List = new sap.ui.model.json.JSONModel();
		MPNAdvExclude_List.setModel(modelMPNAdvExclude_List);
		var MPNAdvExc_CustomListItem = new sap.m.CustomListItem(this.createId("MPNAdvExc_CustomListItem"), {});
		MPNAdvExclude_List.bindAggregation("items", "/", MPNAdvExc_CustomListItem);
		var MPNAdvExc_HBox = new sap.m.HBox(this.createId("MPNAdvExc_HBox"), {});
		MPNAdvExc_CustomListItem.addContent(MPNAdvExc_HBox);
		var MPNAdvExc_Select = new sap.m.Select(this.createId("MPNAdvExc_Select"), {
			selectedKey: "{Option}",
			width: "8rem"
		});
		MPNAdvExc_HBox.addItem(MPNAdvExc_Select);
		var MPNAdvExc_Input = new sap.m.Input(this.createId("MPNAdvExc_Input"), {
			fieldWidth: "100%",
			maxLength: 255,
			placeholder: "Value",
			value: "{Low}",
			width: "23.5rem",
			change: function (oEvent) {
				setMPNTitle('NotInitial', 'E');
				var uc = oEvent.getParameter('newValue');
				var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
				MPNAdvExclude_List.getModel().getData()[index].Low = uc.toUpperCase();
			}
		});
		MPNAdvExc_HBox.addItem(MPNAdvExc_Input);
		// ************************************************************************
		// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
		// * TITLE           : Workbench Waves                                    *
		// * CREATED BY      : Sivaprasad Valluru                                 *
		// * CREATION DATE   : 22-May-2020                                        *
		// * BHU#            : BHU26843                                           *
		// * DESCRIPTION     : UI for Workbench waves                             *
		// *                   Desiger                                            *
		// ************************************************************************
		// *-----------------------********************---------------------------*
		// * Date        Programmer      Ticket     Description     Correction    *
		// *-----------  ------------    --------   ------------    -----------   *
		// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
		// ************************************************************************
		function setCVCSTInitial(iType) {
			var jModel = new sap.ui.model.json.JSONModel();
			var idL = [{
				Selname: '',
				Kind: '',
				Sign: iType,
				Option: 'CP',
				Low: '',
				High: '',
				Txtsh: ''
			}];
			jModel.setData(idL);
			return jModel;
		}

		function setCVCSTTitle(iState, iType) {
			if (iState == 'Initial') {
				if (iType == 'I')
					CVCSTInc_Title.setText('Include');
				if (iType == 'E')
					CVCSTAdvExc_Title.setText('Exclude');
			} else {
				//Advance Include
				if (iType == 'I') {
					var incCount = 0;
					var incList = CVCSTAdvInclude_List.getModel().oData;
					if (incList.length > 0) {
						for (var i = 0; i < incList.length; i++) {
							var il = incList[i];
							if (il.Low == undefined || il.Low == null || il.Low == '') {

							} else {
								incCount++;
							}
						}
						if (incCount > 0) {
							var fText = 'Include(' + incCount + ')';
							CVCSTInc_Title.setText(fText);
						} else {
							CVCSTInc_Title.setText('Include');
						}
					} else {
						CVCSTInc_Title.setText('Include');
					}
				}
				if (iType == 'E') {
					var excCount = 0;
					var excList = CVCSTAdvExclude_List.getModel().oData;
					if (excList.length > 0) {
						for (var i = 0; i < excList.length; i++) {
							var il = excList[i];
							if (il.Low == undefined || il.Low == null || il.Low == '') {

							} else {
								excCount++;
							}
						}
						if (excCount > 0) {
							var fText = 'Exclude(' + excCount + ')';
							CVCSTAdvExc_Title.setText(fText);
						} else {
							CVCSTAdvExc_Title.setText('Exclude');
						}
					} else {
						CVCSTAdvExc_Title.setText('Exclude');
					}
				}
			}
		}
		var CVCSTOk_Button = new sap.m.Button(this.createId("CVCSTOk_Button"), {
			text: "Ok",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// * 12 May2021  C5114277PP     INC078667225     5000002626/DV5K934693    *
				// ************************************************************************
				var basicData = CVCSTBasic_Table.getSelectedContextPaths();
				var advIncData = CVCSTAdvInclude_List.getModel().oData;
				var advExcData = CVCSTAdvExclude_List.getModel().oData;
				var addTokens = false;

				//Check if advance Inc has data
				var advIncHasData = false,
					advExcHasData = false;

				if (lz_SoldToValidate()) {
					// if((basicData.length > 0)
					// && (advIncHasData || advExcHasData)){//both has data
					//     sap.m.MessageToast.show('Please use either Basic or Advanced Selection');
					// }else{
					addTokens = true;
					gMainMRef.getData().CVCSTIncListData = [];
					gMainMRef.getData().CVCSTExcListData = [];
					if (basicData.length == 0 && advIncHasData == false && advExcHasData == false) { //both does not have data
					} else {
						if (basicData.length > 0) {
							for (var i = 0; i < basicData.length; i++) {
								var index = parseInt(basicData[i].split('/')[1]);
								var td = CVCSTBasic_Table.getModel().oData[index];
								var xd = {
									Selname: '',
									Kind: 'S', //DV5K934693
									Sign: 'I',
									Option: 'EQ',
									Low: td.Low,
									High: '',
									Txtsh: td.Txtsh,
									Type: 'B'
								};
								gMainMRef.getData().CVCSTIncListData.push(xd);
							}
						} else {
							if (advIncHasData) {
								for (var i = 0; i < advIncData.length; i++) {
									var incD = advIncData[i];
									if (incD.Low == undefined || incD.Low == null || incD.Low == '') {} else {
										var xd = {
											Selname: '',
											Kind: 'S', //DV5K934693
											Sign: 'I',
											Option: incD.Option,
											Low: incD.Low,
											High: '',
											Txtsh: incD.Txtsh,
											Type: 'A'
										};
										gMainMRef.getData().CVCSTIncListData.push(xd);
									}
								}
							}
							if (advExcHasData) {
								for (var i = 0; i < advExcData.length; i++) {
									var excD = advExcData[i];
									if (excD.Low == undefined || excD.Low == null || excD.Low == '') {} else {
										var xd = {
											Selname: '',
											Kind: 'S', //DV5K934693
											Sign: 'E',
											Option: excD.Option,
											Low: excD.Low,
											High: '',
											Txtsh: excD.Txtsh,
											Type: 'A'
										};
										gMainMRef.getData().CVCSTExcListData.push(xd);
									}
								}
							}
						}
					}

					//Destroy TOKENS
					oinpoSFormCVCSoldTo.destroyTokens();
					var incD = gMainMRef.getData().CVCSTIncListData;
					var incE = gMainMRef.getData().CVCSTExcListData
					var lTxtin = 'Inc(' + incD.length + ')';
					var lTxtex = 'Exc(' + incE.length + ')';
					if (incD.length > 0) {
						oinpoSFormCVCSoldTo.addToken(new sap.m.Token("oTokenWBSTINC", {
							key: 'Include',
							text: lTxtin,
							select: function (oEvent) {
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								var objArray = [];
								datalst = gMainMRef.getData().CVCSTIncListData;
								for (var i in datalst) {
									var newmatlst = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: datalst[i].Option,
										Low: datalst[i].Low,
										High: '',
										Txtsh: datalst[i].Txtsh,
										Type: 'A'
									};
									objArray.push(newmatlst);
								}
								jModel.setData(objArray);
								// PopoverList.setModel(jModel);
								// oPopoverNew.setTitle('Sold To');
								// PopoverNew_Id.setText('Sold To');
								// PopoverDemo_SearchField.setValue('');
								// oPopoverNew.openBy(this);
								MPNSTPOList.setModel(jModel);
								MPNSTPopover.setTitle('Sold To');
								MPNSTPO_Id.setText('Sold To');
								MPNSTPO_SearchField.setValue('');
								MPNSTPopover.openBy(this);
							},
							press: function (oEvent) {

							},
							deselect: function (oEvent) {

							}
						}));
					}
					if (incE.length > 0) {
						oinpoSFormCVCSoldTo.addToken(new sap.m.Token("oTokenWBSTEXC", {
							key: 'Exclude',
							text: lTxtex,
							select: function (oEvent) {
								var jModel = new sap.ui.model.json.JSONModel();
								jModel.setData([]);
								var objArray = [];
								datalstex = gMainMRef.getData().CVCSTExcListData;
								for (var i in datalstex) {
									var newmatlstex = {
										Selname: '',
										Kind: '',
										Sign: 'E',
										Option: datalstex[i].Option,
										Low: datalstex[i].Low,
										High: '',
										Txtsh: datalstex[i].Txtsh,
										Type: 'A'

									};
									objArray.push(newmatlstex);
								}
								jModel.setData(objArray);
								// PopoverList.setModel(jModel);
								// oPopoverNew.setTitle('Sold To');
								// PopoverNew_Id.setText('Sold To');
								// PopoverDemo_SearchField.setValue('');
								// oPopoverNew.openBy(this);
								MPNSTPOList.setModel(jModel);
								MPNSTPopover.setTitle('Sold To');
								MPNSTPO_Id.setText('Sold To');
								MPNSTPO_SearchField.setValue('');
								MPNSTPopover.openBy(this);
							},
							press: function (oEvent) {

							},
							deselect: function (oEvent) {

							}
						}));
					}
					var oBinding = CVCSTBasic_Table.getBinding("items");

					var filter = [];
					oBinding.filter(filter);
					CVCSTBasic_SearchField.setValue('');

					if (addTokens)
						CVCST_Dialog.close();
				}

				function lz_SoldToValidate() {
					var bReturn = true;
					var advIncAnyAstic = false,
						advExcAnyAstic = false;
					for (var i = 0; i < advIncData.length; i++) {
						var incData = advIncData[i];
						if (incData.Low == undefined || incData.Low == null || incData.Low == '') {} else {
							advIncHasData = true;
							if (incData.Low.includes('*')) {
								advIncAnyAstic = true;
							}
						}
					}
					//Check if advance Exc has data.
					for (var i = 0; i < advExcData.length; i++) {
						var excData = advExcData[i];
						if (excData.Low == undefined || excData.Low == null || excData.Low == '') {} else {
							advExcHasData = true;
							if (excData.Low.includes('*')) {
								advExcAnyAstic = true;
							}
						}
					}
					if ((basicData.length > 0) && (advIncHasData || advExcHasData)) {
						sap.m.MessageToast.show('Please use either Basic or Advanced Selection');
						bReturn = false;
					}
					if (bReturn) {
						if (advIncAnyAstic || advExcAnyAstic) {
							sap.m.MessageToast.show('* not allowed');
							bReturn = false;
						}
					}
					return bReturn;
				}
				/*

				*/
			}
		});
		oPageDialog.addContent(CVCSTOk_Button);
		var CVCSTClose_Button = new sap.m.Button(this.createId("CVCSTClose_Button"), {
			type: "Emphasized",
			text: "Close",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var basicData = CVCSTBasic_Table.getSelectedContextPaths();
				var advIncData = CVCSTAdvInclude_List.getModel().oData;
				var advExcData = CVCSTAdvExclude_List.getModel().oData;
				var addTokens = false;

				//Check if advance Inc has data
				var advIncHasData = false;
				for (var i = 0; i < advIncData.length; i++) {
					var incData = advIncData[i];
					if (incData.Low == undefined || incData.Low == null || incData.Low == '') {} else {
						advIncHasData = true;
						break;
					}
				}
				//Check if advance Exc has data.
				var advExcHasData = false;
				for (var i = 0; i < advExcData.length; i++) {
					var excData = advExcData[i];
					if (excData.Low == undefined || excData.Low == null || excData.Low == '') {} else {
						advExcHasData = true;
						break;
					}
				}
				var oBinding = CVCSTBasic_Table.getBinding("items");

				var filter = [];
				oBinding.filter(filter);
				CVCSTBasic_SearchField.setValue('');
				if ((basicData.length > 0) && (advIncHasData || advExcHasData)) { //both has data
					sap.m.MessageToast.show('Basic and advance selection not allowed');
				} else {
					CVCST_Dialog.close();
				}
			}
		});
		oPageDialog.addContent(CVCSTClose_Button);
		var CVCST_Dialog = new sap.m.Dialog(this.createId("CVCST_Dialog"), {
			title: "Sold To",
			draggable: true,
			contentWidth: "600px",
			contentHeight: "480px",
			beginButton: CVCSTOk_Button,
			endButton: CVCSTClose_Button
		});
		var CVCST_IconTabBar = new sap.m.IconTabBar(this.createId("CVCST_IconTabBar"), {
			headerMode: "Inline",
			select: function (oEvent) {
				CVCST_IconTabBar.setExpanded(true);
			}
		});
		CVCST_Dialog.addContent(CVCST_IconTabBar);
		var CVCSTBasic_IconTabFilter = new sap.m.IconTabFilter(this.createId("CVCSTBasic_IconTabFilter"), {
			key: "Basic",
			text: "Basic"
		});
		CVCST_IconTabBar.addItem(CVCSTBasic_IconTabFilter);
		var CVCSTBasic_Panel = new sap.m.Panel(this.createId("CVCSTBasic_Panel"), {
			height: "407px",
			width: "580px"
		});
		CVCSTBasic_IconTabFilter.addContent(CVCSTBasic_Panel);
		var CVCSTBasicHdr_Toolbar = new sap.m.Toolbar(this.createId("CVCSTBasicHdr_Toolbar"), {});
		CVCSTBasic_Panel.setHeaderToolbar(CVCSTBasicHdr_Toolbar);
		var CVCSTBasic_SearchField = new sap.m.SearchField(this.createId("CVCSTBasic_SearchField"), {
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				//var data = ModelData.Find(CVCSTBasic_Table, "Low", usrtxt, "Contains");
				// var filter = new sap.ui.model.Filter("LOW", "Contains", usrtxt);
				var oBinding = CVCSTBasic_Table.getBinding("items");

				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Low", "Contains", usrtxt),
						new sap.ui.model.Filter("Txtsh", "Contains", usrtxt)
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		CVCSTBasicHdr_Toolbar.addContent(CVCSTBasic_SearchField);
		var CVCST_ToolbarSpacer1 = new sap.m.ToolbarSpacer(this.createId("CVCST_ToolbarSpacer1"), {});
		CVCSTBasicHdr_Toolbar.addContent(CVCST_ToolbarSpacer1);
		var CVCSTBasicClear_Button = new sap.m.Button(this.createId("CVCSTBasicClear_Button"), {
			text: "Clear",
			type: "Emphasized",
			press: function (oEvent) {
				if (CVCSTBasic_Table.getItems().length > 0) {
					for (var i = 0; i < CVCSTBasic_Table.getItems().length; i++) {
						CVCSTBasic_Table.getItems()[i].setSelected(false);
					}
				}
				CVCSTBasicInfoTB_Text.setText("Selected " + CVCSTBasic_Table.getSelectedContextPaths().length);
			}
		});
		CVCSTBasicHdr_Toolbar.addContent(CVCSTBasicClear_Button);
		var CVCSTBasicSel_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("CVCSTBasicSel_OverflowToolbar"), {});
		CVCSTBasic_Panel.setInfoToolbar(CVCSTBasicSel_OverflowToolbar);
		var CVCSTBasicInfoTB_Text = new sap.m.Text(this.createId("CVCSTBasicInfoTB_Text"), {});
		CVCSTBasicSel_OverflowToolbar.addContent(CVCSTBasicInfoTB_Text);
		var CVCSTBasic_Table = new sap.m.Table(this.createId("CVCSTBasic_Table"), {
			mode: "MultiSelect",
			selectionChange: function (oEvent) {
				CVCSTBasicInfoTB_Text.setText("Selected " + CVCSTBasic_Table.getSelectedContextPaths().length);
			}
		});
		CVCSTBasic_Panel.addContent(CVCSTBasic_Table);
		var modelCVCSTBasic_Table = new sap.ui.model.json.JSONModel();
		CVCSTBasic_Table.setModel(modelCVCSTBasic_Table);
		var CVCSTSoldTo_Column = new sap.m.Column(this.createId("CVCSTSoldTo_Column"), {
			header: new sap.m.Label({
				text: "Sold To"
			}),
			width: "6rem"
		});
		CVCSTBasic_Table.addColumn(CVCSTSoldTo_Column);
		var CVCSTDesc_Column = new sap.m.Column(this.createId("CVCSTDesc_Column"), {
			header: new sap.m.Label({
				text: "Description"
			})
		});
		CVCSTBasic_Table.addColumn(CVCSTDesc_Column);
		var CVCST_ColumnListItem = new sap.m.ColumnListItem(this.createId("CVCST_ColumnListItem"), {});
		CVCSTBasic_Table.bindAggregation("items", "/", CVCST_ColumnListItem);
		var CVCSTBasicST_Text = new sap.m.Text(this.createId("CVCSTBasicST_Text"), {
			text: "{Low}"
		});
		CVCST_ColumnListItem.addCell(CVCSTBasicST_Text);
		var CVCSTBasicDesc_Text = new sap.m.Text(this.createId("CVCSTBasicDesc_Text"), {
			text: "{Txtsh}"
		});
		CVCST_ColumnListItem.addCell(CVCSTBasicDesc_Text);
		var CVCSTAdv_IconTabFilter = new sap.m.IconTabFilter(this.createId("CVCSTAdv_IconTabFilter"), {
			key: "Advance",
			text: "Advanced"
		});
		CVCST_IconTabBar.addItem(CVCSTAdv_IconTabFilter);
		var CVCSTAdv_VBox = new sap.m.VBox(this.createId("CVCSTAdv_VBox"), {
			height: "396px",
			width: "570px"
		});
		CVCSTAdv_IconTabFilter.addContent(CVCSTAdv_VBox);
		var CVCSTInclude_Panel = new sap.m.Panel(this.createId("CVCSTInclude_Panel"), {
			expandable: true,
			expanded: true
		});
		CVCSTAdv_VBox.addItem(CVCSTInclude_Panel);
		var CVCSTInc_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("CVCSTInc_OverflowToolbar"), {});
		CVCSTInclude_Panel.setHeaderToolbar(CVCSTInc_OverflowToolbar);
		var CVCSTInc_Title = new sap.m.Title(this.createId("CVCSTInc_Title"), {});
		CVCSTInc_OverflowToolbar.addContent(CVCSTInc_Title);
		var CVCST_ToolbarSpacer4 = new sap.m.ToolbarSpacer(this.createId("CVCST_ToolbarSpacer4"), {});
		CVCSTInc_OverflowToolbar.addContent(CVCST_ToolbarSpacer4);
		var CVCSTAdvIncAdd_Button = new sap.m.Button(this.createId("CVCSTAdvIncAdd_Button"), {
			type: "Emphasized",
			icon: "sap-icon://add",
			press: function (oEvent) {
				var xd = {
					Selname: '',
					Kind: '',
					Sign: 'I',
					Option: 'CP',
					Low: '',
					High: '',
					Txtsh: '',
					Type: 'A'
				};
				CVCSTAdvInclude_List.getModel().getData().push(xd);
				CVCSTAdvInclude_List.getModel().refresh();
			}
		});
		CVCSTInc_OverflowToolbar.addContent(CVCSTAdvIncAdd_Button);
		var CVCSTAdvClearInc_Button = new sap.m.Button(this.createId("CVCSTAdvClearInc_Button"), {
			text: "Clear",
			tooltip: "Clear Selection",
			type: "Emphasized",
			press: function (oEvent) {
				CVCSTAdvInclude_List.setModel(setCVCSTInitial('I'));
				setCVCSTTitle('Initial', 'I');
				CVCSTAdvInclude_List.getModel().refresh();
			}
		});
		CVCSTInc_OverflowToolbar.addContent(CVCSTAdvClearInc_Button);
		var CVCSTAdvInclude_List = new sap.m.List(this.createId("CVCSTAdvInclude_List"), {
			mode: "Delete",
			delete: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				CVCSTAdvInclude_List.getModel().getData().splice(index, 1);
				CVCSTAdvInclude_List.getModel().refresh();
				setCVCSTTitle('NotInitial', 'I');
			}
		});
		CVCSTInclude_Panel.addContent(CVCSTAdvInclude_List);
		var modelCVCSTAdvInclude_List = new sap.ui.model.json.JSONModel();
		CVCSTAdvInclude_List.setModel(modelCVCSTAdvInclude_List);
		var CVCSTAdvInc_CustomListItem = new sap.m.CustomListItem(this.createId("CVCSTAdvInc_CustomListItem"), {});
		CVCSTAdvInclude_List.bindAggregation("items", "/", CVCSTAdvInc_CustomListItem);
		var CVCSTAdvInc_HBox = new sap.m.HBox(this.createId("CVCSTAdvInc_HBox"), {});
		CVCSTAdvInc_CustomListItem.addContent(CVCSTAdvInc_HBox);
		var CVCSTAdvInc_Select = new sap.m.Select(this.createId("CVCSTAdvInc_Select"), {
			selectedKey: "{Option}",
			width: "8rem"
		});
		CVCSTAdvInc_HBox.addItem(CVCSTAdvInc_Select);
		var CVCSTAdvInc_Input = new sap.m.Input(this.createId("CVCSTAdvInc_Input"), {
			maxLength: 255,
			placeholder: "Value",
			value: "{Low}",
			width: "23.5rem",
			change: function (oEvent) {
				setCVCSTTitle('NotInitial', 'I');
				var uc = oEvent.getParameter('newValue');
				var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
				CVCSTAdvInclude_List.getModel().getData()[index].Low = uc.toUpperCase();
			}
		});
		CVCSTAdvInc_HBox.addItem(CVCSTAdvInc_Input);
		var CVCSTExclude_Panel = new sap.m.Panel(this.createId("CVCSTExclude_Panel"), {
			expandable: true,
			expanded: true
		});
		CVCSTAdv_VBox.addItem(CVCSTExclude_Panel);
		var CVCSTAdvExc_OverflowToolbar = new sap.m.OverflowToolbar(this.createId("CVCSTAdvExc_OverflowToolbar"), {});
		CVCSTExclude_Panel.setHeaderToolbar(CVCSTAdvExc_OverflowToolbar);
		var CVCSTAdvExc_Title = new sap.m.Title(this.createId("CVCSTAdvExc_Title"), {});
		CVCSTAdvExc_OverflowToolbar.addContent(CVCSTAdvExc_Title);
		var CVCSTAdvEx_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("CVCSTAdvEx_ToolbarSpacer"), {});
		CVCSTAdvExc_OverflowToolbar.addContent(CVCSTAdvEx_ToolbarSpacer);
		var CVCSTAdvExcAdd_Button = new sap.m.Button(this.createId("CVCSTAdvExcAdd_Button"), {
			icon: "sap-icon://add",
			type: "Emphasized",
			press: function (oEvent) {
				var xd = {
					Selname: '',
					Kind: '',
					Sign: 'E',
					Option: 'CP',
					Low: '',
					High: '',
					Txtsh: '',
					Type: 'A'
				};
				CVCSTAdvExclude_List.getModel().getData().push(xd);
				CVCSTAdvExclude_List.getModel().refresh();
			}
		});
		CVCSTAdvExc_OverflowToolbar.addContent(CVCSTAdvExcAdd_Button);
		var CVCSTAdvExcClear_Button = new sap.m.Button(this.createId("CVCSTAdvExcClear_Button"), {
			text: "Clear",
			type: "Emphasized",
			press: function (oEvent) {
				CVCSTAdvExclude_List.setModel(setCVCSTInitial('E'));
				setCVCSTTitle('Initial', 'E');
				CVCSTAdvExclude_List.getModel().refresh();
			}
		});
		CVCSTAdvExc_OverflowToolbar.addContent(CVCSTAdvExcClear_Button);
		var CVCSTAdvExclude_List = new sap.m.List(this.createId("CVCSTAdvExclude_List"), {
			mode: "Delete",
			delete: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				CVCSTAdvExclude_List.getModel().getData().splice(index, 1);
				CVCSTAdvExclude_List.getModel().refresh();
				setCVCSTTitle('NotInitial', 'E');
			}
		});
		CVCSTExclude_Panel.addContent(CVCSTAdvExclude_List);
		var modelCVCSTAdvExclude_List = new sap.ui.model.json.JSONModel();
		CVCSTAdvExclude_List.setModel(modelCVCSTAdvExclude_List);
		var CVCSTAdvExc_CustomListItem = new sap.m.CustomListItem(this.createId("CVCSTAdvExc_CustomListItem"), {});
		CVCSTAdvExclude_List.bindAggregation("items", "/", CVCSTAdvExc_CustomListItem);
		var CVCSTAdvExc_HBox = new sap.m.HBox(this.createId("CVCSTAdvExc_HBox"), {});
		CVCSTAdvExc_CustomListItem.addContent(CVCSTAdvExc_HBox);
		var CVCSTAdvExc_Select = new sap.m.Select(this.createId("CVCSTAdvExc_Select"), {
			selectedKey: "{Option}",
			width: "8rem"
		});
		CVCSTAdvExc_HBox.addItem(CVCSTAdvExc_Select);
		var CVCSTAdvExc_Input = new sap.m.Input(this.createId("CVCSTAdvExc_Input"), {
			maxLength: 255,
			placeholder: "Value",
			value: "{Low}",
			width: "23.5rem",
			change: function (oEvent) {
				setCVCSTTitle('NotInitial', 'E');
				var uc = oEvent.getParameter('newValue');
				var index = oEvent.getSource().getBindingContext().sPath.split('/')[1];
				CVCSTAdvExclude_List.getModel().getData()[index].Low = uc.toUpperCase();
			}
		});
		CVCSTAdvExc_HBox.addItem(CVCSTAdvExc_Input);
		var CVCSel_Popover = new sap.m.Popover(this.createId("CVCSel_Popover"), {
			contentHeight: "200px",
			contentMinWidth: "140px",
			placement: "Bottom",
			showHeader: false
		});
		var CVCSel_Toolbar = new sap.m.Toolbar(this.createId("CVCSel_Toolbar"), {});
		CVCSel_Popover.addContent(CVCSel_Toolbar);
		var CVCSel_SearchField = new sap.m.SearchField(this.createId("CVCSel_SearchField"), {
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = CVCSel_List.getBinding("items");

				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Variant", "Contains", usrtxt),
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		CVCSel_Toolbar.addContent(CVCSel_SearchField);
		var CVCSel_List = new sap.m.List(this.createId("CVCSel_List"), {
			mode: "SingleSelectMaster",
			selectionChange: function (oEvent) {
				var index = oEvent.getParameters().listItem.getBindingContext().sPath.split('/')[1];
				var cData = CVCSel_List.getModel().getData()[index];
				CVCSel_Label.setText(cData.Variant);

				/**/
				gdefault_cvc_var = cData.Default_Flg;
				global_cvc_var = cData.Global_Flg;
				gVariantDesc = cData.Vtext;

				// oinpoSFormCVCOPS.setBusy(true);
				// oinpoSFormCVCMPN.setBusy(true);
				// oinpoSFormCVCSales.setBusy(true);
				// oinpoSFormCVCChan.setBusy(true);
				// oinpoSFormCVCSoldTo.setBusy(true);

				var varnt = cData.Variant;
				if (varnt == "Default") {
					clear();
				}
				// var aVARData = [];
				// var aFiltersvar = [];
				// aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
				// aFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile.getSelectedKey()));
				// aFiltersvar.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, varnt));

				// var varPromise = $.Deferred();
				// gVarModel.read('/VariantDtlSet', {
				//     filters: aFiltersvar,
				//     success: function(oData, resp) {
				//         varPromise.resolve();
				//         aVARData = oData.results;
				//     },
				//     error: function(oError) {
				//         oinpoSFormCVCOPS.setBusy(false);
				//         oinpoSFormCVCMPN.setBusy(false);
				//         oinpoSFormCVCSales.setBusy(false);
				//         oinpoSFormCVCChan.setBusy(false);
				//         oinpoSFormCVCSoldTo.setBusy(false);
				//         varPromise.resolve();
				//         sap.m.MessageToast.show(txtVariantODer);
				//     }
				// });
				// Promise.all(
				//     [
				//         varPromise
				//     ]
				// ).then($.proxy(function() {
				//     var tabval = aVARData;
				//     _setVariantToCVC(tabval);

				//     oinpoSFormCVCOPS.setBusy(false);
				//     oinpoSFormCVCMPN.setBusy(false);
				//     oinpoSFormCVCSales.setBusy(false);
				//     oinpoSFormCVCChan.setBusy(false);
				//     oinpoSFormCVCSoldTo.setBusy(false);

				// }));

				/**/
				_setVariant(varnt);

				CVCSel_Popover.close();
				/*



				*/
			}
		});
		CVCSel_Popover.addContent(CVCSel_List);
		var modelCVCSel_List = new sap.ui.model.json.JSONModel();
		CVCSel_List.setModel(modelCVCSel_List);
		var CVCSel_CustomListItem = new sap.m.CustomListItem(this.createId("CVCSel_CustomListItem"), {});
		CVCSel_List.bindAggregation("items", "/", CVCSel_CustomListItem);
		var CVCSel_HBox2 = new sap.m.HBox(this.createId("CVCSel_HBox2"), {
			height: "1.5rem"
		});
		CVCSel_CustomListItem.addContent(CVCSel_HBox2);
		var CVCSelStar_Icon2 = new sap.ui.core.Icon(this.createId("CVCSelStar_Icon2"), {
			color: "{StarV}",
			src: "sap-icon://favorite"
		});
		CVCSel_HBox2.addItem(CVCSelStar_Icon2);
		var CVCSelGlobal_Icon = new sap.ui.core.Icon(this.createId("CVCSelGlobal_Icon"), {
			width: "8px",
			src: "sap-icon://fa-solid/globe",
			hoverColor: "#ff3300",
			color: "{DelV}"
		});
		CVCSel_HBox2.addItem(CVCSelGlobal_Icon);
		var CVCSel_Text3 = new sap.m.Text(this.createId("CVCSel_Text3"), {
			text: "{Variant}",
			width: "10rem"
		});
		CVCSel_HBox2.addItem(CVCSel_Text3);
		var MPNSTPopover = new sap.m.Popover(this.createId("MPNSTPopover"), {
			bounce: true,
			contentHeight: "250px",
			contentWidth: "450px",
			placement: "PreferredBottomOrFlip"
		});
		var MPNSTPO_Toolbar = new sap.m.Toolbar(this.createId("MPNSTPO_Toolbar"), {});
		MPNSTPopover.addContent(MPNSTPO_Toolbar);
		var MPNSTPO_SearchField = new sap.m.SearchField(this.createId("MPNSTPO_SearchField"), {
			liveChange: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = MPNSTPOList.getBinding("items");
				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Low", "Contains", usrtxt),
						new sap.ui.model.Filter("Txtsh", "Contains", usrtxt)
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		MPNSTPO_Toolbar.addContent(MPNSTPO_SearchField);
		var MPNSTPO_HBox = new sap.m.HBox(this.createId("MPNSTPO_HBox"), {
			height: "2.1rem"
		});
		MPNSTPopover.addContent(MPNSTPO_HBox);
		var MPNSTPO_IE = new sap.m.Text(this.createId("MPNSTPO_IE"), {
			text: "Option",
			width: "115px"
		});
		MPNSTPO_HBox.addItem(MPNSTPO_IE);
		var MPNSTPO_Id = new sap.m.Text(this.createId("MPNSTPO_Id"), {
			width: "150px"
		});
		MPNSTPO_HBox.addItem(MPNSTPO_Id);
		var MPNSTPO_Desc = new sap.m.Text(this.createId("MPNSTPO_Desc"), {
			text: "Description"
		});
		MPNSTPO_HBox.addItem(MPNSTPO_Desc);
		var MPNSTPOList = new sap.m.List(this.createId("MPNSTPOList"), {});
		MPNSTPopover.addContent(MPNSTPOList);
		var modelMPNSTPOList = new sap.ui.model.json.JSONModel();
		MPNSTPOList.setModel(modelMPNSTPOList);
		var MPNSTPO_CustomListItem = new sap.m.CustomListItem(this.createId("MPNSTPO_CustomListItem"), {});
		MPNSTPOList.bindAggregation("items", "/", MPNSTPO_CustomListItem);
		var MPNSTPOList_HBox = new sap.m.HBox(this.createId("MPNSTPOList_HBox"), {
			backgroundDesign: "Solid"
		});
		MPNSTPO_CustomListItem.addContent(MPNSTPOList_HBox);
		var MPNSTPOList_Sign = new sap.m.Text(this.createId("MPNSTPOList_Sign"), {
			text: "{Option}",
			width: "115px"
		});
		MPNSTPOList_HBox.addItem(MPNSTPOList_Sign);
		var MPNSTPOList_Low = new sap.m.Text(this.createId("MPNSTPOList_Low"), {
			text: "{Low}",
			width: "150px"
		});
		MPNSTPOList_HBox.addItem(MPNSTPOList_Low);
		var MPNSTPOList_Desc = new sap.m.Text(this.createId("MPNSTPOList_Desc"), {
			text: "{Txtsh}"
		});
		MPNSTPOList_HBox.addItem(MPNSTPOList_Desc);
		var oPopoverNew = new sap.m.Popover(this.createId("oPopoverNew"), {
			bounce: true,
			contentHeight: "250px",
			contentWidth: "450px",
			placement: "PreferredBottomOrFlip"
		});
		var PopoverDemo_Toolbar = new sap.m.Toolbar(this.createId("PopoverDemo_Toolbar"), {});
		oPopoverNew.addContent(PopoverDemo_Toolbar);
		var PopoverDemo_SearchField = new sap.m.SearchField(this.createId("PopoverDemo_SearchField"), {
			liveChange: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = PopoverList.getBinding("items");
				var filter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Low", "Contains", usrtxt),
						new sap.ui.model.Filter("Txtsh", "Contains", usrtxt)
					],
					and: false
				});
				oBinding.filter([filter]);
			}
		});
		PopoverDemo_Toolbar.addContent(PopoverDemo_SearchField);
		var PopoverNew_HBox = new sap.m.HBox(this.createId("PopoverNew_HBox"), {
			height: "2.1rem"
		});
		oPopoverNew.addContent(PopoverNew_HBox);
		var PopoverNew_Id = new sap.m.Text(this.createId("PopoverNew_Id"), {
			width: "150px"
		});
		PopoverNew_HBox.addItem(PopoverNew_Id);
		var PopoverNew_Desc = new sap.m.Text(this.createId("PopoverNew_Desc"), {
			text: "Description"
		});
		PopoverNew_HBox.addItem(PopoverNew_Desc);
		var PopoverList = new sap.m.List(this.createId("PopoverList"), {});
		oPopoverNew.addContent(PopoverList);
		var modelPopoverList = new sap.ui.model.json.JSONModel();
		PopoverList.setModel(modelPopoverList);
		var PopoverList_CustomListItem = new sap.m.CustomListItem(this.createId("PopoverList_CustomListItem"), {});
		PopoverList.bindAggregation("items", "/", PopoverList_CustomListItem);
		var PopoverList_HBox = new sap.m.HBox(this.createId("PopoverList_HBox"), {
			backgroundDesign: "Solid"
		});
		PopoverList_CustomListItem.addContent(PopoverList_HBox);
		var PopoverList_Low = new sap.m.Text(this.createId("PopoverList_Low"), {
			text: "{Low}",
			width: "150px"
		});
		PopoverList_HBox.addItem(PopoverList_Low);
		var PopoverList_Desc = new sap.m.Text(this.createId("PopoverList_Desc"), {
			text: "{Txtsh}"
		});
		PopoverList_HBox.addItem(PopoverList_Desc);
		var oPopoverNew_job = new sap.m.Popover(this.createId("oPopoverNew_job"), {
			placement: "PreferredBottomOrFlip",
			contentWidth: "650px",
			contentHeight: "250px",
			bounce: true
		});
		var PopoverList_job = new sap.m.Table(this.createId("PopoverList_job"), {});
		oPopoverNew_job.addContent(PopoverList_job);
		var modelPopoverList_job = new sap.ui.model.json.JSONModel();
		PopoverList_job.setModel(modelPopoverList_job);
		var Popover_Date_Column1 = new sap.m.Column(this.createId("Popover_Date_Column1"), {
			header: new sap.m.Label({
				text: "Date"
			}),
			width: "20%"
		});
		PopoverList_job.addColumn(Popover_Date_Column1);
		var Popover_Time_Column3 = new sap.m.Column(this.createId("Popover_Time_Column3"), {
			header: new sap.m.Label({
				text: "Time"
			}),
			width: "20%"
		});
		PopoverList_job.addColumn(Popover_Time_Column3);
		var Popover_M_Column = new sap.m.Column(this.createId("Popover_M_Column"), {
			header: new sap.m.Label({
				text: "Msg Type"
			}),
			width: "15%"
		});
		PopoverList_job.addColumn(Popover_M_Column);
		var Popover_Desc_Column2 = new sap.m.Column(this.createId("Popover_Desc_Column2"), {
			header: new sap.m.Label({
				text: "Text"
			}),
			width: "45%"
		});
		PopoverList_job.addColumn(Popover_Desc_Column2);
		var CLI_ColumnListItem1 = new sap.m.ColumnListItem(this.createId("CLI_ColumnListItem1"), {});
		PopoverList_job.bindAggregation("items", "/", CLI_ColumnListItem1);
		var vPopover_Date_Text5 = new sap.m.Text(this.createId("vPopover_Date_Text5"), {
			text: "{Enterdate}"
		});
		CLI_ColumnListItem1.addCell(vPopover_Date_Text5);
		var Popover_Time_Text2 = new sap.m.Text(this.createId("Popover_Time_Text2"), {
			text: "{Entertime}"
		});
		CLI_ColumnListItem1.addCell(Popover_Time_Text2);
		var Popover_M_Text6 = new sap.m.Text(this.createId("Popover_M_Text6"), {
			text: "{Msgtype}"
		});
		CLI_ColumnListItem1.addCell(Popover_M_Text6);
		var Popover_Desc_Text7 = new sap.m.Text(this.createId("Popover_Desc_Text7"), {
			text: "{Text}"
		});
		CLI_ColumnListItem1.addCell(Popover_Desc_Text7);
		var diaVariantSave = new sap.m.Dialog(this.createId("diaVariantSave"), {
			contentWidth: "400px",
			draggable: true,
			stretchOnPhone: true,
			title: "Save Filter"
		});
		var VSave_MessageStrip = new sap.m.MessageStrip(this.createId("VSave_MessageStrip"), {
			type: "Warning",
			showIcon: true
		});
		diaVariantSave.addContent(VSave_MessageStrip);
		var formVariant = new sap.ui.layout.form.SimpleForm(this.createId("formVariant"), {
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 1
		});
		diaVariantSave.addContent(formVariant);
		var lblformVariantVARIANT = new sap.m.Label(this.createId("lblformVariantVARIANT"), {
			required: true,
			text: "Filter"
		});
		formVariant.addContent(lblformVariantVARIANT);
		var informVariantVARIANT = new sap.m.Input(this.createId("informVariantVARIANT"), {
			maxLength: 20,
			value: "{WA_VARIANT-VARIANT}"
		});
		formVariant.addContent(informVariantVARIANT);
		var lblformVariantVTEXT = new sap.m.Label(this.createId("lblformVariantVTEXT"), {
			required: true,
			text: "Description"
		});
		formVariant.addContent(lblformVariantVTEXT);
		var informVariantVTEXT = new sap.m.Input(this.createId("informVariantVTEXT"), {
			maxLength: 30,
			value: "{WA_VARIANT-VTEXT}"
		});
		formVariant.addContent(informVariantVTEXT);
		var cb_cvc_global = new sap.m.CheckBox(this.createId("cb_cvc_global"), {
			tooltip: "Mark for global variant",
			text: "Global",
			select: function (oEvent) {
				if (cb_cvc_global.getSelected()) {
					cb_cvc_Default.setEnabled(false);
					cb_cvc_Default.setSelected(false);
					global_cvc_var = "X";
				} else {
					cb_cvc_Default.setEnabled(true);
					global_cvc_var = " ";
				}
			}
		});
		formVariant.addContent(cb_cvc_global);
		var cb_cvc_Default = new sap.m.CheckBox(this.createId("cb_cvc_Default"), {
			text: "Default",
			tooltip: "Mark for default variant",
			select: function (oEvent) {
				if (cb_cvc_Default.getSelected()) {
					cb_cvc_global.setEnabled(false);
					cb_cvc_global.setSelected(false);
					gdefault_cvc_var = "X";
				} else {
					cb_cvc_global.setEnabled(true);
					gdefault_cvc_var = " ";
				}
			}
		});
		formVariant.addContent(cb_cvc_Default);
		var VSave_Toolbar = new sap.m.Toolbar(this.createId("VSave_Toolbar"), {});
		diaVariantSave.addContent(VSave_Toolbar);
		var VTB_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("VTB_ToolbarSpacer"), {});
		VSave_Toolbar.addContent(VTB_ToolbarSpacer);
		var butVariantProceed = new sap.m.Button(this.createId("butVariantProceed"), {
			type: "Emphasized",
			text: "Proceed",
			press: function (oEvent) {
				_saveVariant(informVariantVARIANT.getValue(), informVariantVTEXT.getValue());
			}
		});
		VSave_Toolbar.addContent(butVariantProceed);
		var butVariantSaveOK = new sap.m.Button(this.createId("butVariantSaveOK"), {
			text: "OK",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				// Checks
				if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
					'') {
					sap.m.MessageToast.show('Please select a profile');
				} else {
					if (_lz_checkCVCSel()) {
						var error = false;
						var variant;
						var vtext;
						var s_output;
						var s_er;
						if (!informVariantVARIANT.getValue()) {
							informVariantVARIANT.setValueState("Error");
							error = true;
						} else {
							informVariantVARIANT.setValueState();
							variant = informVariantVARIANT.getValue();
						}
						if (!informVariantVTEXT.getValue()) {
							informVariantVTEXT.setValueState("Error");
							error = true;
						} else {
							informVariantVTEXT.setValueState();
							vtext = informVariantVTEXT.getValue();
						}
						if (error) {
							return;
						} else {
							if (CVCSel_Label.getText() == '') {
								variant = informVariantVARIANT.getValue();
							} else {
								var sVariant = CVCSel_Label.getText().split('(')[0]
								if (sVariant == variant) {
									variant = CVCSel_Label.getText();
								}
							}
							sap.ui.core.BusyIndicator.show(0);
							_saveEVariant(variant, vtext);
						}
					}
				}

				function _lz_checkCVCSel() {
					var bReturn = true;
					if (oinpoSFormCVCOPS.getSelectedKeys().length > 0 || oinpoSFormCVCSales.getSelectedKeys().length > 0 || oinpoSFormCVCChan.getSelectedKeys()
						.length > 0 || oinpoSFormCVCMPN.getTokens().length > 0 || oinpoSFormCVCSoldTo.getTokens().length > 0) {

					} else {
						bReturn = false;
						sap.m.MessageToast.show('Please select one or more cvc selections');
					}
					return bReturn;
				}
				/*

				*/
			}
		});
		VSave_Toolbar.addContent(butVariantSaveOK);
		var butVariantSaveCancel = new sap.m.Button(this.createId("butVariantSaveCancel"), {
			text: "Close",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				diaVariantSave.close();
			}
		});
		VSave_Toolbar.addContent(butVariantSaveCancel);
		var WU_Ok = new sap.m.Button(this.createId("WU_Ok"), {
			text: "OK",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                                        *
				// * TITLE           : Workbench waves                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 14-Jul-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 14/07/2020  C5107535SA      65269905   Initial         DV5K927483    *
				// ************************************************************************
				//odata-call
				if (lz_parmVal()) {
					sap.ui.core.BusyIndicator.show(0);
					var xGridObj = {
						Secprofile: oProfileForm_Profile.getSelectedKey(),
						Fisweek: oProfileForm_Week.getSelectedKey(),
						WaveNr: oWavenr.getValue(),
						WaveRelMech: wave_rel_type.getSelectedKey(),
						WaveDescr: oInputDisc.getValue(),
						ScheduleAt: oinpoWaveRelTime.getValue(),
						Retcode: '0',
						Func: 'RC',
					};

					var isSuccess = false;
					var res = [];
					sap.ui.core.BusyIndicator.show(0);
					var xGuid = '';
					var cPromise = $.Deferred();
					gRollModel.create('/wave_propSet', xGridObj, {
						success: function (oData, resp) {
							cPromise.resolve();
							res = oData;
							isSuccess = true;
						},
						error: function (oError) {
							cPromise.resolve();
							sap.m.MessageToast.show('Error');
							sap.ui.core.BusyIndicator.hide();
						}
					});
					Promise.all(
						[
							cPromise
						]
					).then($.proxy(function () {
						if (isSuccess) {
							if (res.Retcode == '0') {
								if (res.Func == "") {
									sap.m.MessageToast.show('Authorization Error');
									update_wave_property.close();
								} else {
									if (res.Func) {
										var Msg = 'Data saved successfully';
									} else {
										var Msg = 'No authorization';
									}
									update_wave_property.close();
									sap.m.MessageToast.show(Msg);
									_getWorkBenchData();
								}

							} else {
								update_wave_property.close();
								if (res.Message != '') {
									sap.m.MessageToast.show(res.Message);
								} else {
									sap.m.MessageToast.show('Data not saved successfully');
								}
							}
						} else {
							update_wave_property.close();
							sap.m.MessageToast.show('Data not saved successfully');
						}
						sap.ui.core.BusyIndicator.hide();
					}));
				}

				function lz_parmVal() {
					var bReturn = true;
					if (wave_rel_type.getSelectedKey() == 'T') {
						if (oinpoWaveRelTime.getValue() == undefined || oinpoWaveRelTime.getValue() == null || oinpoWaveRelTime.getValue().trim() == '') {
							bReturn = false;
						}
					}
					if (bReturn == false) {
						sap.m.MessageToast.show("Select valid Date & Time");
					}
					return bReturn;
				}
				/*

				*/
			}
		});
		oPageDialog.addContent(WU_Ok);
		var WU_Close = new sap.m.Button(this.createId("WU_Close"), {
			type: "Emphasized",
			text: "Close",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				update_wave_property.close();
			}
		});
		oPageDialog.addContent(WU_Close);
		var update_wave_property = new sap.m.Dialog(this.createId("update_wave_property"), {
			contentWidth: "590px",
			stretchOnPhone: true,
			title: "Change Wave Header",
			beginButton: WU_Ok,
			endButton: WU_Close
		});
		var WP_VBox = new sap.m.VBox(this.createId("WP_VBox"), {});
		update_wave_property.addContent(WP_VBox);
		var wave_nr_txt = new sap.m.Label(this.createId("wave_nr_txt"), {
			text: "Wave Number"
		});
		WP_VBox.addItem(wave_nr_txt);
		var oWavenr = new sap.m.Input(this.createId("oWavenr"), {
			fieldWidth: "20%",
			maxLength: 5,
			type: "Number",
			width: "45%",
			change: function (oEvent) {

				var l_value;
				l_value = this.getValue();

				//check valid value
				var regex = /^[A-Za-z]+$/;
				if (l_value.match(regex)) {
					jQuery.sap.require("sap.m.MessageToast");
					sap.m.MessageToast.show(txtvalidval.getText());
				} else {
					if (l_value === "") {
						oWavenr.setRequired(true);
					}
				}
			}
		});
		WP_VBox.addItem(oWavenr);
		var wave_desc_txt = new sap.m.Label(this.createId("wave_desc_txt"), {
			text: "Wave Description"
		});
		WP_VBox.addItem(wave_desc_txt);
		var oInputDisc = new sap.m.Input(this.createId("oInputDisc"), {
			width: "45%",
			maxLength: 40,
			fieldWidth: "180px"
		});
		WP_VBox.addItem(oInputDisc);
		var oHBoxREVsch = new sap.m.HBox(this.createId("oHBoxREVsch"), {
			width: "100%"
		});
		update_wave_property.addContent(oHBoxREVsch);
		var oVBoxWaveRel = new sap.m.VBox(this.createId("oVBoxWaveRel"), {
			width: "50%"
		});
		oHBoxREVsch.addItem(oVBoxWaveRel);
		var oSchFormR2 = new sap.ui.layout.form.SimpleForm(this.createId("oSchFormR2"), {
			columnsL: 4,
			columnsM: 2,
			columnsXL: 6,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout"
		});
		oVBoxWaveRel.addItem(oSchFormR2);
		var oLblRrelsch = new sap.m.Label(this.createId("oLblRrelsch"), {
			text: "Release Type"
		});
		oSchFormR2.addContent(oLblRrelsch);
		var wave_rel_type = new sap.m.Select(this.createId("wave_rel_type"), {
			change: function (oEvent) {
				//"itemPress"
				//chgReleaseType();

				//chgReleaseType();
				var l_wave_release = wave_rel_type.getSelectedKey();
				switch (l_wave_release) {

				case "":
					oSchFormWaveReld.setVisible(false);
					break;

				case "D":
					oSchFormWaveReld.setVisible(false);
					oinpoWaveRelTime.setVisible(false);
					break;

				case "M":
					oSchFormWaveReld.setVisible(false);
					oinpoWaveRelTime.setVisible(false);
					break;

				case "T":
					oSchFormWaveReld.setVisible(true);
					oinpoWaveRelTime.setVisible(true);
					break;

				default:
					break;
				}
			}
		});
		oSchFormR2.addContent(wave_rel_type);
		var oVBoxWaveReld = new sap.m.VBox(this.createId("oVBoxWaveReld"), {
			width: "50%"
		});
		oHBoxREVsch.addItem(oVBoxWaveReld);
		var oSchFormWaveReld = new sap.ui.layout.form.SimpleForm(this.createId("oSchFormWaveReld"), {
			columnsL: 4,
			columnsM: 2,
			columnsXL: 6,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			visible: false
		});
		oVBoxWaveReld.addItem(oSchFormWaveReld);
		var oLblWaveRelTime = new sap.m.Label(this.createId("oLblWaveRelTime"), {
			text: "Date & Time"
		});
		oSchFormWaveReld.addContent(oLblWaveRelTime);
		var oinpoWaveRelTime = new sap.m.DateTimeInput(this.createId("oinpoWaveRelTime"), {
			displayFormat: "MMM d, y, h:mm:ss a",
			type: "DateTime",
			valueFormat: "yyyyMMdd:HHmmss"
		});
		oSchFormWaveReld.addContent(oinpoWaveRelTime);
		var WUClose_Button = new sap.m.Button(this.createId("WUClose_Button"), {
			text: "Close",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				gWaveUploadFile = '';
				diaWaveUP.close();
			}
		});
		oPageDialog.addContent(WUClose_Button);
		var WUProceed_Button = new sap.m.Button(this.createId("WUProceed_Button"), {
			text: "Proceed",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				if (oIconTabBarSdwnload.getSelectedKey() == 'Create')
					createUpload(gUploadErrorType, 'X');
				else
					createUpload(gUploadErrorType, '');
			}
		});
		oPageDialog.addContent(WUProceed_Button);
		var diaWaveUP = new sap.m.Dialog(this.createId("diaWaveUP"), {
			title: "Wave Upload",
			draggable: true,
			contentWidth: "700px",
			contentHeight: "450px",
			beginButton: WUProceed_Button,
			endButton: WUClose_Button
		});
		var Create_MessageStrip = new sap.m.MessageStrip(this.createId("Create_MessageStrip"), {
			type: "Error"
		});
		diaWaveUP.addContent(Create_MessageStrip);
		var oIconTabBarSdwnload = new sap.m.IconTabBar(this.createId("oIconTabBarSdwnload"), {
			expandable: false,
			selectedKey: "Create"
		});
		diaWaveUP.addContent(oIconTabBarSdwnload);
		var oIconTabFilterSdwnloadcr = new sap.m.IconTabFilter(this.createId("oIconTabFilterSdwnloadcr"), {
			key: "Create",
			text: "Create"
		});
		oIconTabBarSdwnload.addItem(oIconTabFilterSdwnloadcr);
		var Panel_create = new sap.m.Panel(this.createId("Panel_create"), {
			headerText: "Wave Upload"
		});
		oIconTabFilterSdwnloadcr.addContent(Panel_create);
		var WUCreate_VBox = new sap.m.VBox(this.createId("WUCreate_VBox"), {});
		Panel_create.addContent(WUCreate_VBox);
		var WUCreate_Label = new sap.m.Label(this.createId("WUCreate_Label"), {
			text: "File Name"
		});
		WUCreate_VBox.addItem(WUCreate_Label);
		var WUCrate_HBox2 = new sap.m.HBox(this.createId("WUCrate_HBox2"), {});
		WUCreate_VBox.addItem(WUCrate_HBox2);
		var oWaveFileUpCr = new sap.ui.unified.FileUploader(this.createId("oWaveFileUpCr"), {
			uploadUrl: "/DV5/zui_dat_workbench_waves?ajax_id=&ajax_applid=ZUI_DAT_WORKBENCH_WAVES&sap-client=&field_id=01081&sapui5-upload",
			placeholder: "select .csv file",
			sameFilenameAllowed: true,
			style: "Emphasized",
			tooltip: "select .csv file",
			width: "23rem",
			change: function (oEvent) {
				//Change File Upload
				gWaveUploadFileName = oWaveFileUpCr.getValue();
				//if(gWaveUploadFileName){
				gWaveUploadFile = oWaveFileUpCr.oFileUpload.files[0];
				Create_MessageStrip.setVisible(false);
				//}
			}
		});
		WUCrate_HBox2.addItem(oWaveFileUpCr);
		var WUCreateUpload_Btn = new sap.m.Button(this.createId("WUCreateUpload_Btn"), {
			text: "Upload",
			type: "Emphasized",
			press: function (oEvent) {
				//gWaveUploadFileName
				if (oWaveFileUpCr.getValue()) {
					sap.ui.core.BusyIndicator.show(0);
					createUpload('', 'X');
				} else {
					Create_MessageStrip.setVisible(true);
					Create_MessageStrip.setType('Error');
					Create_MessageStrip.setText('Please select a .csv file');
				}
			}
		});
		WUCrate_HBox2.addItem(WUCreateUpload_Btn);
		var Panel_temp_create = new sap.m.Panel(this.createId("Panel_temp_create"), {
			expanded: true,
			headerText: "Template Download"
		});
		oIconTabFilterSdwnloadcr.addContent(Panel_temp_create);
		var WUCreateDow_VBox = new sap.m.VBox(this.createId("WUCreateDow_VBox"), {});
		Panel_temp_create.addContent(WUCreateDow_VBox);
		var WUCreateDow_Label = new sap.m.Label(this.createId("WUCreateDow_Label"), {
			text: "No of waves"
		});
		WUCreateDow_VBox.addItem(WUCreateDow_Label);
		var WUCreateDowHBox = new sap.m.HBox(this.createId("WUCreateDowHBox"), {});
		WUCreateDow_VBox.addItem(WUCreateDowHBox);
		var oInpoSFormSdwnloadcrwcr = new sap.m.Input(this.createId("oInpoSFormSdwnloadcrwcr"), {
			maxLength: 2,
			width: "10rem"
		});
		WUCreateDowHBox.addItem(oInpoSFormSdwnloadcrwcr);
		var ButDown = new sap.m.Button(this.createId("ButDown"), {
			text: "Download",
			type: "Emphasized",
			width: "100px",
			press: function (oEvent) {
				var aFilters = [];
				var aWaveDown = [];
				var WaveCreateNr = oInpoSFormSdwnloadcrwcr.getValue();
				if (WaveCreateNr) {
					sap.ui.core.BusyIndicator.show(0);
					aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile.getSelectedKey()));
					aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, oProfileForm_Week.getSelectedKey()));
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));
					aFilters.push(new sap.ui.model.Filter("WavenoCreate", sap.ui.model.FilterOperator.EQ, WaveCreateNr));

					//OPS Subclass
					var ops = oinpoSFormCVCOPS.getSelectedKeys();
					if (ops.length > 0) {
						for (var i = 0; i < ops.length; i++) {
							aFilters.push(new sap.ui.model.Filter("OpsSubclass", sap.ui.model.FilterOperator.EQ, ops[i]));
						}
					}
					//MPN
					var len = oinpoSFormCVCMPN.getTokens().length;
					if (len > 0) {
						var mpnInc = false;
						var mpnExc = false;
						for (var i = 0; i < len; i++) {
							var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								mpnInc = true;
							}
							if (oToken == 'Exclude') {
								mpnExc = true;
							}
						}
						if (mpnInc) {
							var len = gMainMRef.getData().MPNIncListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().MPNIncListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("RuleMatnr",
										oOperator, iData.Low));
								}
							}
						}
						if (mpnExc) {
							var len = gMainMRef.getData().MPNExcListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().MPNExcListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("RuleMatnr",
										oOperator, iData.Low));
								}
							}
						}
					}
					//Sold To
					var stLen = oinpoSFormCVCSoldTo.getTokens().length;
					if (stLen > 0) {
						var stInc = false;
						var stExc = false;
						for (var i = 0; i < stLen; i++) {
							var oToken = oinpoSFormCVCSoldTo.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								stInc = true;
							}
							if (oToken == 'Exclude') {
								stExc = true;
							}
						}
						if (stInc) {
							var len = gMainMRef.getData().CVCSTIncListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().CVCSTIncListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("Kunnr",
										oOperator, iData.Low));

								}
							}
						}
						if (stExc) {
							var len = gMainMRef.getData().CVCSTExcListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().CVCSTExcListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("Kunnr",
										oOperator, iData.Low));
								}
							}
						}
					}
					//Sales Org
					var so = oinpoSFormCVCSales.getSelectedKeys();
					if (so.length > 0) {
						for (var i = 0; i < so.length; i++) {
							aFilters.push(new sap.ui.model.Filter("Vkorg", sap.ui.model.FilterOperator.EQ, so[i]));
						}
					}
					//Channel
					var channel = oinpoSFormCVCChan.getSelectedKeys();
					if (channel.length > 0) {
						for (var i = 0; i < channel.length; i++) {
							aFilters.push(new sap.ui.model.Filter("Zdistc", sap.ui.model.FilterOperator.EQ, channel[i]));
						}
					}

					var wdPromise = $.Deferred();
					gWaveModel.read('/WaveDownloadSet', {
						filters: aFilters,
						urlParameters: {
							'$expand': 'NAVWaveDownList,NAVWaveDMsg'
						},
						success: function (oData, resp) {
							wdPromise.resolve();
							aWaveDown = oData.results[0].NAVWaveDownList.results;

						},
						error: function (oError) {
							wdPromise.resolve();
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show('Error in Downloading');
						}
					});
					Promise.all(
						[
							wdPromise
						]
					).then($.proxy(function () {
						if (aWaveDown !== undefined) {
							var dl_text = aWaveDown[0].DlText;

							var aColumns = [{
								name: "SECPROFILE",
								template: {
									content: "{Secprofile}"
								}
							}, {
								name: "FISWEEK",
								template: {
									content: "{Fisweek}"
								}
							}, {
								name: "PLUID",
								template: {
									content: "{Pluid}"
								}
							}, {
								name: "PROD.ALLOC OBJ",
								template: {
									content: "{Konob}"
								}
							}, {
								name: "SALES ORG",
								template: {
									content: "{Vkorg}"
								}
							}, {
								name: "PRODUCT",
								template: {
									content: "{RuleMatnr}"
								}
							}, {
								name: "DIST.CHNL",
								template: {
									content: "{Zdistc}"
								}
							}, {
								name: "SOLD TO",
								template: {
									content: "{Kunnr}"
								}
							}, {
								name: "SHIP TO",
								template: {
									content: "{Pkunwe}"
								}
							}, {
								name: "POR QTY",
								template: {
									content: "{PorQty}"
								}
							}, {
								name: "RELEASED QTY",
								template: {
									content: "{RelQty}"
								}
							}, {
								name: "HOLDING BKT",
								template: {
									content: "{HldQty}"
								}
							}, ];
							var otherCols = dl_text.split(',');
							for (var i = 0; i < otherCols.length; i++) {
								var oc = otherCols[i];
								var xd = {
									name: oc,
									template: {
										content: "{" + oc + "}"
									}
								};
								aColumns.push(xd);
							}

							aWaveDown.splice(0, 1);
							var dataStr = "data:text/csv;charset=utf-8,";
							var aXBinding = [];
							var iCount = 0;
							for (var i = 0; i < aColumns.length; i++) {
								iCount++;
								if (iCount == aColumns.length) {
									dataStr += aColumns[i].name;
								} else {
									dataStr += aColumns[i].name + ',';
								}
								var aS1 = aColumns[i].template.content.split('{')[1];
								var aS2 = aS1.split('}')[0];
								aXBinding.push(aS2);
							}

							dataStr += "\r";

							var iCount = 0;
							for (var i = 0; i < aWaveDown.length; i++) {
								iCount++;
								var vd = aWaveDown[i];
								for (var x = 0; x < aXBinding.length; x++) {
									var y = x + 1;
									if (y == aXBinding.length) {
										if (vd[aXBinding[x]] == undefined) {
											dataStr += "";
										} else {
											dataStr += vd[aXBinding[x]];
										}
									} else {
										if (vd[aXBinding[x]] == undefined) {
											dataStr += "";
										} else {
											dataStr += vd[aXBinding[x]] + ",";
										}
									}
								}
								dataStr += "\r";
							}
							var xDate = new Date();
							var fTime;
							var xHours = xDate.getHours();
							if (xHours.toString().length == 1) {
								xHours = '0' + xHours.toString();
							}
							var xMin = xDate.getMinutes();
							if (xMin.toString().length == 1)
								xMin = '0' + xMin.toString();
							var xSec = xDate.getSeconds();
							if (xSec.toString().length == 1)
								xSec = '0' + xSec.toString();
							var fTime = xHours.toString() + xMin.toString() + xSec.toString();
							var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;
							var encodedUri = encodeURI(dataStr);
							var aTag = document.createElement('a');
							aTag.setAttribute("href", encodedUri);
							aTag.setAttribute("download", 'DAT_wave_create_' + tmDt + ".csv");
							aTag.innerHTML = "Click Here to download";
							aTag.click();
							aTag.remove();
							sap.ui.core.BusyIndicator.hide();
						}
					}));
				} else {
					/*show message for providing no of wave to be created*/
					sap.m.MessageToast.show('Provide input for No of Waves');
				}
			}
		});
		WUCreateDowHBox.addItem(ButDown);
		var oIconTabFilterSdwnploadch = new sap.m.IconTabFilter(this.createId("oIconTabFilterSdwnploadch"), {
			key: "Change",
			text: "Change"
		});
		oIconTabBarSdwnload.addItem(oIconTabFilterSdwnploadch);
		var Change_MessageStrip = new sap.m.MessageStrip(this.createId("Change_MessageStrip"), {
			type: "Error"
		});
		oIconTabFilterSdwnploadch.addContent(Change_MessageStrip);
		var Panel_change2 = new sap.m.Panel(this.createId("Panel_change2"), {
			headerText: "Wave Upload"
		});
		oIconTabFilterSdwnploadch.addContent(Panel_change2);
		var WUChange_VBox = new sap.m.VBox(this.createId("WUChange_VBox"), {});
		Panel_change2.addContent(WUChange_VBox);
		var WUChange_Label = new sap.m.Label(this.createId("WUChange_Label"), {
			text: "File Name"
		});
		WUChange_VBox.addItem(WUChange_Label);
		var WUChange_HBox2 = new sap.m.HBox(this.createId("WUChange_HBox2"), {});
		WUChange_VBox.addItem(WUChange_HBox2);
		var oWaveFileUpChange = new sap.ui.unified.FileUploader(this.createId("oWaveFileUpChange"), {
			uploadUrl: "/DV5/zui_dat_workbench_waves?ajax_id=&ajax_applid=ZUI_DAT_WORKBENCH_WAVES&sap-client=&field_id=01128&sapui5-upload",
			width: "23rem",
			tooltip: "select .csv file",
			style: "Emphasized",
			sameFilenameAllowed: true,
			placeholder: "select .csv file",
			change: function (oEvent) {
				//Create File Upload
				gWaveUploadFileName = oWaveFileUpChange.getValue();
				//if(gWaveUploadFileName){
				gWaveUploadFile = oWaveFileUpChange.oFileUpload.files[0];
				Create_MessageStrip.setVisible(false);
				//}
			}
		});
		WUChange_HBox2.addItem(oWaveFileUpChange);
		var WUChangeUpload_Btn = new sap.m.Button(this.createId("WUChangeUpload_Btn"), {
			text: "Upload",
			type: "Emphasized",
			press: function (oEvent) {
				//gWaveUploadFileName
				if (oWaveFileUpChange.getValue()) {
					sap.ui.core.BusyIndicator.show(0);
					createUpload('', '');
				} else {
					Create_MessageStrip.setVisible(true);
					Create_MessageStrip.setType('Error');
					Create_MessageStrip.setText('Please select a .csv file');
				}
			}
		});
		WUChange_HBox2.addItem(WUChangeUpload_Btn);
		var Panel_change = new sap.m.Panel(this.createId("Panel_change"), {
			expanded: true,
			headerText: "Template Download"
		});
		oIconTabFilterSdwnploadch.addContent(Panel_change);
		var ChgU_HBox1 = new sap.m.HBox(this.createId("ChgU_HBox1"), {});
		Panel_change.addContent(ChgU_HBox1);
		var ChgUFrom_VBox1 = new sap.m.VBox(this.createId("ChgUFrom_VBox1"), {});
		ChgU_HBox1.addItem(ChgUFrom_VBox1);
		var ChgUFrom_Label = new sap.m.Label(this.createId("ChgUFrom_Label"), {
			text: "Wave From"
		});
		ChgUFrom_VBox1.addItem(ChgUFrom_Label);
		var WaveFromInp = new sap.m.Input(this.createId("WaveFromInp"), {
			maxLength: 5
		});
		ChgUFrom_VBox1.addItem(WaveFromInp);
		var ChgUTo_VBox3 = new sap.m.VBox(this.createId("ChgUTo_VBox3"), {});
		ChgU_HBox1.addItem(ChgUTo_VBox3);
		var ChgUTo_Label = new sap.m.Label(this.createId("ChgUTo_Label"), {
			text: "Wave To"
		});
		ChgUTo_VBox3.addItem(ChgUTo_Label);
		var WaveToInp = new sap.m.Input(this.createId("WaveToInp"), {
			maxLength: 5
		});
		ChgUTo_VBox3.addItem(WaveToInp);
		var ChgUBtn_VBox = new sap.m.VBox(this.createId("ChgUBtn_VBox"), {});
		ChgU_HBox1.addItem(ChgUBtn_VBox);
		var Label1 = new sap.m.Label(this.createId("Label1"), {});
		ChgUBtn_VBox.addItem(Label1);
		var ButDownch = new sap.m.Button(this.createId("ButDownch"), {
			text: "Download",
			type: "Emphasized",
			press: function (oEvent) {
				var aFilters = [];
				var aWaveDown = [];
				var aWaveDMsg = [];
				var WaveFrom = WaveFromInp.getValue();
				var WaveTo = WaveToInp.getValue();
				if (lz_downValidate()) {
					sap.ui.core.BusyIndicator.show(0);
					aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile.getSelectedKey()));
					aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, oProfileForm_Week.getSelectedKey()));
					aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, gWaveProfileSelRegion));
					aFilters.push(new sap.ui.model.Filter("WaveFrom", sap.ui.model.FilterOperator.EQ, WaveFrom));
					if (WaveTo) {
						aFilters.push(new sap.ui.model.Filter("WaveTo", sap.ui.model.FilterOperator.EQ, WaveTo));
					}

					//OPS Subclass
					var ops = oinpoSFormCVCOPS.getSelectedKeys();
					if (ops.length > 0) {
						for (var i = 0; i < ops.length; i++) {
							aFilters.push(new sap.ui.model.Filter("OpsSubclass", sap.ui.model.FilterOperator.EQ, ops[i]));
						}
					}
					//MPN
					var len = oinpoSFormCVCMPN.getTokens().length;
					if (len > 0) {
						var mpnInc = false;
						var mpnExc = false;
						for (var i = 0; i < len; i++) {
							var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								mpnInc = true;
							}
							if (oToken == 'Exclude') {
								mpnExc = true;
							}
						}
						if (mpnInc) {
							var len = gMainMRef.getData().MPNIncListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().MPNIncListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("RuleMatnr",
										oOperator, iData.Low));
								}
							}
						}
						if (mpnExc) {
							var len = gMainMRef.getData().MPNExcListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().MPNExcListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("RuleMatnr",
										oOperator, iData.Low));
								}
							}
						}
					}
					//Sold To
					var stLen = oinpoSFormCVCSoldTo.getTokens().length;
					if (stLen > 0) {
						var stInc = false;
						var stExc = false;
						for (var i = 0; i < stLen; i++) {
							var oToken = oinpoSFormCVCSoldTo.getTokens()[i].getProperty('key');
							if (oToken == 'Include') {
								stInc = true;
							}
							if (oToken == 'Exclude') {
								stExc = true;
							}
						}
						if (stInc) {
							var len = gMainMRef.getData().CVCSTIncListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().CVCSTIncListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("Kunnr",
										oOperator, iData.Low));

								}
							}
						}
						if (stExc) {
							var len = gMainMRef.getData().CVCSTExcListData.length;
							if (len > 0) {
								for (var i = 0; i < len; i++) {
									var iData = gMainMRef.getData().CVCSTExcListData[i];
									var xOptions = 'EQ';
									var oOperator = sap.ui.model.FilterOperator.EQ;
									if (iData.Low.includes('*')) {
										var xOptions = 'CP';
										var oOperator = sap.ui.model.FilterOperator.Contains;
									}
									aFilters.push(new sap.ui.model.Filter("Kunnr",
										oOperator, iData.Low));
								}
							}
						}
					}
					//Sales Org
					var so = oinpoSFormCVCSales.getSelectedKeys();
					if (so.length > 0) {
						for (var i = 0; i < so.length; i++) {
							aFilters.push(new sap.ui.model.Filter("Vkorg", sap.ui.model.FilterOperator.EQ, so[i]));
						}
					}
					//Channel
					var channel = oinpoSFormCVCChan.getSelectedKeys();
					if (channel.length > 0) {
						for (var i = 0; i < channel.length; i++) {
							aFilters.push(new sap.ui.model.Filter("Zdistc", sap.ui.model.FilterOperator.EQ, channel[i]));
						}
					}

					var wdPromise = $.Deferred();
					gWaveModel.read('/WaveDownloadSet', {
						filters: aFilters,
						urlParameters: {
							'$expand': 'NAVWaveDownList,NAVWaveDMsg'
						},
						success: function (oData, resp) {
							wdPromise.resolve();
							aWaveDown = oData.results[0].NAVWaveDownList.results;
							aWaveDMsg = oData.results[0].NAVWaveDMsg.results;
						},
						error: function (oError) {
							wdPromise.resolve();
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show('Error in Downloading');
						}
					});
					Promise.all(
						[
							wdPromise
						]
					).then($.proxy(function () {
						if (aWaveDown !== undefined) {
							if (aWaveDown.length > 0) {
								var dl_text = aWaveDown[0].DlText;

								var aColumns = [{
									name: "SECPROFILE",
									template: {
										content: "{Secprofile}"
									}
								}, {
									name: "FISWEEK",
									template: {
										content: "{Fisweek}"
									}
								}, {
									name: "PLUID",
									template: {
										content: "{Pluid}"
									}
								}, {
									name: "PROD.ALLOC OBJ",
									template: {
										content: "{Konob}"
									}
								}, {
									name: "SALES ORG",
									template: {
										content: "{Vkorg}"
									}
								}, {
									name: "PRODUCT",
									template: {
										content: "{RuleMatnr}"
									}
								}, {
									name: "DIST.CHNL",
									template: {
										content: "{Zdistc}"
									}
								}, {
									name: "SOLD TO",
									template: {
										content: "{Kunnr}"
									}
								}, {
									name: "SHIP TO",
									template: {
										content: "{Pkunwe}"
									}
								}, {
									name: "POR QTY",
									template: {
										content: "{PorQty}"
									}
								}, {
									name: "RELEASED QTY",
									template: {
										content: "{RelQty}"
									}
								}, {
									name: "HOLDING BKT",
									template: {
										content: "{HldQty}"
									}
								}, ];
								var otherCols = dl_text.split(',');
								for (var i = 0; i < otherCols.length; i++) {
									var oc = otherCols[i];
									var xd = {
										name: oc,
										template: {
											content: "{" + oc + "}"
										}
									};
									aColumns.push(xd);
								}
								/**/
								var xKeys = aWaveDown[0].DlText;
								var sKeys = xKeys.split(',');
								aWaveDown.splice(0, 1);

								for (var i = 0; i < aWaveDown.length; i++) {
									var oWD = aWaveDown[i];
									var aXlt = oWD.DlText.split(',');
									for (var j = 0; j < sKeys.length; j++) {
										oWD[sKeys[j]] = aXlt[j];
									}
									// delete oWD.DlText;
								}
								for (var i = 0; i < aWaveDown.length; i++) {
									var oWD = aWaveDown[i];
									delete oWD.DlText;
								}

								/**/
								var dataStr = "data:text/csv;charset=utf-8,";
								var aXBinding = [];
								var iCount = 0;
								for (var i = 0; i < aColumns.length; i++) {
									iCount++;
									if (iCount == aColumns.length) {
										dataStr += aColumns[i].name;
									} else {
										dataStr += aColumns[i].name + ',';
									}
									var aS1 = aColumns[i].template.content.split('{')[1];
									var aS2 = aS1.split('}')[0];
									aXBinding.push(aS2);
								}
								dataStr += "\r";
								var iCount = 0;
								for (var i = 0; i < aWaveDown.length; i++) {
									iCount++;
									var vd = aWaveDown[i];
									for (var x = 0; x < aXBinding.length; x++) {
										var y = x + 1;
										if (y == aXBinding.length) {
											if (vd[aXBinding[x]] == undefined) {
												dataStr += "";
											} else {
												dataStr += vd[aXBinding[x]];
											}
										} else {
											if (vd[aXBinding[x]] == undefined) {
												dataStr += "";
											} else {
												dataStr += vd[aXBinding[x]] + ",";
											}
										}
									}
									dataStr += "\r";
								}
								var xDate = new Date();
								var fTime;
								var xHours = xDate.getHours();
								if (xHours.toString().length == 1) {
									xHours = '0' + xHours.toString();
								}
								var xMin = xDate.getMinutes();
								if (xMin.toString().length == 1)
									xMin = '0' + xMin.toString();
								var xSec = xDate.getSeconds();
								if (xSec.toString().length == 1)
									xSec = '0' + xSec.toString();
								var fTime = xHours.toString() + xMin.toString() + xSec.toString();
								var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;
								var encodedUri = encodeURI(dataStr);
								var aTag = document.createElement('a');
								aTag.setAttribute("href", encodedUri);
								aTag.setAttribute("download", 'DAT_wave_change_' + tmDt + ".csv");
								aTag.innerHTML = "Click Here to download";
								aTag.click();
								aTag.remove();
								sap.ui.core.BusyIndicator.hide();
							}
						}
						if (aWaveDMsg !== undefined) {
							if (aWaveDMsg.length > 0) {
								var eMsg = aWaveDMsg[0].Message;
								sap.m.MessageToast.show(eMsg);
								sap.ui.core.BusyIndicator.hide();
							}
						}
					}));
				} else {
					/*show message for providing no of wave to be created*/
					sap.m.MessageToast.show('Please provide valid wave number');
				}

				function lz_downValidate() {
					var bReturn = true;
					if (WaveFromInp.getValue() == undefined || WaveFromInp.getValue() == null || WaveFromInp.getValue().trim() == '') {
						bReturn = false;
					} else {
						var iWV = parseInt(WaveFromInp.getValue());
						if (iWV <= 0) {
							bReturn = false;
						}
					}
					return bReturn;
				}
			}
		});
		ChgUBtn_VBox.addItem(ButDownch);
		var WUError_Panel = new sap.m.Panel(this.createId("WUError_Panel"), {});
		diaWaveUP.addContent(WUError_Panel);
		var WUError_Table = new sap.m.Table(this.createId("WUError_Table"), {});
		WUError_Panel.addContent(WUError_Table);
		var modelWUError_Table = new sap.ui.model.json.JSONModel();
		WUError_Table.setModel(modelWUError_Table);
		var WUErrorTbl_Column1 = new sap.m.Column(this.createId("WUErrorTbl_Column1"), {
			header: new sap.m.Label({
				text: "Name"
			}),
			width: "3rem"
		});
		WUError_Table.addColumn(WUErrorTbl_Column1);
		var WUErrorTbl_Column2 = new sap.m.Column(this.createId("WUErrorTbl_Column2"), {
			header: new sap.m.Label({
				text: "Error"
			})
		});
		WUError_Table.addColumn(WUErrorTbl_Column2);
		var WUErrorTbl__ColumnListItem = new sap.m.ColumnListItem(this.createId("WUErrorTbl__ColumnListItem"), {});
		WUError_Table.bindAggregation("items", "/", WUErrorTbl__ColumnListItem);
		var WUErrorTbl_Text1 = new sap.m.Text(this.createId("WUErrorTbl_Text1"), {
			text: "{Type}"
		});
		WUErrorTbl__ColumnListItem.addCell(WUErrorTbl_Text1);
		var WUErrorTbl_Text2 = new sap.m.Text(this.createId("WUErrorTbl_Text2"), {
			text: "{Message}"
		});
		WUErrorTbl__ColumnListItem.addCell(WUErrorTbl_Text2);
		var oUBPButCancel = new sap.m.Button(this.createId("oUBPButCancel"), {
			type: "Emphasized",
			text: "Close",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				gUBPUploadFile = '';
				oDialogUBP.close()
			}
		});
		oPageDialog.addContent(oUBPButCancel);
		var oUBPProceed_Button = new sap.m.Button(this.createId("oUBPProceed_Button"), {
			text: "Proceed",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				createUploadUBP('UBPGTPOR');
			}
		});
		oPageDialog.addContent(oUBPProceed_Button);
		var oDialogUBP = new sap.m.Dialog(this.createId("oDialogUBP"), {
			contentHeight: "250px",
			contentWidth: "700px",
			draggable: true,
			title: "User Base Plan Upload",
			beginButton: oUBPProceed_Button,
			endButton: oUBPButCancel
		});
		var UBP_MessageStrip = new sap.m.MessageStrip(this.createId("UBP_MessageStrip"), {
			type: "Error"
		});
		oDialogUBP.addContent(UBP_MessageStrip);
		var Panel_UBP = new sap.m.Panel(this.createId("Panel_UBP"), {
			headerText: "User Base Plan Upload"
		});
		oDialogUBP.addContent(Panel_UBP);
		var oPOR_Region = new sap.m.Select(this.createId("oPOR_Region"), {
			maxWidth: "50%",
			width: "400px"
		});
		Panel_UBP.addContent(oPOR_Region);
		var oVBoxubp = new sap.m.VBox(this.createId("oVBoxubp"), {});
		Panel_UBP.addContent(oVBoxubp);
		var oUBPRadioButtonGroup = new sap.m.RadioButtonGroup(this.createId("oUBPRadioButtonGroup"), {
			columns: 2
		});
		oVBoxubp.addItem(oUBPRadioButtonGroup);
		var oUBPRBplan1 = new sap.m.RadioButton(this.createId("oUBPRBplan1"), {
			text: "User Base Plan 1"
		});
		oUBPRadioButtonGroup.addButton(oUBPRBplan1);
		var oUBPRBplan2 = new sap.m.RadioButton(this.createId("oUBPRBplan2"), {
			text: "User Base Plan 2"
		});
		oUBPRadioButtonGroup.addButton(oUBPRBplan2);
		var UBPFilename_Label = new sap.m.Label(this.createId("UBPFilename_Label"), {
			text: "File Name"
		});
		Panel_UBP.addContent(UBPFilename_Label);
		var oUBPHBox = new sap.m.HBox(this.createId("oUBPHBox"), {
			alignContent: "Inherit",
			alignItems: "Start",
			backgroundDesign: "Solid"
		});
		Panel_UBP.addContent(oUBPHBox);
		var oUBPFileUploader = new sap.ui.unified.FileUploader(this.createId("oUBPFileUploader"), {
			uploadUrl: "/DV5/zui_dat_workbench_waves?ajax_id=&ajax_applid=ZUI_DAT_WORKBENCH_WAVES&sap-client=&field_id=01278&sapui5-upload",
			fileType: "csv",
			placeholder: "select .csv file",
			sameFilenameAllowed: true,
			style: "Emphasized",
			tooltip: "select .csv file",
			width: "23rem",
			change: function (oEvent) {
				gUBPUploadFileName = oUBPFileUploader.getValue();
				if (gUBPUploadFileName) {
					gUBPUploadFile = oUBPFileUploader.oFileUpload.files[0];
					UBP_MessageStrip.setVisible(false);
				}
			}
		});
		oUBPHBox.addItem(oUBPFileUploader);
		var oUBPUpload = new sap.m.Button(this.createId("oUBPUpload"), {
			text: "Upload",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				if (oUBPFileUploader.getValue()) {
					sap.ui.core.BusyIndicator.show(0);
					createUploadUBP('');
				} else {
					UBP_MessageStrip.setVisible(true);
					UBP_MessageStrip.setType('Error');
					UBP_MessageStrip.setText('Please select a .csv file');
				}
			}
		});
		oUBPHBox.addItem(oUBPUpload);
		var UBPDownload_Link = new sap.m.Link(this.createId("UBPDownload_Link"), {
			text: "Download Template",
			press: function (oEvent) {
				var aColumns = [{
					name: "Product allocation object"
				}, {
					name: "Channel"
				}, {
					name: "MPN"
				}, {
					name: "Sales org"
				}, {
					name: "Ship-to"
				}, {
					name: "Sold-to"
				}, {
					name: "UserBasePlan Qty"
				}, {
					name: "Unit(EA)"
				}, {
					name: "Fiscal week(Please remove column header before upload)"
				}];
				var dataStr = "data:text/csv;charset=utf-8,";
				for (var i = 0; i < aColumns.length; i++) {
					dataStr += aColumns[i].name + ",";
				}
				dataStr = dataStr.substring(0, dataStr.length - 1);
				dataStr += "\r";
				var xDate = new Date();
				var fTime;
				var xHours = xDate.getHours();
				if (xHours.toString().length == 1)
					xHours = '0' + xHours.toString();
				var xMin = xDate.getMinutes();
				if (xMin.toString().length == 1)
					xMin = '0' + xMin.toString();
				var xSec = xDate.getSeconds();
				if (xSec.toString().length == 1)
					xSec = '0' + xSec.toString();
				var fTime = xHours.toString() + xMin.toString() + xSec.toString();
				var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;

				var encodedUri = encodeURI(dataStr);
				var aTag = document.createElement('a');
				aTag.setAttribute("href", encodedUri);
				aTag.setAttribute("download", 'User base plan template_' + tmDt + ".csv");
				aTag.innerHTML = "Click Here to download";
				aTag.click();
				aTag.remove();
				/*


				*/
			}
		});
		Panel_UBP.addContent(UBPDownload_Link);
		var UBPError_Panel = new sap.m.Panel(this.createId("UBPError_Panel"), {
			visible: false
		});
		oDialogUBP.addContent(UBPError_Panel);
		var UBPError_Table = new sap.m.Table(this.createId("UBPError_Table"), {});
		UBPError_Panel.addContent(UBPError_Table);
		var modelUBPError_Table = new sap.ui.model.json.JSONModel();
		UBPError_Table.setModel(modelUBPError_Table);
		var colUBPError_TableFileData = new sap.m.Column(this.createId("colUBPError_TableFileData"), {
			header: new sap.m.Label({
				text: "File Data"
			}),
			width: "60%"
		});
		UBPError_Table.addColumn(colUBPError_TableFileData);
		var colUBPError_TableType = new sap.m.Column(this.createId("colUBPError_TableType"), {
			header: new sap.m.Label({
				text: "Message Type"
			}),
			width: "10%"
		});
		UBPError_Table.addColumn(colUBPError_TableType);
		var colUBPError_TableMessage = new sap.m.Column(this.createId("colUBPError_TableMessage"), {
			header: new sap.m.Label({
				text: "Message"
			}),
			width: "30%"
		});
		UBPError_Table.addColumn(colUBPError_TableMessage);
		var colItemUBPError_Table = new sap.m.ColumnListItem(this.createId("colItemUBPError_Table"), {});
		UBPError_Table.bindAggregation("items", "/", colItemUBPError_Table);
		var txtUBPError_TableFileData = new sap.m.Text(this.createId("txtUBPError_TableFileData"), {
			text: "{FileData}"
		});
		colItemUBPError_Table.addCell(txtUBPError_TableFileData);
		var txtUBPError_TableType = new sap.m.Text(this.createId("txtUBPError_TableType"), {
			text: "{Type}"
		});
		colItemUBPError_Table.addCell(txtUBPError_TableType);
		var txtUBPError_TableMessage = new sap.m.Text(this.createId("txtUBPError_TableMessage"), {
			text: "{Message}"
		});
		colItemUBPError_Table.addCell(txtUBPError_TableMessage);
		var oPPUButCancel = new sap.m.Button(this.createId("oPPUButCancel"), {
			type: "Emphasized",
			text: "Close",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				gPPUploadFile = '';
				oDialogPLAPOR_UPD.close();
			}
		});
		oPageDialog.addContent(oPPUButCancel);
		var oPPUProceed_Button = new sap.m.Button(this.createId("oPPUProceed_Button"), {
			text: "Proceed",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				createUploadPP('PLAPOR');
			}
		});
		oPageDialog.addContent(oPPUProceed_Button);
		var oDialogPLAPOR_UPD = new sap.m.Dialog(this.createId("oDialogPLAPOR_UPD"), {
			title: "PLA Upload",
			draggable: true,
			contentWidth: "700px",
			contentHeight: "260px",
			beginButton: oPPUProceed_Button,
			endButton: oPPUButCancel
		});
		var PPU_MessageStrip = new sap.m.MessageStrip(this.createId("PPU_MessageStrip"), {
			type: "Error"
		});
		oDialogPLAPOR_UPD.addContent(PPU_MessageStrip);
		var Panel_PPU = new sap.m.Panel(this.createId("Panel_PPU"), {
			headerText: "PLA Upload"
		});
		oDialogPLAPOR_UPD.addContent(Panel_PPU);
		var oPPUHBox = new sap.m.HBox(this.createId("oPPUHBox"), {});
		Panel_PPU.addContent(oPPUHBox);
		var oPPUVBox = new sap.m.VBox(this.createId("oPPUVBox"), {});
		oPPUHBox.addItem(oPPUVBox);
		var oPPUreg_Label = new sap.m.Label(this.createId("oPPUreg_Label"), {
			text: "Region"
		});
		oPPUVBox.addItem(oPPUreg_Label);
		var oPPOR_Region = new sap.m.Select(this.createId("oPPOR_Region"));
		oPPUVBox.addItem(oPPOR_Region);
		var oPPUVBox1 = new sap.m.VBox(this.createId("oPPUVBox1"), {});
		oPPUHBox.addItem(oPPUVBox1);
		var oPPUweek_Label = new sap.m.Label(this.createId("oPPUweek_Label"), {
			text: "Week"
		});
		oPPUVBox1.addItem(oPPUweek_Label);
		var oPPU_Week = new sap.m.Select(this.createId("oPPU_Week"), {
			selectedKey: "{WA_FISC_WEEK-WEEK}",
			change: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var l_week = oPPU_Week.getSelectedKey();

				//getWeekProfile(l_week, '', '');
				//oProfileForm_Profile.setSelectedKey('');
				//resetData();
				//CVCSel_Label.setText('');

				// var xGrid = document.querySelector('#xsGrid');
				// if(xGrid != null){
				//     xGrid.remove();
				//     gGridOptions.rowData = [];
				// }

				// oSat_Switch.setState(false);
			}
		});
		oPPUVBox1.addItem(oPPU_Week);
		var oVBoxppu = new sap.m.VBox(this.createId("oVBoxppu"), {});
		Panel_PPU.addContent(oVBoxppu);
		var PPUFilename_Label = new sap.m.Label(this.createId("PPUFilename_Label"), {
			text: "File Name"
		});
		oVBoxppu.addItem(PPUFilename_Label);
		var oPPUHBox1 = new sap.m.HBox(this.createId("oPPUHBox1"), {
			alignContent: "Inherit",
			alignItems: "Start",
			backgroundDesign: "Solid"
		});
		Panel_PPU.addContent(oPPUHBox1);
		var oPPUFileUploader = new sap.ui.unified.FileUploader(this.createId("oPPUFileUploader"), {
			uploadUrl: "/DV5/zui_dat_workbench_waves?ajax_id=&ajax_applid=ZUI_DAT_WORKBENCH_WAVES&sap-client=&field_id=01724&sapui5-upload",
			fileType: "csv",
			placeholder: "select .csv file",
			sameFilenameAllowed: true,
			style: "Emphasized",
			tooltip: "select .csv file",
			width: "23rem",
			change: function (oEvent) {
				gPPUploadFileName = oPPUFileUploader.getValue();
				if (gPPUploadFileName) {
					gPPUploadFile = oPPUFileUploader.oFileUpload.files[0];
					PPU_MessageStrip.setVisible(false);
				}
			}
		});
		oPPUHBox1.addItem(oPPUFileUploader);
		var oPPUUpload = new sap.m.Button(this.createId("oPPUUpload"), {
			text: "Upload",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				debugger;
				PPU_MessageStrip.setVisible(false);
				if (oPPUFileUploader.getValue()) {
					if (oPPUFileUploader.getValue().split('.')[1] !== 'csv') {
						PPU_MessageStrip.setVisible(true);
						PPU_MessageStrip.setType('Error');
						PPU_MessageStrip.setText('Only .csv file allowed');
					} else {
						sap.ui.core.BusyIndicator.show(0);
						createUploadPP('');
					}
				} else {
					PPU_MessageStrip.setVisible(true);
					PPU_MessageStrip.setType('Error');
					PPU_MessageStrip.setText('Please select a .csv file');
				}
			}
		});
		oPPUHBox1.addItem(oPPUUpload);
		var PPUDW_Link = new sap.m.Link(this.createId("PPUDW_Link"), {
			text: "Download Template",
			press: function (oEvent) {
				var aColumns = [{
					name: "Channel"
				}, {
					name: "MPN"
				}, {
					name: "Plant"
				}, {
					name: "Sales org"
				}, {
					name: "Ship-to"
				}, {
					name: "Sold-to"
				}, {
					name: "POR Qty (must be Lot Size compliant)"
				}];
				var dataStr = "data:text/csv;charset=utf-8,";
				for (var i = 0; i < aColumns.length; i++) {
					dataStr += aColumns[i].name + ",";
				}
				dataStr = dataStr.substring(0, dataStr.length - 1);
				dataStr += "\r";
				var xDate = new Date();
				var fTime;
				var xHours = xDate.getHours();
				if (xHours.toString().length == 1)
					xHours = '0' + xHours.toString();
				var xMin = xDate.getMinutes();
				if (xMin.toString().length == 1)
					xMin = '0' + xMin.toString();
				var xSec = xDate.getSeconds();
				if (xSec.toString().length == 1)
					xSec = '0' + xSec.toString();
				var fTime = xHours.toString() + xMin.toString() + xSec.toString();
				var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;

				var encodedUri = encodeURI(dataStr);
				var aTag = document.createElement('a');
				aTag.setAttribute("href", encodedUri);
				aTag.setAttribute("download", 'PLA POR template_' + tmDt + ".csv");
				aTag.innerHTML = "Click Here to download";
				aTag.click();
				aTag.remove();
				/*


				*/
			}
		});
		Panel_PPU.addContent(PPUDW_Link);
		var PPUError_Panel = new sap.m.Panel(this.createId("PPUError_Panel"), {
			visible: false
		});
		oDialogPLAPOR_UPD.addContent(PPUError_Panel);
		var PPUError_Table = new sap.m.Table(this.createId("PPUError_Table"), {});
		PPUError_Panel.addContent(PPUError_Table);
		var modelPPUError_Table = new sap.ui.model.json.JSONModel();
		PPUError_Table.setModel(modelPPUError_Table);
		var colPPUError_TableFileData = new sap.m.Column(this.createId("colPPUError_TableFileData"), {
			header: new sap.m.Label({
				text: "File Data"
			}),
			width: "60%"
		});
		PPUError_Table.addColumn(colPPUError_TableFileData);
		var colUBPPPUError_TableType = new sap.m.Column(this.createId("colUBPPPUError_TableType"), {
			header: new sap.m.Label({
				text: "Message Type"
			}),
			width: "10%"
		});
		PPUError_Table.addColumn(colUBPPPUError_TableType);
		var colPPUError_TableMessage = new sap.m.Column(this.createId("colPPUError_TableMessage"), {
			header: new sap.m.Label({
				text: "Message"
			}),
			width: "30%"
		});
		PPUError_Table.addColumn(colPPUError_TableMessage);
		var colItemPPUError_Table = new sap.m.ColumnListItem(this.createId("colItemPPUError_Table"), {});
		PPUError_Table.bindAggregation("items", "/", colItemPPUError_Table);
		var txtPPUError_TableFileData = new sap.m.Text(this.createId("txtPPUError_TableFileData"), {
			text: "{FileData}"
		});
		colItemPPUError_Table.addCell(txtPPUError_TableFileData);
		var txtPPUError_TableType = new sap.m.Text(this.createId("txtPPUError_TableType"), {
			text: "{Type}"
		});
		colItemPPUError_Table.addCell(txtPPUError_TableType);
		var txtPPUError_TableMessage = new sap.m.Text(this.createId("txtPPUError_TableMessage"), {
			text: "{Message}"
		});
		var oPGUButCancel = new sap.m.Button(this.createId("oPGUButCancel"), {
			text: "Close",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				gPGUploadFile = '';
				oDialogPLAGATP_UPD.close();
			}
		});
		oPageDialog.addContent(oPGUButCancel);
		var oPGUProceed_Button = new sap.m.Button(this.createId("oPGUProceed_Button"), {
			text: "Proceed",
			type: "Emphasized",
			press: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_RCA                                        *
				// * TITLE           : RCA                                                *
				// * CREATED BY      : Swetha AS                                          *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for RCA.                                        *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5107535SA      58532883   Initial         DV5K927483    *
				// ************************************************************************
				createUploadPP('PLAPOR');
			}
		});
		oPageDialog.addContent(oPGUProceed_Button);
		var oDialogPLAGATP_UPD = new sap.m.Dialog(this.createId("oDialogPLAGATP_UPD"), {
			contentHeight: "260px",
			contentWidth: "700px",
			draggable: true,
			title: "PLA GATP Upload",
			beginButton: oPGUProceed_Button,
			endButton: oPGUButCancel
		});
		var PGU_MessageStrip = new sap.m.MessageStrip(this.createId("PGU_MessageStrip"), {
			type: "Error"
		});
		oDialogPLAGATP_UPD.addContent(PGU_MessageStrip);
		var Panel_PGU = new sap.m.Panel(this.createId("Panel_PGU"), {
			headerText: "PLA Upload"
		});
		oDialogPLAGATP_UPD.addContent(Panel_PGU);
		var oPGUHBox = new sap.m.HBox(this.createId("oPGUHBox"), {});
		Panel_PGU.addContent(oPGUHBox);
		var oPGUVBox = new sap.m.VBox(this.createId("oPGUVBox"), {});
		oPGUHBox.addItem(oPGUVBox);
		var oPGUreg_Label = new sap.m.Label(this.createId("oPGUreg_Label"), {
			text: "Region"
		});
		oPGUVBox.addItem(oPGUreg_Label);
		var oPGU_Region = new sap.m.Select(this.createId("oPGU_Region"));
		oPGUVBox.addItem(oPGU_Region);
		var oPGUVBox1 = new sap.m.VBox(this.createId("oPGUVBox1"), {});
		oPGUHBox.addItem(oPGUVBox1);
		var oPGUweek_Label = new sap.m.Label(this.createId("oPGUweek_Label"), {
			text: "Week"
		});
		oPGUVBox1.addItem(oPGUweek_Label);
		var oPGU_Week = new sap.m.Select(this.createId("oPGU_Week"), {
			selectedKey: "{WA_FISC_WEEK-WEEK}",
			change: function (oEvent) {
				// ************************************************************************
				// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
				// * TITLE           : Workbench Waves                                    *
				// * CREATED BY      : Sivaprasad Valluru                                 *
				// * CREATION DATE   : 22-May-2020                                        *
				// * BHU#            : BHU26843                                           *
				// * DESCRIPTION     : UI for Workbench waves                             *
				// *                   Desiger                                            *
				// ************************************************************************
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
				// ************************************************************************
				var l_week = oPPU_Week.getSelectedKey();

				//getWeekProfile(l_week, '', '');
				//oProfileForm_Profile.setSelectedKey('');
				//resetData();
				//CVCSel_Label.setText('');

				// var xGrid = document.querySelector('#xsGrid');
				// if(xGrid != null){
				//     xGrid.remove();
				//     gGridOptions.rowData = [];
				// }

				// oSat_Switch.setState(false);
			}
		});
		oPGUVBox1.addItem(oPGU_Week);
		var oPGUVBoxGap1 = new sap.m.VBox(this.createId("oPGUVBoxGap1"), {
			width: "2rem"
		});
		oPGUHBox.addItem(oPGUVBoxGap1);
		var oLabelGap1 = new sap.m.Label(this.createId("oLabelGap1"), {
			width: "1rem"
		});
		oPGUVBoxGap1.addItem(oLabelGap1);
		var oPGUVBox2 = new sap.m.VBox(this.createId("oPGUVBox2"), {});
		oPGUHBox.addItem(oPGUVBox2);
		var Label_Consump = new sap.m.Label(this.createId("Label_Consump"), {
			text: "Check consumption"
		});
		oPGUVBox2.addItem(Label_Consump);
		var Switch_Coms_status = new sap.m.Switch(this.createId("Switch_Coms_status"), {});
		oPGUVBox2.addItem(Switch_Coms_status);
		var oVBoxPGU = new sap.m.VBox(this.createId("oVBoxPGU"), {});
		Panel_PGU.addContent(oVBoxPGU);
		var PGUFilename_Label = new sap.m.Label(this.createId("PGUFilename_Label"), {
			text: "File Name"
		});
		oVBoxPGU.addItem(PGUFilename_Label);
		var oPGUHBox2 = new sap.m.HBox(this.createId("oPGUHBox2"), {});
		Panel_PGU.addContent(oPGUHBox2);
		var oPGUHBox1 = new sap.m.HBox(this.createId("oPGUHBox1"), {
			alignContent: "Inherit",
			alignItems: "Start",
			backgroundDesign: "Solid"
		});
		oPGUHBox2.addItem(oPGUHBox1);
		var oPGUFileUploader = new sap.ui.unified.FileUploader(this.createId("oPGUFileUploader"), {
			uploadUrl: "/DV5/zui_dat_workbench_waves?ajax_id=&ajax_applid=ZUI_DAT_WORKBENCH_WAVES&sap-client=&field_id=01753&sapui5-upload",
			fileType: "csv",
			placeholder: "select .csv file",
			sameFilenameAllowed: true,
			style: "Emphasized",
			tooltip: "select .csv file",
			width: "23rem",
			change: function (oEvent) {
				gPGUploadFileName = oPGUFileUploader.getValue();
				if (gPGUploadFileName) {
					gPGUploadFile = oPGUFileUploader.oFileUpload.files[0];
					PGU_MessageStrip.setVisible(false);
				}
			}
		});
		oPGUHBox1.addItem(oPGUFileUploader);
		var oPGUUpload = new sap.m.Button(this.createId("oPGUUpload"), {
			text: "Upload",
			type: "Emphasized",
			press: function (oEvent) {
				// *-----------------------********************---------------------------*
				// * Date        Programmer      Ticket     Description     Correction    *
				// *-----------  ------------    --------   ------------    -----------   *
				// * 06/08/2022  C8852945SN      94170129                                 *
				// ************************************************************************
				//Check if Release POR switch is ON, if yes then display the warning popup
				if (Switch_Release_POR.getState()) {
					sap.m.MessageBox.warning("The POR quantity in the file will not be copied.", {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						emphasizedAction: sap.m.MessageBox.Action.OK,
						onClose: function (sAction) {
							if (sAction === 'OK') {
								debugger;
								PGU_MessageStrip.setVisible(false);
								if (oPGUFileUploader.getValue()) {
									if (oPGUFileUploader.getValue().split('.')[1] !== 'csv') {
										PGU_MessageStrip.setVisible(true);
										PGU_MessageStrip.setType('Error');
										PGU_MessageStrip.setText('Only .csv file allowed');
									} else {
										sap.ui.core.BusyIndicator.show(0);
										//createUploadPP('');
										createUploadPG('');
									}
								} else {
									PGU_MessageStrip.setVisible(true);
									PGU_MessageStrip.setType('Error');
									PGU_MessageStrip.setText('Please select a .csv file');
								}
							}
						}
					});
				} else {
					debugger;
					PGU_MessageStrip.setVisible(false);
					if (oPGUFileUploader.getValue()) {
						if (oPGUFileUploader.getValue().split('.')[1] !== 'csv') {
							PGU_MessageStrip.setVisible(true);
							PGU_MessageStrip.setType('Error');
							PGU_MessageStrip.setText('Only .csv file allowed');
						} else {
							sap.ui.core.BusyIndicator.show(0);
							//createUploadPP('');
							createUploadPG('');
						}
					} else {
						PGU_MessageStrip.setVisible(true);
						PGU_MessageStrip.setType('Error');
						PGU_MessageStrip.setText('Please select a .csv file');
					}
				}
			}
		});
		oPGUHBox1.addItem(oPGUUpload);
		var oPGUVBoxGap2 = new sap.m.VBox(this.createId("oPGUVBoxGap2"), {
			width: "2rem"
		});
		oPGUHBox2.addItem(oPGUVBoxGap2);
		var oLabelGap2 = new sap.m.Label(this.createId("oLabelGap2"), {
			width: "1rem"
		});
		oPGUVBoxGap2.addItem(oLabelGap2);
		var oPGUVBoxReleasePOR = new sap.m.VBox(this.createId("oPGUVBoxReleasePOR"), {});
		oPGUHBox2.addItem(oPGUVBoxReleasePOR);
		var Label_ReleasePOR = new sap.m.Label(this.createId("Label_ReleasePOR"), {
			text: "Release PLA POR"
		});
		oPGUVBoxReleasePOR.addItem(Label_ReleasePOR);
		var Switch_Release_POR = new sap.m.Switch(this.createId("Switch_Release_POR"), {
			change: function (oEvent) {
				//#94170129 -In PLA GATP UPLOAD  screen , if the release PLA POR is off ,
				//then consumption check button should be always on and vice versa.

				if (Switch_Release_POR.getState()) {
					Switch_Coms_status.setState(false);
				} else {
					Switch_Coms_status.setState(true);
				}
			}
		});
		oPGUVBoxReleasePOR.addItem(Switch_Release_POR);
		var PGUDW_Link = new sap.m.Link(this.createId("PGUDW_Link"), {
			text: "Download Template",
			press: function (oEvent) {
				var aColumns = [{
					name: "Channel"
				}, {
					name: "MPN"
				}, {
					name: "Plant"
				}, {
					name: "Sales org"
				}, {
					name: "Ship-to"
				}, {
					name: "Sold-to"
				}, {
					name: "POR Qty"
				}];
				var dataStr = "data:text/csv;charset=utf-8,";
				for (var i = 0; i < aColumns.length; i++) {
					dataStr += aColumns[i].name + ",";
				}
				dataStr = dataStr.substring(0, dataStr.length - 1);
				dataStr += "\r";
				var xDate = new Date();
				var fTime;
				var xHours = xDate.getHours();
				if (xHours.toString().length == 1)
					xHours = '0' + xHours.toString();
				var xMin = xDate.getMinutes();
				if (xMin.toString().length == 1)
					xMin = '0' + xMin.toString();
				var xSec = xDate.getSeconds();
				if (xSec.toString().length == 1)
					xSec = '0' + xSec.toString();
				var fTime = xHours.toString() + xMin.toString() + xSec.toString();
				var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;

				var encodedUri = encodeURI(dataStr);
				var aTag = document.createElement('a');
				aTag.setAttribute("href", encodedUri);
				aTag.setAttribute("download", 'PLA GATP template_' + tmDt + ".csv");
				aTag.innerHTML = "Click Here to download";
				aTag.click();
				aTag.remove();
				/*


				*/
			}
		});
		Panel_PGU.addContent(PGUDW_Link);
		var PGUError_Panel = new sap.m.Panel(this.createId("PGUError_Panel"), {
			visible: false
		});
		oDialogPLAGATP_UPD.addContent(PGUError_Panel);
		var PGUError_Table = new sap.m.Table(this.createId("PGUError_Table"), {});
		PGUError_Panel.addContent(PGUError_Table);
		var modelPGUError_Table = new sap.ui.model.json.JSONModel();
		PGUError_Table.setModel(modelPGUError_Table);
		var colPGUError_TableFileData = new sap.m.Column(this.createId("colPGUError_TableFileData"), {
			header: new sap.m.Label({
				text: "File Data"
			}),
			width: "60%"
		});
		PGUError_Table.addColumn(colPGUError_TableFileData);
		var colUBPPGUError_TableType = new sap.m.Column(this.createId("colUBPPGUError_TableType"), {
			header: new sap.m.Label({
				text: "Message Type"
			}),
			width: "10%"
		});
		PGUError_Table.addColumn(colUBPPGUError_TableType);
		var colPGUError_TableMessage = new sap.m.Column(this.createId("colPGUError_TableMessage"), {
			width: "30%",
			header: new sap.m.Label({
				text: "Message"
			})
		});
		PGUError_Table.addColumn(colPGUError_TableMessage);
		var colItemPGUError_Table = new sap.m.ColumnListItem(this.createId("colItemPGUError_Table"), {});
		PGUError_Table.bindAggregation("items", "/", colItemPGUError_Table);
		var txtPGUError_TableFileData = new sap.m.Text(this.createId("txtPGUError_TableFileData"), {
			text: "{FileData}"
		});
		colItemPGUError_Table.addCell(txtPGUError_TableFileData);
		var txtPGUError_TableType = new sap.m.Text(this.createId("txtPGUError_TableType"), {
			text: "{Type}"
		});
		colItemPGUError_Table.addCell(txtPGUError_TableType);
		var txtPGUError_TableMessage = new sap.m.Text(this.createId("txtPGUError_TableMessage"), {
			text: "{Message}"
		});
		var CWPage = new sap.m.Page(this.createId("CWPage"), {
			showFooter: false
		})
		oApp.addPage(CWPage);
		var CWPageCustomHdr_bar = new sap.m.Bar(this.createId("CWPageCustomHdr_bar"), {});
		CWPage.setCustomHeader(CWPageCustomHdr_bar);
		var CWHDRBack_Icon = new sap.ui.core.Icon(this.createId("CWHDRBack_Icon"), {
			color: "white",
			src: "sap-icon://navigation-left-arrow",
			width: "3.5rem",
			press: function (oEvent) {
				//AppCacheNav.back();

				oApp.to(WBPage);
			}
		});
		CWPageCustomHdr_bar.addContentLeft(CWHDRBack_Icon);
		var CWHDR_Text = new sap.m.Text(this.createId("CWHDR_Text"), {
			text: "Dynamic Allocation Tool"
		});
		CWPageCustomHdr_bar.addContentLeft(CWHDR_Text);
		var CWText1 = new sap.m.Text(this.createId("CWText1"), {
			text: "Workbench Strategy"
		});
		CWPageCustomHdr_bar.addContentMiddle(CWText1);
		var CWInfoH_Icon = new sap.ui.core.Icon(this.createId("CWInfoH_Icon"), {
			size: "1.5rem",
			src: "sap-icon://message-information",
			tooltip: "Click here to open help document",
			press: function (oEvent) {
				//var url = "https://sosdevelopment.apple.com/course/a7190480-cafe-11ea-a5a7-c1bf25875dc9";
				var aTag = document.createElement('a');
				aTag.setAttribute("href", gHelpLink);
				aTag.setAttribute("target", '_blank');
				aTag.innerHTML = "Click Here to open help document";
				aTag.click();
				aTag.remove();
			}
		});
		CWPageCustomHdr_bar.addContentRight(CWInfoH_Icon);
		var DWPage = new sap.m.Page(this.createId("DWPage"), {})
		oApp.addPage(DWPage);

		function _setDisplayData(dd) {
			CVC_Panel.setExpanded(false);
			Strg_Panel.setExpanded(true);
			Schd_Panel.setExpanded(true);
			/*
			    Wave Setup
			*/
			//Week
			oDispWeek_Text.setText(dd.FiscWeek);
			//Profile
			oDispProf_Text.setText(dd.Secprofile);
			//Desc
			oDispDesc_Text.setText(dd.WaveDesc);
			//Created On
			oDispCO_Text.setText(dd.CreatedOn);
			/*
			    Strategy
			*/
			StrategyImportData_HBox.setVisible(false);
			//Summary
			if (dd.CVCSelection == '') {
				SSCVC_Label.setText('');
				StrgSelVarInfoHdr_Text.setText('');
			} else {
				SSCVC_Label.setText(dd.CVCSelection);
				StrgSelVarInfoHdr_Text.setText('Variant Name: ' + dd.CVCSelection);
			}
			// Boc DV5K935147	 78974891
			if (dd.WaveSelection == '') {
				DMWaveStg_Label.setText('');
			} else {
				DMWaveStg_Label.setText(dd.WaveSelection.slice(2));
			}
			// Eoc DV5K935147	 78974891
			//_getWaveSetting(dd);
			_newGetWaveSetting(dd);

			NoOfWaves_Label.setVisible(true);
			NoOfWaves_Text.setVisible(true);
			BasePlan_Label.setVisible(true);
			BasePlan_Text.setVisible(true);
			//NoOfWaves_HBox.setVisible(false);
			//BasePlan_HBox.setVisible(false);
			IR_CheckBox.setVisible(false);
			//Wave - Cum
			WSWaveCum_VBox.setVisible(false);
			WSWaveCumBase_VBox.setVisible(false);
			SourcingPlant_VBox.setVisible(false);
			SalesOrg_VBox.setVisible(false);
			DWSoldTo_VBox.setVisible(false);
			PQ_VBox.setVisible(false);
			//Cap to
			CapTo_Label.setVisible(false);
			CapTo_Text.setVisible(false);
			CapTo_Text.setText(gDDMap.get(dd.CapTo));
			//No.of waves
			NoOfWaves_Label.setVisible(false);
			NoOfWaves_Text.setVisible(false);
			//Base Plan
			BasePlan_Label.setVisible(false);
			BasePlan_Text.setVisible(false);
			//Wave Strategy
			WaveStrategy_Text.setText(gDDMap.get(dd.WaveStrategy));
			if (dd.WaveStrategy == 'FAIRSHARE') {
				WaveStrategy_Text.setText(gDDMap.get(dd.WaveStrategy));
				//No.of Waves
				NoOfWaves_Label.setVisible(true);
				NoOfWaves_Text.setVisible(true);
				NoOfWaves_Text.setText(dd.NoOfWaves);
				//Cap To
				CapTo_Label.setVisible(true);
				CapTo_Text.setVisible(true);
				StrategyImportData_HBox.setVisible(false);
			} else if (dd.WaveStrategy == 'PERC_WEEKLY') {
				WSWaveCum_VBox.setVisible(true);
				setWaveCum(dd);
				//Cap To
				CapTo_Label.setVisible(true);
				CapTo_Text.setVisible(true);
				StrategyImportData_HBox.setVisible(true);
				NoOfWaves_Text.setText('N/A');
			} else if (dd.WaveStrategy == 'PERC_SHPPLAN') {
				WSWaveCumBase_VBox.setVisible(true);
				setWaveCumBasePlan(dd);
				//Cap To
				CapTo_Label.setVisible(true);
				CapTo_Text.setVisible(true);
				StrategyImportData_HBox.setVisible(true);
				NoOfWaves_Text.setText('N/A');
				//Begin of Changes - DV5K938119 - Added PLA to the condition
			} else if (dd.WaveStrategy == "USER_SPEC" || dd.WaveStrategy == "USER_SPEC_PLA") {
				//End of Changes - DV5K938119
				//Cap To
				CapTo_Label.setVisible(true);
				CapTo_Text.setVisible(true);
				//No.of waves
				NoOfWaves_Label.setVisible(true);
				NoOfWaves_Text.setVisible(true);
				NoOfWaves_Text.setText('N/A');

				//Base Plan
				BasePlan_Label.setVisible(true);
				BasePlan_Text.setVisible(true);
				BasePlan_Text.setText(dd.BasePlan);

				IR_CheckBox.setVisible(true);
				if (dd.IgnoreShipRoll == '') {
					IR_CheckBox.setSelected(false);
				} else {
					IR_CheckBox.setSelected(true);
				}

				//Sourcing Plant
				sourcingPlant(dd);
				SourcingPlant_VBox.setVisible(true);
				//Sales Org
				salesOrg(dd);
				SalesOrg_VBox.setVisible(true);
				//Sold to
				StrgSoldTo(dd);
				//Prod Qty
				pq(dd);
				PQ_VBox.setVisible(true);
				DWSoldTo_VBox.setVisible(true);
				StrategyImportData_HBox.setVisible(true);

				//Begin of changes - 90318902
				//Hide IR_CheckBox wen the line item is a PLA line item
				if (dd.WaveStrategy == "USER_SPEC_PLA") {
					IR_CheckBox.setVisible(false);
				} else {
					IR_CheckBox.setVisible(true);
				}

				//End of changes - 90318902

			} else if (dd.WaveStrategy == "MATCH_MAX") {
				//WaveStrategy_Text.setText("Match Max(GATP Alloc. Consump");
				StrategyImportData_HBox.setVisible(false);
				NoOfWaves_Text.setText('N/A');
			} else if (dd.WaveStrategy == "ADJ_CONS") {
				//WaveStrategy_Text.setText("Adjust to Consumption");
				StrategyImportData_HBox.setVisible(false);
				NoOfWaves_Text.setText('N/A');
			}

			/*
			        Schedule tab
			*/
			oSchFormRschat.setVisible(false);
			ReleaseTime_Text.setVisible(false);
			Days_VBox.setVisible(false);

			WaveCreate_Text.setText(gDDMap.get(dd.WaveCreate));
			if (dd.WaveCreate == 'SCHD') {
				oSchFormRschat.setVisible(true);
			}
			// var WaveSchMode = dd.WaveCreate;
			// if (WaveSchMode == 'IMME') {
			//     WaveCreate_Text.setText('Immediate');
			// } else if (WaveSchMode == 'SCHD') {
			//     WaveCreate_Text.setText('Scheduled');
			//     oSchFormRschat.setVisible(true);
			// } else if (WaveSchMode == 'TDM') {
			//     WaveCreate_Text.setText('TDM Job');
			// }
			//Schedule At
			var fText = 'Schedule At (' + dd.TimeZone + ')';
			ScheduleAt_Label.setText(fText);
			if (dd.ScheduleAt == '0000-00-00-00-00-00' || dd.ScheduleAt == '') {
				ScheduleAt_Text.setText('');
				//Begin of Insert DV5K934693
				// 75583227 - Display Multi Start Time  on Wave Summary and workbench
				AddTime_Label.setVisible(false);
				MulSch_Table.setVisible(false);
				//End of Insert DV5K934693
			} else {
				ScheduleAt_Text.setText(dd.ScheduleAt);
				//Begin of Insert DV5K934693
				// 75583227 - Display Multi Start Time  on Wave Summary and workbench
				AddTime_Label.setVisible(false);
				MulSch_Table.setVisible(false);
				setWaveMulSch(dd);
				//End of Insert DV5K934693
			}
			//Repeats
			Repeats_Text.setText(dd.Repeat);
			if (Repeats_Text.getText() == 'WEEK') {
				Days_VBox.setVisible(true);
			}
			//Till Date
			var fText = ' Till (' + dd.TimeZone + ')';
			Till_Label.setText(fText);
			if (dd.ScheduleTill == '0000-00-00-00-00-00' || dd.ScheduleTill == '') {
				TillDate_Text.setText('');
			} else {
				TillDate_Text.setText(dd.ScheduleTill);
			}
			//Every
			Every_Text.setText(dd.Every);

			//Days
			var aDays = dd.NAVWaveWeekDay.results;
			W_1S.setPressed(false);
			W_2M.setPressed(false);
			W_3T.setPressed(false);
			W_4W.setPressed(false);
			W_5T.setPressed(false);
			W_6F.setPressed(false);
			W_7S.setPressed(false);
			for (var i = 0; i < aDays.length; i++) {
				var ds = aDays[i];
				if (ds.Days == 1)
					W_2M.setPressed(true);
				if (ds.Days == 2)
					W_3T.setPressed(true);
				if (ds.Days == 3)
					W_4W.setPressed(true);
				if (ds.Days == 4)
					W_5T.setPressed(true);
				if (ds.Days == 5)
					W_6F.setPressed(true);
				if (ds.Days == 6)
					W_7S.setPressed(true);
				if (ds.Days == 7)
					W_1S.setPressed(true);
			}
			//Release Type
			ReleaseType_Text.setText(gDDMap.get(dd.ReleaseType));
			if (dd.ReleaseType == 'T') {
				ReleaseTime_Text.setVisible(true);
			}
			// var WaveRelMech = dd.ReleaseType;
			// if (WaveRelMech == 'D') {
			//     ReleaseType_Text.setText('Dependency Release');
			// } else if (WaveRelMech == 'T') {
			//     ReleaseType_Text.setText('Time Release');
			//     ReleaseTime_Text.setVisible(true);
			// } else if (WaveRelMech == 'M') {
			//     ReleaseType_Text.setText('Manual Release');
			// }
			//Release Time
			var fText = 'Release Time (' + dd.TimeZone + ')';
			ReleaseTime_Label.setText(fText);
			if (dd.ReleaseDatetime == '0000-00-00-00-00-00' || dd.ReleaseDatetime == '') {
				ReleaseTime_Text.setText('');
			} else {
				ReleaseTime_Text.setText(dd.ReleaseDatetime);
			}
			//Move to page
			oApp.to(DWPage);
		}

		function setWaveCum(dd) {
			var waveCum = [];
			var waveCumMRef = new sap.ui.model.json.JSONModel();
			waveCumMRef.setSizeLimit(10000);
			waveCumMRef.setData(waveCum);
			//Wave - %Cum
			if (dd.NAVWaveCumPer.results != undefined && dd.NAVWaveCumPer.results.length > 0) {
				for (var i = 0; i < dd.NAVWaveCumPer.results.length; i++) {
					var wc = dd.NAVWaveCumPer.results[i];
					var xd = {
						Wave: wc.Wave,
						Cum: wc.Cum
					}
					waveCum.push(xd);
				}
				waveCumMRef.setData(waveCum);
			}
			WaveCum_Table.setModel(waveCumMRef);
			WaveCum_Table.getModel().refresh();
		}

		function setWaveCumBasePlan(dd) {
			var waveCumBase = [];
			var waveCumBaseMRef = new sap.ui.model.json.JSONModel();
			waveCumBaseMRef.setSizeLimit(10000);
			waveCumBaseMRef.setData(waveCumBase);
			//Wave - %Cum
			if (dd.NAVWaveCumBase.results != undefined && dd.NAVWaveCumBase.results.length > 0) {
				for (var i = 0; i < dd.NAVWaveCumBase.results.length; i++) {
					var wc = dd.NAVWaveCumBase.results[i];
					var xd = {
						Wave: wc.Wave,
						Cum: wc.Cum,
						BasePlan: wc.BasePlan
					}
					waveCumBase.push(xd);
				}
				waveCumBaseMRef.setData(waveCumBase);
			}
			WaveCumBase_Table.setModel(waveCumBaseMRef);
			WaveCumBase_Table.getModel().refresh();
		}

		function pq(dd) {
			var pqLocal = [];
			var colType = '';
			var pqMRef = new sap.ui.model.json.JSONModel();
			pqMRef.setSizeLimit(10000);
			pqMRef.setData(pqLocal);
			if (dd.NAVWaveProdQty.results != undefined && dd.NAVWaveProdQty.results.length > 0) {
				colType = dd.NAVWaveProdQty.results[0].Type;
				for (var i = 0; i < dd.NAVWaveProdQty.results.length; i++) {
					var pq = dd.NAVWaveProdQty.results[i];
					var xd = {
						Value: pq.Value,
						Qty: pq.Qty
					}
					pqLocal.push(xd);
				}
				if (colType == 'MPN')
					PQID_Column.setLabel('Product');
				else
					PQID_Column.setLabel('Sold To');
				PQHdr_Label.setText('Additional Information : ' + colType);
				pqMRef.setData(pqLocal);
			}
			PQ_Table.setModel(pqMRef);
			PQ_Table.getModel().refresh();

		}
		/*
		    Sourcing Plant

		*/

		function sourcingPlant(dd) {
			var spLocal = [];
			var spMRef = new sap.ui.model.json.JSONModel();
			spMRef.setSizeLimit(10000);
			spMRef.setData(spLocal);
			if (dd.NAVWaveSourcPlant.results != undefined && dd.NAVWaveSourcPlant.results.length > 0) {
				for (var i = 0; i < dd.NAVWaveSourcPlant.results.length; i++) {
					var sp = dd.NAVWaveSourcPlant.results[i];
					var xd = {
						Plant: sp.Plant,
						PlantDesc: sp.PlantDesc
					}
					spLocal.push(xd);
				}
				spMRef.setData(spLocal);
			}
			SourcingPlant_Table.setModel(spMRef);
			SourcingPlant_Table.getModel().refresh();
		}

		function salesOrg(dd) {
			var soLocal = [];
			var soMRef = new sap.ui.model.json.JSONModel();
			soMRef.setSizeLimit(10000);
			soMRef.setData(soLocal);
			if (dd.NAVWaveSratSales.results != undefined && dd.NAVWaveSratSales.results.length > 0) {
				for (var i = 0; i < dd.NAVWaveSratSales.results.length; i++) {
					var so = dd.NAVWaveSratSales.results[i];
					var xd = {
						SalesOrg: so.SalesOrg
					}
					soLocal.push(xd);
				}
				soMRef.setData(soLocal);
			}
			SalesOrg_Table.setModel(soMRef);
			SalesOrg_Table.getModel().refresh();
		}

		function StrgSoldTo(dd) {
			/*
			    Below code is set the criteria tab for MPN & Sold To
			    Also set the other tables
			*/
			var stLocal = [];
			var stMRef = new sap.ui.model.json.JSONModel();
			stMRef.setSizeLimit(10000);
			stMRef.setData(stLocal);
			if (dd.NAVWaveSratSold.results != undefined && dd.NAVWaveSratSold.results.length > 0) {
				for (var i = 0; i < dd.NAVWaveSratSold.results.length; i++) {
					var st = dd.NAVWaveSratSold.results[i];
					if (st.Option == 'EQ')
						var option = 'Equal';
					if (st.Option == 'CP')
						var option = 'Contains';
					var xd = {
						Low: st.Low,
						Option: option,
						Txtsh: st.Txtsh
					}
					stLocal.push(xd);
				}
				stMRef.setData(stLocal);
			}
			StrgSoldTo_Table.setModel(stMRef);
			StrgSoldTo_Table.getModel().refresh();
			// StrgSoldToM_Table.setModel(stMRef);
			// StrgSoldToM_Table.getModel().refresh();
		}

		function _getWaveSetting(dd) {
			var aOpsSubClass = [];
			var aSalesOrg = [];
			var aDC = [];
			var aMPN = [];
			var aSoldTo = [];
			var cvcList = dd.NAVWaveCVCList.results;
			$.each(cvcList, function (i, data) {
				switch (data.Selname) {
				case "OPS_SUBCLASS":
					aOpsSubClass.push(data);
					break;
				case "VKORG":
					aSalesOrg.push(data);
					break;
				case "ZDISTC":
					aDC.push(data);
					break;
				case "RULE_MATNR":
					aMPN.push(data);
					break;
				case "RULE_MATNRA":
					aMPN.push(data);
					break;
				case "KUNNR": //basic
					aSoldTo.push(data);
					break;
				case "KUNNR_A": //Advance
					aSoldTo.push(data);
					break;
				default:
					break;
				}
			});
			//OPS Subclass
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData(aOpsSubClass);
			OPSSubclass_Table.setModel(jModel);
			OPSSubclass_Table.getModel().refresh();
			//MPN
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData(aMPN);
			MPNCriteria_Table.setModel(jModel);
			MPNCriteria_Table.getModel().refresh();
			//Sales Org
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData(aSalesOrg);
			SalesOrgCVC_Table.setModel(jModel);
			SalesOrgCVC_Table.getModel().refresh();
			//Dist Channel
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData(aDC);
			DistC_Table.setModel(jModel);
			DistC_Table.getModel().refresh();
			//Sold To
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setSizeLimit(10000);
			jModel.setData(aSoldTo);
			SoldToCVC_Table.setModel(jModel);
			SoldToCVC_Table.getModel().refresh();

			/*
			    Below Odata is to actually get the data based on criteria
			*/
			var aCVCData = [];
			//OPSSubclass
			for (var i = 0; i < aOpsSubClass.length; i++) {
				var xd = aOpsSubClass[i];
				aCVCData.push(xd);
			}
			//MPN
			for (var i = 0; i < aMPN.length; i++) {
				var xd = aMPN[i];
				aCVCData.push(xd);
			}
			//aSalesOrg
			for (var i = 0; i < aSalesOrg.length; i++) {
				var xd = aSalesOrg[i];
				aCVCData.push(xd);
			}
			//DC
			for (var i = 0; i < aDC.length; i++) {
				var xd = aDC[i];
				aCVCData.push(xd);
			}
			//Sold To
			for (var i = 0; i < aSoldTo.length; i++) {
				var xd = aSoldTo[i];
				aCVCData.push(xd);
			}
			var xData = {
				Secprofile: gSelTblProfile,
				FiscWeek: gSelTblWeek,
				Region: gSelTblRegion,
				CVCVariant: dd.CVCSelection,
				WaveNr: '',
				NAVWaveSPluids: [],
				NAVWaveSCVC: aCVCData,
				NAVWaveSSAELS: [],
				NAVWaveSOPS: [],
				NAVWaveSMPN: [],
				NAVWaveSSoldTo: [],
				NAVWaveSChannel: []
			};
			var rData = []
			var xPromise = $.Deferred();
			gWaveModel.create('/WaveSettingSet', xData, {
				success: function (oData, resp) {
					xPromise.resolve();
					rData = oData;
				},
				error: function (oError) {
					sap.m.MessageToast.show('Error');
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {
				//MPN
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSMPN.results != undefined) {
					jModel.setData(rData.NAVWaveSMPN.results);
					MPNResults_Table.setModel(jModel);
					MPNResults_Table.getModel().refresh();
					//MPNCount_Label.setText("MPN's - (" + rData.NAVWaveSMPN.results.length + ")");
				} else {
					//MPNCount_Label.setText("MPN's - (0)");
					MPNResults_Table.setModel(jModel);
					MPNResults_Table.getModel().refresh();
				}
				//Sold to
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSSoldTo.results != undefined) {
					jModel.setData(rData.NAVWaveSSoldTo.results);
					SoldToCVCResults_Table.setModel(jModel);
					SoldToCVCResults_Table.getModel().refresh();
					//SoldToCount_Label.setText("Sold-To's - (" + rData.NAVWaveSSoldTo.results.length + ")");
				} else {
					SoldToCVCResults_Table.setModel(jModel);
					SoldToCVCResults_Table.getModel().refresh();
					//SoldToCount_Label.setText("Sold-To's - (0)");
				}
			}));
		}

		function _newGetWaveSetting(dd) {
			gDispVariant = [];
			var cvcList = dd.NAVWaveCVCList.results;
			gDispVariant = cvcList;
			for (var i = 0; i < cvcList.length; i++) {
				var cvc = cvcList[i];
				if (cvc.Selname == 'OPS_SUBCLASS') {
					cvc.Txtsh = 'OPS Subclass'
				}
				if (cvc.Selname == 'VKORG') {
					cvc.Txtsh = 'Sales Org'
				}
				if (cvc.Selname == 'ZDISTC') {
					cvc.Txtsh = 'Channel'
				}
				if (cvc.Selname == 'RULE_MATNR' || cvc.Selname == 'RULE_MATNRA') {
					cvc.Txtsh = 'MPN'
				}
				if (cvc.Selname == 'KUNNR' || cvc.Selname == 'KUNNR_A') {
					cvc.Txtsh = 'Sold To'
				}

			}
			var xData = {
				Secprofile: gSelTblProfile,
				FiscWeek: gSelTblWeek,
				Region: gSelTblRegion,
				CVCVariant: dd.CVCSelection,
				WaveNr: '',
				NAVWaveSPluids: [],
				NAVWaveSCVC: cvcList,
				NAVWaveSSAELS: [],
				NAVWaveSOPS: [],
				NAVWaveSMPN: [],
				NAVWaveSSoldTo: [],
				NAVWaveSChannel: []
			};
			var rData = []
			var xPromise = $.Deferred();
			gWaveModel.create('/WaveSettingSet', xData, {
				success: function (oData, resp) {
					xPromise.resolve();
					rData = oData;
				},
				error: function (oError) {
					sap.m.MessageToast.show('Error');
					sap.ui.core.BusyIndicator.hide();
				}
			});
			Promise.all(
				[
					xPromise
				]
			).then($.proxy(function () {
				//OPS Subclass
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSOPS.results == undefined) {
					OPSSubclass_Table.setModel(jModel);
					OPSSubclass_Table.getModel().refresh();
				} else {
					jModel.setData(rData.NAVWaveSOPS.results);
					OPSSubclass_Table.setModel(jModel);
					OPSSubclass_Table.getModel().refresh();
				}
				//MPN
				MPNHdr_Label.setText('MPN');
				MPNCVC_SearchField.setVisible(false);
				MPNSR_Icon.setSrc('sap-icon://search');
				MPNCVC_SearchField.setValue('');
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSMPN.results == undefined) {
					MPNResults_Table.setModel(jModel);
					MPNResults_Table.getModel().refresh();
				} else {
					jModel.setData(rData.NAVWaveSMPN.results);
					MPNHdr_Label.setText("MPN (" + rData.NAVWaveSMPN.results.length + ")");
					MPNResults_Table.setModel(jModel);
					MPNResults_Table.getModel().refresh();
				}
				//Sales Org
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSSAELS.results == undefined) {
					SalesOrgCVC_Table.setModel(jModel);
					SalesOrgCVC_Table.getModel().refresh();
				} else {
					jModel.setData(rData.NAVWaveSSAELS.results);
					SalesOrgCVC_Table.setModel(jModel);
					SalesOrgCVC_Table.getModel().refresh();
				}
				//Dist Channel
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSChannel.results == undefined) {
					DistC_Table.setModel(jModel);
					DistC_Table.getModel().refresh();
				} else {
					jModel.setData(rData.NAVWaveSChannel.results);
					DistC_Table.setModel(jModel);
					DistC_Table.getModel().refresh();
				}
				//Sold to
				STHdr_Label.setText('Sold To');
				STHdr_SearchField.setVisible(false);
				STHdr_SearchField.setValue('');
				STHdr_Icon.setSrc('sap-icon://search');
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData([]);
				if (rData.NAVWaveSSoldTo.results == undefined) {
					SoldToCVCResults_Table.setModel(jModel);
					SoldToCVCResults_Table.getModel().refresh();
				} else {
					jModel.setData(rData.NAVWaveSSoldTo.results);
					STHdr_Label.setText('Sold To (' + rData.NAVWaveSSoldTo.results.length + ')');
					SoldToCVCResults_Table.setModel(jModel);
					SoldToCVCResults_Table.getModel().refresh();

				}
				sap.ui.core.BusyIndicator.hide();
			}));

		}

		function setWaveMulSch(dd) {

			var waveMulSch = [];
			var waveMulSchRef = new sap.ui.model.json.JSONModel();
			waveMulSchRef.setSizeLimit(10000);
			waveMulSchRef.setData(waveMulSch);
			//Wave - Multi Schedule
			if (dd.NAVWaveMulsch.results != undefined && dd.NAVWaveMulsch.results.length > 0) {
				AddTime_Label.setVisible(true);
				MulSch_Table.setVisible(true);
				for (var i = 0; i < dd.NAVWaveMulsch.results.length; i++) {
					var wc = dd.NAVWaveMulsch.results[i];
					var xd = {
						ScheduleAtn: wc.ScheduleAtn + " " + dd.TimeZone

					};
					waveMulSch.push(xd);
				}
				waveMulSchRef.setData(waveMulSch);
			}
			MulSch_Table.setModel(waveMulSchRef);
			MulSch_Table.getModel().refresh();
		}
		/*

		*/
		var DWPageCustomHdr_bar = new sap.m.Bar(this.createId("DWPageCustomHdr_bar"), {});
		DWPage.setCustomHeader(DWPageCustomHdr_bar);
		var DWBack_Icon = new sap.ui.core.Icon(this.createId("DWBack_Icon"), {
			color: "white",
			src: "sap-icon://navigation-left-arrow",
			width: "3.5rem",
			press: function (oEvent) {
				oApp.to(WBPage);
			}
		});
		DWPageCustomHdr_bar.addContentLeft(DWBack_Icon);
		var DWHDR_Text = new sap.m.Text(this.createId("DWHDR_Text"), {
			text: "Dynamic Allocation Tool"
		});
		DWPageCustomHdr_bar.addContentLeft(DWHDR_Text);
		var DWText1 = new sap.m.Text(this.createId("DWText1"), {
			text: "Wave Schedule Summary"
		});
		DWPageCustomHdr_bar.addContentMiddle(DWText1);
		var DWInfoH_Icon = new sap.ui.core.Icon(this.createId("DWInfoH_Icon"), {
			size: "1.5rem",
			src: "sap-icon://message-information",
			tooltip: "Click here to open help document",
			press: function (oEvent) {
				//var url = "https://sosdevelopment.apple.com/course/a7190480-cafe-11ea-a5a7-c1bf25875dc9";
				var aTag = document.createElement('a');
				aTag.setAttribute("href", gHelpLink);
				aTag.setAttribute("target", '_blank');
				aTag.innerHTML = "Click Here to open help document";
				aTag.click();
				aTag.remove();
			}
		});
		DWPageCustomHdr_bar.addContentRight(DWInfoH_Icon);
		var DWVBox = new sap.m.VBox(this.createId("DWVBox"), {
			height: "100%",
			width: "100%"
		});
		DWPage.addContent(DWVBox);
		var WaveSetup_Panel = new sap.m.Panel(this.createId("WaveSetup_Panel"), {});
		DWVBox.addItem(WaveSetup_Panel);
		var oDispSFormProfile = new sap.ui.layout.form.SimpleForm(this.createId("oDispSFormProfile"), {
			adjustLabelSpan: false,
			columnsL: 4,
			columnsM: 4,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 4,
			title: "Wave Setup",
			width: "100%"
		});
		WaveSetup_Panel.addContent(oDispSFormProfile);
		var oDispWeek_Title = new sap.ui.core.Title(this.createId("oDispWeek_Title"), {});
		oDispSFormProfile.addContent(oDispWeek_Title);
		var oDispWeek_Label = new sap.m.Label(this.createId("oDispWeek_Label"), {
			text: "Week"
		});
		oDispSFormProfile.addContent(oDispWeek_Label);
		var oDispWeek_Text = new sap.m.Text(this.createId("oDispWeek_Text"), {});
		oDispSFormProfile.addContent(oDispWeek_Text);
		var oDispProf_Title = new sap.ui.core.Title(this.createId("oDispProf_Title"), {});
		oDispSFormProfile.addContent(oDispProf_Title);
		var oDispProf_Label = new sap.m.Label(this.createId("oDispProf_Label"), {
			text: "Wave Profile"
		});
		oDispSFormProfile.addContent(oDispProf_Label);
		var oDispProf_Text = new sap.m.Text(this.createId("oDispProf_Text"), {});
		oDispSFormProfile.addContent(oDispProf_Text);
		var oDispDesc_Title = new sap.ui.core.Title(this.createId("oDispDesc_Title"), {});
		oDispSFormProfile.addContent(oDispDesc_Title);
		var oDispDesc_Label = new sap.m.Label(this.createId("oDispDesc_Label"), {
			text: "Description"
		});
		oDispSFormProfile.addContent(oDispDesc_Label);
		var oDispDesc_Text = new sap.m.Text(this.createId("oDispDesc_Text"), {});
		oDispSFormProfile.addContent(oDispDesc_Text);
		var oDispCO_Title = new sap.ui.core.Title(this.createId("oDispCO_Title"), {});
		oDispSFormProfile.addContent(oDispCO_Title);
		var oDispCO_Label = new sap.m.Label(this.createId("oDispCO_Label"), {
			text: "Created On"
		});
		oDispSFormProfile.addContent(oDispCO_Label);
		var oDispCO_Text = new sap.m.Text(this.createId("oDispCO_Text"), {});
		oDispSFormProfile.addContent(oDispCO_Text);
		var CVC_Panel = new sap.m.Panel(this.createId("CVC_Panel"), {
			expandable: true
		});
		DWVBox.addItem(CVC_Panel);
		var SS_Toolbar = new sap.m.Toolbar(this.createId("SS_Toolbar"), {
			width: "100%"
		});
		CVC_Panel.setHeaderToolbar(SS_Toolbar);
		var SSHdr_Label = new sap.m.Label(this.createId("SSHdr_Label"), {
			text: "CVC Selection",
			design: "Bold"
		});
		SS_Toolbar.addContent(SSHdr_Label);
		var Variant_Icon = new sap.ui.core.Icon(this.createId("Variant_Icon"), {
			src: "sap-icon://fa-solid/info-circle",
			width: "8px",
			press: function (oEvent) {
				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setSizeLimit(10000);
				jModel.setData(gDispVariant);
				StrgSelVarInfo_Table.setModel(jModel);
				StrgSelVarInfo_Table.getModel().refresh();
				var vGroup = function (oContext) {
					var name = oContext.getProperty("Txtsh");
					return {
						key: name,
						text: name
					};
				};
				var oBinding = StrgSelVarInfo_Table.getBinding("items"),
					sPath,
					bDescending = false,
					vGroup,
					aGroups = [];
				aGroups.push(new sap.ui.model.Sorter('Txtsh', bDescending, vGroup));
				oBinding.sort(aGroups);
				StrgSelVarInfo_Popover.openBy(oEvent.getSource());
			}
		});
		SS_Toolbar.addContent(Variant_Icon);
		var SSCVC_Label = new sap.m.Label(this.createId("SSCVC_Label"), {});
		SS_Toolbar.addContent(SSCVC_Label);
		var ToolbarSpacer1 = new sap.m.ToolbarSpacer(this.createId("ToolbarSpacer1"), {});
		SS_Toolbar.addContent(ToolbarSpacer1);
		var CVC_HBox = new sap.m.HBox(this.createId("CVC_HBox"), {});
		CVC_Panel.addContent(CVC_HBox);
		var OPSSubclass_VBox = new sap.m.VBox(this.createId("OPSSubclass_VBox"), {
			height: "18rem",
			width: "15%"
		});
		CVC_HBox.addItem(OPSSubclass_VBox);
		var OPSSubclass_Toolbar = new sap.m.Toolbar(this.createId("OPSSubclass_Toolbar"), {});
		OPSSubclass_VBox.addItem(OPSSubclass_Toolbar);
		var OPSSubclass_Label = new sap.m.Label(this.createId("OPSSubclass_Label"), {
			text: "OPS subclass"
		});
		OPSSubclass_Toolbar.addContent(OPSSubclass_Label);
		var OPSSubclass_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("OPSSubclass_ToolbarSpacer"), {});
		OPSSubclass_Toolbar.addContent(OPSSubclass_ToolbarSpacer);
		var OPSSubclass_Table = new sap.ui.table.Table(this.createId("OPSSubclass_Table"), {
			selectionMode: "None",
			visibleRowCount: 5
		});
		OPSSubclass_VBox.addItem(OPSSubclass_Table);
		var modelOPSSubclass_Table = new sap.ui.model.json.JSONModel();
		OPSSubclass_Table.setModel(modelOPSSubclass_Table);
		OPSSubclass_Table.bindRows("/");
		var OPSSubclassID_Column = new sap.ui.table.Column(this.createId("OPSSubclassID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false
		});
		OPSSubclass_Table.addColumn(OPSSubclassID_Column);
		var OPSSubclassID_Text = new sap.m.Text(this.createId("OPSSubclassID_Text"), {
			text: "{Low}"
		});
		OPSSubclassID_Column.setTemplate(OPSSubclassID_Text);
		var MPN_VBox = new sap.m.VBox(this.createId("MPN_VBox"), {
			height: "18rem",
			width: "28%"
		});
		CVC_HBox.addItem(MPN_VBox);
		var MPNHdr_Toolbar = new sap.m.Toolbar(this.createId("MPNHdr_Toolbar"), {});
		MPN_VBox.addItem(MPNHdr_Toolbar);
		var MPNHdr_Label = new sap.m.Label(this.createId("MPNHdr_Label"), {
			text: "MPN",
			width: "7rem"
		});
		MPNHdr_Toolbar.addContent(MPNHdr_Label);
		var MPNCVC_SearchField = new sap.m.SearchField(this.createId("MPNCVC_SearchField"), {
			showSearchButton: false,
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = MPNResults_Table.getBinding("rows");
				var aFilters = [];
				var orFilter = new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Low", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("Txtsh", sap.ui.model.FilterOperator.Contains, usrtxt)

					], false);
				aFilters.push(orFilter);
				oBinding.filter(aFilters);
			}
		});
		MPNHdr_Toolbar.addContent(MPNCVC_SearchField);
		var MPN_ToolbarSpacer3 = new sap.m.ToolbarSpacer(this.createId("MPN_ToolbarSpacer3"), {});
		MPNHdr_Toolbar.addContent(MPN_ToolbarSpacer3);
		var MPNSR_Icon = new sap.ui.core.Icon(this.createId("MPNSR_Icon"), {
			press: function (oEvent) {
				if (MPNSR_Icon.getSrc() == 'sap-icon://search') {
					MPNSR_Icon.setSrc('sap-icon://decline');
					MPNCVC_SearchField.setVisible(true);
				} else {
					MPNSR_Icon.setSrc('sap-icon://search');
					MPNCVC_SearchField.setVisible(false);
					var oBinding = MPNResults_Table.getBinding("rows");
					var aFilters = [];
					oBinding.filter(aFilters);
				}
			}
		});
		MPNHdr_Toolbar.addContent(MPNSR_Icon);
		var MPNResults_Table = new sap.ui.table.Table(this.createId("MPNResults_Table"), {
			visibleRowCount: 5,
			selectionMode: "None"
		});
		MPN_VBox.addItem(MPNResults_Table);
		var modelMPNResults_Table = new sap.ui.model.json.JSONModel();
		MPNResults_Table.setModel(modelMPNResults_Table);
		MPNResults_Table.bindRows("/");
		var MPNR_Column = new sap.ui.table.Column(this.createId("MPNR_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false,
			width: "7rem"
		});
		MPNResults_Table.addColumn(MPNR_Column);
		var MPNRID_Text = new sap.m.Text(this.createId("MPNRID_Text"), {
			text: "{Low}"
		});
		MPNR_Column.setTemplate(MPNRID_Text);
		var MPNRDesc1_Column = new sap.ui.table.Column(this.createId("MPNRDesc1_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		MPNResults_Table.addColumn(MPNRDesc1_Column);
		var MPNRDesc_Text = new sap.m.Text(this.createId("MPNRDesc_Text"), {
			text: "{Txtsh}"
		});
		MPNRDesc1_Column.setTemplate(MPNRDesc_Text);
		var SalesOrgCVC_VBox = new sap.m.VBox(this.createId("SalesOrgCVC_VBox"), {
			height: "18rem",
			width: "25%"
		});
		CVC_HBox.addItem(SalesOrgCVC_VBox);
		var SalesOrgCVC_Toolbar = new sap.m.Toolbar(this.createId("SalesOrgCVC_Toolbar"), {});
		SalesOrgCVC_VBox.addItem(SalesOrgCVC_Toolbar);
		var SalesOrgCVC_Label = new sap.m.Label(this.createId("SalesOrgCVC_Label"), {
			text: "Sales Org"
		});
		SalesOrgCVC_Toolbar.addContent(SalesOrgCVC_Label);
		var SalesOrgCVC_Table = new sap.ui.table.Table(this.createId("SalesOrgCVC_Table"), {
			selectionMode: "None",
			visibleRowCount: 5
		});
		SalesOrgCVC_VBox.addItem(SalesOrgCVC_Table);
		var modelSalesOrgCVC_Table = new sap.ui.model.json.JSONModel();
		SalesOrgCVC_Table.setModel(modelSalesOrgCVC_Table);
		SalesOrgCVC_Table.bindRows("/");
		var SalesOrgCVCID_Column = new sap.ui.table.Column(this.createId("SalesOrgCVCID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false,
			width: "auto"
		});
		SalesOrgCVC_Table.addColumn(SalesOrgCVCID_Column);
		var SalesOrgCVCID_Text = new sap.m.Text(this.createId("SalesOrgCVCID_Text"), {
			text: "{Low}"
		});
		SalesOrgCVCID_Column.setTemplate(SalesOrgCVCID_Text);
		var SalesOrgCVCDesc_Column = new sap.ui.table.Column(this.createId("SalesOrgCVCDesc_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		SalesOrgCVC_Table.addColumn(SalesOrgCVCDesc_Column);
		var SalesOrgCVCDesc_Text = new sap.m.Text(this.createId("SalesOrgCVCDesc_Text"), {
			text: "{Txtsh}"
		});
		SalesOrgCVCDesc_Column.setTemplate(SalesOrgCVCDesc_Text);
		var DistC_VBox = new sap.m.VBox(this.createId("DistC_VBox"), {
			height: "18rem",
			width: "15%"
		});
		CVC_HBox.addItem(DistC_VBox);
		var DistC_Toolbar = new sap.m.Toolbar(this.createId("DistC_Toolbar"), {});
		DistC_VBox.addItem(DistC_Toolbar);
		var DistC_Label = new sap.m.Label(this.createId("DistC_Label"), {
			text: "Dist Channel"
		});
		DistC_Toolbar.addContent(DistC_Label);
		var DistC_Table = new sap.ui.table.Table(this.createId("DistC_Table"), {
			selectionMode: "None",
			visibleRowCount: 5
		});
		DistC_VBox.addItem(DistC_Table);
		var modelDistC_Table = new sap.ui.model.json.JSONModel();
		DistC_Table.setModel(modelDistC_Table);
		DistC_Table.bindRows("/");
		var DistCID_Column = new sap.ui.table.Column(this.createId("DistCID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false,
			width: "auto"
		});
		DistC_Table.addColumn(DistCID_Column);
		var DistCID_Text = new sap.m.Text(this.createId("DistCID_Text"), {
			text: "{Low}"
		});
		DistCID_Column.setTemplate(DistCID_Text);
		var DistCDesc_Column = new sap.ui.table.Column(this.createId("DistCDesc_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		DistC_Table.addColumn(DistCDesc_Column);
		var DistCDesc_Text = new sap.m.Text(this.createId("DistCDesc_Text"), {
			text: "{Txtsh}"
		});
		DistCDesc_Column.setTemplate(DistCDesc_Text);
		var SoldToCVC_VBox = new sap.m.VBox(this.createId("SoldToCVC_VBox"), {
			height: "18rem",
			width: "28%"
		});
		CVC_HBox.addItem(SoldToCVC_VBox);
		var STHdr_Toolbar = new sap.m.Toolbar(this.createId("STHdr_Toolbar"), {});
		SoldToCVC_VBox.addItem(STHdr_Toolbar);
		var STHdr_Label = new sap.m.Label(this.createId("STHdr_Label"), {
			text: "Sold To",
			width: "7rem"
		});
		STHdr_Toolbar.addContent(STHdr_Label);
		var STHdr_SearchField = new sap.m.SearchField(this.createId("STHdr_SearchField"), {
			showSearchButton: false,
			liveChange: function (oEvent) {
				var usrtxt = oEvent.getParameter("newValue");
				var oBinding = SoldToCVCResults_Table.getBinding("rows");
				var aFilters = [];
				var orFilter = new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Low", sap.ui.model.FilterOperator.Contains, usrtxt),
						new sap.ui.model.Filter("Txtsh", sap.ui.model.FilterOperator.Contains, usrtxt)

					], false);
				aFilters.push(orFilter);
				oBinding.filter(aFilters);
			}
		});
		STHdr_Toolbar.addContent(STHdr_SearchField);
		var STHdr_ToolbarSpacer3 = new sap.m.ToolbarSpacer(this.createId("STHdr_ToolbarSpacer3"), {});
		STHdr_Toolbar.addContent(STHdr_ToolbarSpacer3);
		var STHdr_Icon = new sap.ui.core.Icon(this.createId("STHdr_Icon"), {
			press: function (oEvent) {
				if (STHdr_Icon.getSrc() == 'sap-icon://search') {
					STHdr_Icon.setSrc('sap-icon://decline');
					STHdr_SearchField.setVisible(true);
				} else {
					STHdr_Icon.setSrc('sap-icon://search');
					STHdr_SearchField.setVisible(false);
					var oBinding = SoldToCVCResults_Table.getBinding("rows");
					var aFilters = [];
					oBinding.filter(aFilters);
				}
			}
		});
		STHdr_Toolbar.addContent(STHdr_Icon);
		var SoldToCVCResults_Table = new sap.ui.table.Table(this.createId("SoldToCVCResults_Table"), {
			selectionMode: "None",
			visibleRowCount: 5
		});
		SoldToCVC_VBox.addItem(SoldToCVCResults_Table);
		var modelSoldToCVCResults_Table = new sap.ui.model.json.JSONModel();
		SoldToCVCResults_Table.setModel(modelSoldToCVCResults_Table);
		SoldToCVCResults_Table.bindRows("/");
		var SoldToRCVC_Column = new sap.ui.table.Column(this.createId("SoldToRCVC_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			width: "7rem",
			resizable: false
		});
		SoldToCVCResults_Table.addColumn(SoldToRCVC_Column);
		var SoldToRCVCID_Text = new sap.m.Text(this.createId("SoldToRCVCID_Text"), {
			text: "{Low}"
		});
		SoldToRCVC_Column.setTemplate(SoldToRCVCID_Text);
		var SoldToRCVCDesc1_Column = new sap.ui.table.Column(this.createId("SoldToRCVCDesc1_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		SoldToCVCResults_Table.addColumn(SoldToRCVCDesc1_Column);
		var SoldToRCVCDesc_Text = new sap.m.Text(this.createId("SoldToRCVCDesc_Text"), {
			text: "{Txtsh}"
		});
		SoldToRCVCDesc1_Column.setTemplate(SoldToRCVCDesc_Text);
		var Strg_Panel = new sap.m.Panel(this.createId("Strg_Panel"), {
			expandable: true,
			expanded: true
		});
		DWVBox.addItem(Strg_Panel);
		var WaveStrategy_Toolbar = new sap.m.Toolbar(this.createId("WaveStrategy_Toolbar"), {});
		Strg_Panel.setHeaderToolbar(WaveStrategy_Toolbar);
		var DMWaveStrategy_Label = new sap.m.Label(this.createId("DMWaveStrategy_Label"), {
			text: "Wave Strategy"
		});
		WaveStrategy_Toolbar.addContent(DMWaveStrategy_Label);
		var DMWaveStg_Label = new sap.m.Label(this.createId("DMWaveStg_Label"), {});
		WaveStrategy_Toolbar.addContent(DMWaveStg_Label);
		var StrgMain_VBox = new sap.m.VBox(this.createId("StrgMain_VBox"), {});
		Strg_Panel.addContent(StrgMain_VBox);
		var Strategy_HBox = new sap.m.HBox(this.createId("Strategy_HBox"), {});
		StrgMain_VBox.addItem(Strategy_HBox);
		var WaveStrategy_VBox = new sap.m.VBox(this.createId("WaveStrategy_VBox"), {
			width: "100%"
		});
		Strategy_HBox.addItem(WaveStrategy_VBox);
		var oStrgMain_Form1 = new sap.ui.layout.form.SimpleForm(this.createId("oStrgMain_Form1"), {
			adjustLabelSpan: false,
			columnsL: 4,
			columnsM: 4,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 4,
			width: "100%"
		});
		WaveStrategy_VBox.addItem(oStrgMain_Form1);
		var STitle1 = new sap.ui.core.Title(this.createId("STitle1"), {});
		oStrgMain_Form1.addContent(STitle1);
		var WaveStrategy_Label = new sap.m.Label(this.createId("WaveStrategy_Label"), {
			text: "Wave Strategy"
		});
		oStrgMain_Form1.addContent(WaveStrategy_Label);
		var WaveStrategy_Text = new sap.m.Text(this.createId("WaveStrategy_Text"), {});
		oStrgMain_Form1.addContent(WaveStrategy_Text);
		var STitle2 = new sap.ui.core.Title(this.createId("STitle2"), {});
		oStrgMain_Form1.addContent(STitle2);
		var CapTo_Label = new sap.m.Label(this.createId("CapTo_Label"), {
			text: "Cap To"
		});
		oStrgMain_Form1.addContent(CapTo_Label);
		var CapTo_Text = new sap.m.Text(this.createId("CapTo_Text"), {});
		oStrgMain_Form1.addContent(CapTo_Text);
		var STitle3 = new sap.ui.core.Title(this.createId("STitle3"), {});
		oStrgMain_Form1.addContent(STitle3);
		var NoOfWaves_Label = new sap.m.Label(this.createId("NoOfWaves_Label"), {
			text: "Number of waves"
		});
		oStrgMain_Form1.addContent(NoOfWaves_Label);
		var NoOfWaves_Text = new sap.m.Text(this.createId("NoOfWaves_Text"), {});
		oStrgMain_Form1.addContent(NoOfWaves_Text);
		var STitle4 = new sap.ui.core.Title(this.createId("STitle4"), {});
		oStrgMain_Form1.addContent(STitle4);
		var BasePlan_Label = new sap.m.Label(this.createId("BasePlan_Label"), {
			text: "Base Plan"
		});
		oStrgMain_Form1.addContent(BasePlan_Label);
		var BasePlan_Text = new sap.m.Text(this.createId("BasePlan_Text"), {});
		oStrgMain_Form1.addContent(BasePlan_Text);
		var STitle5 = new sap.ui.core.Title(this.createId("STitle5"), {});
		oStrgMain_Form1.addContent(STitle5);
		var IR_CheckBox = new sap.m.CheckBox(this.createId("IR_CheckBox"), {
			enabled: false,
			text: "Ignore Roll Shipment plan prioritization"
		});
		WaveStrategy_VBox.addItem(IR_CheckBox);
		var StrategyImportData_HBox = new sap.m.HBox(this.createId("StrategyImportData_HBox"), {});
		StrgMain_VBox.addItem(StrategyImportData_HBox);
		var WSWaveCum_VBox = new sap.m.VBox(this.createId("WSWaveCum_VBox"), {
			height: "16rem",
			width: "30%"
		});
		StrategyImportData_HBox.addItem(WSWaveCum_VBox);
		var WaveCum_Toolbar1 = new sap.m.Toolbar(this.createId("WaveCum_Toolbar1"), {});
		WSWaveCum_VBox.addItem(WaveCum_Toolbar1);
		var WCTB_Label = new sap.m.Label(this.createId("WCTB_Label"), {
			text: "Wave - %Cum"
		});
		WaveCum_Toolbar1.addContent(WCTB_Label);
		var WaveCum_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("WaveCum_ToolbarSpacer"), {});
		WaveCum_Toolbar1.addContent(WaveCum_ToolbarSpacer);
		var WaveCum_Table = new sap.ui.table.Table(this.createId("WaveCum_Table"), {
			selectionMode: "None",
			visibleRowCount: 4
		});
		WSWaveCum_VBox.addItem(WaveCum_Table);
		var modelWaveCum_Table = new sap.ui.model.json.JSONModel();
		WaveCum_Table.setModel(modelWaveCum_Table);
		WaveCum_Table.bindRows("/");
		var WCWave_Column = new sap.ui.table.Column(this.createId("WCWave_Column"), {
			label: new sap.m.Label({
				text: "Wave"
			}),
			resizable: false
		});
		WaveCum_Table.addColumn(WCWave_Column);
		var WCWave_Text = new sap.m.Text(this.createId("WCWave_Text"), {
			text: "{Wave}"
		});
		WCWave_Column.setTemplate(WCWave_Text);
		var WCCum_Column = new sap.ui.table.Column(this.createId("WCCum_Column"), {
			label: new sap.m.Label({
				text: "%Cum"
			}),
			resizable: false
		});
		WaveCum_Table.addColumn(WCCum_Column);
		var WCCum_Text = new sap.m.Text(this.createId("WCCum_Text"), {
			text: "{Cum}"
		});
		WCCum_Column.setTemplate(WCCum_Text);
		var WSWaveCumBase_VBox = new sap.m.VBox(this.createId("WSWaveCumBase_VBox"), {
			height: "16rem",
			width: "40%"
		});
		StrategyImportData_HBox.addItem(WSWaveCumBase_VBox);
		var WaveCumB_Toolbar1 = new sap.m.Toolbar(this.createId("WaveCumB_Toolbar1"), {});
		WSWaveCumBase_VBox.addItem(WaveCumB_Toolbar1);
		var WCBTB_Label = new sap.m.Label(this.createId("WCBTB_Label"), {
			text: "Wave - %Cum - Base Plan"
		});
		WaveCumB_Toolbar1.addContent(WCBTB_Label);
		var ToolbarSpacer2 = new sap.m.ToolbarSpacer(this.createId("ToolbarSpacer2"), {});
		WaveCumB_Toolbar1.addContent(ToolbarSpacer2);
		var WaveCumBase_Table = new sap.ui.table.Table(this.createId("WaveCumBase_Table"), {
			visibleRowCount: 4,
			selectionMode: "None"
		});
		WSWaveCumBase_VBox.addItem(WaveCumBase_Table);
		var modelWaveCumBase_Table = new sap.ui.model.json.JSONModel();
		WaveCumBase_Table.setModel(modelWaveCumBase_Table);
		WaveCumBase_Table.bindRows("/");
		var WCBWave_Column = new sap.ui.table.Column(this.createId("WCBWave_Column"), {
			label: new sap.m.Label({
				text: "Wave"
			}),
			resizable: false
		});
		WaveCumBase_Table.addColumn(WCBWave_Column);
		var WCBWave_Text = new sap.m.Text(this.createId("WCBWave_Text"), {
			text: "{Wave}"
		});
		WCBWave_Column.setTemplate(WCBWave_Text);
		var WCBCum_Column = new sap.ui.table.Column(this.createId("WCBCum_Column"), {
			label: new sap.m.Label({
				text: "%Cum"
			}),
			resizable: false
		});
		WaveCumBase_Table.addColumn(WCBCum_Column);
		var WCBCum_Text = new sap.m.Text(this.createId("WCBCum_Text"), {
			text: "{Cum}"
		});
		WCBCum_Column.setTemplate(WCBCum_Text);
		var WCBBase_Column = new sap.ui.table.Column(this.createId("WCBBase_Column"), {
			label: new sap.m.Label({
				text: "Base"
			}),
			resizable: false
		});
		WaveCumBase_Table.addColumn(WCBBase_Column);
		var WCBBaseP_Text = new sap.m.Text(this.createId("WCBBaseP_Text"), {
			text: "{BasePlan}"
		});
		WCBBase_Column.setTemplate(WCBBaseP_Text);
		var SourcingPlant_VBox = new sap.m.VBox(this.createId("SourcingPlant_VBox"), {
			height: "16rem",
			width: "25%"
		});
		StrategyImportData_HBox.addItem(SourcingPlant_VBox);
		var SourcingPlant_Toolbar = new sap.m.Toolbar(this.createId("SourcingPlant_Toolbar"), {});
		SourcingPlant_VBox.addItem(SourcingPlant_Toolbar);
		var SourcingPlant_Label = new sap.m.Label(this.createId("SourcingPlant_Label"), {
			text: "Sourcing Plant"
		});
		SourcingPlant_Toolbar.addContent(SourcingPlant_Label);
		var SourcingPlant_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("SourcingPlant_ToolbarSpacer"), {});
		SourcingPlant_Toolbar.addContent(SourcingPlant_ToolbarSpacer);
		var SourcingPlant_Table = new sap.ui.table.Table(this.createId("SourcingPlant_Table"), {
			selectionMode: "None",
			visibleRowCount: 4
		});
		SourcingPlant_VBox.addItem(SourcingPlant_Table);
		var modelSourcingPlant_Table = new sap.ui.model.json.JSONModel();
		SourcingPlant_Table.setModel(modelSourcingPlant_Table);
		SourcingPlant_Table.bindRows("/");
		var SPlantID_Column = new sap.ui.table.Column(this.createId("SPlantID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false,
			width: "5rem"
		});
		SourcingPlant_Table.addColumn(SPlantID_Column);
		var SourcingPlantID_Text = new sap.m.Text(this.createId("SourcingPlantID_Text"), {
			text: "{Plant}"
		});
		SPlantID_Column.setTemplate(SourcingPlantID_Text);
		var SPlantDesc_Column = new sap.ui.table.Column(this.createId("SPlantDesc_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		SourcingPlant_Table.addColumn(SPlantDesc_Column);
		var SourcingPlantDesc_Text = new sap.m.Text(this.createId("SourcingPlantDesc_Text"), {
			text: "{PlantDesc}"
		});
		SPlantDesc_Column.setTemplate(SourcingPlantDesc_Text);
		var SalesOrg_VBox = new sap.m.VBox(this.createId("SalesOrg_VBox"), {
			height: "16rem",
			width: "25%"
		});
		StrategyImportData_HBox.addItem(SalesOrg_VBox);
		var SalesOrg_Toolbar = new sap.m.Toolbar(this.createId("SalesOrg_Toolbar"), {});
		SalesOrg_VBox.addItem(SalesOrg_Toolbar);
		var SalesOrg_Label = new sap.m.Label(this.createId("SalesOrg_Label"), {
			text: "Sales Org"
		});
		SalesOrg_Toolbar.addContent(SalesOrg_Label);
		var SalesOrg_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("SalesOrg_ToolbarSpacer"), {});
		SalesOrg_Toolbar.addContent(SalesOrg_ToolbarSpacer);
		var SalesOrg_Table = new sap.ui.table.Table(this.createId("SalesOrg_Table"), {
			selectionMode: "None",
			visibleRowCount: 4
		});
		SalesOrg_VBox.addItem(SalesOrg_Table);
		var modelSalesOrg_Table = new sap.ui.model.json.JSONModel();
		SalesOrg_Table.setModel(modelSalesOrg_Table);
		SalesOrg_Table.bindRows("/");
		var SalesOrgID_Column = new sap.ui.table.Column(this.createId("SalesOrgID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false
		});
		SalesOrg_Table.addColumn(SalesOrgID_Column);
		var SalesOrg_Text2 = new sap.m.Text(this.createId("SalesOrg_Text2"), {
			text: "{SalesOrg}"
		});
		SalesOrgID_Column.setTemplate(SalesOrg_Text2);
		var SalesOrgDesc_Column = new sap.ui.table.Column(this.createId("SalesOrgDesc_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		SalesOrg_Table.addColumn(SalesOrgDesc_Column);
		var SalesOrgDesc1_Text = new sap.m.Text(this.createId("SalesOrgDesc1_Text"), {});
		SalesOrgDesc_Column.setTemplate(SalesOrgDesc1_Text);
		var DWSoldTo_VBox = new sap.m.VBox(this.createId("DWSoldTo_VBox"), {
			fitContainer: true,
			height: "16rem",
			width: "25%"
		});
		StrategyImportData_HBox.addItem(DWSoldTo_VBox);
		var StrgSoldTo_Toolbar = new sap.m.Toolbar(this.createId("StrgSoldTo_Toolbar"), {});
		DWSoldTo_VBox.addItem(StrgSoldTo_Toolbar);
		var StrgSoldTo_Label = new sap.m.Label(this.createId("StrgSoldTo_Label"), {
			text: "Sold To"
		});
		StrgSoldTo_Toolbar.addContent(StrgSoldTo_Label);
		var StrgSoldTo_ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("StrgSoldTo_ToolbarSpacer"), {});
		StrgSoldTo_Toolbar.addContent(StrgSoldTo_ToolbarSpacer);
		var StrgSoldTo_Table = new sap.ui.table.Table(this.createId("StrgSoldTo_Table"), {
			selectionMode: "None",
			visibleRowCount: 4
		});
		DWSoldTo_VBox.addItem(StrgSoldTo_Table);
		var modelStrgSoldTo_Table = new sap.ui.model.json.JSONModel();
		StrgSoldTo_Table.setModel(modelStrgSoldTo_Table);
		StrgSoldTo_Table.bindRows("/");
		var StrgSoldToID_Column = new sap.ui.table.Column(this.createId("StrgSoldToID_Column"), {
			label: new sap.m.Label({
				text: "Value"
			}),
			resizable: false
		});
		StrgSoldTo_Table.addColumn(StrgSoldToID_Column);
		var StrgSoldToID_Text = new sap.m.Text(this.createId("StrgSoldToID_Text"), {
			text: "{Low}"
		});
		StrgSoldToID_Column.setTemplate(StrgSoldToID_Text);
		var StrgSoldToOption_Column = new sap.ui.table.Column(this.createId("StrgSoldToOption_Column"), {
			label: new sap.m.Label({
				text: "Option"
			}),
			resizable: false
		});
		StrgSoldTo_Table.addColumn(StrgSoldToOption_Column);
		var StrgSoldToOption_Text = new sap.m.Text(this.createId("StrgSoldToOption_Text"), {
			text: "{Option}"
		});
		StrgSoldToOption_Column.setTemplate(StrgSoldToOption_Text);
		var StrgSoldToDesc_Column = new sap.ui.table.Column(this.createId("StrgSoldToDesc_Column"), {
			label: new sap.m.Label({
				text: "Desc"
			}),
			resizable: false
		});
		StrgSoldTo_Table.addColumn(StrgSoldToDesc_Column);
		var StrgSoldToDesc_Text = new sap.m.Text(this.createId("StrgSoldToDesc_Text"), {
			text: "{Txtsh}"
		});
		StrgSoldToDesc_Column.setTemplate(StrgSoldToDesc_Text);
		var PQ_VBox = new sap.m.VBox(this.createId("PQ_VBox"), {
			height: "16rem",
			width: "25%"
		});
		StrategyImportData_HBox.addItem(PQ_VBox);
		var PQ_Toolbar = new sap.m.Toolbar(this.createId("PQ_Toolbar"), {});
		PQ_VBox.addItem(PQ_Toolbar);
		var PQHdr_Label = new sap.m.Label(this.createId("PQHdr_Label"), {});
		PQ_Toolbar.addContent(PQHdr_Label);
		var ToolbarSpacer = new sap.m.ToolbarSpacer(this.createId("ToolbarSpacer"), {});
		PQ_Toolbar.addContent(ToolbarSpacer);
		var PQ_Table = new sap.ui.table.Table(this.createId("PQ_Table"), {
			visibleRowCount: 4,
			selectionMode: "None"
		});
		PQ_VBox.addItem(PQ_Table);
		var modelPQ_Table = new sap.ui.model.json.JSONModel();
		PQ_Table.setModel(modelPQ_Table);
		PQ_Table.bindRows("/");
		var PQID_Column = new sap.ui.table.Column(this.createId("PQID_Column"), {
			resizable: false
		});
		PQ_Table.addColumn(PQID_Column);
		var PQID_Text = new sap.m.Text(this.createId("PQID_Text"), {
			text: "{Value}"
		});
		PQID_Column.setTemplate(PQID_Text);
		var PQDesc_Column = new sap.ui.table.Column(this.createId("PQDesc_Column"), {
			label: new sap.m.Label({
				text: "Qty"
			}),
			resizable: false
		});
		PQ_Table.addColumn(PQDesc_Column);
		var PQDesc_Text = new sap.m.Text(this.createId("PQDesc_Text"), {
			text: "{Qty}"
		});
		PQDesc_Column.setTemplate(PQDesc_Text);
		var Schd_Panel = new sap.m.Panel(this.createId("Schd_Panel"), {
			expandable: true,
			expanded: true
		});
		DWVBox.addItem(Schd_Panel);
		var Schedule_Toolbar = new sap.m.Toolbar(this.createId("Schedule_Toolbar"), {});
		Schd_Panel.setHeaderToolbar(Schedule_Toolbar);
		var DWSchedule_Label = new sap.m.Label(this.createId("DWSchedule_Label"), {
			text: "Wave Schedule"
		});
		Schedule_Toolbar.addContent(DWSchedule_Label);
		var Schedule_VBox = new sap.m.VBox(this.createId("Schedule_VBox"), {});
		Schd_Panel.addContent(Schedule_VBox);
		var oHBoxREV = new sap.m.HBox(this.createId("oHBoxREV"), {
			width: "100%"
		});
		Schedule_VBox.addItem(oHBoxREV);
		var oVBoxWaveSch = new sap.m.VBox(this.createId("oVBoxWaveSch"), {
			width: "25%"
		});
		oHBoxREV.addItem(oVBoxWaveSch);
		var oSchFormR = new sap.ui.layout.form.SimpleForm(this.createId("oSchFormR"), {
			columnsL: 4,
			columnsM: 2,
			columnsXL: 6,
			editable: true,
			labelSpanL: 12,
			labelSpanM: 12,
			"layout": "ResponsiveGridLayout",
			maxContainerCols: 1
		});
		oVBoxWaveSch.addItem(oSchFormR);
		var oTitleR_WaveSchedule = new sap.ui.core.Title(this.createId("oTitleR_WaveSchedule"), {});
		oSchFormR.addContent(oTitleR_WaveSchedule);
		var oLblRwavecre = new sap.m.Label(this.createId("oLblRwavecre"), {
			text: "Wave Create"
		});
		oSchFormR.addContent(oLblRwavecre);
		var WaveCreate_Text = new sap.m.Text(this.createId("WaveCreate_Text"), {});
		oSchFormR.addContent(WaveCreate_Text);
		var ReleaseType_Label = new sap.m.Label(this.createId("ReleaseType_Label"), {
			text: "Release Type"
		});
		oSchFormR.addContent(ReleaseType_Label);
		var ReleaseType_Text = new sap.m.Text(this.createId("ReleaseType_Text"), {});
		oSchFormR.addContent(ReleaseType_Text);
		var ReleaseTime_Label = new sap.m.Label(this.createId("ReleaseTime_Label"), {});
		oSchFormR.addContent(ReleaseTime_Label);
		var ReleaseTime_Text = new sap.m.Text(this.createId("ReleaseTime_Text"), {});
		oSchFormR.addContent(ReleaseTime_Text);
		var oVBoxWaveSchd = new sap.m.VBox(this.createId("oVBoxWaveSchd"), {
			width: "75%"
		});
		oHBoxREV.addItem(oVBoxWaveSchd);
		var oSchFormRschat = new sap.ui.layout.form.SimpleForm(this.createId("oSchFormRschat"), {
			width: "100%",
			"layout": "ResponsiveGridLayout",
			labelSpanM: 12,
			labelSpanL: 12,
			editable: true,
			columnsXL: 6,
			columnsM: 2,
			columnsL: 4
		});
		oVBoxWaveSchd.addItem(oSchFormRschat);
		var oTitleWaveSchd1 = new sap.ui.core.Title(this.createId("oTitleWaveSchd1"), {});
		oSchFormRschat.addContent(oTitleWaveSchd1);
		var ScheduleAt_Label = new sap.m.Label(this.createId("ScheduleAt_Label"), {});
		oSchFormRschat.addContent(ScheduleAt_Label);
		var VBox12 = new sap.m.VBox(this.createId("VBox12"), {});
		oSchFormRschat.addContent(VBox12);
		var ScheduleAt_Text = new sap.m.Text(this.createId("ScheduleAt_Text"), {});
		VBox12.addItem(ScheduleAt_Text);
		var AddTime_Label = new sap.m.Label(this.createId("AddTime_Label"), {
			text: "Additional Start Time:",
			visible: false
		});
		VBox12.addItem(AddTime_Label);
		var MulSch_Table = new sap.m.List(this.createId("MulSch_Table"), {
			visible: false,
			mode: "SingleSelectMaster"
		});
		VBox12.addItem(MulSch_Table);
		var modelMulSch_Table = new sap.ui.model.json.JSONModel();
		MulSch_Table.setModel(modelMulSch_Table);
		var MulSch_Column = new sap.m.CustomListItem(this.createId("MulSch_Column"), {});
		MulSch_Table.bindAggregation("items", "/", MulSch_Column);
		var MulSch_Text = new sap.m.Text(this.createId("MulSch_Text"), {
			text: "{ScheduleAtn}"
		});
		MulSch_Column.addContent(MulSch_Text);
		var Repeats_Label = new sap.m.Label(this.createId("Repeats_Label"), {
			text: "Repeats"
		});
		oSchFormRschat.addContent(Repeats_Label);
		var Repeats_Text = new sap.m.Text(this.createId("Repeats_Text"), {});
		oSchFormRschat.addContent(Repeats_Text);
		var oTitleWaveSchd2 = new sap.ui.core.Title(this.createId("oTitleWaveSchd2"), {});
		oSchFormRschat.addContent(oTitleWaveSchd2);
		var Till_Label = new sap.m.Label(this.createId("Till_Label"), {});
		oSchFormRschat.addContent(Till_Label);
		var TillDate_Text = new sap.m.Text(this.createId("TillDate_Text"), {});
		oSchFormRschat.addContent(TillDate_Text);
		var Every_Label = new sap.m.Label(this.createId("Every_Label"), {
			text: "Every"
		});
		oSchFormRschat.addContent(Every_Label);
		var Every_Text = new sap.m.Text(this.createId("Every_Text"), {});
		oSchFormRschat.addContent(Every_Text);
		var Days_VBox = new sap.m.VBox(this.createId("Days_VBox"), {});
		oVBoxWaveSchd.addItem(Days_VBox);
		var Days_Label = new sap.m.Label(this.createId("Days_Label"), {
			text: "Days"
		});
		Days_VBox.addItem(Days_Label);
		var oSWeeklyAlloc_List = new sap.m.HBox(this.createId("oSWeeklyAlloc_List"), {});
		Days_VBox.addItem(oSWeeklyAlloc_List);
		var W_1S = new sap.m.ToggleButton(this.createId("W_1S"), {
			enabled: false,
			text: "S",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_1S = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_1S = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_1S);
		var W_2M = new sap.m.ToggleButton(this.createId("W_2M"), {
			enabled: false,
			text: "M",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_2M = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_2M = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_2M);
		var W_3T = new sap.m.ToggleButton(this.createId("W_3T"), {
			enabled: false,
			text: "T",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_3T = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_3T = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_3T);
		var W_4W = new sap.m.ToggleButton(this.createId("W_4W"), {
			enabled: false,
			text: "W",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_4W = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_4W = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_4W);
		var W_5T = new sap.m.ToggleButton(this.createId("W_5T"), {
			enabled: false,
			text: "T",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_5T = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_5T = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_5T);
		var W_6F = new sap.m.ToggleButton(this.createId("W_6F"), {
			text: "F",
			enabled: false,
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_6F = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_6F = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_6F);
		var W_7S = new sap.m.ToggleButton(this.createId("W_7S"), {
			enabled: false,
			text: "S",
			press: function (oEvent) {
				// if(oEvent.getSource().getPressed())
				//     gMainMRef.getData().ScheduleWeeklyDays.W_7S = true;
				// else
				//     gMainMRef.getData().ScheduleWeeklyDays.W_7S = false;
			}
		});
		oSWeeklyAlloc_List.addItem(W_7S);
		var StrgSelVarInfo_Popover = new sap.m.Popover(this.createId("StrgSelVarInfo_Popover"), {
			contentHeight: "250px",
			contentMinWidth: "450px",
			placement: "Bottom",
			title: "Selected Variants"
		});
		var StrgSelVarInfoHdr_Text = new sap.m.Text(this.createId("StrgSelVarInfoHdr_Text"), {});
		StrgSelVarInfo_Popover.addContent(StrgSelVarInfoHdr_Text);
		var StrgSelVarInfo_Table = new sap.m.Table(this.createId("StrgSelVarInfo_Table"), {
			width: "440px"
		});
		StrgSelVarInfo_Popover.addContent(StrgSelVarInfo_Table);
		var modelStrgSelVarInfo_Table = new sap.ui.model.json.JSONModel();
		StrgSelVarInfo_Table.setModel(modelStrgSelVarInfo_Table);
		var SSVIField_Column = new sap.m.Column(this.createId("SSVIField_Column"), {
			header: new sap.m.Label({
				text: "Field Name"
			})
		});
		StrgSelVarInfo_Table.addColumn(SSVIField_Column);
		var SSVIIE_Column2 = new sap.m.Column(this.createId("SSVIIE_Column2"), {
			header: new sap.m.Label({
				text: "Include/Exclude"
			})
		});
		StrgSelVarInfo_Table.addColumn(SSVIIE_Column2);
		var SSVIIE_Option = new sap.m.Column(this.createId("SSVIIE_Option"), {
			header: new sap.m.Label({
				text: "Option"
			})
		});
		StrgSelVarInfo_Table.addColumn(SSVIIE_Option);
		var SSVIValue_Column = new sap.m.Column(this.createId("SSVIValue_Column"), {
			header: new sap.m.Label({
				text: "Value"
			})
		});
		StrgSelVarInfo_Table.addColumn(SSVIValue_Column);
		var ColumnListItem = new sap.m.ColumnListItem(this.createId("ColumnListItem"), {});
		StrgSelVarInfo_Table.bindAggregation("items", "/", ColumnListItem);
		var SSVIField_Text2 = new sap.m.Text(this.createId("SSVIField_Text2"), {
			text: "{Txtsh}"
		});
		ColumnListItem.addCell(SSVIField_Text2);
		var SSVIIE_Text = new sap.m.Text(this.createId("SSVIIE_Text"), {
			text: "{Sign}"
		});
		ColumnListItem.addCell(SSVIIE_Text);
		var SSVIIE_Option_Text = new sap.m.Text(this.createId("SSVIIE_Option_Text"), {
			text: "{Option}"
		});
		ColumnListItem.addCell(SSVIIE_Option_Text);
		var SSVIValue_Text3 = new sap.m.Text(this.createId("SSVIValue_Text3"), {
			text: "{Low}"
		});
		ColumnListItem.addCell(SSVIValue_Text3);
		var Dialog = new sap.m.Dialog(this.createId("Dialog"), {});
		// ************************************************************************
		// * App Name        : ZUI_DAT_WORKBENCH_WAVES                            *
		// * TITLE           : Workbench Waves                                    *
		// * CREATED BY      : Sivaprasad Valluru                                 *
		// * CREATION DATE   : 22-May-2020                                        *
		// * BHU#            : BHU26843                                           *
		// * DESCRIPTION     : UI for Workbench waves                             *
		// *                   Desiger                                            *
		// ************************************************************************
		// *-----------------------********************---------------------------*
		// * Date        Programmer      Ticket     Description     Correction    *
		// *-----------  ------------    --------   ------------    -----------   *
		// * 22/05/2020  C5197695VS      61741285   Initial         DV5K927722    *
		// * 01/10/2020  C5162473NS    INC076695189 Prod Bug fix    DV5K926281    *
		// ************************************************************************
		//function onBeforeDisplay() {
		sap.ui.getCore().attachInit(function (data) {

			if (data) {
				if (data.initFn) {
					//data.initFn("Hi there! Param1 = " + data.mode);
				}
				if (data.mode) {
					switch (data.mode) {
					case 'CREATE':
						sap.ui.core.BusyIndicator.show(0);
						gWBMode = 'C';
						gWBProfile = data.wbProfile;
						gWBWeek = data.wbWeek;
						gWBRegion = data.wbRegion;
						gHelpLink = gHelpLink;
						break;
					case 'CHANGE':
						sap.ui.core.BusyIndicator.show(0);
						gWBMode = 'E';
						gWBSchGuid = data.wbSchGuid;
						gWBWeek = data.wbWeek;
						gWBProfile = data.wbProfile;
						gWBRegion = data.wbRegion;
						gHelpLink = gHelpLink;
						break;
					default:
						// code
					}
					//onInit();
				}
			}

			// setTimeout(function() {
			//     onInit();
			// }, 250);

			/*
			    MPN Dialog Copy Paste
			*/
			MPNAdvInc_Input.addEventDelegate({
				onmousedown: function (e) {
					gMPNWhichPaste = 'Inc';
					gMPNIncIdx = e.currentTarget.id.split('-')[6];
				},
				onpaste: function (e) {
					e.preventDefault();
					var rows = (e.originalEvent || e).clipboardData.getData('text/plain').split(/\+/);
					//begin of DV5K926281
					//var rowData = rows[0].split('\n');
					var rowData = rows[0].split('\r\n');
					if (rowData != undefined) {
						if (rowData.length == 1) {
							var rowData = rows[0].split('\n');
						}
					}
					//end of DV5K926281
					var pasteHowMany = rowData[0].split('	');
					if (pasteHowMany.length > 1) {
						sap.m.MessageToast.show('Not a valid copy/paste');
					} else if (pasteHowMany.length == 1) {
						if (rowData.length == 1) {
							rows[0].trim(); //DV5K926281
							MPNAdvInclude_List.getModel().getData()[gMPNIncIdx].Low = rows[0].toUpperCase();
						} else {
							var startingIdx = gMPNIncIdx;
							for (var i = 0; i < rowData.length; i++) {
								rowData[i].trim(); //DV5K926281
								if (MPNAdvInclude_List.getModel().getData()[startingIdx] == undefined) {
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: 'CP',
										Low: rowData[i].toUpperCase(),
										High: '',
										Txtsh: '',
										Type: 'A'
									};
									MPNAdvInclude_List.getModel().getData().push(xd);
								} else {
									MPNAdvInclude_List.getModel().getData()[startingIdx].Low = rowData[i].toUpperCase();
								}
								startingIdx++;
							}
						}
						MPNAdvInclude_List.getModel().refresh();
						setMPNTitle('NotInitial', 'I');
						setMPNTitle('NotInitial', 'E');
					}
				}
			});
			MPNAdvExc_Input.addEventDelegate({
				onmousedown: function (e) {
					gMPNWhichPaste = 'Exc';
					gMPNExcIdx = e.currentTarget.id.split('-')[6];
				},
				onpaste: function (e) {
					e.preventDefault();
					var rows = (e.originalEvent || e).clipboardData.getData('text/plain').split(/\+/);
					//begin of DV5K926281
					//var rowData = rows[0].split('\n');
					var rowData = rows[0].split('\r\n');
					if (rowData != undefined) {
						if (rowData.length == 1) {
							var rowData = rows[0].split('\n');
						}
					}
					//end of DV5K926281
					var pasteHowMany = rowData[0].split('	');
					if (pasteHowMany.length > 1) {
						sap.m.MessageToast.show('Not a valid copy/paste');
					} else if (pasteHowMany.length == 1) {
						if (rowData.length == 1) {
							rows[0].trim(); //DV5K926281
							MPNAdvExclude_List.getModel().getData()[gMPNExcIdx].Low = rows[0].toUpperCase();
						} else {
							var startingIdx = gMPNExcIdx;
							for (var i = 0; i < rowData.length; i++) {
								rowData[i].trim(); //DV5K926281
								if (MPNAdvExclude_List.getModel().getData()[startingIdx] == undefined) {
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'E',
										Option: 'CP',
										Low: rowData[i].toUpperCase(),
										High: '',
										Txtsh: '',
										Type: 'A'
									};
									MPNAdvExclude_List.getModel().getData().push(xd);
								} else {
									MPNAdvExclude_List.getModel().getData()[startingIdx].Low = rowData[i].toUpperCase();
								}
								startingIdx++;
							}
						}
						MPNAdvExclude_List.getModel().refresh();
						setMPNTitle('NotInitial', 'I');
						setMPNTitle('NotInitial', 'E');
					}
				}
			});

			/*
			    CVC Sold To Copy/Paste
			*/
			CVCSTAdvInc_Input.addEventDelegate({
				onmousedown: function (e) {
					gCVCSoldToWhichPaste = 'Inc';
					gCVCSTIncIdx = e.currentTarget.id.split('-')[6];
				},
				onpaste: function (e) {
					e.preventDefault();
					var rows = (e.originalEvent || e).clipboardData.getData('text/plain').split(/\+/);
					//begin of DV5K926281
					//var rowData = rows[0].split('\n');
					var rowData = rows[0].split('\r\n');
					if (rowData != undefined) {
						if (rowData.length == 1) {
							var rowData = rows[0].split('\n');
						}
					}
					//end of DV5K926281
					var pasteHowMany = rowData[0].split('	');
					if (pasteHowMany.length > 1) {
						sap.m.MessageToast.show('Not a valid copy/paste');
					} else if (pasteHowMany.length == 1) {
						if (rowData.length == 1) {
							rows[0].trim(); //DV5K926281
							CVCSTAdvInclude_List.getModel().getData()[gCVCSTIncIdx].Low = rows[0].toUpperCase();
						} else {
							var startingIdx = gCVCSTIncIdx;
							for (var i = 0; i < rowData.length; i++) {
								rowData[i].trim(); //DV5K926281
								if (CVCSTAdvInclude_List.getModel().getData()[startingIdx] == undefined) {
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'I',
										Option: 'CP',
										Low: rowData[i].toUpperCase(),
										High: '',
										Txtsh: '',
										Type: 'A'
									};
									CVCSTAdvInclude_List.getModel().getData().push(xd);
								} else {
									CVCSTAdvInclude_List.getModel().getData()[startingIdx].Low = rowData[i].toUpperCase();
								}
								startingIdx++;
							}
						}
						CVCSTAdvInclude_List.getModel().refresh();
						setCVCSTTitle('NotInitial', 'I');
						setCVCSTTitle('NotInitial', 'E');
					}
				}
			});
			CVCSTAdvExc_Input.addEventDelegate({
				onmousedown: function (e) {
					gCVCSoldToWhichPaste = 'Exc';
					gCVCSTExcIdx = e.currentTarget.id.split('-')[6];
				},
				onpaste: function (e) {
					e.preventDefault();
					var rows = (e.originalEvent || e).clipboardData.getData('text/plain').split(/\+/);
					//begin of DV5K926281
					//var rowData = rows[0].split('\n');
					var rowData = rows[0].split('\r\n');
					if (rowData != undefined) {
						if (rowData.length == 1) {
							var rowData = rows[0].split('\n');
						}
					}
					//end of DV5K926281
					var pasteHowMany = rowData[0].split('	');
					if (pasteHowMany.length > 1) {
						sap.m.MessageToast.show('Not a valid copy/paste');
					} else if (pasteHowMany.length == 1) {
						if (rowData.length == 1) {
							rows[0].trim(); //DV5K926281
							CVCSTAdvExclude_List.getModel().getData()[gCVCSTExcIdx].Low = rows[0].toUpperCase();
						} else {
							var startingIdx = gCVCSTExcIdx;
							for (var i = 0; i < rowData.length; i++) {
								rowData[i].trim(); //DV5K926281
								if (CVCSTAdvExclude_List.getModel().getData()[startingIdx] == undefined) {
									var xd = {
										Selname: '',
										Kind: '',
										Sign: 'E',
										Option: 'CP',
										Low: rowData[i].toUpperCase(),
										High: '',
										Txtsh: '',
										Type: 'A'
									};
									CVCSTAdvExclude_List.getModel().getData().push(xd);
								} else {
									CVCSTAdvExclude_List.getModel().getData()[startingIdx].Low = rowData[i].toUpperCase();
								}
								startingIdx++;
							}
						}
						CVCSTAdvExclude_List.getModel().refresh();
						setCVCSTTitle('NotInitial', 'I');
						setCVCSTTitle('NotInitial', 'E');
					}
				}
			});

			/*
			    Call is to make sure that the create wave header
			    number are not lost after the ag-grid calls in any other
			    apps like RCA or SOLD while swaping the applications.
			*/
			if (sap.z.ZUI_DAT_WAVE_CREATION != undefined || sap.z.ZUI_DAT_WAVE_CREATION != null)
				sap.z.ZUI_DAT_WAVE_CREATION.wcCallback();
		});
		//}

		sap.ui.getCore().attachInit(function (data) {
			setTimeout(function () {
				//           onBeforeDisplay();
				onInit();
			}, 250);
			sap.z = {
				ZUI_DAT_WORKBENCH_WAVES: {
					yourCallback: data.callback || function () {
						callBackCW();
						//This will bring back to workbench page on click of save
						CWHDRBack_Icon.firePress();
					}
				}
			};
		});

		var ODataWS = "";
		var ODataVariant = "";
		var ODataWB = "";
		var ODataRCA = "";

		WaveStrategy_Text8.bindProperty("text", {
			parts: ["WaveStrat"],
			formatter: function (WaveStrat) {
				if (typeof WaveStrat === "undefined" || WaveStrat === null || WaveStrat === "") {
					return WaveStrat;

				} else {
					if (WaveStrat == 'FAIRSHARE') {
						return 'Fairshare of Weekly Alloc.';
					} else if (WaveStrat == 'PERC_WEEKLY') {
						return 'Percentage of Weekly Alloc.';
					} else if (WaveStrat == 'PERC_SHPPLAN') {
						return 'Percentage of ShipPlan/Rollover';
					} else if (WaveStrat == "USER_SPEC") {
						return "User Specified Quantity";
						//Begin of Changes - DV5K938119 - DAT FY22
					} else if (WaveStrat == "USER_SPEC_PLA") {
						return "PLA - User Specified Quantity";
						//End of Changes - DV5K938119 - DAT FY22
					} else if (WaveStrat == "MATCH_MAX") {
						return "Match Max(GATP Alloc. Consump";
					} else if (WaveStrat == "ADJ_CONS") {
						return "Adjust to Consumption";
					}
				}
				// var formattedText = WaveStrat
				// ;return formattedText;
			}
		});
		WaveRelease_Text9.bindProperty("text", {
			parts: ["WaveRelMech"],
			formatter: function (WaveRelMech) {
				if (typeof WaveRelMech === "undefined" || WaveRelMech === null || WaveRelMech === "") {
					return WaveRelMech;

				} else {
					if (WaveRelMech == 'D') {
						return 'Dependency Release';
					} else if (WaveRelMech == 'T') {
						return 'Time Release';
					} else if (WaveRelMech == 'M') {
						return 'Manual Release';
					}
				}
				// var formattedText = WaveRelMech;
				// return formattedText;
			}
		});
		WeekDays_Text2.bindProperty("text", {
			parts: ["WeekDays"],
			formatter: function (WeekDays) {
				if (typeof WeekDays === "undefined" || WeekDays === null || WeekDays === "") {
					return WeekDays;
				} else {
					var formattedText = '';
					var weeks_tab = WeekDays.split(',');
					for (var i = 0; i < weeks_tab.length; i++) {
						var wt = weeks_tab[i];
						var week = '';
						if (wt == 1) {
							week = 'Monday';
						} else if (wt == 2) {
							week = 'Tuesday';
						} else if (wt == 3) {
							week = 'Wednesday';
						} else if (wt == 4) {
							week = 'Thursday';
						} else if (wt == 5) {
							week = 'Friday';
						} else if (wt == 6) {
							week = 'Saturday';
						} else if (wt == 7) {
							week = 'Sunday';
						}

						if (formattedText == '') {
							formattedText = week;
						} else {
							formattedText = formattedText + ',' + week;
						}
					}

					return formattedText;
				}
			}
		});
		FrequencyType_Text12.bindProperty("text", {
			parts: ["FreqType"],
			formatter: function (FreqType) {
				if (typeof FreqType === "undefined" || FreqType === null || FreqType === "") {
					return FreqType;
				} else {
					if (FreqType == 'ONE') {
						return 'One Time';
					} else if (FreqType == 'HOUR') {
						return 'Hourly';
					} else if (FreqType == 'DAILY') {
						return 'Daily';
					} else if (FreqType == 'WEEK') {
						return 'Weekly';
					}
				}
				//var formattedText = FreqType;return formattedText;
			}
		});
		ScheduleMode_Text.bindProperty("text", {
			parts: ["WaveSchMode"],
			formatter: function (WaveSchMode) {
				if (typeof WaveSchMode === "undefined" || WaveSchMode === null || WaveSchMode === "") {
					return WaveSchMode;
				} else {
					if (WaveSchMode == 'IMME') {
						return 'Immediate';
					} else if (WaveSchMode == 'SCHD') {
						return 'Scheduled';
					} else if (WaveSchMode == 'TDM') {
						return 'TDM Job';
					}
				}
				//var formattedText = WaveSchMode;return formattedText;
			}
		});
		JobName_Text5.bindProperty("text", {
			parts: ["JobName"],
			formatter: function (JobName) {
				if (typeof JobName === "undefined" || JobName === null || JobName === "") {
					return;
				}
				var formattedText = JobName;
				return formattedText;
			}
		});
		txtWaveRelMech.bindProperty("text", {
			parts: ["WaveRelMech"],
			formatter: function (WaveRelMech) {
				if (typeof WaveRelMech === "undefined" || WaveRelMech === null || WaveRelMech === "") {
					return WaveRelMech;

				} else {
					if (WaveRelMech == 'D') {
						return 'Dependency Release';
					} else if (WaveRelMech == 'T') {
						return 'Time Release';
					} else if (WaveRelMech == 'M') {
						return 'Manual Release';
					}
				}
			}
		});
		MPNSTPOList_Sign.bindProperty("text", {
			parts: ["Option"],
			formatter: function (Option) {
				if (typeof Option === "undefined" || Option === null || Option === "") {
					return Option;
				} else {
					if (Option == 'CP') {
						return 'Contains';
					} else if (Option == 'EQ') {
						return 'Equals';
					} else if (Option == 'BW') {
						return 'Begins with';
					} else if (Option == 'EW') {
						return 'Ends with';
					}
				}
			}
		});
		MulSch_Text.bindProperty("text", {
			parts: ["ScheduleAtn"],
			formatter: function (ScheduleAtn) {
				if (typeof ScheduleAtn === "undefined" || ScheduleAtn === null || ScheduleAtn === "") {
					return;

				}

				var str = ScheduleAtn.replace(/-/gi, ':');
				var formattedText = str;
				return formattedText;
			}
		});
		SSVIIE_Text.bindProperty("text", {
			parts: ["Sign"],
			formatter: function (Sign) {
				if (typeof Sign === "undefined" || Sign === null || Sign === "") {
					return Sign;
				} else {
					if (Sign == 'I') {
						return 'Include';
					} else if (Sign == 'E') {
						return 'Exclude';
					}
				}
			}
		});
		SSVIIE_Option_Text.bindProperty("text", {
			parts: ["Option"],
			formatter: function (Option) {
				if (typeof Option === "undefined" || Option === null || Option === "") {
					return Option;
				} else {
					if (Option == 'CP') {
						return 'Contains';
					} else if (Option == 'EQ') {
						return 'Equals';
					} else if (Option == 'BW') {
						return 'Begins with';
					} else if (Option == 'EW') {
						return 'Ends with';
					}
				}
			}
		});

		//FUNCTIONS
		function getODataWS_Table(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/WaveSchdSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelWS_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataWave_Table(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/WorkBWavesSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelWave_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataCVCOptions_List(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelCVCOptions_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		VName_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		VDesc_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataVariantChange_Table(sPath, options) {
			if (!ODataVariant) {
				createODataVariant();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/VariantListSet"
			}
			ODataVariant.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelVariantChange_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataMPNBasic_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMPNBasic_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataMPNAdvInclude_List(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMPNAdvInclude_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		MPNAdvInc_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataMPNAdvExclude_List(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMPNAdvExclude_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		MPNAdvExc_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataCVCSTBasic_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelCVCSTBasic_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataCVCSTAdvInclude_List(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelCVCSTAdvInclude_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		CVCSTAdvInc_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataCVCSTAdvExclude_List(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelCVCSTAdvExclude_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		CVCSTAdvExc_Input.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataCVCSel_List(sPath, options) {
			if (!ODataVariant) {
				createODataVariant();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/VariantListSet"
			}
			ODataVariant.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelCVCSel_List.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataMPNSTPOList(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMPNSTPOList.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataPopoverList(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelPopoverList.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataPopoverList_job(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/JobLogSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelPopoverList_job.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}
		informVariantVARIANT.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		informVariantVTEXT.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		oWavenr.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		oInputDisc.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		oInpoSFormSdwnloadcrwcr.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		WaveFromInp.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});
		WaveToInp.attachBrowserEvent("touchstart", function () {
			if (!this.getEditable() || !this.getEnabled()) return;
			activeInputField = this;
			activeScrollContainer = oPageDialog;
		});

		function getODataWUError_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/WaveUpMsgSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelWUError_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataUBPError_Table(sPath, options) {
			if (!ODataRCA) {
				createODataRCA();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/UBPMsgSet"
			}
			ODataRCA.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelUBPError_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataPPUError_Table(sPath, options) {
			if (!ODataModelV2) {
				createODataModelV2();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/UBPMsgSet"
			}
			ODataModelV2.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelPPUError_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataPGUError_Table(sPath, options) {
			if (!ODataModelV2) {
				createODataModelV2();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/UBPMsgSet"
			}
			ODataModelV2.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelPGUError_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataOPSSubclass_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelOPSSubclass_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataMPNResults_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMPNResults_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataSalesOrgCVC_Table(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelSalesOrgCVC_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataDistC_Table(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelDistC_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataSoldToCVCResults_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelSoldToCVCResults_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataWaveCum_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/WaveCumSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelWaveCum_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataWaveCumBase_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/WaveCumBaseSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelWaveCumBase_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataSourcingPlant_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/SourcPlantSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelSourcingPlant_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataSalesOrg_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/StratSalesOrgSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelSalesOrg_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataStrgSoldTo_Table(sPath, options) {
			if (!ODataWB) {
				createODataWB();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWB.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelStrgSoldTo_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataPQ_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/ProdSoldToQtySet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelPQ_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataMulSch_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/MulScheduleSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelMulSch_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function getODataStrgSelVarInfo_Table(sPath, options) {
			if (!ODataWS) {
				createODataWS();
			}
			if (!options) {
				options = {}
			}
			if (!sPath) {
				sPath = "/CVCSet"
			}
			ODataWS.read(sPath, {
				urlParameters: options.urlParameters || null,
				context: options.context || null,
				filters: options.filters || null,
				sorters: options.sorters || null,
				success: function (oData, oResponse) {
					modelStrgSelVarInfo_Table.setData(oData.results);
				},
				error: function (result, status, errorThrown) {
					sapNepApp.onAjaxError(result.status, result.statusText, result.responseText);
				}
			});
		}

		function createODataWS() {
			ODataWS = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/sap/opu/odata/sap/ZOD_DAT_CVC_WAVE_SRV/",
				annotationURI: "",
				user: "",
				password: ""
			});
		}

		function createODataVariant() {
			ODataVariant = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/sap/opu/odata/sap/ZOD_NAD_SCREEN_VARIANT_SRV",
				annotationURI: "",
				user: "",
				password: ""
			});
		}

		function createODataWB() {
			ODataWB = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/sap/opu/odata/sap/ZOD_DAT_WAVE_WORKBENCH_SRV",
				annotationURI: "",
				user: "",
				password: ""
			});
		}

		function createODataRCA() {
			ODataRCA = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/sap/opu/odata/sap/ZOD_DAT_RCA_BY_PROFILE_SRV",
				annotationURI: "",
				user: "",
				password: ""
			});
		}

		function AppDestroy(viewId) {
			sapNepApp = null;
			delete neptune.app[sapNepAppID];
			sap.n.Phonegap.onOnlineCustom = null;
			sap.n.Phonegap.onOfflineCustom = null;
			sap.n.Phonegap.onBackButtonCustom = null;
			sap.n.Phonegap.onMenuButtonCustom = null;
			sap.n.Phonegap.onPauseCustom = null;
			sap.n.Phonegap.onResumeCustom = null;
			sap.n.Phonegap.onSearchButtonCustom = null;
			sap.n.Phonegap.onVolumeUpButtonCustom = null;
			sap.n.Phonegap.onVolumeDownButtonCustom = null;
			var oStyle = sap.ui.getCore().byId("oStyleZUI_DAT_WORKBENCH_WAVES");
			if (oStyle) {
				oStyle.destroy();
				oStyle = null
			}
			var oHtml = sap.ui.getCore().byId("oHtmlZUI_DAT_WORKBENCH_WAVES");
			if (oHtml) {
				oHtml.destroy();
				oHtml = null
			}

		}
		//INIT
		oApp.addStyleClass("sapUiSizeCompact");
		PageCustomHdr_bar.addStyleClass("appleUiHdrBG appUiHdrHeight appleUiHdrSize appleUiHdrMBar");
		HDR_Icon.addStyleClass("sapUiTinyMarginBegin");
		InfoH_Icon.addStyleClass("sapUiSmallMarginEnd");
		VBox2.addStyleClass("sapUiNoMargin");
		oPanelProfile.addStyleClass("zPanelProfile");
		oSFormProfile.addStyleClass("sapUiSizeCompact");
		oSFormProfile.addStyleClass("zForm");
		oSFormProfile.addStyleClass("sapUiSmallMarginTop");
		oProfileForm_Week.addStyleClass("zSecProf");
		oProfileForm_Profile.addStyleClass("zSecProf");
		oPanelCVC.addStyleClass("zPanelCVC zPanelCVCPC zMarginBottom0");
		oPanelCVC.addStyleClass("sapUiSizeCompact");
		oLabelCVC.addStyleClass("zcvclabel");
		CVCSel_Label.addStyleClass("zMLabelB");
		CVCSel_Label.addStyleClass("sapUiLargeMarginBegin");
		CVCHdrSelVar_Icon.addStyleClass("sapUiLargeMarginEnd");
		oHBoxCVC.addStyleClass("zHoxCVC");
		oVBoxCVC.addStyleClass("zPanelCVC1");
		oCVCForm.addStyleClass("sapUiSizeCompact");
		oCVCForm.addStyleClass("zSFormCVC");
		oCVCForm.addStyleClass("sapUiNoMarginTop");
		oinpoSFormCVCOPS.addStyleClass("zMInput");
		oinpoSFormCVCMPN.addStyleClass("zMInput");
		oinpoSFormCVCSales.addStyleClass("zMInput");
		oinpoSFormCVCChan.addStyleClass("zMInput");
		oinpoSFormCVCSoldTo.addStyleClass("zMInput");
		oCVCSearch_Button.addStyleClass("zBtnBlue");
		oCVCSearch_Button.addStyleClass("sapUiSmallMarginTop");
		Tables_Panel.addStyleClass("zPanel zMarginL1 zPanelBB zMarginR1");
		Tables_IconTabBar.addStyleClass("zMainWBIconTB zSearchFieldM zIconTabBarHeader zMarginTop1");
		WSTable_VBox.addStyleClass("zTableBorder");
		WS_OverflowToolbar.addStyleClass("zMarginBottom");
		WS_SearchField.addStyleClass("zSearchFieldM");
		WSRefresh_Button.addStyleClass("zBtnBlue");
		Upload_MenuButton.addStyleClass("zBtnBlue");
		Create_Button.addStyleClass("zBtnBlue");
		Change_Button.addStyleClass("zBtnBlue");
		Delete_Button.addStyleClass("zBtnBlue");
		selectVariant.addStyleClass("zDropDownBR");
		Variant_Button.addStyleClass("zBtnBlue");
		Variant_Button.addStyleClass("sapUiTinyMarginEnd");
		WS_Table.addStyleClass("appleUiTable sapUiTinyMarginBottom zTable");
		WS_Table.addStyleClass("sapUiTinyMarginBeginEnd");
		OpsSubClass_Icon.addStyleClass("zIconSumryWB");
		MPNSel_Icon.addStyleClass("appleUiButtonColor zIconSumry");
		SalesOrg_Icon.addStyleClass("zIconSumryWB");
		Channel_Icon.addStyleClass("zIconSumryWB");
		SoldToSel_Icon.addStyleClass("zIconSumryWB");
		Wave_VBox.addStyleClass("zTableBorder");
		WRefresh_Button.addStyleClass("zBtnBlue");
		WUpload_MenuButton.addStyleClass("zBtnBlue");
		WCreate_Button.addStyleClass("zBtnBlue");
		WRelease_Button.addStyleClass("zBtnBlue");
		wave_param.addStyleClass("zBtnBlue");
		WaveDel_Button.addStyleClass("zBtnBlue");
		selectVariant_wave.addStyleClass("zDropDownBR");
		WaveVariant_Button.addStyleClass("zBtnBlue");
		Wave_Table.addStyleClass("appleUiTable sapUiTinyMarginBottom");
		Wave_Table.addStyleClass("sapUiTinyMarginBeginEnd");
		jobLogIconstatus.addStyleClass("zIconSumryWB");
		jobLogIconstatus.addStyleClass("sapUiTinyMarginBegin");
		jobLogIcon.addStyleClass("zIconSumryWB");
		jobLogIcon.addStyleClass("sapUiTinyMarginBegin");
		CVCOptions_Text.addStyleClass("zMText12");
		CVCOptions_Text.addStyleClass("sapUiTinyMargin");
		VarOK_Button.addStyleClass("zBtnBlue");
		VarClose_Button.addStyleClass("zBtnBlue");
		Variant_Dialog.addStyleClass("sapUiSizeCompact");
		VDesc_Label.addStyleClass("sapUiTinyMarginTop");
		MPN_Ok_Button.addStyleClass("zBtnBlue");
		MPN_Close_Button.addStyleClass("zBtnBlue");
		MPN_Dialog.addStyleClass("zNDialog sapUiSizeCompact");
		MPN_IconTabBar.addStyleClass("zIconTB");
		MPNBasicClear_Button.addStyleClass("zBtnBlue");
		MPNBasicInfoTB_Text.addStyleClass("appleUiMText");
		MPNInclude_Panel.addStyleClass("appleUiPanelBorderBottom");
		MPNAdvIncAdd_Button.addStyleClass("zBtnBlue");
		MPNAdvClearInc_Button.addStyleClass("zBtnBlue");
		MPNAdvInclude_List.addStyleClass("appleUiMLIBBorderBottom zMPNSOLDToAdvDelBtn");
		MPNAdvInc_Select.addStyleClass("sapUiTinyMarginEnd");
		MPNExclude_Panel.addStyleClass("appleUiPanelBorderBottom");
		MPNAdvExcAdd_Button.addStyleClass("zBtnBlue");
		MPNAdvExcClear_Button.addStyleClass("zBtnBlue");
		MPNAdvExclude_List.addStyleClass("appleUiMLIBBorderBottom zMPNSOLDToAdvDelBtn");
		MPNAdvExc_Select.addStyleClass("sapUiTinyMarginEnd");
		CVCSTOk_Button.addStyleClass("zBtnBlue");
		CVCSTClose_Button.addStyleClass("zBtnBlue");
		CVCST_Dialog.addStyleClass("zNDialog sapUiSizeCompact");
		CVCST_IconTabBar.addStyleClass("zIconTB");
		CVCSTBasicClear_Button.addStyleClass("zBtnBlue");
		CVCSTBasicInfoTB_Text.addStyleClass("appleUiMText");
		CVCSTInclude_Panel.addStyleClass("appleUiPanelBorderBottom");
		CVCSTAdvIncAdd_Button.addStyleClass("zBtnBlue");
		CVCSTAdvClearInc_Button.addStyleClass("zBtnBlue");
		CVCSTAdvInclude_List.addStyleClass("appleUiMLIBBorderBottom zMPNSOLDToAdvDelBtn");
		CVCSTAdvInc_Select.addStyleClass("sapUiTinyMarginEnd");
		CVCSTExclude_Panel.addStyleClass("appleUiPanelBorderBottom");
		CVCSTAdvExcAdd_Button.addStyleClass("zBtnBlue");
		CVCSTAdvExcClear_Button.addStyleClass("zBtnBlue");
		CVCSTAdvExclude_List.addStyleClass("appleUiMLIBBorderBottom zMPNSOLDToAdvDelBtn");
		CVCSTAdvExc_Select.addStyleClass("sapUiTinyMarginEnd");
		CVCSel_Popover.addStyleClass("zMPORadius");
		CVCSel_List.addStyleClass("appleUiMLIBBorderBottom");
		CVCSel_HBox2.addStyleClass("sapUiTinyMarginTop");
		CVCSelStar_Icon2.addStyleClass("sapUiTinyMarginBegin");
		CVCSelGlobal_Icon.addStyleClass("sapUiTinyMarginBeginEnd");
		CVCSel_Text3.addStyleClass("zMTextSize");
		CVCSel_Text3.addStyleClass("sapUiTinyMarginBegin");
		MPNSTPO_HBox.addStyleClass("appleUiHBoxBGGray sapUiTinyMarginTopBottom");
		MPNSTPO_IE.addStyleClass("sapUiTinyMarginTop");
		MPNSTPO_IE.addStyleClass("sapUiTinyMarginBegin");
		MPNSTPO_Id.addStyleClass("sapUiTinyMarginTop");
		MPNSTPO_Id.addStyleClass("sapUiTinyMarginBegin");
		MPNSTPO_Desc.addStyleClass("sapUiTinyMarginTop");
		MPNSTPOList.addStyleClass("appleUiMBarPH");
		MPNSTPOList_HBox.addStyleClass("sapUiTinyMarginTopBottom");
		MPNSTPOList_Sign.addStyleClass("sapUiTinyMarginBegin");
		MPNSTPOList_Low.addStyleClass("sapUiTinyMarginBegin");
		PopoverNew_HBox.addStyleClass("appleUiHBoxBGGray sapUiTinyMarginTopBottom");
		PopoverNew_Id.addStyleClass("sapUiTinyMarginTop");
		PopoverNew_Id.addStyleClass("sapUiTinyMarginBegin");
		PopoverNew_Desc.addStyleClass("sapUiTinyMarginTop");
		PopoverList.addStyleClass("appleUiMBarPH");
		PopoverList_HBox.addStyleClass("sapUiTinyMarginTopBottom");
		PopoverList_Low.addStyleClass("sapUiTinyMarginBegin");
		diaVariantSave.addStyleClass("sapUiSizeCompact");
		lblformVariantVARIANT.addStyleClass("zSFormlbl");
		informVariantVARIANT.addStyleClass("zMInput");
		lblformVariantVTEXT.addStyleClass("zSFormlbl");
		informVariantVTEXT.addStyleClass("zMInput");
		cb_cvc_global.addStyleClass("sapUiMediumMarginBeginEnd");
		cb_cvc_global.addStyleClass("zcheckbox");
		cb_cvc_global.addStyleClass("sapUiSizeCompact");
		cb_cvc_Default.addStyleClass("sapUiSizeCompact");
		cb_cvc_Default.addStyleClass("zcheckbox");
		butVariantProceed.addStyleClass("zBtnBlue");
		butVariantSaveOK.addStyleClass("sapUiSizeCompact");
		butVariantSaveOK.addStyleClass("zBtnBlue");
		butVariantSaveCancel.addStyleClass("sapUiSizeCompact");
		butVariantSaveCancel.addStyleClass("zBtnBlue");
		WU_Ok.addStyleClass("sapUiSizeCompact");
		WU_Ok.addStyleClass("zBtnBlue");
		WU_Close.addStyleClass("zBtnBlue");
		WU_Close.addStyleClass("sapUiSizeCompact");
		update_wave_property.addStyleClass("zNDialog sapUiSizeCompact");
		WP_VBox.addStyleClass("sapUiSmallMarginBegin");
		wave_nr_txt.addStyleClass("ztext");
		oWavenr.addStyleClass("zMInput");
		wave_desc_txt.addStyleClass("ztext1");
		oInputDisc.addStyleClass("zMInput");
		oHBoxREVsch.addStyleClass("zwProfile");
		oHBoxREVsch.addStyleClass("sapUiNoMargin");
		oVBoxWaveRel.addStyleClass("sapUiNoMargin");
		oSchFormR2.addStyleClass("sapUiSizeCompact");
		oSchFormR2.addStyleClass("zWaveParForm");
		oSchFormR2.addStyleClass("sapUiSmallMarginTop");
		oLblRrelsch.addStyleClass("zSFormlbl");
		wave_rel_type.addStyleClass("zMSelect");
		oVBoxWaveReld.addStyleClass("sapUiNoMargin");
		oSchFormWaveReld.addStyleClass("sapUiSizeCompact");
		oSchFormWaveReld.addStyleClass("zWaveParForm");
		oSchFormWaveReld.addStyleClass("sapUiSmallMarginTop");
		oLblWaveRelTime.addStyleClass("zSFormlbl");
		oinpoWaveRelTime.addStyleClass("zMInput");
		WUClose_Button.addStyleClass("zBtnBlue");
		WUProceed_Button.addStyleClass("zBtnBlue");
		diaWaveUP.addStyleClass("zNDialog sapUiSizeCompact");
		oIconTabBarSdwnload.addStyleClass("zIconTB");
		Panel_create.addStyleClass("zPanel zMarginBottom0");
		WUCreate_Label.addStyleClass("zMLabelReg");
		oWaveFileUpCr.addStyleClass("zBtnBlue");
		WUCreateUpload_Btn.addStyleClass("zBtnBlue");
		WUCreateUpload_Btn.addStyleClass("sapUiTinyMarginBegin");
		Panel_temp_create.addStyleClass("zPanel zMarginBottom0");
		WUCreateDow_Label.addStyleClass("zMLabelReg");
		oInpoSFormSdwnloadcrwcr.addStyleClass("zMInput");
		ButDown.addStyleClass("zBtnBlue");
		ButDown.addStyleClass("sapUiTinyMarginBegin");
		Panel_change2.addStyleClass("zPanel");
		WUChange_Label.addStyleClass("zMLabelWU");
		oWaveFileUpChange.addStyleClass("zBtnBlue");
		WUChangeUpload_Btn.addStyleClass("zBtnBlue");
		WUChangeUpload_Btn.addStyleClass("sapUiTinyMarginBegin");
		Panel_change.addStyleClass("zPanel");
		ChgUFrom_Label.addStyleClass("zMLabelWU");
		WaveFromInp.addStyleClass("zMInput");
		ChgUTo_Label.addStyleClass("zMLabelWU");
		ChgUTo_Label.addStyleClass("sapUiTinyMarginBegin");
		WaveToInp.addStyleClass("sapUiTinyMarginBegin");
		WaveToInp.addStyleClass("zMInput sapUiTinyMarginEnd");
		ButDownch.addStyleClass("zBtnBlue");
		ButDownch.addStyleClass("sapUiSmallMarginBegin");
		oUBPButCancel.addStyleClass("zBtnBlue");
		oUBPProceed_Button.addStyleClass("zBtnBlue");
		oDialogUBP.addStyleClass("zNDialog sapUiSizeCompact");
		Panel_UBP.addStyleClass("zPanelWaveUp zPanel zMarginBottom0");
		oUBPFileUploader.addStyleClass("zBtnBlue");
		oUBPUpload.addStyleClass("zBtnBlue");
		oUBPUpload.addStyleClass("sapUiTinyMarginBegin");
		UBPDownload_Link.addStyleClass("sapUiTinyMarginTop");
		oPPUButCancel.addStyleClass("zBtnBlue");
		oPPUProceed_Button.addStyleClass("zBtnBlue");
		oDialogPLAPOR_UPD.addStyleClass("zNDialog sapUiSizeCompact");
		Panel_PPU.addStyleClass("zPanelWaveUp zPanel zMarginBottom0");
		oPPUreg_Label.addStyleClass("zMLabelReg");
		oPPUVBox1.addStyleClass("sapUiMediumMarginBegin");
		oPPUweek_Label.addStyleClass("zMLabelReg");
		oPPU_Week.addStyleClass("zSecProf");
		oVBoxppu.addStyleClass("sapUiTinyMarginTop");
		oPPUFileUploader.addStyleClass("zBtnBlue");
		oPPUUpload.addStyleClass("zBtnBlue");
		oPPUUpload.addStyleClass("sapUiTinyMarginBegin");
		PPUDW_Link.addStyleClass("sapUiTinyMarginTop");
		oPGUButCancel.addStyleClass("zBtnBlue");
		oPGUProceed_Button.addStyleClass("zBtnBlue");
		oDialogPLAGATP_UPD.addStyleClass("zNDialog sapUiSizeCompact");
		Panel_PGU.addStyleClass("zPanelWaveUp zPanel zMarginBottom0");
		oPGUreg_Label.addStyleClass("zMLabelReg");
		oPGUVBox1.addStyleClass("sapUiMediumMarginBegin");
		oPGUweek_Label.addStyleClass("zMLabelReg");
		oPGU_Week.addStyleClass("zSecProf");
		oVBoxPGU.addStyleClass("sapUiTinyMarginTop");
		oPGUFileUploader.addStyleClass("zBtnBlue");
		oPGUUpload.addStyleClass("zBtnBlue");
		oPGUUpload.addStyleClass("sapUiTinyMarginBegin");
		PGUDW_Link.addStyleClass("sapUiTinyMarginTop");
		CWPageCustomHdr_bar.addStyleClass("appleUiHdrBG appUiHdrHeight appleUiHdrSize appleUiHdrMBar");
		CWInfoH_Icon.addStyleClass("sapUiSmallMarginEnd");
		DWPageCustomHdr_bar.addStyleClass("appleUiHdrBG appUiHdrHeight appleUiHdrSize appleUiHdrMBar");
		DWInfoH_Icon.addStyleClass("sapUiSmallMarginEnd");
		WaveSetup_Panel.addStyleClass("zPanelProfile");
		oDispSFormProfile.addStyleClass("sapUiSizeCompact");
		oDispSFormProfile.addStyleClass("zForm");
		oDispSFormProfile.addStyleClass("sapUiNoMargin");
		CVC_Panel.addStyleClass("zPanelCVC zPanelCVCPC zMarginBottom0");
		SSHdr_Label.addStyleClass("sapUiSmallMarginBegin");
		SSHdr_Label.addStyleClass("zcvclabel");
		Variant_Icon.addStyleClass("sapUiTinyMarginBegin");
		SSCVC_Label.addStyleClass("zMLabelB");
		SSCVC_Label.addStyleClass("sapUiLargeMarginBegin");
		CVC_HBox.addStyleClass("zVBoxBorder zMargins");
		OPSSubclass_VBox.addStyleClass("sapUiTinyMarginBegin");
		OPSSubclass_Table.addStyleClass("appleDispUiTable");
		MPN_VBox.addStyleClass("sapUiTinyMarginBegin");
		MPNCVC_SearchField.addStyleClass("zSearchFieldM");
		MPNSR_Icon.addStyleClass("sapUiSmallMarginEnd");
		MPNResults_Table.addStyleClass("appleDispUiTable");
		SalesOrgCVC_VBox.addStyleClass("sapUiTinyMarginBegin");
		SalesOrgCVC_Table.addStyleClass("appleDispUiTable");
		DistC_VBox.addStyleClass("sapUiTinyMarginBegin");
		DistC_Table.addStyleClass("appleDispUiTable");
		SoldToCVC_VBox.addStyleClass("sapUiTinyMarginBegin");
		STHdr_SearchField.addStyleClass("zSearchFieldM");
		STHdr_Icon.addStyleClass("sapUiSmallMarginEnd");
		SoldToCVCResults_Table.addStyleClass("appleDispUiTable");
		Strg_Panel.addStyleClass("zPanelProfile");
		DMWaveStrategy_Label.addStyleClass("zSSLabel");
		DMWaveStg_Label.addStyleClass("zMLabelB");
		DMWaveStg_Label.addStyleClass("sapUiLargeMarginBegin");
		StrgMain_VBox.addStyleClass("sapUiNoMargin");
		Strategy_HBox.addStyleClass("zStrategy");
		oStrgMain_Form1.addStyleClass("sapUiSizeCompact");
		oStrgMain_Form1.addStyleClass("zForm");
		oStrgMain_Form1.addStyleClass("sapUiNoMargin");
		WaveStrategy_Label.addStyleClass("zSFormlbl");
		NoOfWaves_Label.addStyleClass("zSFormlbl");
		IR_CheckBox.addStyleClass("zCB");
		StrategyImportData_HBox.addStyleClass("zVBoxBorder zMargins1");
		StrategyImportData_HBox.addStyleClass("sapUiNoMargin");
		WSWaveCum_VBox.addStyleClass("sapUiTinyMarginBegin");
		WaveCum_Table.addStyleClass("appleDispUiTable");
		WSWaveCumBase_VBox.addStyleClass("sapUiTinyMarginBegin");
		WaveCumBase_Table.addStyleClass("appleDispUiTable");
		SourcingPlant_VBox.addStyleClass("sapUiTinyMarginBegin");
		SourcingPlant_Table.addStyleClass("appleDispUiTable");
		SalesOrg_VBox.addStyleClass("sapUiTinyMarginBegin");
		SalesOrg_Table.addStyleClass("appleDispUiTable");
		DWSoldTo_VBox.addStyleClass("sapUiTinyMarginBegin");
		StrgSoldTo_Table.addStyleClass("appleDispUiTable");
		PQ_VBox.addStyleClass("sapUiTinyMarginBegin");
		PQ_Table.addStyleClass("appleDispUiTable");
		Schd_Panel.addStyleClass("zPanelProfile");
		DWSchedule_Label.addStyleClass("zSSLabel");
		oSchFormR.addStyleClass("sapUiSizeCompact");
		oSchFormR.addStyleClass("zForm");
		oLblRwavecre.addStyleClass("zSFormlbl");
		ReleaseTime_Label.addStyleClass("zSFormlbl");
		oSchFormRschat.addStyleClass("sapUiTinyMarginTop");
		oSchFormRschat.addStyleClass("zForm");
		oSchFormRschat.addStyleClass("sapUiSizeCompact");
		ScheduleAt_Label.addStyleClass("zSFormlbl");
		AddTime_Label.addStyleClass("zSFormlbl");
		MulSch_Table.addStyleClass("appleUiMLIBBorderBottom");
		Repeats_Label.addStyleClass("zSFormlbl");
		Till_Label.addStyleClass("zSFormlbl");
		Every_Label.addStyleClass("zSFormlbl");
		Days_Label.addStyleClass("zSFormlbl sapUiSmallMarginBegin");
		oSWeeklyAlloc_List.addStyleClass("sapUiTinyMarginBegin");
		W_2M.addStyleClass("sapUiTinyMarginBegin");
		W_3T.addStyleClass("sapUiTinyMarginBegin");
		W_4W.addStyleClass("sapUiTinyMarginBegin");
		W_5T.addStyleClass("sapUiTinyMarginBegin");
		W_6F.addStyleClass("sapUiTinyMarginBegin");
		W_7S.addStyleClass("sapUiTinyMarginBegin");
		StrgSelVarInfoHdr_Text.addStyleClass("sapUiSmallMarginBegin");
		StrgSelVarInfoHdr_Text.addStyleClass("sapUiSmallMarginTopBottom");
		sap.ui.getCore().attachInit(function () {
			setTimeout(function () {
				createODataWS();
				createODataVariant();
				createODataWB();
				createODataRCA();
				sap.ui.core.BusyIndicator.hide();
			}, 150);
		});

		sap.n.AppDestroy = function () {
			AppDestroy();
		}
		return Shell;
	}
});
//# sourceURL=ZUI_DAT_WORKBENCH_WAVES.view.js