if(typeof neptune === "undefined")neptune={};
neptune.Debug = {
	console: {},
    timestamp: null,
    ext: 0,
    init: false,
    initLog: [],
    loaded: function() {},
    add: function(type, msg, stackTrace) {},
    updateInitLog: function() {},
    activate: function() {},
    deactivate: function() {},
	getStackTrace: function(args) {}
};
