sap.ui.define([
		"sap/ui/core/UIComponent",
		"sap/ui/Device",
		"com/apple/ui/zuidatwavewb/model/models",
		"sap/ui/model/json/JSONModel"
	],
	function (UIComponent, Device, models, JSONModel) {
		"use strict";

		return UIComponent.extend("com.apple.ui.zuidatwavewb.Component", {
			metadata: {
				manifest: "json"
			},

			/**
			 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
			 * @public
			 * @override
			 */
			init: function () {
				// call the base component's init function
				UIComponent.prototype.init.apply(this, arguments);

				// enable routing
				this.getRouter().initialize();

				// set the device model
				this.setModel(models.createDeviceModel(), "device");

				var dataSources = this.getManifestEntry("/sap.app/dataSources");
				// var 

				for (var service in dataSources) {
					// skip loop if the property is from prototype
					if (!dataSources.hasOwnProperty(service)) continue;

					var iService = dataSources[service];
					var serviceAlias = "";
					if (service !== "mainService") {
						serviceAlias = service;
					}
					this.loadMetadata(iService.uri, serviceAlias);

				}

				var oViewModel,
					that = this;

				oViewModel = new JSONModel({
					bBusy: true,
					delay: 0,
					appId: that.appId
				});

				this.setModel(oViewModel, "busyModel");

				this.getModel().attachRequestSent(function () {
					that.getModel("busyModel").setProperty("/bBusy", true);
				});
				this.getModel().attachRequestCompleted(function () {
					that.getModel("busyModel").setProperty("/bBusy", false);
				});
				this.getModel("busyModel").refresh(true);
			},
			loadMetadata: function (sUri, sAlias) {
				var oParameters = {
					defaultOperationMode: "Server",
					defaultBindingMode: "OneWay",
					defaultCountMode: "Request"

				};

				var oModel = new sap.ui.model.odata.v2.ODataModel(sUri, oParameters);
				if (sAlias !== "") {
					this.setModel(oModel, sAlias);
				} else {
					this.setModel(oModel);
				}
			}
		});
	}
);