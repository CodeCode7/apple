/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"comappleui/zui_dat_wave_wb/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
