sap.ui.define([
	"comappleui/zui_dat_wave_wb/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
