sap.ui.define([
    'sap/ui/core/Fragment',
    "sap/ui/model/json/JSONModel"

], function (Fragment, JsonModel) {
    "use strict";

    return {
        init: function (cReference) {
            this.cReference = cReference;
        },

        initialiseCvcModel: function () {
            this.cReference.cvcModel = new JsonModel();
            this.cReference.getView().setModel(this.cReference.cvcModel, "cvcModel");
            this.cReference.cvcModel.setProperty("/selOptions", [{ "key": "CP", "text": "contains" }, { "key": "EQ", "text": "equals" }, { "key": "BW", "text": "begins with" }, { "key": "EW", "text": "ends with" }]);
            this.cReference.selectionHelper = {
                "MPN": {
                    "I": { "modelRef": "/MPNIncListData", "countPropRef": "/MPNinclCount" },
                    "E": { "modelRef": "/MPNExcListData", "countPropRef": "/MPNexclCount" },
                    "Basic": { "modelRef": "/mpnData", "searchProp": "/MPNSearchField", "TableId": "MPNBasic_Table", "SelCountProp": "/selCountMPN" },
                    "DialogId": "MPN_Dialog",
                    "Token": { "inclModelRef": "/MPNTokenIncl", "exclModelRef": "/MPNTokenExcl" },
                    "MultiInpId": "oinpoSFormCVCMPN",
                    "iconTabBarKeyProp": "/MPNSelTab"
                },
                "SoldTo": {
                    "I": { "modelRef": "/CVCSTIncListData", "countPropRef": "/CVCSTinclCount" },
                    "E": { "modelRef": "/CVCSTExcListData", "countPropRef": "/CVCSTexclCount" },
                    "Basic": { "modelRef": "/soldToData", "searchProp": "/SoldToSearchField", "TableId": "SoldToBasic_Table", "SelCountProp": "/selCountSoldTo" },
                    "DialogId": "CVCST_Dialog",
                    "Token": { "inclModelRef": "/SoldToTokenIncl", "exclModelRef": "/SoldToTokenExcl" },
                    "MultiInpId": "oinpoSFormCVCSoldTo",
                    "iconTabBarKeyProp": "/SoldToSelTab"
                }
            };
            this.cReference.cvcModel.setProperty("/selCountMPN", 0);
            this.cReference.cvcModel.setProperty("/selCountSoldTo", 0);
        },

        setVariantToMultiInput: function (identifier, hasBasicData) {
            var mModel = this.cReference.selectionHelper[identifier];
            this.onClearBasic(identifier);
            this.cReference.cvcModel.setProperty(mModel.iconTabBarKeyProp, 'Basic');

            var mControl = this.cReference.getView().byId(mModel.MultiInpId);

            if (hasBasicData) {
                var basicData = this.cReference.cvcModel.getProperty(mModel.Token.inclModelRef);
                var txtin = 'Inc' + '(' + basicData.length + ')';
                this.addToken(mControl, identifier, "Include", txtin, basicData);
            }

            //advance tab include
            var mpnAdvInc = this.cReference.cvcModel.getProperty(mModel.I.modelRef);
            if (mpnAdvInc.length > 0) {
                var txtin = 'Inc' + '(' + mpnAdvInc.length + ')';
                this.addToken(mControl, identifier, "Include", txtin, mpnAdvInc);
            } else {
                this.onOptionsClear(mModel.I.modelRef, 'I', mModel.I.countPropRef)
            }

            var mpnAdvExc = this.cReference.cvcModel.getProperty(mModel.E.modelRef);
            if (mpnAdvExc.length > 0) {
                var txtex = 'Exc' + '(' + mpnAdvExc.length + ')';
                this.addToken(mControl, identifier, "Exclude", txtex, mpnAdvExc);

            } else {
                this.onOptionsClear(mModel.E.modelRef, 'E', mModel.E.countPropRef)
            }

        },

        addToken: function (control, sourceId, key, tokenText, listElements) {
            var that = this;
            control.addToken(new sap.m.Token({
                key: key,
                text: tokenText,
                select: function (oEvent) {
                    that.openTokenPopover(oEvent, sourceId, listElements);
                },
                delete: function () {
                    //Refresh related CVC Token model
                    let selKey = this.getProperty("key");
                    let propName = (selKey === "Exclude") ? "exclModelRef": "inclModelRef";
                    let modelRef = that.cReference.selectionHelper[sourceId].Token[propName];
                    that.cReference.cvcModel.setProperty(modelRef, []);
                }
            }));
        },

        onOptionsAdd: function (modelRef, iSign, isNew, iOption, iType) {
            if (!iOption)
                iOption = 'CP';

            if (!iType)
                iType = 'A';

            var xd = {
                Selname: '',
                Kind: '',
                Sign: iSign,
                Option: iOption,
                Low: '',
                High: '',
                Txtsh: '',
                Type: iType
            };

            let listArray;

            if (isNew) {
                listArray = [xd];
            } else {
                listArray = this.cReference.cvcModel.getProperty(modelRef);
                listArray.push(xd);
            }

            this.cReference.cvcModel.setProperty(modelRef, listArray);
        },

        onOptionsClear: function (modelRef, iType, countPropName) {
            this.onOptionsAdd(modelRef, iType, true);
            this.setOptionsTitle('Initial', modelRef, countPropName);
        },

        onClearBasic: function (identifier) {
            var basicModel = this.cReference.selectionHelper[identifier].Basic;

            let inputId = this.cReference.getView().byId(basicModel.TableId);
            let countProp = basicModel.SelCountProp;
            if (inputId) {
                //Clear all the Basic selected data
                if (inputId.getItems().length > 0) {
                    for (var i = 0; i < inputId.getItems().length; i++) {
                        inputId.getItems()[i].setSelected(false);
                    }
                }

                this.cReference.onTableSelectionChange(null, countProp, inputId);
            } else {
                this.cReference.cvcModel.setProperty(countProp, 0);
            }
        },

        onChangeAdvInput: function (modelRef, countPropName) {
            this.setOptionsTitle('NotInitial', modelRef, countPropName);
        },

        setOptionsTitle: function (iState, modelRef, countPropName) {
            var count = 0;
            if (iState !== 'Initial') {
                var list = this.cReference.cvcModel.getProperty(modelRef);
                for (let rec of list) {
                    if (!(rec.Low == undefined
                        || rec.Low == null
                        || rec.Low == '')) {
                        count++;
                    }
                }
            }
            this.cReference.cvcModel.setProperty(countPropName, count);
        },

        optionsTextFormatter: function (option) {
            if (typeof option === "undefined"
                || option === null
                || option === "") {
                return option;
            } else {
                if (option == 'CP') {
                    return 'Contains';
                } else if (option == 'EQ') {
                    return 'Equals';
                } else if (option == 'BW') {
                    return 'Begins with';
                } else if (option == 'EW') {
                    return 'Ends with';
                }
            }
        },

        openTokenPopover: function (oEvent, tokenId, listData) {
            var src = oEvent.getSource();
            var oView = this.cReference.getView();
            var that = this.cReference;
            this.cReference.cvcModel.setProperty("/tokenID", tokenId);
            this.cReference.cvcModel.setProperty("/TokenList", listData);
            this.cReference.cvcModel.setProperty("/tokenSearch", '');

            if (!this.cReference.tokenPopover) {
                Fragment.load({
                    id: oView.getId(),
                    name: "com.apple.ui.zuidatwavewb.fragment.TokenPopover",
                    controller: this.cReference
                }).then(function (oPopover) {
                    oView.addDependent(oPopover);
                    that.tokenPopover = oPopover;
                    oPopover.openBy(src);
                });
            } else {
                this.cReference.tokenPopover.openBy(src);
            }
        },
        onHandleLiveChangeFilter: function (oEvent, controlId, filterFields) {
            var usrtxt = oEvent.getParameter("newValue");
            var control = this.cReference.getView().byId(controlId);
            var oBinding = control.getBinding("items");
            var aFilters = [];

            for (let field of filterFields) {
                aFilters.push(new sap.ui.model.Filter(field, "Contains", usrtxt));
            }

            var filter = new sap.ui.model.Filter({
                filters: aFilters,
                and: false
            });
            oBinding.filter([filter]);
        },
        setUpDialogInitialData: function (identifier) {
            //Set Up initial Data
            var model = this.cReference.selectionHelper[identifier];
            var src = this.cReference.getView().byId(model.MultiInpId);

            var len = src.getTokens().length;
            if (len == 0) { //no Tokens
                //Basic Tab
                this.onClearBasic(identifier);
                //advance tab
                this.onOptionsClear(model.I.modelRef, 'I', model.I.countPropRef); //Incl list
                this.onOptionsClear(model.E.modelRef, 'E', model.E.countPropRef); //Excl list
            } else {
                var incTokenExists = false,
                    excTokenExists = false;

                var incTokenList = this.cReference.cvcModel.getProperty(model.Token.inclModelRef);
                var excTokenList = this.cReference.cvcModel.getProperty(model.Token.exclModelRef);
                if (incTokenList.length > 0)
                    incTokenExists = true;
                if (excTokenList.length > 0)
                    excTokenExists = true;

                //Now populate based on token - Include token exists then
                if (incTokenExists) { //token inc exists
                    if (incTokenList[0].Type === 'B') {
                        //Data in Incl token list is of Basic Data
                        var basicTable = this.cReference.getView().byId(model.Basic.TableId);
                        var basicItems = basicTable.getItems();
                        var incMap = new Map([]);

                        for (let incItem of incTokenList) {
                            incMap.set(incItem.Low, incItem.Low);
                        }

                        for (let item of basicItems) {
                            let itemData = item.getBindingContext('cvcModel').getObject();

                            if (incMap.has(itemData.Low)) {
                                item.setSelected(true);
                            } else {
                                item.setSelected(false);
                            }
                        }

                        this.cReference.cvcModel.setProperty(model.iconTabBarKeyProp, 'Basic');
                        // var iconTabBar = this.cReference.getView().byId(model.iconTabBarId);
                        // iconTabBar.setSelected('Basic');
                    } else
                        this.cReference.cvcModel.setProperty(model.iconTabBarKeyProp, 'Advanced');
                } else {
                    this.onOptionsClear(model.I.modelRef, 'I', model.I.countPropRef); //Incl list

                }

                if (!excTokenExists) {
                    this.onOptionsClear(model.E.modelRef, 'E', model.E.countPropRef); //Excl list
                }
            }

        },
        onVHRequestCVCMultiInp: function (dialogId, identifier) {
            var oProfileForm_Profile = this.cReference.getView().byId("oProfileForm_Profile");
            if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() == '') {
                sap.m.MessageToast.show('Please select valid wave profile');
            } else {
                //Load Dialog
                var oView = this.cReference.getView();
                var that = this;
                if (!this.cReference[dialogId]) {
                    Fragment.load({
                        id: oView.getId(),
                        name: "com.apple.ui.zuidatwavewb.fragment." + dialogId,
                        controller: that.cReference
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        that.cReference[dialogId] = oDialog;
                        that.setUpDialogInitialData(identifier);
                        that.cReference[dialogId].open();
                    });
                } else {
                    this.setUpDialogInitialData(identifier);
                    this.cReference[dialogId].open();
                }
            }
        },

        onHandleMultiInpClose: function (isError, identifier) {
            //Check if change validation is required?
            var model = this.cReference.selectionHelper[identifier];
            this.cReference.cvcModel.setProperty(model.Basic.searchProp, '');
            this.cReference.getView().byId(model.Basic.TableId).getBinding("items").filter([]);
            if (!isError)
                this.cReference[model.DialogId].close();
        },

        chgMultiInput: function (inputId) {
            var bReturn = true;
            var control = this.cReference.getView().byId(inputId);
            if (control === undefined || control.getValue() == undefined || control.getValue() == null ||
                control.getValue() == '') {
                control.setValueState('None');
                control.setValueStateText('');
            } else {
                control.setValueState('Error');
                control.setValueStateText('Manual entry is not allowed.');
                bReturn = false;
            }
            return bReturn;
        },

        onListItemDelete: function (oEvent, modelRef, countPropName) {
            var index = oEvent.getParameters().listItem.getBindingContext('cvcModel').sPath.split('/')[2];
            var model = this.cReference.cvcModel.getProperty(modelRef);
            model.pop(index);
            this.cReference.cvcModel.setProperty(modelRef, model);
            this.setOptionsTitle('NotInitial', modelRef, countPropName);
        },

        lz_MultiInpValidate: function (basicData, advIncData, advExcData) {
            var advIncHasData = false, advExcHasData = false;
            var bReturn = true;
            //Check if advance Inc has data
            var advIncAnyAstic = false, advExcAnyAstic = false;
            for (var i = 0; i < advIncData.length; i++) {
                var incData = advIncData[i];
                if (incData.Low == undefined
                    || incData.Low == null
                    || incData.Low == '') {
                } else {
                    advIncHasData = true;
                    if (incData.Low.includes('*')) {
                        advIncAnyAstic = true;
                    }
                }
            }
            //Check if advance Exc has data.
            for (var i = 0; i < advExcData.length; i++) {
                var excData = advExcData[i];
                if (excData.Low == undefined
                    || excData.Low == null
                    || excData.Low == '') {
                } else {
                    advExcHasData = true;
                    if (excData.Low.includes('*')) {
                        advExcAnyAstic = true;
                    }
                }
            }
            if ((basicData.length > 0)
                && (advIncHasData || advExcHasData)) {
                sap.m.MessageToast.show('Please use either Basic or Advanced Selection');
                bReturn = false;
            }
            if (bReturn) {
                if (advIncAnyAstic
                    || advExcAnyAstic) {
                    sap.m.MessageToast.show('* not allowed');
                    bReturn = false;
                }
            }
            return { "isValid": bReturn, "advIncHasData": advIncHasData, "advExcHasData": advExcHasData };
        },

        onHandleMultiInpOk: function (identifier) {
            var dialogModel = this.cReference.selectionHelper[identifier]
            var basicTable = this.cReference.getView().byId(dialogModel.Basic.TableId);

            var basicData = basicTable.getSelectedItems();
            var advIncData = this.cReference.cvcModel.getProperty(dialogModel.I.modelRef);
            var advExcData = this.cReference.cvcModel.getProperty(dialogModel.E.modelRef);
            var addTokens = false;

            //Check if advance Inc has data
            var validationRes = this.lz_MultiInpValidate(basicData, advIncData, advExcData),
                advIncHasData = validationRes.advIncHasData,
                advExcHasData = validationRes.advExcHasData;

            if (validationRes.isValid) {
                addTokens = true;
                this.cReference.cvcModel.setProperty(dialogModel.Token.inclModelRef, []);
                this.cReference.cvcModel.setProperty(dialogModel.Token.exclModelRef, []);
                if (basicData.length == 0
                    && advIncHasData == false
                    && advExcHasData == false) {//both does not have data
                } else {
                    if (basicData.length > 0) {
                        for (var i = 0; i < basicData.length; i++) {
                            var td = basicData[i].getBindingContext("cvcModel").getObject();
                            var xd = {
                                Selname: '',
                                Kind: '',
                                Sign: 'I',
                                Option: 'EQ',
                                Low: td.Low,
                                High: '',
                                Txtsh: td.Txtsh,
                                Type: 'B'
                            };
                            this.cReference.cvcModel.getProperty(dialogModel.Token.inclModelRef).push(xd);
                        }
                    } else {
                        if (advIncHasData) {
                            for (var i = 0; i < advIncData.length; i++) {
                                var incD = advIncData[i];
                                if (incD.Low == undefined
                                    || incD.Low == null
                                    || incD.Low == '') {
                                } else {
                                    var xd = {
                                        Selname: '',
                                        Kind: '',
                                        Sign: 'I',
                                        Option: incD.Option,
                                        Low: incD.Low,
                                        High: '',
                                        Txtsh: incD.Txtsh,
                                        Type: 'A'
                                    };
                                    this.cReference.cvcModel.getProperty(dialogModel.Token.inclModelRef).push(xd);
                                }
                            }
                        }
                        if (advExcHasData) {
                            for (var i = 0; i < advExcData.length; i++) {
                                var excD = advExcData[i];
                                if (excD.Low == undefined
                                    || excD.Low == null
                                    || excD.Low == '') {
                                } else {
                                    var xd = {
                                        Selname: '',
                                        Kind: '',
                                        Sign: 'E',
                                        Option: excD.Option,
                                        Low: excD.Low,
                                        High: '',
                                        Txtsh: excD.Txtsh,
                                        Type: 'A'
                                    };
                                    this.cReference.cvcModel.getProperty(dialogModel.Token.exclModelRef).push(xd);
                                }
                            }
                        }
                    }
                }

                //Destroy TOKENS
                var multiInput = this.cReference.getView().byId(dialogModel.MultiInpId);
                multiInput.destroyTokens();
                var incD = this.cReference.cvcModel.getProperty(dialogModel.Token.inclModelRef);
                var incE = this.cReference.cvcModel.getProperty(dialogModel.Token.exclModelRef);
                var lTxtin = 'Inc(' + incD.length + ')';
                var lTxtex = 'Exc(' + incE.length + ')';
                if (incD.length > 0) {
                    this.addToken(multiInput, identifier, "Include", lTxtin, incD);
                }
                if (incE.length > 0) {
                    this.addToken(multiInput, identifier, "Exclude", lTxtex, incE);
                }

                this.onHandleMultiInpClose(!addTokens, identifier);
            }
        },

        resetData: function () {
            var opsDropdown = this.cReference.getView().byId("oinpoSFormCVCOPS");

            opsDropdown.removeAllItems(); //OPS Drop down
            opsDropdown.destroyItems();

            this.resetMultiInput("oinpoSFormCVCMPN", "MPN", "mpnData", true); //MPN
            this.resetMultiInput("oinpoSFormCVCSoldTo", "SoldTo", "soldToData", true); //Sold-to

            //Sales Org
            this.cReference.getView().byId("oinpoSFormCVCSales").removeAllItems();

            //Channel
            this.cReference.getView().byId("oinpoSFormCVCChan").removeAllItems();

            //reset selection text
            var MPNBasicInfoTB_Text = this.cReference.getView().byId("MPNBasicInfoTB_Text");
            if (MPNBasicInfoTB_Text) { MPNBasicInfoTB_Text.setText(''); }

            var CVCSTBasicInfoTB_Text = this.cReference.getView().byId("CVCSTBasicInfoTB_Text");
            if (CVCSTBasicInfoTB_Text) { CVCSTBasicInfoTB_Text.setText(''); }

            this.cReference.sModel.setProperty("/CVCSelLabel", '');
            this.cReference.sModel.setProperty("/oSatSwitchVal", false);
        },

        resetMultiInput: function (fieldId, category, basicModel, clearValue) {
            var oMInput = this.cReference.getView().byId(fieldId);
            oMInput.destroyTokens();

            if (basicModel)
                this.cReference.cvcModel.setProperty("/" + basicModel, []); //Initialise basic list model 

            this.clearOptionsModels(category); //Initialise Inclusive and Exclusive lists

            if (clearValue) {
                oMInput.setValue() == '';
                oMInput.setValueState('None');
                oMInput.setValueStateText('');
                this.cReference.cvcModel.setProperty("/selCount" + category, 0); //Selected count reset
            }
        },

        clearOptionsModels: function (category) {
            var model = this.cReference.selectionHelper[category];
            for (let obj in model) {
                if (obj === 'I' || obj === 'E') {
                    let subModel = model[obj];
                    this.onOptionsClear(subModel.modelRef, obj, subModel.countPropRef);
                }
            }
        },
        lz_cvcValidate: function () {
            var bReturn = true;
            var mpnRet = this.chgMultiInput("oinpoSFormCVCMPN");
            var soldToRet = this.chgMultiInput("oinpoSFormCVCSoldTo");
            if (mpnRet == false || soldToRet == false) {
                bReturn = false;
                if (mpnRet == false && soldToRet == false) {
                    sap.m.MessageToast.show('Manual entry is not allowed - MPN & Sold To');
                } else {
                    if (mpnRet == false) {
                        sap.m.MessageToast.show('Manual entry is not allowed - MPN');
                    } else if (soldToRet == false) {
                        sap.m.MessageToast.show('Manual entry is not allowed - Sold To');
                    }
                }

            }
            return bReturn;
        }
    };

});
