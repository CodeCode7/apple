sap.ui.define([
    'sap/ui/core/Fragment',
    "sap/ui/model/json/JSONModel"

], function (Fragment, JsonModel) {
    "use strict";

    return {
        init: function (cReference) {
            this.cReference = cReference;
        },
        onInitialiseGrid: function () {
            this.cReference.gridModel = new JsonModel();
            this.cReference.getView().setModel(this.cReference.gridModel, "gridModel");
            //Model for Aggr_Select control
            this.cReference.gridModel.setProperty("/aggrOptions",
                [{ key: 'SHIP_PLAN_ROLL', text: 'Roll Ship Plan' }, { key: 'SHIP_PLAN_QTY_CW', text: 'Ship Plan' },
                { key: 'SHIP_PLAN_QTY_CW_1', text: 'Ship Plan 1' }, { key: 'SHIP_PLAN_QTY_CW_2', text: 'Ship Plan 2' },
                { key: 'SHIP_PLAN_QTY_CW_3', text: 'Ship Plan 3' }, { key: 'SAT_ALLOCATION', text: 'SAT Allocation' }]);
            this.cReference.gridModel.setProperty("/aggrSelKey", "SHIP_PLAN_QTY_CW");
            sessionStorage.Aggr_Select = 'SHIP_PLAN_QTY_CW';

            this.cReference.gridModel.setProperty("/isLocked", false);

            this.uploadSelHelper = {
                'UP_Wave': 'UpWaveDialog',
                'UPUBP': 'UBPDialog',
                'UPPLA_POR': 'PORDialog',
                'UPPLA_GATP': 'GATPDialog'
            };

            this.cReference.gFilterOptions = {
                buttons: ['reset'],
                inRangeInclusive: true,
                filterOptions: [{
                    displayKey: 'cequals',
                    displayName: 'Equals',
                    test: function (filterValue, cellValue) {
                        return cellValue == filterValue;
                    },
                }, {
                    displayKey: 'cnotEqual',
                    displayName: 'Not Equals',
                    test: function (filterValue, cellValue) {
                        return cellValue != filterValue;
                    },
                }, {
                    displayKey: 'clessThan',
                    displayName: 'Less Than',
                    test: function (filterValue, cellValue) {
                        return cellValue < filterValue;
                    },
                }, {
                    displayKey: 'clessThanOrEqual',
                    displayName: 'Less Than or Equal',
                    test: function (filterValue, cellValue) {
                        return cellValue <= filterValue;
                    },
                }, {
                    displayKey: 'cgreaterThan',
                    displayName: 'Greater Than',
                    test: function (filterValue, cellValue) {
                        return cellValue > filterValue;
                    },
                }, {
                    displayKey: 'cgreaterThanOrEqual',
                    displayName: 'Greater Than or Equal',
                    test: function (filterValue, cellValue) {
                        return cellValue >= filterValue;
                    },
                },
                    'inRange'
                ],
            };

            this.cReference.gGridOptions = {
                columnDefs: '',
                rowData: '',
                autoGroupColumnDef: '',
                groupHeaderHeight: 35,
                defaultColDef: {
                    flex: 1,
                    minWidth: 100,
                    // allow every column to be aggregated
                    enableValue: true,
                    // allow every column to be grouped
                    enableRowGroup: true,
                    // allow every column to be pivoted
                    enablePivot: true,
                    sortable: true,
                    filter: true,
                    resizable: true
                },
                enableRangeSelection: true,
                animateRows: true,
                suppressRowClickSelection: true,
                rowSelection: 'multiple',
                groupSelectsChildren: true,
                groupSelectsFiltered: true,
                groupMultiAutoColumn: true,
                suppressAggFuncInHeader: true,
                suppressExcelExport: false,
                suppressColumnVirtualisation: true,
                statusBar: {
                    statusPanels: [{
                        statusPanel: 'agTotalAndFilteredRowCountComponent',
                        key: 'totalAndFilter',
                        align: 'left'
                    }, {
                        statusPanel: 'agSelectedRowCountComponent',
                        align: 'left'
                    }, {
                        statusPanel: 'agAggregationComponent',
                        align: 'right'
                    }]
                },
                rowSelection: 'multiple', // one of ['single','multiple'], leave blank for no selection
                rowDeselection: true,
                groupSelectsChildren: true,
                sideBar: {
                    toolPanels: [{
                        id: 'columns',
                        labelDefault: 'Columns',
                        labelKey: 'columns',
                        iconKey: 'columns',
                        toolPanel: 'agColumnsToolPanel',
                        toolPanelParams: {
                            syncLayoutWithGrid: true
                        }
                    }, {
                        id: 'filters',
                        labelDefault: 'Filters',
                        labelKey: 'filters',
                        iconKey: 'filter',
                        toolPanel: 'agFiltersToolPanel',
                        toolPanelParams: {
                            syncLayoutWithGrid: true
                        }
                    }],
                    position: 'right',
                    defaultToolPanel: 'columns'
                },
                isExternalFilterPresent: this.isExternalFilterPresent,
                doesExternalFilterPass: this.doesExternalFilterPass,
                getMainMenuItems: this.getMainMenuItems,
                excelStyles: [{
                    id: 'C3',
                    interior: {
                        color: '#FFCC01',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C5',
                    interior: {
                        color: '#34C759',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C6',
                    interior: {
                        color: '#FF3B30',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C7',
                    interior: {
                        color: '#9B9500',
                        pattern: 'Solid',
                    },
                }]
            };

            this.cReference.gByWaveGridOptions = {
                columnDefs: '',
                rowData: '',
                autoGroupColumnDef: '',
                groupHeaderHeight: 35,
                defaultColDef: {
                    flex: 1,
                    minWidth: 100,
                    // allow every column to be aggregated
                    enableValue: true,
                    // allow every column to be grouped
                    enableRowGroup: true,
                    // allow every column to be pivoted
                    enablePivot: true,
                    sortable: true,
                    filter: true,
                    resizable: true
                },
                enableRangeSelection: true,
                animateRows: true,
                suppressRowClickSelection: true,
                rowSelection: 'multiple',
                groupSelectsChildren: false,
                groupSelectsFiltered: false,
                groupMultiAutoColumn: true,
                suppressAggFuncInHeader: true,
                suppressExcelExport: false,
                suppressColumnVirtualisation: true,
                getMainMenuItems: this.getMainMenuItems,
                statusBar: {
                    statusPanels: [{
                        statusPanel: 'agTotalAndFilteredRowCountComponent',
                        key: 'totalAndFilter',
                        align: 'left'
                    }, {
                        statusPanel: 'agSelectedRowCountComponent',
                        align: 'left'
                    }, {
                        statusPanel: 'agAggregationComponent',
                        align: 'right'
                    }]
                },
                rowSelection: 'multiple', // one of ['single','multiple'], leave blank for no selection
                rowDeselection: true,
                groupSelectsChildren: false,
                sideBar: {
                    toolPanels: [{
                        id: 'columns',
                        labelDefault: 'Columns',
                        labelKey: 'columns',
                        iconKey: 'columns',
                        toolPanel: 'agColumnsToolPanel',
                        toolPanelParams: {
                            syncLayoutWithGrid: true
                        }
                    }, {
                        id: 'filters',
                        labelDefault: 'Filters',
                        labelKey: 'filters',
                        iconKey: 'filter',
                        toolPanel: 'agFiltersToolPanel',
                        toolPanelParams: {
                            syncLayoutWithGrid: true
                        }
                    }],
                    position: 'right',
                    defaultToolPanel: 'columns',
                },
                excelStyles: [{
                    id: 'C3',
                    interior: {
                        color: '#FFCC01',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C5',
                    interior: {
                        color: '#34C759',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C6',
                    interior: {
                        color: '#FF3B30',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'C7',
                    interior: {
                        color: '#9B9500',
                        pattern: 'Solid',
                    },
                }, {
                    id: 'custHeader',
                    font: {
                        size: 14,
                    },
                }]
            };

            let xGrid = document.querySelector('#xsGrid');
            if (xGrid != null) {
                xGrid.remove();
                this.cReference.gGridOptions.rowData = [];
            }

            //Saving in sessionStorage for event for availability in events isExternalFilterPresent & doesExternalFilterPass
            sessionStorage.setItem('gEXTFilter', '');
        },
        
        resetByWaveGrid: function () {
            //destroy ag-grid not done yet.
            var xGrid = document.querySelector('#xWaveGrid');
            if (xGrid != null) {
                xGrid.remove();
                this.cReference.gGridOptions.rowData = [];
            }
        },

        onChangeAggrOptions: function (oEvent) {
            sessionStorage.Aggr_Select = oEvent.getSource().getSelectedKey();
            this.gGridOptions.api.redrawRows();
            this.gGridOptions.api.refreshClientSideRowModel('aggregate');
        },
        onSatSwitchChange: function (oEvent) {
            var extFilter;
            if (oEvent.getParameter('state')) {
                extFilter = 'SAT';
            } else {
                extFilter = '';
            }

            sessionStorage.setItem('gEXTFilter', extFilter);
            //Invoke filter change
            this.gGridOptions.api.onFilterChanged();

        },
        /*External Filter logic */
        isExternalFilterPresent: function () {
            //if SAT filter is pressed
            return sessionStorage.gEXTFilter != '';
        },

        doesExternalFilterPass: function (node) {
            switch (sessionStorage.gEXTFilter) {
                case 'SAT':
                    var satAlloc = 0;
                    if (node.data.SAT_ALLOCATION != undefined) {
                        satAlloc = node.data.SAT_ALLOCATION;
                    }
                    return satAlloc > 0;
                    break;

                default:
                    return true;
                    break;
            }
        },

        getMainMenuItems: function (params) {
            var menuItems = [];

            for (var i = 0; i < params.defaultItems.length; i++) {
                var menuItem = params.defaultItems[i];
                if (menuItem != 'resetColumns') {
                    menuItems.push(menuItem);
                }
            }
            return menuItems;
        },

        onUploadFragmentOption: function (reference) {
            reference.setUpInitialData(reference.selKey);
            reference.fragmentOpen(reference.uploadSelHelper[reference.selKey], "com.apple.ui.zuidatwavewb.fragment.upload." + reference.uploadSelHelper[reference.selKey]);
            //WUError_Table.getModel().setData([]);

            // reference.openUploadFrag(reference.selKey);
            //check and open this up --- TODO
            // //Tab
            // oIconTabBarSdwnload.setVisible(true);
            // oIconTabBarSdwnload.setSelectedKey('Create');
            // //Create tab
            // WUCreateUpload_Btn.setVisible(true);
            // Create_MessageStrip.setVisible(false);
            // Create_MessageStrip.setText('Upload has 200 errors');
            // //Create Upload field
            // oWaveFileUpCr.setValue('');

            // //Change tab
            // Change_MessageStrip.setVisible(false);
            // //Error Panel
            // WUError_Panel.setVisible(false);
            // //Dialog footer buttons
            // WUProceed_Button.setVisible(false);
            // oWaveFileUpChange.setValue('');
            // WaveFromInp.setValue('');
            // WaveToInp.setValue('');

            // var jModel = new sap.ui.model.json.JSONModel();
            // jModel.setData([]);
            // WUError_Table.setModel(jModel);
            // WUError_Table.getModel().refresh();

            // diaWaveUP.open(); // CHECK FOR SELECTED KEY AND THEN OPEN THE RESPECTIVE FRAGMENT
            //begin of DV5K930819
        },

        onUploadMenuItemSelected: function (oEvent) {
            var oProfileForm_Profile = this.getView().byId("oProfileForm_Profile");
            this.gridUtil.selKey = oEvent.getParameter('item').getKey();

            if (oProfileForm_Profile.getSelectedKey()) {
                this.datui_lock_check('Rollover is in progress, Please try after some time', this.gridUtil.onUploadFragmentOption);
            } else {
                sap.m.MessageToast.show('Please select Wave Profile');
            }

        },
        setUpInitialData: function (selKey) {
            // 'UP_Wave': 'UpWaveDialog',
            // 'UPUBP': 'UBPDialog',
            // 'UPPLA_POR': 'PORDialog',
            // 'UPPLA_GATP': 'GATPDialog'

            switch (selKey) {
                case 'UPUBP':
                    //User Base Plan
                    this.initialiseUBP();
                    break;
            }
        },
        initialiseUBP: function () {
            //Set default region
            if (this.cReference.gWaveProfileSelRegion == 'EURO'
                || this.cReference.gWaveProfileSelRegion == 'EMEA') {
                this.cReference.gridModel.setProperty('/SelectedRegion', 'EMEA_MPN');
            } else {
                if (this.cReference.gWaveProfileSelRegion == 'PAC'
                    || this.cReference.gWaveProfileSelRegion == 'APAC') {
                    this.cReference.gridModel.setProperty('/SelectedRegion', 'APAC');
                } else {
                    this.cReference.gridModel.setProperty('/SelectedRegion', this.cReference.gWaveProfileSelRegion);
                }
            }

            this.cReference.gridModel.setProperty("/isMStripVisible", false);
            this.cReference.gridModel.setProperty("/mStripText", '');
            this.cReference.gridModel.setProperty("/isErrPanelVisible", false);
            this.cReference.gridModel.setProperty("/isInitialScreen", true);

            this.cReference.gUBPUploadFile = '';
            //Initialise error table TODO
        },

        dialogClose: function (oEvent) {
            oEvent.getSource().getParent().close(); //Close the dialog
        },

        onUBPUploadClose: function (oEvent) {
            this.gUBPUploadFile = '';
            this.gridUtil.dialogClose(oEvent);
        },

        fragmentOpen: function (dialogId, fragmentPath) {
            var that = this.cReference;
            var oView = that.getView();
            if (!that[dialogId]) {
                Fragment.load({
                    id: oView.getId(),
                    name: fragmentPath,
                    controller: that
                }).then(function (oDialog) {
                    oView.addDependent(oDialog);
                    that[dialogId] = oDialog;
                    oDialog.open();
                });
            } else {
                that[dialogId].open();
            }
        },

        onGridVariantPress: function (tabSelected, cReference) {
            if (tabSelected == 'KPROFILE') {
                cReference.gridModel.setProperty("/gridVariant", cReference.gridModel.getProperty("/gridVariantP"));
                cReference.gridModel.setProperty("/default", cReference.gridModel.getProperty("/defaultP"));
                cReference.gridModel.setProperty("/global", cReference.gridModel.getProperty("/globalP"));
            } else if (tabSelected == 'KWAVE') {
                cReference.gridModel.setProperty("/gridVariant", cReference.gridModel.getProperty("/gridVariantW"));
                cReference.gridModel.setProperty("/default", cReference.gridModel.getProperty("/defaultW"));
                cReference.gridModel.setProperty("/global", cReference.gridModel.getProperty("/globalW"));
            }
            cReference.gridModel.setProperty("/gridVariantValueState", "None");
            this.fragmentOpen('gridVariantDialog', 'com.apple.ui.zuidatwavewb.fragment.variant.gridVariant');
        },

        openWaveParameterDialog: function (reference) {
            //Initialise
            reference.cReference.gridModel.setProperty("/WPWaveNr", '');
            reference.cReference.gridModel.setProperty("/WPWaveDesc", '');
            reference.cReference.gridModel.setProperty("/WaveRelType", 'D');
            reference.cReference.gridModel.setProperty("/isWaveRelTimeVisible", false)

            //open Fragment
            reference.fragmentOpen('UpdateWaveDialog', 'com.apple.ui.zuidatwavewb.fragment.UpdateWaveDialog');
        },

        onChangeWaveRelType: function (oEvent) {
            let selKey = oEvent.getSource().getSelectedKey();
            (selKey === 'T') ? this.gridModel.setProperty("/isWaveRelTimeVisible", true) : this.gridModel.setProperty("/isWaveRelTimeVisible", false);
        },

        onWaveParameterPress: function () {
            this.datui_lock_check('Rollover is in progress, Please try after some time', this.gridUtil.openWaveParameterDialog);
        },

        onWaveParameterOk: function () {
            var oWavenr = this.gridModel.getProperty("/WPWaveNr");
            var oWaveRelType = this.gridModel.getProperty("/WaveRelType");
            var oWaveRelTime = this.getView().byId("dateTimeUW").getValue();
            //  var oWaveRelTime = this.gridModel.getProperty("/WaveRelTime");
            var oWaveDesc = this.gridModel.getProperty("/WPWaveDesc");

            if (oWavenr === '') {
                sap.m.MessageToast.show('Enter valid wave number');
                return;
            }

            if (oWaveRelType === 'T') {
                if (!oWaveRelTime) {
                    sap.m.MessageToast.show('Please specify Date & Time');
                    return;
                }
            }

            let oProfileForm_Profile = this.getView().byId("oProfileForm_Profile");
            let oProfileForm_Week = this.getView().byId("oProfileForm_Week");
            var that = this;

            var xGridObj = {
                Secprofile: oProfileForm_Profile.getSelectedKey(),
                Fisweek: oProfileForm_Week.getSelectedKey(),
                WaveNr: oWavenr,
                WaveRelMech: oWaveRelType,
                WaveDescr: oWaveDesc,
                ScheduleAt: oWaveRelTime,
                Retcode: '0',
                Func: 'RC',
            };

            sap.ui.core.BusyIndicator.show(0);
            var cPromise = new Promise(function (resolve, reject) {
                that.gRollModel.create('/wave_propSet', xGridObj, {
                    success: function (oData) {
                        resolve(oData);
                    },
                    error: function (oError) {
                        reject(oError);
                    }
                });
            });

            cPromise.then(
                function (res) {
                    //Success
                    if (res.Retcode == '0') {
                        if (res.Func == "") {
                            sap.m.MessageToast.show('Authorization Error');
                            that.UpdateWaveDialog.close();
                        } else {
                            if (res.Func) {
                                var Msg = 'Data saved successfully';
                            } else {
                                var Msg = 'No authorization';
                            }
                            that.UpdateWaveDialog.close();
                            sap.m.MessageToast.show(Msg);
                            that.getGridData();
                        }

                    } else {
                        that.UpdateWaveDialog.close();
                        if (res.Message != '')
                            sap.m.MessageToast.show(res.Message);
                        else
                            sap.m.MessageToast.show('Data not saved successfully');

                    }
                    sap.ui.core.BusyIndicator.hide();
                },
                function (oError) {
                    //Error
                    sap.ui.core.BusyIndicator.hide();
                    that.UpdateWaveDialog.close();
                    sap.m.MessageToast.show('Data not saved successfully');
                });
        },
        onDownloadBtnPress: function () {
            var Aggr_Select = this.getView().byId("Aggr_Select");

            var xDate = new Date();
            var fTime;
            var xHours = xDate.getHours();
            if (xHours.toString().length == 1) {
                xHours = '0' + xHours.toString();
            }
            var xMin = xDate.getMinutes();
            if (xMin.toString().length == 1)
                xMin = '0' + xMin.toString();
            var xSec = xDate.getSeconds();
            if (xSec.toString().length == 1)
                xSec = '0' + xSec.toString();
            var fTime = xHours.toString() + xMin.toString() + xSec.toString();
            var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;
            var xTargetPlan = Aggr_Select.getSelectedItem().getText();
            xTargetPlan = 'Target Plan: ' + xTargetPlan;

            if (this.gGridOptions != undefined) {
                this.gGridOptions.api.exportDataAsExcel({
                    customHeader: [
                        [],
                        [{
                            styleId: 'custHeader',
                            data: {
                                type: 'String',
                                value: xTargetPlan
                            },
                            mergeAcross: 2
                        },],
                        [],
                    ],
                    fileName: 'DAT_RCA_Profile_' + tmDt,
                    processRowGroupCallback: this.gridUtil.rowGroupCallback,

                });
            }
        },
         onWaveDownloadPress() {
            var xDate = new Date();
            var fTime;
            var xHours = xDate.getHours();
            if (xHours.toString().length == 1) {
                xHours = '0' + xHours.toString();
            }
            var xMin = xDate.getMinutes();
            if (xMin.toString().length == 1)
                xMin = '0' + xMin.toString();
            var xSec = xDate.getSeconds();
            if (xSec.toString().length == 1)
                xSec = '0' + xSec.toString();
            var fTime = xHours.toString() + xMin.toString() + xSec.toString();
            var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;
        
            if (this.gGridOptions != undefined) {
                this.gByWaveGridOptions.api.exportDataAsExcel({
                    fileName: 'DAT_RCA_Wave_' + tmDt,
                    processRowGroupCallback: this.rowGroupCallback,
                });
            }
            var that = this;
            //begin of DV5K930019
            //Download Run Log
            setTimeout(() => {
                that.gridUtil.downloadRun();
            }, 1000);
            //end of DV5K930019
        },
         downloadRun: function() {
            if (this.cReference.gRunlog != undefined && this.cReference.gRunlog != null) {
                if (this.cReference.gRunlog.length > 0) {
                    var str;
                    var aFilters = [];
                    var aWaveDown = [];
                    var aColumns = [{
                        name: "MessageType",
                        template: {
                            content: "{MessageType}"
                        }
                    }, {
                        name: "GatingMessage",
                        template: {
                            content: "{GatingMessage}"
                        }
                    }, ];
    
                    var dataStr = "data:text/csv;charset=utf-8,";
                    var aXBinding = [];
                    var iCount = 0;
                    for (var i = 0; i < aColumns.length; i++) {
                        iCount++;
                        if (iCount == aColumns.length) {
                            dataStr += aColumns[i].name;
                        } else {
                            dataStr += aColumns[i].name + ',';
                        }
                        var aS1 = aColumns[i].template.content.split('{')[1];
                        var aS2 = aS1.split('}')[0];
                        aXBinding.push(aS2);
                    }
                    dataStr += "\n";
                    var iCount = 0;
                    for (var i = 0; i < gRunlog.length; i++) {
                        iCount++;
                        var vd = gRunlog[i];
                        for (var x = 0; x < aXBinding.length; x++) {
                            var y = x + 1;
                            if (y == aXBinding.length) {
                                str = vd[aXBinding[x]];
                                var res = str.replace(/,/g, ';');
                                vd[aXBinding[x]] = res;
                                if (vd[aXBinding[x]] == undefined) {
                                    dataStr += "";
                                } else {
                                    dataStr += vd[aXBinding[x]];
                                }
                            } else {
                                if (vd[aXBinding[x]] == undefined) {
                                    dataStr += "";
                                } else {
                                    dataStr += vd[aXBinding[x]] + ",";
                                }
                            }
                        }
                        dataStr += "\n";
                    }
    
                    var xDate = new Date();
                    var fTime;
                    var xHours = xDate.getHours();
                    if (xHours.toString().length == 1) {
                        xHours = '0' + xHours.toString();
                    }
                    var xMin = xDate.getMinutes();
                    if (xMin.toString().length == 1)
                        xMin = '0' + xMin.toString();
                    var xSec = xDate.getSeconds();
                    if (xSec.toString().length == 1)
                        xSec = '0' + xSec.toString();
                    var fTime = xHours.toString() + xMin.toString() + xSec.toString();
                    var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;
                    var encodedUri = encodeURI(dataStr);
                    var aTag = document.createElement('a');
                    aTag.setAttribute("href", encodedUri);
                    aTag.setAttribute("download", 'DAT_RCA_Wave_RUNLOG_' + tmDt + ".csv");
                    aTag.innerHTML = "Click Here to download";
                    aTag.click();
                    aTag.remove();
                    sap.ui.core.BusyIndicator.hide();
                }
            }
        },
    
        rowGroupCallback: function (params) {
            return params.node.key;
        },
        oSelectGridvarWaveChange: function (oEvent, tableName) {
            let varnt = oEvent.getSource().getSelectedKey();
            this.cReference.processGRIDVariant(varnt, tableName);
        },
        onWaveReleasePress: function () {
            //Validation
            if (!this.gridUtil.validateWeekSelected())
                return;

            this.gridUtil.actionType = 'WAVE_REL';
            this.gridUtil.fragmentOpen('waveRelDialog', 'com.apple.ui.zuidatwavewb.ReleaseWave');
        },
        onWaveReleaseOk: function () {
            this.gridUtil.okActionNow(this, true);
            this.waveRelDialog.close();
        },

        onRollOverPress: function () {
            //Validation
            if (!this.gridUtil.validateWeekSelected())
                return;

            //Init Rollover
            this.gridModel.setProperty("/isROWaveNumVisible", false);
            //Open Dialog
            this.gridUtil.fragmentOpen('rollOverDialog', 'com.apple.ui.zuidatwavewb.fragment.RollOver');
        },
        onRollOverOptionsChange: function (oEvent) {
            let selKey = oEvent.getSource().getSelectedKey();
            if (selKey === 'C')
                this.gridModel.setProperty("/isROWaveNumVisible", true);
            else
                this.gridModel.setProperty("/isROWaveNumVisible", false);
        },
        onRollOverOk: function () {
            let oView = this.getView();
            let rolloverOptions = oView.byId("rolloverOptions");
            let roWaveNum = oView.byId("roWaveNum");
            var that = this;

            var l_roll = rolloverOptions.getSelectedKey();
            var val = roWaveNum.getValue();

            if (l_roll == "C" && val == "") {
                sap.m.MessageBox.show('Please provide the Wave number for Rollover Option C', {
                    title: "Error",
                    actions: [sap.m.MessageBox.Action.OK]
                });
            }

            if (l_roll != "C" || val != "") {
                let oProfileForm_Profile = oView.byId("oProfileForm_Profile");
                let oProfileForm_Week = oView.byId("oProfileForm_Week");

                //odata-call
                var xGridObj = {
                    Secprofile: oProfileForm_Profile.getSelectedKey(),
                    Fisweek: oProfileForm_Week.getSelectedKey(),
                    WaveNr: roWaveNum.getValue(),
                    RollOpt: rolloverOptions.getSelectedKey(),
                    retcode: '0',
                    Func: 'RC',
                    Nav_to_pluids: []
                };

                //Grid selection Data
                if (this.gGridOptions.api) {
                    var agGridSelRows = this.gGridOptions.api.getSelectedRows();
                    if (agGridSelRows.length > 0) {//selected something in grid
                        for (var i = 0; i < agGridSelRows.length; i++) {
                            var gd = agGridSelRows[i];
                            var xd = {
                                Pluid: gd.PLUID
                            };
                            xGridObj.Nav_to_pluids.push(xd);
                        }
                    }
                }

                var isSuccess = false;
                var res = [];
                sap.ui.core.BusyIndicator.show(0);

                var cPromise = $.Deferred();
                this.gRollModel.create('/Wave_dataSet', xGridObj, {
                    success: function (oData) {
                        res = oData;
                        isSuccess = true;
                        cPromise.resolve();
                    },
                    error: function () {
                        sap.m.MessageToast.show('Error in Rollover');
                        sap.ui.core.BusyIndicator.hide();
                        // cPromise.resolve();
                    }
                });
                cPromise.then($.proxy(function () {
                    if (isSuccess) {
                        if (res.retcode == '0') {
                            sap.m.MessageBox.show('Data saved successfully', {
                                title: "Success",
                                actions: [sap.m.MessageBox.Action.OK],
                                onClose: function (oAction) {
                                    if (oAction == 'OK') {
                                        that.rollOverDialog.close();
                                        that.getGridData();
                                    }
                                }
                            });
                        } else {
                            if (res.Func) {
                                var Msg = 'Data not saved successfully';
                            } else {
                                var Msg = 'No authorization';
                            }

                            sap.m.MessageBox.show(Msg, {
                                title: "Error",
                                actions: [sap.m.MessageBox.Action.OK],
                                onClose: function (oAction) {
                                    if (oAction == 'OK') {
                                        that.rollOverDialog.close()
                                    }
                                }
                            });
                        }

                    } else {
                        sap.m.MessageBox.show('Data not saved successfully', {
                            title: "Error",
                            actions: [sap.m.MessageBox.Action.OK],
                            onClose: function (oAction) {
                                if (oAction == 'OK') {
                                    that.rollOverDialog.close();
                                }
                            }
                        });
                    }
                    sap.ui.core.BusyIndicator.hide();
                }));

            }
        },

        onGridVariantSave: function () {
            // Checks
            var variant = this.gridModel.getProperty("/gridVariant");
            if (!variant) {
                this.gridModel.setProperty("/gridVariantValueState", "Error");
                return;
            } else {
                this.gridModel.setProperty("/gridVariantValueState", "None");
            }

            let IconTabBar = this.getView().byId("IconTabBar");
            let lv_tab = IconTabBar.getSelectedKey();
            switch (lv_tab) {
                case "KPROFILE":
                    this.gridUtil.saveGRIDVariant(variant, "AG_GRID_PROF", this.gGridOptions, lv_tab);
                    break;
                case "KWAVE":
                    this.gridUtil.saveGRIDVariant(variant, "AG_GRID_WAVE", this.gByWaveGridOptions,lv_tab);
            }
            this.gridVariantDialog.close();
        },

        saveGRIDVariant: function (variant, tableName, gridOptions, selTab) {
            var autocol = [];
            var selectedcolumnsposition;
            var allColumnIds = [];

            // columns
            gridOptions.columnApi.getAllDisplayedColumns().forEach(function (column) {
                var l_gr = column.colId.includes("AutoColumn");

                if (l_gr === false) {
                    allColumnIds.push(column.colId);
                    // check pin columns
                    if (column.isPinned()) {
                        var pinval = column.getPinned();
                        var lpinid = 'AGGRIDPIN.' + pinval + '.' + column.colId;
                        selectedcolumnsposition = lpinid + "#" + selectedcolumnsposition;
                    } else {
                        selectedcolumnsposition = column.colId + "#" + selectedcolumnsposition;
                    }
                } else {
                    if (column.isPinned()) {
                        autocol = column.colId.split("-");
                        var vln = autocol.length - 1;
                        var Apinval = column.getPinned();
                        var Alpinid = 'AGGRIDAUTOPIN.' + Apinval + '.' + autocol[vln];
                        selectedcolumnsposition = Alpinid + "#" + selectedcolumnsposition;
                    }
                }
            });

            // RowGroupColumns
            gridOptions.columnApi.getRowGroupColumns().forEach(function (row) {
                var lrowid = 'AGGRIDROWGRP.' + row.colId;
                selectedcolumnsposition = lrowid + "#" + selectedcolumnsposition;
            });

            //ColumnGroups
            gridOptions.columnApi.getAllDisplayedColumnGroups().forEach(function (colgr) {
                var vAllChildren = [];
                var vDisChildren = [];
                var vColGroupDef = colgr.getOriginalColumnGroup().getColGroupDef();
                if (vColGroupDef) {
                    vAllChildren = colgr.getOriginalColumnGroup().getChildren();
                    vDisChildren = colgr.getDisplayedChildren();
                    if (vAllChildren.length === vDisChildren.length) {
                        var lcolid = 'AGGRIDCOLGRP.' + colgr.groupId;
                        selectedcolumnsposition = lcolid + "#" + selectedcolumnsposition;
                    }
                }
            });

            var lv_default = (this.cReference.gridModel.getProperty("/default")) ? 'X' : '';
            var lv_global = (this.cReference.gridModel.getProperty("/global")) ? 'X' : '';
            var lv_delete = (this.cReference.gridModel.getProperty("/delete")) ? 'X' : '';

            var xGridObj = {
                AppName: 'ZUI_DAT_RCA',
                TableName: tableName,
                Variant: variant,
                Columns: selectedcolumnsposition,
                Global: lv_global,
                Default: lv_default,
                Delete: lv_delete
            };

            var that = this;
            this.cReference.gAGridVarModel.create('/ColumnSet', xGridObj, {
                success: function () {
                    that.cReference.getGRIDVariant(tableName, "");
                    let oView = that.cReference.getView();
                    switch (selTab) {
                        case "KPROFILE":
                            oView.byId("oSelectGridvarProf").setSelectedKey(variant);
                            break;
                        case "KWAVE":
                            oView.byId("oSelectGridvarWave").setSelectedKey(variant);
                            break;
                    }

                    if (lv_delete === 'X') {
                        sap.m.MessageToast.show("Variant Deleted!");
                    } else {
                        sap.m.MessageToast.show("Variant saved!");
                    }
                },
                error: function () {
                    sap.m.MessageToast.show("Variant not saved");
                }
            });
        },
        validateWeekSelected: function () {
            let oProfileForm_Week = this.cReference.getView().byId("oProfileForm_Week");

            //Validation
            if (oProfileForm_Week.getSelectedKey() === 'PAST') {
                sap.m.MessageToast.show('Action not now allowed for past week');
                return false;
            }

            if (!this.cReference.gGridOptions.api) {
                sap.m.MessageToast.show('Please select Intersections');
                return false;
            }

            let agGridSelRows = this.cReference.gGridOptions.api.getSelectedRows();
            if (agGridSelRows.length <= 0) {
                sap.m.MessageToast.show('Please select Intersections');
                return false;
            }

            return true;
        },

        onGridActionPress: function (actionType) {
            this.cReference.gridUtil.actionType = actionType;
            if (!this.validateWeekSelected())
                return;

            this.cReference.datui_lock_check('Rollover is in progress, Please try after some time', this.actionDialogOpen);
        },

        dialogOnTheFly: function (reference, dText, successCallBack) {
            var dialog = new sap.m.Dialog({
                title: 'Confirm',
                type: 'Message',
                content: new sap.m.Text({ text: dText }),
                beginButton: new sap.m.Button({
                    text: 'OK',
                    press: function () {
                        successCallBack(reference.cReference);
                        dialog.close();
                    }

                }).addStyleClass('zButton'),
                endButton: new sap.m.Button({
                    text: 'Cancel',
                    press: function () {
                        dialog.close();
                    }

                }).addStyleClass('zButton'),
                afterClose: function () {
                    dialog.destroy();
                }
            }).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
            dialog.open();
        },
        actionDialogOpen: function (reference) {
            reference.gridActionHelper = {
                "CW_BYPASS": 'Sending all CW SAT allocation to GATP. DAT will be deactivated for this CVC for remainder of CW.',
                "SEND_ZERO": 'Do you want to execute "Send Zero Wave" Functionality?'
            };
            var confirmText = reference.gridActionHelper[reference.actionType];
            // var confirmText = config.
            reference.dialogOnTheFly(reference, confirmText, reference.okActionNow);
        },

        okActionNow: function (that, waveNumExists) {
            let oProfileForm_Profile = that.getView().byId("oProfileForm_Profile");
            let oProfileForm_Week = that.getView().byId("oProfileForm_Week");

            sap.ui.core.BusyIndicator.show(0);

            var xGridObj = {
                Secprofile: oProfileForm_Profile.getSelectedKey(),
                Fisweek: oProfileForm_Week.getSelectedKey(),
                WaveNr: (waveNumExists) ? that.gridModel.getProperty("/WaveNumRW") : '',
                Type: that.gridUtil.actionType,
                Retcode: '0',
                Func: 'RC',
                Navpluid: []
            };

            if (that.gGridOptions.api) {
                var agGridSelRows = that.gGridOptions.api.getSelectedRows();
                if (agGridSelRows.length > 0) {//selected something in grid
                    for (var i = 0; i < agGridSelRows.length; i++) {
                        var gd = agGridSelRows[i];
                        var xd = {
                            Pluid: gd.PLUID
                        };
                        xGridObj.Navpluid.push(xd);
                    }
                }
            }

            var cPromise = new Promise(function (resolve, reject) {
                that.gRollModel.create('/RCA_PROFILESet', xGridObj, {
                    success: function (oData) {
                        resolve(oData);
                    },
                    error: function (oError) {
                        reject(oError);
                    }
                });
            });

            cPromise.then(
                function (res) {
                    //Success
                    if (res.Retcode == '0') {
                        sap.m.MessageToast.show('Data saved successfully');
                        that.getGridData();
                    } else {
                        if (res.Func) {
                            var Msg = 'Data not saved successfully';
                        } else {
                            var Msg = 'No authorization';
                        }
                        sap.m.MessageToast.show(Msg);
                    }
                    sap.ui.core.BusyIndicator.hide();
                },
                function (oError) {
                    //Error
                    sap.m.MessageToast.show('Data not saved successfully');
                    sap.ui.core.BusyIndicator.hide();
                }
            );
        }
    }
});