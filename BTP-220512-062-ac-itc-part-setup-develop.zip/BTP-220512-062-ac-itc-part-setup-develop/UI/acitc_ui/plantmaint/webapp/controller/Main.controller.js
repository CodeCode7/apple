 sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, JSONModel, MessageBox, Filter, FilterOperator) {
    "use strict";

    return Controller.extend("com.apple.scp.ui.plantmaint.controller.Main", {
        onInit: function () {

            this.oFilterBar = this.getView().byId("filterbar");
            this.oFilterBar._oSearchButton.setText("Search");
            this._GPlant = "";
            this._GPrimarypartNo = "";

        },

        onPlantmainSPCCValueHelpRequested: function () {
            this._PlantmainSPCCValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                "com.apple.scp.ui.plantmaint.fragment.SPCCValueHelpDialog", this);
            this.getView().addDependent(this._PlantmainSPCCValueHelpDialog);
            this._PlantmainSPCCValueHelpDialog.setRangeKeyFields([{
                label: "SPCC",
                key: "SPCC"
            }]);

            this._PlantmainSPCCValueHelpDialog.setTokens(this.getView().byId("multiInputSPCC").getTokens());
            this._PlantmainSPCCValueHelpDialog.open();

        },
        onSPCCValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            this.getView().byId("multiInputSPCC").setTokens(aTokens);
            this._PlantmainSPCCValueHelpDialog.close();
        },
        onPSPCCValueHelpCancelPress: function () {
            this._PlantmainSPCCValueHelpDialog.close();
        },

        onSPCCValueHelpAfterClose: function () {
            this._PlantmainSPCCValueHelpDialog.destroy();
        },

        onSearchPress: function () {
            var multiInputPlant = this.getView().byId("multiInputPlant").getSelectedKey();
            var multiInputBuyerCode = this.getView().byId("multiInputBuyerCode").getSelectedKeys();
            var multiInputPlannerCode = this.getView().byId("multiInputPlannerCode").getSelectedKeys();
            var multiInputSPCC = this.getView().byId("multiInputSPCC").getTokens();
            var multiInputProgramID = this.getView().byId("multiInputProgramID").getSelectedKeys();
            var aFilter = [];
            var aBuyerCodeFilter = [];
            var aPlannerCodeFilter = [];
            var aProgramIDFilter = [];
            var that = this;
            if (multiInputPlant) {

                aFilter.push(new Filter("Plant", FilterOperator.EQ, multiInputPlant));

            }
            if (multiInputBuyerCode.length > 0) {
                multiInputBuyerCode.map(function (oToken) {
                    aBuyerCodeFilter.push(new Filter("BuyerCode", FilterOperator.EQ, oToken));

                });

                var aBuyerCodeFilterMul = new sap.ui.model.Filter({
                    filters: aBuyerCodeFilter,
                    and: false,
                });
                aFilter.push(aBuyerCodeFilterMul);

            }
            if (multiInputPlannerCode.length > 0) {
                multiInputPlannerCode.map(function (oToken) {
                    aPlannerCodeFilter.push(new Filter("PlannerCode", FilterOperator.EQ, oToken));

                });

                var aPlannerCodeFilterMul = new sap.ui.model.Filter({
                    filters: aPlannerCodeFilter,
                    and: false,
                });
                aFilter.push(aPlannerCodeFilterMul);

            }
            if (multiInputSPCC.length > 0) {
                multiInputSPCC.map(function (oToken) {
                    aFilter.push(new Filter("SPCC", FilterOperator.EQ, oToken.getText().substring(1).toUpperCase()));

                });

            }
            if (multiInputProgramID.length > 0) {
                multiInputProgramID.map(function (oToken) {
                    aProgramIDFilter.push(new Filter("ProgramID", FilterOperator.EQ, oToken));

                });

                var aProgramIDFilterMul = new sap.ui.model.Filter({
                    filters: aProgramIDFilter,
                    and: false,
                });
                aFilter.push(aProgramIDFilterMul);

            }

            if (multiInputPlant.length == "0") {
                MessageBox.error("Plant cannot be blank");
            } else if (multiInputPlannerCode.length == "0") {
                MessageBox.error("Planner Code  cannot be blank");
            } else {
              
                var oPrimaryPartSetModel = new JSONModel();
                this.getView().setModel(oPrimaryPartSetModel, "oPrimaryPartSetModel");
                this.getView().getModel().read("/PrimaryPartSet", {
                    filters: aFilter,

                    success: function (oData) {

                        if (oData.results.length > 0) {
                            oPrimaryPartSetModel.setData(oData)

                            that.onSelectPartIndex(oData.results[0].PrimaryPartNumber, oData.results[0].Plant);
                            that.getView().byId("primaryPartTable").setSelectedIndex(0);

                        }

                    },
                    error: function (snItemsError1) {
                        
                        that.getView().byId("primaryPartTable").clearSelection();
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        that._GPlant = "";
                        that._GPrimarypartNo = "";
                        if(that.getView().getModel("oIPrimaryPartSetModel")){
                        that.getView().getModel("oIPrimaryPartSetModel").setData(null);
                        }
                    }
                });
               
            }

        },

        onFilterbarClear: function (oEvent) {
            var oItems = this.oFilterBar.getAllFilterItems(true);
            this._GPlant = "";
            this._GPrimarypartNo = "";
            for (var i = 0; i < oItems.length; i++) {
                var oControl = this.oFilterBar.determineControlByFilterItem(oItems[i]);
                if (oControl.getId() == "container-com.apple.scp.ui.plantmaint---Main--multiInputSPCC") {
                    oControl.removeAllTokens();
                } else if (oControl.getId() == "container-com.apple.scp.ui.plantmaint---Main--multiInputPlant") {
                
                    oControl.setSelectedKey(null);
                } else {
                    
                    oControl.removeSelectedKeys();
                    oControl.setSelectedKeys(null);
                }
            }
        },

        onPartPrimarySelectionChange: function (e) {
            var oIndex = e.getParameter('rowIndex');
            var oTable = this.getView().byId("primaryPartTable");
            if (oTable.isIndexSelected(oIndex)) {
                var oContext = oTable.getContextByIndex(oIndex);
                var path = oContext.sPath;
                var object = oTable.getModel("oPrimaryPartSetModel").getProperty(path);
                var PrimaryPartNumber = object.PrimaryPartNumber;
                var Plant = object.Plant;

                this.onSelectPartIndex(PrimaryPartNumber, Plant);

            }
        },

        onSelectPartIndex: function (PrimaryPartNumber, Plant) {
            var that = this;
            var oIPrimaryPartSetModel = new JSONModel();
            this.getView().setModel(oIPrimaryPartSetModel, "oIPrimaryPartSetModel");
            this.getView().getModel().read("/PrimaryPartSet(PrimaryPartNumber='" + PrimaryPartNumber + "',Plant='" + Plant + "')", {
                urlParameters: {
                    '$expand': "ITCPart"
                },
                success: function (odata) {

                    that._GPlant = odata.Plant;
                    that._GPrimarypartNo = odata.PrimaryPartNumber;

                    var resultArray = odata.ITCPart;

                

                    resultArray.results.forEach((element) => {
                        element.ITCPartNoStatusFlag = 'R'
                    });

                    oIPrimaryPartSetModel.setData(resultArray);

                

                },
                error: function (snItemsError1) {
                    MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                }
            });
        },

        onPressAddNewPart: function () {
            this._AddNewPartDialog = sap.ui.xmlfragment(this.getView().getId(),
                "com.apple.scp.ui.plantmaint.fragment.AddNewPart", this);
            this.getView().addDependent(this._AddNewPartDialog);

            this._AddNewPartDialog.open();
        },

        onAddPartNo: function () {

            this.getView().getModel().setDeferredGroups(["GetAddPartNo"]);
           
            var Payload = {
                "ITCPartNumber": this.getView().byId("idAddPartNo").getValue(),
                "PrimaryPartNumber":this._GPrimarypartNo,
                "Plant":this._GPlant
            };

            this.getView().getModel().callFunction("/GetITCPartNoDetails", {
                urlParameters: Payload,
                method: "GET",
                batchGroupId: "GetAddPartNo"
            });

            var that = this;
           
            this.getView().getModel().submitChanges({
                batchGroupId: "GetAddPartNo",
                async: false,
                success: function (oData, oResponse) {
                    that._ITCDublicateFLag = "";
                    if (oResponse.data.__batchResponses[0].response === undefined) {
                        oData.__batchResponses.forEach((element) => {
                            element.data.ITCPartNoStatusFlag = 'C';
                                element.data.PrimaryPartNumber = that._GPrimarypartNo;
                                element.data.Plant = that._GPlant
                        });
                        var ITCModelData =  that.getView().getModel("oIPrimaryPartSetModel").getData().results;

                        for (var i = 0; i < ITCModelData.length; i++) {
                            if ((ITCModelData[i].Priority == 'R0') && (ITCModelData[i].ITCPartNumber == oData.__batchResponses[0].data.ITCPartNumber)){
                                that._ITCDublicateFLag = "X";
                                break;
                            }

                        }
                        if (that._ITCDublicateFLag != "X") {
                            that.getView().getModel("oIPrimaryPartSetModel").getData().results.push(oData.__batchResponses[0].data);
                            that.getView().getModel("oIPrimaryPartSetModel").refresh(true);
                         
                        }else{
                            MessageBox.error("ITC Part Number already exists")
                        }

                    } else {
                        MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
                    }


                },
                error: function (snItemsError1) {
                    MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);

                }
            });

            this.onCloseAddpart();
        },

        onCloseAddpart: function () {
            this.getView().byId("idAddPartNo").setValue("");
            this._AddNewPartDialog.close();
            this._AddNewPartDialog.destroy();
        },

        onPressSave: function () {

            var oPartNo = this.getView().getModel("oIPrimaryPartSetModel").getData().results;
            var that = this;
            this.getView().getModel().setDeferredGroups(["ITCPartNOGroupID"]);
            this.getView().getModel().sDefaultUpdateMethod = "PUT";

            for (var i = 0; i < oPartNo.length; i++) {

                var partPayloadCreate;
                var partPayloadUpdate;
                var partPayloadDelete;

                if (oPartNo[i].ITCPartNoStatusFlag == "C") {

                    partPayloadCreate = {
                        "PrimaryPartNumber": oPartNo[i].PrimaryPartNumber,
                        "Plant": oPartNo[i].Plant,
                        "CountryOfOrigin": oPartNo[i].CountryOfOrigin,
                        "Priority": oPartNo[i].Priority,
                        "ITCPartNumber": oPartNo[i].ITCPartNumber,
                        "ITCPartNumberDescription": oPartNo[i].ITCPartNumberDescription
                    }
                    this.getView().getModel().create("/ITCPartSet", partPayloadCreate, {
                        groupId: "ITCPartNOGroupID"
                    });

                }

                if (oPartNo[i].ITCPartNoStatusFlag == "U") {
                    partPayloadUpdate = {
                        "PrimaryPartNumber": oPartNo[i].PrimaryPartNumber,
                        "Plant": oPartNo[i].Plant,
                        "CountryOfOrigin": oPartNo[i].CountryOfOrigin,
                        "Priority": oPartNo[i].Priority,
                        "ITCPartNumber": oPartNo[i].ITCPartNumber,
                        "ITCPartNumberDescription": oPartNo[i].ITCPartNumberDescription,
                        "DeletionIndicator": ""
                    }

                    this.getView().getModel().update("/ITCPartSet(PrimaryPartNumber='" + oPartNo[i].PrimaryPartNumber + "',Plant='" + oPartNo[i].Plant +
                        "')", partPayloadUpdate, {

                            groupId: "ITCPartNOGroupID"
                        });

                }

                if (oPartNo[i].ITCPartNoStatusFlag == "D") {
                    partPayloadDelete = {
                        "PrimaryPartNumber": oPartNo[i].PrimaryPartNumber,
                        "Plant": oPartNo[i].Plant,
                        "CountryOfOrigin": oPartNo[i].CountryOfOrigin,
                        "Priority": oPartNo[i].Priority,
                        "ITCPartNumber": oPartNo[i].ITCPartNumber,
                        "ITCPartNumberDescription": oPartNo[i].ITCPartNumberDescription,
                        "DeletionIndicator": "X"
                    }

                    this.getView().getModel().update("/ITCPartSet(PrimaryPartNumber='" + oPartNo[i].PrimaryPartNumber + "',Plant='" + oPartNo[i].Plant +
                        "')", partPayloadDelete, {

                            groupId: "ITCPartNOGroupID"
                        });

                }

            }

            this.getView().getModel().submitChanges({
                groupId: "ITCPartNOGroupID",
                success: function (oData, oResponse) {

                    if (oResponse.data.__batchResponses[0].response === undefined) {
                        MessageBox.success("Success");
                        that.onSelectPartIndex(that._GPrimarypartNo, that._GPlant);

                    } else {
                        MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
                    }
                },
                error: function (oResponse) {
                    MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
                }
            });

        },

        onPriorityChange: function (oEvent) {
            var sNewValue = oEvent.getParameter("value");
            var oPartNo = this.getView().getModel("oIPrimaryPartSetModel").getData();

            var oTable = this.getView().byId("primaryPartTable");
            var path = oEvent.getSource().getParent().getBindingContext("oIPrimaryPartSetModel").getPath();
            var object = oTable.getModel("oIPrimaryPartSetModel").getProperty(path);
            var ITCPartNumber = object.ITCPartNumber;

            oPartNo.results.forEach((element) => {
                if (element.ITCPartNumber == ITCPartNumber) {
                    if (element.ITCPartNoStatusFlag) {
                        if (element.ITCPartNoStatusFlag == "C") {
                            object.Priority = sNewValue;
                            object.ITCPartNoStatusFlag = 'C'
                        } else {
                            object.Priority = sNewValue;
                            object.ITCPartNoStatusFlag = 'U'
                        }

                    } else {
                        object.Priority = sNewValue;
                        object.ITCPartNoStatusFlag = 'U'

                    }

                }

            });

            this.getView().getModel("oIPrimaryPartSetModel").refresh(true);

        },

        onDeletePart: function (oEvent) {

            var oTable = this.getView().byId("primaryPartTable");
            var path = oEvent.getSource().getParent().getBindingContext("oIPrimaryPartSetModel").getPath();
            var object = oTable.getModel("oIPrimaryPartSetModel").getProperty(path);
            if (object.ITCPartNoStatusFlag == "R") {
                object.ITCPartNoStatusFlag = 'D';
            } else if (object.ITCPartNoStatusFlag == "D") {
                object.ITCPartNoStatusFlag = 'R';
            } else {
                object.ITCPartNoStatusFlag = 'R';
            }

            this.getView().getModel("oIPrimaryPartSetModel").refresh(true);

        },
        onPlantSelectionFinish:function(oEvent){
            if (oEvent.getSource().getValue() != "") {
                var onPlantRegionFilter = [];
                var that = this;
                var onPlannerCodesModel = new JSONModel();
                this.getView().setModel(onPlannerCodesModel, "onPlannerCodesModel");
                onPlannerCodesModel.setSizeLimit(20000);
                var selectedItems = oEvent.getSource().getSelectedItem().getKey();
                onPlantRegionFilter.push(new Filter("Plant", FilterOperator.EQ, selectedItems));
                this.getView().getModel().read("/ZC_ACITCPlannerCodes", {
                    filters: onPlantRegionFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            onPlannerCodesModel.setData(oData)
                            onPlannerCodesModel.setSizeLimit(20000);
                        }
                        that.getView().byId("multiInputPlannerCode").setEditable(true);  
                    },
                    error: function (snItemsError1) {
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        that.getView().byId("multiInputPlannerCode").setEditable(false); 
                    }
                });
                    
            }
         else{
            this.getView().byId("multiInputPlannerCode").setEditable(false);  
        } 
            
        },

        onRefresh:function(){
            this.onSelectPartIndex(this._GPrimarypartNo, this._GPlant);
        }

    });
});