sap.ui.define([
	"com/apple/scp/ui/plantmaint/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
