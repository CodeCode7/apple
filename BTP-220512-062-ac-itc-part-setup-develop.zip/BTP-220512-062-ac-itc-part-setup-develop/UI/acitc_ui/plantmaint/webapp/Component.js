sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/ui/plantmaint/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/UriParameters",
    // "com/apple/scp/ui/acitcreports/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel",
],
function (UIComponent, Device, models,JSONModel, UriParameters, ODataModel) {
    "use strict";

    return UIComponent.extend("com.apple.scp.ui.plantmaint.Component", {
        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {

            if (window.parent.location.href.includes("epweb") || window.parent.location.href.includes("acitc") || window.parent.location.href.includes("applicationstudio")) {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
            if (this.isMock) {
                //Start Mock Server
                            this.oMockserver = MockServer.init();
        
                            //Set Mockmodel to Component
                            var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                                json: true
                            });
        
                            this.setModel(oModel);
                            this.bMock = true;
            }else{


        //new 
        fetch("/getAppVariables")
        .then(res => res.json())
        .then(variables => {
            this.appId = variables;
            this.gModelConfig = {
                headers: { appid: variables },
                defaultBindingMode: "TwoWay",
                defaultCountMode: "Inline",
                useBatch: true
            };
            this.ACITCPlantModel = new sap.ui.model.odata.v2.ODataModel("/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv", this.gModelConfig);
            this.setModel(this.ACITCPlantModel);

                    var oViewModel,
                    that = this;

                oViewModel = new JSONModel({
                    bBusy: true,
                    delay: 0
                });
                this.setModel(oViewModel, "busyModel");
                
               
                this.getModel().attachRequestSent(function(){
                    that.getModel("busyModel").setProperty("/bBusy", true);
                });
                this.getModel().attachRequestCompleted(function(){
                    that.getModel("busyModel").setProperty("/bBusy", false);
                });
                this.getModel("busyModel").refresh(true);
            });
        }

    }

    }
    });
}
);