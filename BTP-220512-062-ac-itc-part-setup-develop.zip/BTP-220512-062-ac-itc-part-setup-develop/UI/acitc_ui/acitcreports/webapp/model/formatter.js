sap.ui.define([], function () {
	"use strict";

	return {

		onTimeDispplay: function (sValue) {
			var timeStr;
			if (sValue) {
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "KK:mm:ss a"
				});

				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

				 timeStr = timeFormat.format(new Date(sValue.ms + TZOffsetMs));

			}else{
				timeStr = "";
			}

			return timeStr;
		}

	};

});