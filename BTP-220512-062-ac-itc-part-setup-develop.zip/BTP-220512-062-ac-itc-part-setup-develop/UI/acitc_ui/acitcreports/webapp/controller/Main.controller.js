sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/json/JSONModel',
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "com/apple/scp/ui/acitcreports/model/formatter",
    'sap/ui/export/library'
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, JSONModel, Filter, FilterOperator, MessageBox, Spreadsheet,formatter, exportLibrary) {
    "use strict";
    var EdmType = exportLibrary.EdmType;
    

    return Controller.extend("com.apple.scp.ui.acitcreports.controller.Main", {
        formatter: formatter,
        onInit: function () {
          
            this.oFilterBar1 = this.getView().byId("filterbar1");
            this.oFilterBar2 = this.getView().byId("filterbar2");
            this.oFilterBar3 = this.getView().byId("filterbar3");
            this.oFilterBar1._oSearchButton.setText("Search");
            this.oFilterBar2._oSearchButton.setText("Search");
            this.oFilterBar3._oSearchButton.setText("Search");
            this.oDateFormatUTC = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "yyyy-MM-dd",
                UTC: false
            });
            this._FromDate = "";
            this._ToDate = "";
            this._FromDateReport = "";
            this._ToDateReport = ""
            this._FromDateSales = "";
            this._ToDateSales = "";
            this._DateSelectReportFlag = false;
            this._DateSelectSalesFlag = false;
            this._DefaultToDate = new Date();
            this._DefaultFromDate = new Date();
            this._DefaultFromDate.setDate(this._DefaultFromDate.getDate() - 180);
            this.getView().byId("idReportCreationdate").setFrom(this._DefaultFromDate);
            this.getView().byId("idReportCreationdate").setTo(this._DefaultToDate);
            this.getView().byId("idSalesCreationdate").setFrom(this._DefaultFromDate);
            this.getView().byId("idSalesCreationdate").setTo(this._DefaultToDate);

            



        },
        onSearchPress: function () {
            var multiInputRegion = this.getView().byId("multiInputRegion").getSelectedKeys();
            var multiInputPlant = this.getView().byId("multiInputPlant").getSelectedKeys();
            var multiInputPlannerCode = this.getView().byId("multiInputPlannerCode").getSelectedKeys();
            var multiInputPrimaryPart = this.getView().byId("multiInputPrimaryPart").getTokens();
            var multiInputProgramId = this.getView().byId("multiInputProgramID").getSelectedKeys();
            var aFilter = [];
            var aRegionFilter = [];
            var aPlantFilter = [];
            var aProgramIDFilter = [];
            var aPlannerCodeFilter = [];
            if (multiInputRegion) {
                multiInputRegion.map(function (oToken) {
                    aRegionFilter.push(new Filter("Region", FilterOperator.EQ, oToken));

                });

                var aRegionFilterMul = new sap.ui.model.Filter({
                    filters: aRegionFilter,
                    and: false,
                });
                aFilter.push(aRegionFilterMul);

            }
            if (multiInputPlant) {
                multiInputPlant.map(function (oToken) {
                    aPlantFilter.push(new Filter("Plant", FilterOperator.EQ, oToken));

                });

                var oPlantFilterMul = new sap.ui.model.Filter({
                    filters: aPlantFilter,
                    and: false,
                });
                aFilter.push(oPlantFilterMul);

            }
            if (multiInputPlannerCode.length > 0) {
                multiInputPlannerCode.map(function (oToken) {
                    aPlannerCodeFilter.push(new Filter("PlannerCode", FilterOperator.EQ, oToken));

                });
                var aPlannerCodeFilterMul = new sap.ui.model.Filter({
                    filters: aPlannerCodeFilter,
                    and: false,
                });
                aFilter.push(aPlannerCodeFilterMul);

            }
            if (multiInputPrimaryPart) {
                multiInputPrimaryPart.map(function (oToken) {
                    aFilter.push(new Filter("PrimaryPartNumber", FilterOperator.EQ, oToken.getText().substring(1)));

                });

            }
            if (multiInputProgramId.length > 0) {
                multiInputProgramId.map(function (oToken) {
                    aProgramIDFilter.push(new Filter("ProgramID", FilterOperator.EQ, oToken));

                });

                var aProgramIDFilterMul = new sap.ui.model.Filter({
                    filters: aProgramIDFilter,
                    and: false,
                });
                aFilter.push(aProgramIDFilterMul);

            }

            if ((this.getView().byId("idReportCreationdate").getDateValue() != null) && (this._DateSelectReportFlag)){
                aFilter.push(new sap.ui.model.Filter("ChangedDate", sap.ui.model.FilterOperator.BT, this._FromDateReport,this._ToDateReport));
            }else{
                this._FromDateReport= this.oDateFormatUTC.format(this._DefaultFromDate) +"T00:00:00Z";
                this._ToDateReport =this.oDateFormatUTC.format(this._DefaultToDate) +"T00:00:00Z";
                aFilter.push(new sap.ui.model.Filter("ChangedDate", sap.ui.model.FilterOperator.BT, this._FromDateReport,this._ToDateReport));
            }

            if (multiInputRegion.length == "0") {
                MessageBox.error("Region cannot be blank");
            } else if (multiInputPlant.length == "0") {
                MessageBox.error("Plant cannot be blank");
            } else {

                var ITCPlantReportSetModel = new JSONModel();
                ITCPlantReportSetModel.setSizeLimit(70000);
                this.getView().setModel(ITCPlantReportSetModel, "ITCPlantReportSetModel");
                this.getView().getModel().read("/ITCPlantReportSet", {
                    filters: aFilter,

                    success: function (oData) {

                        if (oData.results.length > 0) {
                            ITCPlantReportSetModel.setData(oData)

                        }

                    },
                    error: function (snItemsError1) {
                    
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                    }
                });

            }

        },

        onPrimaryPartValueHelpRequested: function () {

            this._PrimaryPartValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                "com.apple.scp.ui.acitcreports.fragment.PrimaryPartValueHelpDialog", this);
            this.getView().addDependent(this._PrimaryPartValueHelpDialog);
            this._PrimaryPartValueHelpDialog.setRangeKeyFields([{
                label: "PrimaryPartNumber",
                key: "PrimaryPartNumber"
            }]);

            this._PrimaryPartValueHelpDialog.setTokens(this.getView().byId(this.onFieldIDPrimaryPartcheck()).getTokens());
            this._PrimaryPartValueHelpDialog.open();

        },

        onFieldIDPrimaryPartcheck: function () {

            if (this.getView().byId("idManifestReport").getProperty("selectedKey") == "saleOrgReport") {
                return "multiInputSalePrimaryPartId";
            } else {
                return "multiInputPrimaryPart";

            }

        },
        onPrimaryPartValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            this.getView().byId(this.onFieldIDPrimaryPartcheck()).setTokens(aTokens);
            this._PrimaryPartValueHelpDialog.close();
        },
        onPrimaryPartValueHelpCancelPress: function () {
            this._PrimaryPartValueHelpDialog.close();
        },

        onPrimaryPartValueHelpAfterClose: function () {
            this._PrimaryPartValueHelpDialog.destroy();
        },

        //Sale Org

        onSaleOrgSearchPress: function () {
            var multiInputSaleRegionId = this.getView().byId("multiInputSaleRegionId").getSelectedKeys();
            var multiInputSaleOrgId = this.getView().byId("multiInputSaleOrgId").getSelectedKeys();
            var multiInputSalePrimaryPartId = this.getView().byId("multiInputSalePrimaryPartId").getTokens();
            var multiInputSalesProgramId = this.getView().byId("multiInputSalesProgramId").getSelectedKeys();
          
            var aFilter = [];
            var aRegionFilter = [];
            var aProgramIDilter = [];

            if (multiInputSaleRegionId) {
                multiInputSaleRegionId.map(function (oToken) {
                    aRegionFilter.push(new Filter("Region", FilterOperator.EQ, oToken));

                });

                var aRegionFilterMul = new sap.ui.model.Filter({
                    filters: aRegionFilter,
                    and: false,
                });
                aFilter.push(aRegionFilterMul);

            }
            if (multiInputSaleOrgId) {
                var aSalesOrgFilter = [];
                multiInputSaleOrgId.map(function (oToken) {
                    aSalesOrgFilter.push(new Filter("SalesOrg", FilterOperator.EQ, oToken));

                });

                var aSalesOrgFilterMul = new sap.ui.model.Filter({
                    filters: aSalesOrgFilter,
                    and: false,
                });
                aFilter.push(aSalesOrgFilterMul);

            }
        
            if (multiInputSalePrimaryPartId.length > 0) {
                multiInputSalePrimaryPartId.map(function (oToken) {
                    aFilter.push(new Filter("PrimaryPartNumber", FilterOperator.EQ, oToken.getText().substring(1)));

                });

            }
            if (multiInputSalesProgramId.length > 0) {
                multiInputSalesProgramId.map(function (oToken) {
                    aProgramIDilter.push(new Filter("ProgramID", FilterOperator.EQ, oToken));

                });

                var aProgramIDilterMul = new sap.ui.model.Filter({
                    filters: aProgramIDilter,
                    and: false,
                });
                aFilter.push(aProgramIDilterMul);

            }

            if ((this.getView().byId("idSalesCreationdate").getDateValue() != null) && (this._DateSelectSalesFlag)){
                aFilter.push(new sap.ui.model.Filter("ChangedDate", sap.ui.model.FilterOperator.BT,this._FromDateSales,this._ToDateSales));
            }else{
                this._FromDateSales= this._DefaultFromDate;
                this._ToDateSales =this._DefaultToDate;
                aFilter.push(new sap.ui.model.Filter("ChangedDate", sap.ui.model.FilterOperator.BT, this._FromDateSales,this._ToDateSales));
            }

            if (multiInputSaleRegionId.length == "0") {
                MessageBox.error("Region cannot be blank");
            } else if (multiInputSaleOrgId.length == "0") {
                MessageBox.error("Sales Org cannot be blank");
            } else {
              

                var ITCSalesOrgReportSetModel = new JSONModel();
                ITCSalesOrgReportSetModel.setSizeLimit(70000);
                this.getView().setModel(ITCSalesOrgReportSetModel, "ITCSalesOrgReportSetModel");
                this.getView().getModel().read("/ITCSalesOrgReportSet", {
                    filters: aFilter,

                    success: function (oData) {

                        if (oData.results.length > 0) {
                            ITCSalesOrgReportSetModel.setData(oData)

                        }

                    },
                    error: function (snItemsError1) {
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                    }
                });
            }

        },

        onFilterbar1Clear: function (oEvent) {
            var oItems = this.oFilterBar1.getAllFilterItems(true);
            for (var i = 0; i < oItems.length; i++) {
                var oControl = this.oFilterBar1.determineControlByFilterItem(oItems[i]);

                if (oControl.getId() == "container-com.apple.scp.ui.acitcreports---Main--multiInputPrimaryPart") {
                    oControl.removeAllTokens();
                } else   if (oControl.getId() == "container-com.apple.scp.ui.acitcreports---Main--idReportCreationdate") {
                    oControl.setValue("");
                } else {
                    
                    oControl.removeSelectedKeys();
                    oControl.setSelectedKeys(null);
                }

            }
            this._FromDateReport = "";
            this._ToDateReport = "";
            this._DateSelectReportFlag = false;
            this.getView().byId("multiInputPlannerCode").setEditable(false);
            this.getView().byId("multiInputPlant").setEditable(false);
            this.getView().byId("idReportCreationdate").setFrom(this._DefaultFromDate);
            this.getView().byId("idReportCreationdate").setTo(this._DefaultToDate);   
        },
        onFilterbar2Clear: function (oEvent) {
            var oItems = this.oFilterBar2.getAllFilterItems(true);
            for (var i = 0; i < oItems.length; i++) {
                var oControl = this.oFilterBar2.determineControlByFilterItem(oItems[i]);
                if (oControl.getId() == "container-com.apple.scp.ui.acitcreports---Main--multiInputSalePrimaryPartId") {
                    oControl.removeAllTokens();
                } else   if (oControl.getId() == "container-com.apple.scp.ui.acitcreports---Main--idSalesCreationdate") {
                    oControl.setValue("");
                }
                else {
                   
                    oControl.removeSelectedKeys();
                    oControl.setSelectedKeys(null);
                }
               
            }
            this._FromDateSales = "";
            this._ToDateSales = "";
            this._DateSelectSalesFlag = false;
            this.getView().byId("multiInputSaleOrgId").setEditable(false);
            this.getView().byId("idSalesCreationdate").setFrom(this._DefaultFromDate);
            this.getView().byId("idSalesCreationdate").setTo(this._DefaultToDate);
        },
        onFilterbar3Clear: function (oEvent) {
            var oItems = this.oFilterBar3.getAllFilterItems(true);
            for (var i = 0; i < oItems.length; i++) {
                var oControl = this.oFilterBar3.determineControlByFilterItem(oItems[i]);
                if (oControl) {
                    oControl.setValue("");
                    this._FromDate = "";
                    this._ToDate = "";
                   
                }
            }
        },

      

        exportSaleOrgData: function () {
            var oTableSales = this.getView().byId("SaleReportTable");
            var SalesCols = this.createSalesHeaderColumnConfig();
            var sFileNameSales = "SalesOrgReport";
            this.exportTableData(oTableSales, SalesCols, sFileNameSales);
        },

        exportPlantData: function () {
            var oTablePlant = this.getView().byId("headerData");
            var PlantsCols = this.createPlantHeaderColumnConfig();
            var sFileNamePlant = "PlantReport";
            this.exportTableData(oTablePlant, PlantsCols, sFileNamePlant);
        },

        exportTableData: function (oTableReport, aReportCols, sReportFileName) {

            var oRowBinding, oSettings, oSheet;

            oRowBinding = oTableReport.getBinding('rows');
            oSettings = {
                workbook: {
                    columns: aReportCols,
                    hierarchyLevel: 'Level'
                },
                dataSource: oRowBinding,
                fileName: sReportFileName,
                worker: false
            };

            oSheet = new Spreadsheet(oSettings);

            oSheet.build().finally(function () {
                oSheet.destroy();
            });
        },

        createPlantHeaderColumnConfig: function () {
            var PlantsCols = [];

            PlantsCols.push({
                property: 'Region',
                label: 'Region'

            });

            PlantsCols.push({

                label: 'Plant',
                property: 'Plant'
            });

            PlantsCols.push({
                property: 'PrimaryPartNumber',
                label: 'PrimaryPartNumber'

            });

            PlantsCols.push({
                property: 'ITCPartNumber',
                label: 'ITCPartNumber'

            });
            PlantsCols.push({
                property: 'ITCPartNumberDescription',
                label: 'ITCPartNumberDescription'

            });


            PlantsCols.push({
                property: 'SPCC',
                label: 'SPCC'

            });

            PlantsCols.push({
                property: 'ProgramID',
                label: 'ProgramID'

            });

            PlantsCols.push({
                property: 'PlannerCode',
                label: 'PlannerCode'

            });

            PlantsCols.push({

                label: 'BuyerCode',
                property: 'BuyerCode'
            });

           
            PlantsCols.push({
                property: 'CountryOfOrigin',
                label: 'CountryOfOrigin'

            });

            PlantsCols.push({

                label: 'Priority',
                property: 'Priority'
            });
            PlantsCols.push({

                label: 'Status',
                property: 'Status'
            });
            PlantsCols.push({

                label: 'DeletionIndicator',
                property: 'DeletionIndicator'
            });

            PlantsCols.push({

                label: 'CreatedDate',
                property: 'CreatedDate',
                type: EdmType.Date,
                format: 'MMM dd, yyyy',
                utc: true
            });

            PlantsCols.push({

                label: 'CreatedTime',
                type: EdmType.Time,
				property: 'CreatedTime/ms'
              
                
            });
            
            PlantsCols.push({

                label: 'ChangedDate',
                property: 'ChangedDate',
                type: EdmType.Date,
                format: 'MMM dd, yyyy',
                utc: true
            });

            PlantsCols.push({

                label: 'ChangedTime',
                type: EdmType.Time,
				property: 'ChangedTime/ms'
            });

        
    

            PlantsCols.push({
                property: 'CreatedUser',
                label: 'CreatedBy'

            });
            PlantsCols.push({
                property: 'ChangedUser',
                label: 'ChangedBy'

            });

            return PlantsCols;
        },

        createSalesHeaderColumnConfig: function () {
            var SalesCols = [];

            SalesCols.push({
                property: 'Region',
                label: 'Region'

            });

            SalesCols.push({

                label: 'SalesOrg',
                property: 'SalesOrg'
            });

            SalesCols.push({
                property: 'PrimaryPartNumber',
                label: 'PrimaryPartNumber'

            });

            SalesCols.push({
                property: 'ITCPartNumber',
                label: 'ITCPartNumber'

            });

            SalesCols.push({
                property: 'ITCPartNumberDescription',
                label: 'ITCPartNumberDescription'

            });

            SalesCols.push({
                property: 'CountryOfOrigin',
                label: 'CountryOfOrigin'

            });

            SalesCols.push({
                property: 'ProgramID',
                label: 'ProgramID'

            });


            SalesCols.push({
                property: 'ConfigCode',
                label: 'ConfigCode'

            });

         

            
            SalesCols.push({

                label: 'Priority',
                property: 'Priority'
            });

            SalesCols.push({

                label: 'DeletionIndicator',
                property: 'DeletionIndicator'
            });

            SalesCols.push({

                label: 'CreatedDate',
                property: 'CreatedDate',
                type: EdmType.Date,
                format: 'MMM dd, yyyy',
                utc: true
            });

            SalesCols.push({

                label: 'CreatedTime',
                type: EdmType.Time,
				property: 'CreatedTime/ms'
            });
            
            SalesCols.push({

                label: 'ChangedDate',
                property: 'ChangedDate',
                type: EdmType.Date,
                format: 'MMM dd, yyyy',
                utc: true
            });

            SalesCols.push({

                label: 'ChangedTime',
                type: EdmType.Time,
				property: 'ChangedTime/ms'
               
            });

            SalesCols.push({
                property: 'CreatedUser',
                label: 'CreatedBy'

            });
            SalesCols.push({
                property: 'ChangedUser',
                label: 'ChangedBy'

            });

            return SalesCols;
        },

        handleChange: function (oEvent) {

            this._FromDate = this.oDateFormatUTC.format(oEvent.getParameter("from"))+ "T00:00:00Z";
            this._ToDate = this.oDateFormatUTC.format(oEvent.getParameter("to"))+ "T00:00:00Z";
          

        },
        reporthandleChange: function (oEvent) {

            this._FromDateReport = this.oDateFormatUTC.format(oEvent.getParameter("from"))+ "T00:00:00Z";
            this._ToDateReport = this.oDateFormatUTC.format(oEvent.getParameter("to"))+ "T00:00:00Z";
            this._DateSelectReportFlag = true;

        },
        saleshandleChange: function (oEvent) {

            this._FromDateSales = this.oDateFormatUTC.format(oEvent.getParameter("from"))+ "T00:00:00Z";
            this._ToDateSales = this.oDateFormatUTC.format(oEvent.getParameter("to"))+ "T00:00:00Z";
            this._DateSelectSalesFlag = true;

        },
        

        onErrorReportSearchPress: function () {
            var aFilter = []

            if (!this._FromDate && !this._ToDate) {
                MessageBox.error("Please Select Date Range");
            } else {
                aFilter.push(new sap.ui.model.Filter("CreatedDate", sap.ui.model.FilterOperator.BT, this._FromDate,this._ToDate));
                
                var ITCErrorReportSetModel = new JSONModel();
                ITCErrorReportSetModel.setSizeLimit(70000);
                this.getView().setModel(ITCErrorReportSetModel, "ITCErrorReportSetModel");
                this.getView().getModel().read("/ZC_ITCErrorReport", {
                    filters: aFilter,

                    success: function (oData) {

                        if (oData.results.length > 0) {
                            ITCErrorReportSetModel.setData(oData)

                        }

                    },
                    error: function (snItemsError1) {

                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                    }
                });

            }

        },

        handleRegionSelectionFinish:function(oEvent){
            var selectedItems = oEvent.getParameter("selectedItems");
            var onSelectRegionFilter = [];
            var that = this;
            var onPlantModel = new JSONModel();
            this.getView().setModel(onPlantModel, "onPlantModel");
            onPlantModel.setSizeLimit(20000);
            if (selectedItems.length > 0) {
                selectedItems.map(function (oToken) {
                    onSelectRegionFilter.push(new Filter("Region", FilterOperator.EQ, oToken.getKey()));

                });
                this.getView().getModel().read("/ZC_RptPlants", {
                    filters: onSelectRegionFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            onPlantModel.setData(oData)
                            onPlantModel.setSizeLimit(20000);
                        }
                        that.getView().byId("multiInputPlant").setEditable(true);  
                    },
                    error: function (snItemsError1) {
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        that.getView().byId("multiInputPlant").setEditable(false); 
                    }
                });
                
            }else{
             this.getView().byId("multiInputPlant").setEditable(false); 
        }        

        },
        handlePlantSelectionFinish:function(oEvent){
            var selectedItems = oEvent.getParameter("selectedItems");
            var onPlantRegionFilter = [];
            var that = this;
            var onPlannerCodesModel = new JSONModel();
            this.getView().setModel(onPlannerCodesModel, "onPlannerCodesModel");
            onPlannerCodesModel.setSizeLimit(20000);
            if (selectedItems.length > 0) {
                selectedItems.map(function (oToken) {
                    onPlantRegionFilter.push(new Filter("Plant", FilterOperator.EQ, oToken.getKey()));

                });
                this.getView().getModel().read("/ZC_ACITCPlannerCodes", {
                    filters: onPlantRegionFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            onPlannerCodesModel.setData(oData)
                            onPlannerCodesModel.setSizeLimit(20000);
                        }
                        that.getView().byId("multiInputPlannerCode").setEditable(true);
                    },
                    error: function (snItemsError1) {
                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        that.getView().byId("multiInputPlannerCode").setEditable(false); 
                    }
                });
                
            }
         else{
            this.getView().byId("multiInputPlannerCode").setEditable(false);  
        } 
            
        },
        handleSaleRegionSelectionFinish:function(oEvent){
            var SaleRegionselectedItems = oEvent.getParameter("selectedItems");
            var onSalesorgModel = new JSONModel();
            this.getView().setModel(onSalesorgModel, "onSalesorgModel");
            onSalesorgModel.setSizeLimit(300);
            var that = this;
          
            var onSalesPRegionFilter = [];
            if (SaleRegionselectedItems.length > 0) {
                SaleRegionselectedItems.map(function (oToken) {
                    onSalesPRegionFilter.push(new Filter("Region", FilterOperator.EQ, oToken.getKey()));

                });

                this.getView().getModel().read("/ZC_ACITCSlsOrgs", {
                    filters: onSalesPRegionFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            onSalesorgModel.setData(oData)
                            onSalesorgModel.setSizeLimit(300);
                        }
                        that.getView().byId("multiInputSaleOrgId").setEditable(true);
                    },
                    error: function (snItemsError1) {

                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        that.getView().byId("multiInputSaleOrgId").setEditable(false);
                    }
                });
              
                
            }   
        else{
            this.getView().byId("multiInputSaleOrgId").setEditable(false);
        }

        },
        onClickErrorExcelLink:function(e){
            var appId = this.getView().getModel("busyModel").getData().appId;
            var object=  this.getView().getModel("ITCErrorReportSetModel").getProperty(e.getSource().getParent().getBindingContext('ITCErrorReportSetModel').getPath())
            var sUrl = "/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv/GetPlantPartOutputSet(guid'" + object.RequestId +
                    "')/$value?appid="+appId;
                sap.m.URLHelper.redirect(sUrl);


        },

    });
});