sap.ui.define([
	"com/apple/scp/ui/acitcreports/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
