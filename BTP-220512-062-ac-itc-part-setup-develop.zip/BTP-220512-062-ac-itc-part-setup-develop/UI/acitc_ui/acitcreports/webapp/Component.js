sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "com/apple/scp/ui/acitcreports/model/models",
       "sap/ui/model/odata/v2/ODataModel",
       "sap/base/util/UriParameters"
        // "com/apple/scp/ui/acitcreports/localService/mockserver"


],
function (UIComponent, JSONModel, Device, models, ODataModel,UriParameters) {
    "use strict";

    return UIComponent.extend("com.apple.scp.ui.acitcreports.Component", {
        metadata: {
            manifest: "json"
        },
        init: function () {

            if (window.parent.location.href.includes("epweb") || window.parent.location.href.includes("acitc") || window.parent.location.href.includes("applicationstudio")) {

            
            
            UIComponent.prototype.init.apply(this, arguments);

           
            this.getRouter().initialize();

            this.setModel(models.createDeviceModel(), "device");
   this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
    if (this.isMock) {
        //Start Mock Server
                    this.oMockserver = MockServer.init();

                    //Set Mockmodel to Component
                    var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                        json: true
                    });

                    this.setModel(oModel);
                    this.bMock = true;
    }else{
            
            //new 
            fetch("/getAppVariables")
                .then(res => res.json())
                .then(variables => {
                    this.appId = variables;
                    this.gModelConfig = {
                        headers: {
                            appid: variables
                        },
                        defaultBindingMode: "TwoWay",
                        defaultCountMode: "Inline",
                        useBatch: true
                    };
                    this.ACITCReportModel = new sap.ui.model.odata.v2.ODataModel("/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv", this.gModelConfig);
                    this.setModel(this.ACITCReportModel);

                    var oViewModelReports,
                        that = this;

                    oViewModelReports = new JSONModel({
                        bBusy: true,
                        delay: 0,
                        appId : that.appId
                    });
                              
                    this.setModel(oViewModelReports, "busyModel");
                  
                    this.getModel().attachRequestSent(function(){
                        that.getModel("busyModel").setProperty("/bBusy", true);
                    });
                    this.getModel().attachRequestCompleted(function(){
                        that.getModel("busyModel").setProperty("/bBusy", false);
                    });
                    this.getModel("busyModel").refresh(true);
                });
    }
    

        }
    }
    });
}
);