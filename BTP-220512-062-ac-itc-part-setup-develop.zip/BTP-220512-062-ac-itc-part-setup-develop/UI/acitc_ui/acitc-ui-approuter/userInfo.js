/* eslint-disable no-console */
const approuter = require("@sap/approuter");
const jwtDecode = require("jwt-decode");

let ar = approuter();

ar.beforeRequestHandler.use((req, res, next) => {
    next();
});

require("@sap/xsenv").loadEnv();
ar.beforeRequestHandler.use("/getAppVariables", (req, res) => {
    res.end(JSON.stringify(process.env.AppID));
});

ar.beforeRequestHandler.use("/getPackType", (req, res) => {
    res.end(process.env.apiurl);
});

ar.beforeRequestHandler.use("/getTableDetails", (req, res) => {
    res.end(process.env.TableDetails);
});

ar.beforeRequestHandler.use("/getUserInfo", (req, res) => {

  if (!req.user) {
    res.statusCode = 403;
    res.end("Missing JWT Token");
  }

  res.statusCode = 200;
  let decodedJWTToken = jwtDecode(req.user.token.accessToken).scope;

  res.end(JSON.stringify({
    decodedJWTToken
  }));

});

ar.start();