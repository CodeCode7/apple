sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function (sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},
        onTimeDispplay: function (sValue) {
			var timeStr;
			if (sValue) {
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "KK:mm:ss a"
				});

				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

				 timeStr = timeFormat.format(new Date(sValue.ms + TZOffsetMs));

			}else{
				timeStr = "";
			}

			return timeStr;
		},
        statusCode: function (sValue) {
			if (sValue == "Error") {
				return true;
			}else{
                return false;
            }

			
		},
        statusAction: function (sValue) {
            if (sValue == 'E') {
                return true;
            }else{
                return false;
            }

        
    }
	};

});