sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log"
], function (MockServer, Log) {
    "use strict";

    var _sAppPathManifestReport = "com/apple/scp/ui/uploadrequest/",
        _sJsonFilesPathManifestReport = _sAppPathManifestReport + "localService/Mockdata",
        _aEntitySetsManifestReport = {
            "mainService": ["ZC_ACITCPlants", "ZC_ACITCBuyerCodes", "ZC_ACITCPlannerCodes", "ZC_ACITCProgramIds", "GetITCUploadFileSet"]
        };

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function () {
            var sJsonFilesUrlManifestReport = sap.ui.require.toUrl(_sJsonFilesPathManifestReport),
                // sManifestUrlManifestReport = sap.ui.require.toUrl(_sAppPathManifestReport + "manifest.json"),
                // oManifestReport = jQuery.sap.syncGetJSON(sManifestUrlManifestReport).data,
                // oMainDataSource = oManifestReport["sap.app"].dataSources.mainService,
                sMetadataUrlManifestReport = sap.ui.require.toUrl(_sAppPathManifestReport + "localService/metadata.xml");//oMainDataSource.settings.localUri

            this.sMockServerUrl = "/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv/";//oMainDataSource.uri;

            // init root URI
            this.oMockServer = new MockServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MockServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockServer.simulate(sMetadataUrlManifestReport, {
                sMockdataBaseUrl: sJsonFilesUrlManifestReport,
                aEntitySetsNames: _aEntitySetsManifestReport,
                bGenerateMissingMockData: false
            });

            this.oMockServer.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrlManifestReport + "\n" +
                "   mockdata dir: " + sJsonFilesUrlManifestReport);

            return this;
        }
    };

});