sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/Device",
        "com/apple/scp/ui/uploadrequest/model/models",
        "com/apple/scp/ui/uploadrequest/model/formatter",
        "sap/base/util/UriParameters",
        "sap/m/MessageBox",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/odata/v2/ODataModel"
        // "com/apple/scp/ui/uploadrequest/localService/mockserver"
    ],
    function (UIComponent, Device, models,formatter, UriParameters, MessageBox, JSONModel, ODataModel, MockServer) {
        "use strict";

        return UIComponent.extend("com.apple.scp.ui.uploadrequest.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
               
                // call the base component's init function
            if (window.parent.location.href.includes("epweb") || window.parent.location.href.includes("acitc") || window.parent.location.href.includes("applicationstudio")) {
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                this.setModel(models.createDeviceModel(), "device");
                

                
                

                this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
                if (this.isMock) {
                    //Start Mock Server
                    this.oMockserver = MockServer.init();

                    //Set Mockmodel to Component
                    var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                        json: true
                    });

                    this.setModel(oModel);
                    this.bMock = true;
                } else {
                    this.bMock = false;
                    this.gModelConfig2 = {
                        headers: {
                            appid: ""
                        },
                        defaultBindingMode: "TwoWay",
                        defaultCountMode: "Inline",
                        "defaultUpdateMethod": "PUT",
                        useBatch: true
                    };
                   
                    fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        this.setModelConfig(variables);
                    });
                }

                this.setModel(new JSONModel({
                    bMock: this.bMock,
                    bBusy: false
                }), "busyModel");

                


            } else {
                MessageBox.show(
                    "Please access ACITC from Enterprise Portal", {
                    icon: MessageBox.Icon.ERROR,
                    title: "Access From Enterprise Portal",
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });
            }

            },

            setModelConfig: function(variables) {
                this.gModelConfig2.headers.appid = variables
                    var that = this;
                    this.ACITCModel2 = new sap.ui.model.odata.v2.ODataModel("/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv", this.gModelConfig2);
                    this.setModel(this.ACITCModel2);
                    var oUploadViewModel;

                    oUploadViewModel = new JSONModel({
                    bBusy: true,
                    delay: 0,
                    appId :variables
                });
                this.setModel(oUploadViewModel, "busyModel");

                var GetITCUploadFileSetModel = new sap.ui.model.json.JSONModel();
			    this.setModel(GetITCUploadFileSetModel, "GetITCUploadFileSetModel");
                this.oDateFormatUTC = sap.ui.core.format.DateFormat.getDateInstance({
                    			pattern: "yyyy-MM-dd",
                    			UTC: false
                    		});
                    		this.dToDate = this.oDateFormatUTC.format(new Date()) + "T00:00:00Z";
                    		this.dFromDate = new Date();
                    		this.dFromDate.setDate(this.dFromDate.getDate() - 30);
                    		this.dFromDate = this.oDateFormatUTC.format(this.dFromDate) + "T00:00:00Z";
				this.getModel().metadataLoaded().then(function() {
                    that.getModel().read("/GetITCUploadFileSet", {
                        async: true,
                        filters: [new sap.ui.model.Filter("Erdat", "BT", that.dFromDate, that.dToDate)],
                        success: function(data) {
                            GetITCUploadFileSetModel.setData(data);
                        },
                        error: function(snItemsError1) {
                            MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        }
                    });
    
                });
               
                    this.getModel().attachRequestSent(function(){
                        that.getModel("busyModel").setProperty("/bBusy", true);
                    });
                    this.getModel().attachRequestCompleted(function(){
                        that.getModel("busyModel").setProperty("/bBusy", false);
                    });
            }
        });
    }
);