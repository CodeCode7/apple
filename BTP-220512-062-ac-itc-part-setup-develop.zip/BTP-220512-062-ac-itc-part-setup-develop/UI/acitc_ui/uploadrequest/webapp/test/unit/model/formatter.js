/*global QUnit*/
sap.ui.define([
    "com/apple/scp/ui/uploadrequest/model/formatter",
    "sap/ui/Device"
], function (formatter, Device) {
    "use strict";

    QUnit.test("Test currency blank value", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.currencyValue(""), "", "Blank Currency success");
	});

    QUnit.test("Format Currency Value Test", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.currencyValue("22"), "22.00", "Currency Value formatted successfully");
	});

    QUnit.test("Status Code error true test case", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.statusCode("Error"), true, "Status Code error true success");
	});

    QUnit.test("Status Code error false test case", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.statusCode(""), false, "Status Code error false success");
	});

    QUnit.test("Status Code E test case", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.statusAction("E"), true, "Status Code E success");
	});

    QUnit.test("Status Code not E test case", function (assert) {
		this.oDeviceModelMR = formatter;
		assert.strictEqual(this.oDeviceModelMR.statusAction(""), false, "Status Code not E success");
	});
    function timeFormatTestCase(assert, sValue, fExpectedTime) {
        this.oDeviceModelMR = formatter;
        var msg = "The Time format expected was " + fExpectedTime;
        var fTime = formatter.onTimeDispplay(sValue);
        assert.strictEqual(fTime, fExpectedTime, msg);
    }
    QUnit.test("Should return correct formatted Time", function (assert) {
        var oTime = {"ms": 37157000, "__edmType": "Edm.Time"};
        timeFormatTestCase.call(this, assert, oTime, "10:19:17 AM");
    });
    QUnit.test("Should return incorrect formatted Time", function (assert) {
        var oTime = "";
        timeFormatTestCase.call(this, assert, oTime, "");
    });
    
});
