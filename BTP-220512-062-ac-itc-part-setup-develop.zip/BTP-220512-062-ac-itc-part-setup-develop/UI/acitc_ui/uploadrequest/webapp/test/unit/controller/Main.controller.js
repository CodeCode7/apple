/*global QUnit*/

sap.ui.define([
	"com/apple/scp/ui/uploadrequest/controller/Main.controller",
    "sap/ui/core/UIComponent",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/mvc/View"
], function (Controller, UiComp, ResourceModel, View) {
	"use strict";
    const i18nPath = "com/apple/scp/ui/uploadrequest/i18n/i18n.properties"
	QUnit.module("Main Controller");

    QUnit.module("Main Controller", {
        beforeEach: function () {
            this.oMainController = new Controller();
        },
        afterEach: function () {
            this.oMainController.destroy();
        }
    });

    // QUnit.test("Main controller Load", function (assert) {
    //     assert.ok(this.oMainController);
    //     this.oMainController.onDownloadTemp();
    // });

    QUnit.test("getI18nText function test", function (assert) {
        //Arrange
        var smComp = new UiComp();
        var oControllerStub = sinon.stub(this.oMainController, "getOwnerComponent").returns(smComp);
        var oResourceModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl(i18nPath) });
        var oCompStub = sinon.stub(UiComp.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResourceModel);

        //Action
        var aText = this.oMainController.getI18nText("downloadBtnTxt");

        //Assert
        assert.strictEqual(aText, "Download", "Download button text to be returned");

        //CleanUp
        smComp.destroy();
        oControllerStub.restore();
        oResourceModel.destroy();
        oCompStub.restore();
    });

});
