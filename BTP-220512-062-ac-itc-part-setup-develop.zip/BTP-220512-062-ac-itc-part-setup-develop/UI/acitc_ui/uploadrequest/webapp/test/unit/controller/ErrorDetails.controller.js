/*global QUnit*/

sap.ui.define([
    "com/apple/scp/ui/uploadrequest/controller/ErrorDetails.controller",
    "sap/ui/core/mvc/View",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/UIComponent",
], function (Controller, View, aController, JSONModel, UIComponent) {
    "use strict";
    const Event = sap.ui.base.Event;
    QUnit.module("ErrorDetails Controller", {
        beforeEach: function () {
            this.oErrorDetailsController = new Controller();
        },
        afterEach: function () {
            this.oErrorDetailsController.destroy();
        }
    });

    QUnit.test("ErrorDetails controller Load", function (assert) {
        var oRouter = new sap.m.routing.Router([
            {
                "name": "RouteMain",
                "pattern": "RouteMain",
                "target": [
                    "TargetMain"
                ]
            },
            {
                "pattern": "UploadCollectionItemSet/{ReqID}",
                "name": "object",
                "target": [
                    "object"
                ]
            }
        ]);

        //System under test
        var oGetRouterStub = sinon.stub(this.oErrorDetailsController, "getRouter").returns(oRouter);
        var oRouterSpy = this.stub(sap.ui.core.routing.Router.prototype, "navTo");
        this.oErrorDetailsController.onInit();
        assert.ok(this.oErrorDetailsController);
    });

    QUnit.test("Export to excel", function (assert) {
        var oViewStubErrorDetails = new View({});
        var oGetViewStubErrorDetails = sinon.stub(this.oErrorDetailsController, "getView").returns(oViewStubErrorDetails);

        var oBtn = new sap.m.Button();
        var oBtnStub = sinon.stub(View.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oErrorDetailsController.onErrorDataExport();

        assert.strictEqual(oBtnSpy.callCount, 0, "Download function to be triggered");

        oViewStubErrorDetails.destroy();
        oGetViewStubErrorDetails.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });

    QUnit.test("navigateToMain function test", function (assert) {
        var oRouter = new sap.m.routing.Router([
            {
                "name": "RouteMain",
                "pattern": "RouteMain",
                "target": [
                    "TargetMain"
                ]
            },
            {
                "pattern": "UploadCollectionItemSet/{ReqID}",
                "name": "object",
                "target": [
                    "object"
                ]
            }
        ]);

        //System under test
        var oGetRouterStub = sinon.stub(this.oErrorDetailsController, "getRouter").returns(oRouter);
        var oRouterSpy = this.stub(sap.ui.core.routing.Router.prototype, "navTo");

        //Actions
        this.oErrorDetailsController.onBackPress();

        assert.strictEqual(oRouterSpy.callCount, 1, "Router navigation method to be called");

        //CleanUp
        oGetRouterStub.restore();
        oRouterSpy.restore();
    });

    // QUnit.test("Error Details controller onObject Matched", function (assert) {
    //     var oRouter = new sap.m.routing.Router([
    //         {
    //             "name": "RouteMain",
    //             "pattern": "RouteMain",
    //             "target": [
    //                 "TargetMain"
    //             ]
    //         },
    //         {
    //             "pattern": "UploadCollectionItemSet/{ReqID}",
    //             "name": "object",
    //             "target": [
    //                 "object"
    //             ]
    //         }
    //     ]);

    //     //System under test
    //     var oGetRouterStub = sinon.stub(this.oErrorDetailsController, "getRouter").returns(oRouter);
    //     var oRouterSpy = this.stub(sap.ui.core.routing.Router.prototype, "navTo");
    //     var dEvent = new Event('oEvent', {}, {
    //         arguments:{
    //              "ReqID" : "98be9466-106d-1edc-bce0-94b74bd257d2" 
    //             }
    //         });
    //         var oViewStub = new View({});
    //         var lModel = new JSONModel();
    //         oViewStub.setModel(lModel);

            
        
    //     this.oErrorDetailsController.onObjectMatched(dEvent)

    //     assert.strictEqual(oRouterSpy.callCount, 1, "Error Details ObjectMatch Called");
    // });

});
