/*global QUnit*/

sap.ui.define([
	"com/apple/scp/ui/uploadrequest/controller/App.controller",
    "sap/ui/core/mvc/View"
], function (Controller, View) {
	"use strict";

    QUnit.module("Main Controller", {
        beforeEach: function () {
            this.oAppController = new Controller();
        },
        afterEach: function () {
            this.oAppController.destroy();
        }
    });

    QUnit.test("App controller Load", function (assert) {
        assert.ok(this.oAppController);
    });

});
