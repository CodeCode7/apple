sap.ui.define([
	"com/apple/scp/ui/uploadrequest/test/unit/controller/Main.controller",
    "com/apple/scp/ui/uploadrequest/test/unit/controller/ErrorDetails.controller",
    "com/apple/scp/ui/uploadrequest/test/unit/controller/BaseController",
    "com/apple/scp/ui/uploadrequest/test/unit/controller/App.controller",
    "com/apple/scp/ui/uploadrequest/test/unit/model/models",
    "com/apple/scp/ui/uploadrequest/test/unit/model/formatter"
], function () {
	"use strict";
});
