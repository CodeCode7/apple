/* global QUnit */

sap.ui.require(["com/apple/scp/ui/uploadrequest/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
