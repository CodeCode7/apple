sap.ui.define([
	"sap/ui/test/Opa5",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/ui/test/matchers/Properties"
], function (Opa5, EnterText, AggregationLengthEquals, Press, PropertyStrictEquals, Properties) {
	"use strict";
	var sViewName = "Main";
    var sPlantInputId = "multiInputPlant";
    var sTableId = "uploadtableStatus";
    var sDwnldBtn = "container-com.apple.scp.ui.uploadrequest---Main--filterbar1-btnGo";
    var sExistingTempId = "rb1";
    var sNewTempId = "rb2";
	// Opa54.createPageObjects({
	// 	onTheAppPage: {

	// 		actions: {},

	// 		assertions: {

	// 			iShouldSeeTheApp: function () {
	// 				return this.waitFor({
	// 					id: "app",
	// 					viewName: sViewName,
	// 					success: function () {
	// 						Opa54.assert.ok(true, "The " + sViewName + " view is displayed");
	// 					},
	// 					errorMessage: "Did not find the " + sViewName + " view"
	// 				});
	// 			}
	// 		}
	// 	}
	// });

    Opa5.createPageObjects({
        onTheMainPage: {

            actions: {
                // iClickOnFileNameLink: function (fValue) {
                //     return this.waitFor({
                //         id: sTableId,
                //         viewName: sViewName,
                //         // actions: [new Press()],
                //         success: function(){
                //             this.waitFor({
                //                 viewName: sViewName,
                //                 id: "container-com.apple.scp.ui.uploadrequest---Main--uploadtableStatus-rows-row1-col0",
                //                 // actions: new Press(),
                //                 success: function(){
                //                     Opa5.assert.ok("File Name is visible");
                //                     this.waitFor({
                //                         controlType: "sap.m.Link",
                                        
                //                         matchers: [
                //                             new PropertyStrictEquals({
                //                                 name: "text",
                //                                 value: fValue
                //                             })
                //                         ],
                //                         success: function(oLink) {
                //                             oLink[0].firePress();
                //                             Opa5.assert.ok(true, "File Name clicked successfully");
                //                         },
                //                         errorMessage: "Cell could not be found in the table"
                //                      });
                //                 },
                //                 errorMessage: "Did not find the table column"
                //             });
                //         },
                //         errorMessage: "The Main page loading failed"
                //     }); 
                // },

                iEnterPlantForSearchAndPressEnter: function (plant, sBtnTxt) {
                    return this.waitFor({
                        id: sPlantInputId,
                        viewName: sViewName,
                        actions: [new EnterText({ text: plant, pressEnterKey: true })],
                        success: function(){
                            Opa5.assert.ok("Plant value is entered");
                            this.waitFor({
                                controlType: "sap.m.Button",
                                
                                matchers: [
                                    new PropertyStrictEquals({
                                        name: "text",
                                        value: sBtnTxt
                                    })
                                ],
                                success: function(oLink) {
                                    oLink[0].firePress();
                                    Opa5.assert.ok(true, "Download Button clicked successfully");
                                },
                                errorMessage: "Download Button not found"
                             });
                        },
                        errorMessage: "The Plant cannot be entered"
                    });
                },

                iSelectNewTemplate: function (bSelect) {
                    return this.waitFor({
                        id: sNewTempId,
                        viewName: sViewName,
                        actions: new Press(),
                        success: function(){
                            Opa5.assert.ok("New Template selected");
                        },
                        errorMessage: "Could not find new temp radio button"
                    });
                },
            },
                //,

            //     iClickOnTableItemByFieldValue: function (fName, fValue) {
            //         return this.waitFor({
            //             controlType: "sap.m.ColumnListItem",

            //             // Retrieve all list items in the table
            //             matchers: [function(oCandidateListItem) {
            //                 var oTableLine = {};
            //                 oTableLine = oCandidateListItem.getBindingContext().getObject();
            //                 var sFound = false;

            //                 // Iterate through the list items until the specified cell is found
            //                 for (var sName in oTableLine) {
            //                     if ((sName === fName) && (oTableLine[sName].toString() === fValue)) {
            //                          QUnit.ok(true, "Cell has been found");
            //                         sFound = true;
            //                         break;
            //                     }
            //                 }
            //                 return sFound;
            //             }],

            //             // Click on the specified item
            //             actions: new Press(),
            //             errorMessage: "Cell could not be found in the table"
            //          });
            //     }
            // },

            assertions: {
                iShouldSeeFilterBar2: function (bVisible) {
                    return this.waitFor({
                        viewName: sViewName,
                        id: "filterbar2",
                        success: function () {
                            Opa5.assert.ok("Filter bar 2 is visible");
                        },
                        errorMessage: "Did not find the " + sViewName + " view"
                    });
                },

                iShouldSeeMessageBox: function (title) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.MessageBox",
                        matchers: new Properties({
                            title: "Error",
                            text: title
                        }),
                        success: function () {
                            Opa5.assert.ok(true, title + " Popup seen");
                        },
                        errorMessage: title + " PopUp not seen"
                    });
                }

                // iShouldSeeMainPage: function () {
                //     return this.waitFor({
                //         viewName: sViewName,
                //         id: sPlantInputId,
                //         success: function () {
                //             Opa5.assert.ok(true, "The " + sViewName + " view is displayed");
                //         },
                //         errorMessage: "Did not find the " + sViewName + " view"
                //     });
                // },

                
                // ,

                // iShouldSeeItemCount: function (iItemCount) {
                //     return this.waitFor({
                //         id: sTableId,
                //         viewName: sViewName,
                //         matchers: [new AggregationLengthEquals({
                //             name: "rows",
                //             length: iItemCount
                //         })],
                //         success: function () {
                //             Opa5.assert.ok(true, "The table has " + iItemCount + " item(s)");
                //         },
                //         errorMessage: "Table does not have expected number of items '" + iItemCount + "'."
                //     });
                // }
            }
            
        }
    });

});
