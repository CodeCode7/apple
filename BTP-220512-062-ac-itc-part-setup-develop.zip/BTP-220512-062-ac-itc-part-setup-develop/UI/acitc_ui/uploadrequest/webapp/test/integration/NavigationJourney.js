/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "./pages/App",
	"./pages/Main",
    "./pages/ErrorDetails"
    
], function (opaTest, Opa5) {
	"use strict";

	QUnit.module("Navigation Journey");

	// opaTest("Should see the initial page of the app", function (Given, When, Then) {
	// 	// Arrangements
	// 	Given.iStartMyApp();

	// 	// Assertions
	// 	Then.onTheAppPage.iShouldSeeTheApp();

	// 	//Cleanup
	// 	Then.iTeardownMyApp();
	// });
    function jsonOk(body) {
        var mockResponse = new window.Response(JSON.stringify(body), {
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });
        return Promise.resolve(mockResponse);
    }

    // opaTest("Should navigate to Error Details page", function (Given, When, Then) {
    //     // Arrangements
    //     Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
    //         Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
    //     });

    //     //Actions
    //     When.onTheMainPage.iClickOnFileNameLink("AC_ITC_20220622203814.XLSX");
        
    //     // // Assertions
    //     Then.onTheErrorDetailsPage.iShouldSeeTheErrorDetails();

    //     // When.onTheErrorDetailsPage.iClickOnRowShiftIcon(true).and.iClickOnRowShiftIcon(false).and.iClickonSLToggleButton().and.iClickonSLToggleButton().and.iClickOnBack();
    //     // Then.onTheMainPage.iShouldSeeMainPage();

    //     Then.iTeardownMyApp();
    // });
});
