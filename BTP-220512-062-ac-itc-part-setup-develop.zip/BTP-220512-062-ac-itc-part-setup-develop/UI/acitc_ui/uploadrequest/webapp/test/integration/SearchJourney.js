/* global QUnit */

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/ui/uploadrequest/test/integration/arrangements/Startup",
    "com/apple/scp/ui/uploadrequest/test/integration/pages/Main"
    
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Filter and Search");

    // opaTest("Select New Template Radio Button", function (Given, When, Then) {
    //     // Arrangements
    //     Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
    //         Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
    //     });
    //     //Actions
    //     When.onTheMainPage.iSelectNewTemplate(true);

    //     // Assertions
    //     Then.onTheMainPage.iShouldSeeFilterBar2(true).and.iTeardownMyApp();
    //     // Then.iTeardownMyApp();
    // });

    // opaTest("Enter Plant and click download button", function (Given, When, Then) {
    //     // Arrangements
    //     Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
    //         Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
    //     });
    //     //Actions
    //     When.onTheMainPage.iEnterPlantForSearchAndPressEnter("", "Download");

    //     // Assertions
    //     Then.onTheMainPage.iShouldSeeMessageBox("Error").and.iTeardownMyApp();
    //     // Then.iTeardownMyApp();
    // });

    // opaTest("Should show correct item count after Date search (1)", function (Given, When, Then) {
    //     // Arrangements
    //     Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
    //         Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
    //     });
    //      //Actions
    //      When.onThePOPage.iEnterDateForSearchAndPressEnter("Jan 7, 2021 - Jan 8, 2021");
    //      // Assertions
    //      Then.onThePOPage.iShouldSeeItemCount(1).and.iTeardownMyApp();
    // });
});