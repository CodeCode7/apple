sap.ui.define([
	"sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent"
], function (Controller, UIComponent) {
	"use strict";
	return Controller.extend("com.apple.scp.ui.uploadrequest.controller.BaseController", {
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		
		getModel: function (sName) {
			return this.getView().getModel(sName);
		}

		
	});

});