sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "com/apple/scp/ui/uploadrequest/controller/BaseController",
    'sap/ui/model/json/JSONModel',
    "com/apple/scp/ui/uploadrequest/model/formatter",
    "sap/ui/model/type/String",
    "sap/ui/export/Spreadsheet",
    'sap/ui/export/library'
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, BaseController, JSONModel, formatter, String, Spreadsheet, exportLibrary) { 
    "use strict";

var EdmType = exportLibrary.EdmType;

    return BaseController.extend("com.apple.scp.ui.uploadrequest.controller.ErrorDetails", {
        formatter: formatter,
        
        onBackPress: function () {
            this.getRouter().navTo("RouteMain");            
        },
        onInit: function () {
            this.getRouter().getRoute("object").attachPatternMatched(this.onObjectMatched, this);

        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Binds the view to the object path.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        onObjectMatched: function (oEvent) {
            var ReqID = oEvent.getParameter("arguments").ReqID;
            this.getModel().metadataLoaded().then(function () {
                var sObjectPath = this.getModel().createKey("GetITCUploadFileSet", {
                    RequestId: ReqID
                });
                this._bindView("/" + sObjectPath);
            }.bind(this));
        },

        /**
         * Binds the view to the object path.
         * @function
         * @param {string} sObjectPath path to the object to be bound
         * @private
         */
        _bindView: function (sObjectPath) {
        

            this.getView().bindElement({
                path: sObjectPath
            });
        },

        onErrorDataExport: function () {
            var oTableUploaderror = this.getView().byId("idTableUploadfileError");
            var aAllColsError = this.createUploadErrorHeaderColumnConfig();
            var sUploadFileName = "UploadErrorReport";
            this.exportErrorTableData(oTableUploaderror, aAllColsError, sUploadFileName);
        },
        exportErrorTableData: function (oTableUploaderror, aAllColsError, sUploadFileName) {

            var oRowBinding, oSettings, oSheet;

            oRowBinding = oTableUploaderror.getBinding('rows');
            oSettings = {
                workbook: {
                    columns: aAllColsError,
                    hierarchyLevel: 'Level'
                },
                dataSource: oRowBinding,
                fileName: sUploadFileName,
                worker: false
            };

            oSheet = new Spreadsheet(oSettings);

            oSheet.build().finally(function () {
                oSheet.destroy();
            });
        },

        createUploadErrorHeaderColumnConfig: function () {
            var aColsError = [];

            aColsError.push({

                label: 'Plant',
                property: 'Plant'
            });

            aColsError.push({
                property: 'PrimaryPart',
                label: 'PrimaryPart'

            });

            aColsError.push({
                property: 'ItcPart',
                label: 'ItcPart'

            });

            aColsError.push({
                property: 'Priority',
                label: 'Priority'

            });

            aColsError.push({

                label: 'Date',
                property: 'Erdat',
                type: EdmType.Date,
                format: 'MMM dd, yyyy',
                utc: true,
            });
            aColsError.push({

                label: 'Time',
                type: EdmType.Time,
				property: 'Erzet'
              
                
            });

            aColsError.push({
                property: 'ErrorMessage',
                label: 'ErrorMessage'

            });

            aColsError.push({
                property: 'Ernam',
                label: 'CreatedBy'

            });

            return aColsError;
        },

    });
});