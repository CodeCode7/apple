sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/json/JSONModel',
    "com/apple/scp/ui/uploadrequest/model/formatter",
    "sap/ui/Device",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, JSONModel, formatter, Device, MessageBox, Filter, FilterOperator) {
    "use strict";

    return Controller.extend("com.apple.scp.ui.uploadrequest.controller.Main", {

        formatter: formatter,

        onInit: function () {
            this.getView().byId("filterbar2")._oSearchButton.setText("Download");
            this.oFilterBar1 = this.getView().byId("filterbar1");
            this.oFilterBar1._oSearchButton.setText(this.getI18nText("downloadBtnTxt"));
        },

        getI18nText: function (textID) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(textID);
        },

        onExistingTempClick: function () {
            this.getView().byId("filterbar1").setVisible(true);
            this.getView().byId("filterbar2").setVisible(false);
        },
        onNewTempClick: function () {
            this.getView().byId("filterbar1").setVisible(false);
            this.getView().byId("filterbar2").setVisible(true);
        },

        uploadFile: function (oEvent) {
            var oFileUploader = this.getView().byId("fileUploader");
            var file = oFileUploader.oFileUpload.files[0];
            var token = this.getView().getModel().getSecurityToken();
            var appId = this.getView().getModel("busyModel").getData().appId;
            var oUploadURL = "/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv/ITCUploadFileSet";
            jQuery.ajax({
                type: 'POST',
                url: oUploadURL,
                cache: false,
                useMultipart: false,
                contentType: "application/xlsx",
                processData: false,
                data: file,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("X-CSRF-Token", token);
                    xhr.setRequestHeader("slug", oFileUploader.getValue());
                    xhr.setRequestHeader("Content-Type", "application/xlsx");
                    xhr.setRequestHeader("appid", appId);
                },
                success: function (data, response) {
                    sap.m.MessageToast.show("File upload Successful");
                    oFileUploader.setValue('');
                    this.onRefresh();
                }.bind(this),
                error: function (error) {
                    sap.m.MessageToast.show("File upload failed");
                    oFileUploader.setValue('');

                }.bind(this)
            });
        },
        handleUploadComplete: function (oEvent) {
            var sResponse = oEvent.getParameter("response"),
                iHttpStatusCode = parseInt(/\d{3}/.exec(sResponse)[0]),
                sMessage;

            if (sResponse) {
                sMessage = iHttpStatusCode === 200 ? sResponse + " (Upload Success)" : sResponse + " (Upload Error)";
                sap.m.MessageToast.show(sMessage);
            }
            
        },

        onDownloadTemp: function () {

            var multiInputPlantToken = [];
            var multiInputBuyerCodeToken = [];
            var multiInputPlannerCodeToken = [];
            var multiInputSPCCToken = [];
            var multiInputSOReqToken = [];
            var multiInputPlant = this.getView().byId("multiInputPlant").getSelectedKeys();
            var multiInputBuyerCode = this.getView().byId("multiInputBuyerCode").getSelectedKeys();
            var multiInputPlannerCode = this.getView().byId("multiInputPlannerCode").getSelectedKeys();
            var multiInputSPCC = this.getView().byId("multiInputSPCC").getTokens();
            var multiInputSOReq = this.getView().byId("multiInputProgramID").getSelectedKeys();
            var appId = this.getView().getModel("busyModel").getData().appId;

            multiInputPlant.map(function (oToken) {
                multiInputPlantToken.push(oToken)
            }).join(",");

            multiInputBuyerCode.map(function (oToken2) {
                multiInputBuyerCodeToken.push(oToken2)
            }).join(",");

            multiInputPlannerCode.map(function (oToken) {
                multiInputPlannerCodeToken.push(oToken)
            }).join(",");

            multiInputSPCC.map(function (oToken) {
                multiInputSPCCToken.push(oToken.getText().substring(1).toUpperCase())
            }).join(",");

            multiInputSOReq.map(function (oToken) {
                multiInputSOReqToken.push(oToken)
            }).join(",");

            if (multiInputPlant.length == "0") {
                MessageBox.error("Plant cannot be blank");

            } else {
                var sUrl = "/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv/ITCTemplateFileSet(Plant='" + multiInputPlantToken + "',PlannerCode='" +
                    multiInputPlannerCodeToken + "',BuyerCode='" + multiInputBuyerCodeToken + "',SPCC='" + multiInputSPCCToken + "',ProgramID='" +
                    multiInputSOReqToken + "')/$value?appid="+appId;
                sap.m.URLHelper.redirect(sUrl);

            }

        },

        onEmptyDownloadTemp: function () {
            var appId = this.getView().getModel("busyModel").getData().appId;
            var sUrl =
                "/ui5_pp/sap/opu/odata/sap/zod_ac_itc_srv/ITCTemplateFileSet(Plant='',PlannerCode='',BuyerCode='',SPCC='',ProgramID='')/$value?appid="+appId;
            sap.m.URLHelper.redirect(sUrl);

        },

        onSPCCValueHelpRequested: function () {
            this._SPCCValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                "com.apple.scp.ui.uploadrequest.fragment.SPCCValueHelpDialog", this);
            this.getView().addDependent(this._SPCCValueHelpDialog);
            this._SPCCValueHelpDialog.setRangeKeyFields([{
                label: "SPCC",
                key: "SPCC"
            }]);

            this._SPCCValueHelpDialog.setTokens(this.getView().byId("multiInputSPCC").getTokens());
            this._SPCCValueHelpDialog.open();

        },
        onSPCCValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            this.getView().byId("multiInputSPCC").setTokens(aTokens);
            this._SPCCValueHelpDialog.close();
        },
        onPSPCCValueHelpCancelPress: function () {
            this._SPCCValueHelpDialog.close();
        },

        onSPCCValueHelpAfterClose: function () {
            this._SPCCValueHelpDialog.destroy();
        },

        onRefresh: function () {
        
            var that = this;
            this.oDateFormatUTC = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "yyyy-MM-dd",
                UTC: false
            });
            this.dToDate = this.oDateFormatUTC.format(new Date()) + "T00:00:00Z";
            this.dFromDate = new Date();
            this.dFromDate.setDate(this.dFromDate.getDate() - 30);
            this.dFromDate = this.oDateFormatUTC.format(this.dFromDate) + "T00:00:00Z";
            this.getView().getModel().read("/GetITCUploadFileSet", {
                async: true,
                filters: [new sap.ui.model.Filter("Erdat", "BT", that.dFromDate, that.dToDate)],
                success: function(data) {
                    that.getView().getModel("GetITCUploadFileSetModel").setData(data);
                    that.getView().getModel("GetITCUploadFileSetModel").refresh(true);
                },
                error: function(snItemsError1) {
                    MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                }
            });
        },
        onFilterbar1Clear: function (oEvent) {
            var oItems = this.oFilterBar1.getAllFilterItems(true);
            for (var i of oItems) {
                var oControl = this.oFilterBar1.determineControlByFilterItem(i);
                if (oControl.getId() == "container-com.apple.scp.ui.uploadrequest---Main--multiInputSPCC") {
                    oControl.removeAllTokens();
                } else {
                    oControl.removeSelectedKeys();
                    oControl.setSelectedKeys(null);
                }
            }
            this.getView().byId("multiInputPlannerCode").setEditable(false);
        },

        onClickErrorLink: function (e) {
            var ReqID = this.getView().getModel("GetITCUploadFileSetModel").getProperty(e.getSource().getParent().getBindingContext('GetITCUploadFileSetModel').getPath()).RequestId;
            this.getOwnerComponent().getRouter().navTo("object", {
                ReqID: ReqID
            });

        },

        onUploadPlantSelectionFinish: function (oEvent) {
            var selectedItems = oEvent.getParameter("selectedItems");
            var onPlannerCodesModel = new JSONModel();
            this.getView().setModel(onPlannerCodesModel, "onPlannerCodesModel");
            onPlannerCodesModel.setSizeLimit(20000);
            var onPlantRegionFilter = [];
            if (selectedItems.length > 0) {
                selectedItems.map(function (oToken) {
                    onPlantRegionFilter.push(new Filter("Plant", FilterOperator.EQ, oToken.getKey()));

                });
            
                this.getView().byId("multiInputPlannerCode").setEditable(true);
                this.getView().byId("multiInputBuyerCode").setEditable(true);
                this.getView().byId("multiInputSPCC").setEditable(true);
                this.getView().byId("multiInputProgramID").setEditable(true);
                this.getView().getModel().read("/ZC_ACITCPlannerCodes", {
                    filters: onPlantRegionFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            onPlannerCodesModel.setData(oData)
                            onPlannerCodesModel.setSizeLimit(20000);

                        }
                    },
                    error: function (snItemsError1) {

                        MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                    }
                });
                this.onBuyercodeProgramload();
            } else {
                this.getView().byId("multiInputPlannerCode").setEditable(false);
                this.getView().byId("multiInputBuyerCode").setEditable(false);
                this.getView().byId("multiInputSPCC").setEditable(false);
                this.getView().byId("multiInputProgramID").setEditable(false);
            }

        },
        onBuyercodeProgramload: function () {

            var onBuyerCodeModel = new JSONModel();
            this.getView().setModel(onBuyerCodeModel, "onBuyerCodeModel");
            onBuyerCodeModel.setSizeLimit(20000);
            var onProgramIDModel = new JSONModel();
            this.getView().setModel(onProgramIDModel, "onProgramIDModel");
            onProgramIDModel.setSizeLimit(20000);
            this.getView().getModel().read("/ZC_ACITCBuyerCodes", {
                success: function (oData) {
                    if (oData.results.length > 0) {
                        onBuyerCodeModel.setData(oData);
                    }

                },
                error: function (error) {

                    MessageBox.error(JSON.parse(error.responseText).error.message.value);
                }
            });
            this.getView().getModel().read("/ZC_ACITCProgramIds", {
                success: function (oData) {
                    if (oData.results.length > 0) {
                        onProgramIDModel.setData(oData);
                    }

                },
                error: function (snItemsError1) {

                    MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                }
            });

        }

    });
});