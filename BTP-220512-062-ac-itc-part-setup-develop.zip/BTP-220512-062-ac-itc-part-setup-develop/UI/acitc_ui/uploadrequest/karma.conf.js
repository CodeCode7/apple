module.exports = function (configAcitcUploadRequest) {
    configAcitcUploadRequest.set({
        async: true,
        frameworks: ["ui5"],

        ui5: {
            configPath: "ui5-test.yaml"
        },

        reporters: ['progress', 'coverage'],
        preprocessors: {
            'webapp/Component.js': ['coverage'],
            'webapp/!(test)/*.js': ['coverage']
        },
        coverageReporter: { type: 'lcov', dir: 'coverage', subdir: 'reports' },
        browsers: ["ChromeHeadless"],
        pingTimeout: 90000000,
        browserNoActivityTimeout: 90000000
    });

    require("karma-ui5/helper").configureIframeCoverage(configAcitcUploadRequest);
};
