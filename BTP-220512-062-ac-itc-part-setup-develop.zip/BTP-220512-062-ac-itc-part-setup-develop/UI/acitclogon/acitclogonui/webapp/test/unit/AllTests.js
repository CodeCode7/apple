sap.ui.define([
	"com/apple/scp/ui/acitclogonui/test/unit/controller/Main.controller",
    "com/apple/scp/ui/acitclogonui/test/unit/model/models",
], function () {
	"use strict";
});