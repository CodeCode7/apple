sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.apple.scp.ui.acitclogonui.controller.Main", {
		onInit: function () {
            window.close();
		}
	});
});