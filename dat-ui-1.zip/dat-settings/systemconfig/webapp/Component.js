sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/ui/dat/systemconfig/model/models",
    "sap/base/util/UriParameters",
    "sap/ui/model/odata/v2/ODataModel",
    "com/apple/scp/ui/dat/systemconfig/localService/mockserver"
],
    function (UIComponent, Device, models, UriParameters, ODataModel, MockServer) {
        "use strict";

        return UIComponent.extend("com.apple.scp.ui.dat.systemconfig.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");

                this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
                if (this.isMock) {
                    //Start Mock Server
                    this.oMockserver = MockServer.init();

                    //Set Mockmodel to Component
                    var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                        json: true
                    });

                    this.setModel(oModel);
                } else {
                    this.loadMetadata();
                }
            },

            loadMetadata: function (sUri) {
                var oParameters = {
                    defaultBindingMode: "TwoWay",
                    disableHeadRequestForToken: true,
                    headers: {
                        // appID: appId
                    }
                };

                var sUri = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
                var oModel = new sap.ui.model.odata.v2.ODataModel(sUri, oParameters);
                this.setModel(oModel);
            }
            // fetchAppIdBestBuy: function () {
            //     var that = this;
            //     fetch("/getAppVariables").then(
            //         resp => resp.json()).then(
            //             appId => {
            //                 that.loadMetadataWithAppIDBestBuy(appId);
            //             });
            // },

            // loadMetadataWithAppIDBestBuy: function (appId) {
            //     var oParameters = {
            //         defaultBindingMode: "TwoWay",
            //         disableHeadRequestForToken: true,
            //         headers: {
            //             appID: appId
            //         }
            //     };

            //     var sUriBestBuy = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
            //     var oModelBestBuy = new sap.ui.model.odata.v2.ODataModel(sUriBestBuy, oParameters);
            //     this.setModel(oModelBestBuy);
            // }

        });
    }
);