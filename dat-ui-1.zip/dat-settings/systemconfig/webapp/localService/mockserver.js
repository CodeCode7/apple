sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log"
], function (MockServer, Log) {
    "use strict";

    var _sAppPathBestBuy = "com/apple/scp/ui/dat/systemconfig/",
        _sJsonFilesPathBestBuy = _sAppPathBestBuy + "localService/mockdata",
        _aEntitySetsBestBuy = ["SysConfigSet"];

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function () {
            var sJsonFilesUrlBestBuy = sap.ui.require.toUrl(_sJsonFilesPathBestBuy),
                sManifestUrlBestBuy = sap.ui.require.toUrl(_sAppPathBestBuy + "manifest.json"),
                oManifestBestBuy = jQuery.sap.syncGetJSON(sManifestUrlBestBuy).data,
                oMainDataSource = oManifestBestBuy["sap.app"].dataSources.mainService,
                sMetadataUrlBestBuy = sap.ui.require.toUrl(_sAppPathBestBuy + oMainDataSource.settings.localUri);

            this.sMockServerUrl = oMainDataSource.uri;

            // init root URI
            this.oMockServer = new MockServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MockServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockServer.simulate(sMetadataUrlBestBuy, {
                sMockdataBaseUrl: sJsonFilesUrlBestBuy,
                aEntitySetsNames: _aEntitySetsBestBuy,
                bGenerateMissingMockData: false
            });

            this.oMockServer.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrlBestBuy + "\n" +
                "   mockdata dir: " + sJsonFilesUrlBestBuy);

            return this;
        }
    };

});