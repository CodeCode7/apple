sap.ui.define([
	"comapplescpuidat/systemconfig/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
