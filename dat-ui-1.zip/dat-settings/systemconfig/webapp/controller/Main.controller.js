sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JsonModel) {
        "use strict";

        return Controller.extend("com.apple.scp.ui.dat.systemconfig.controller.Main", {
            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("RouteMain").attachMatched(this.onRouteMatched, this);
            },

            onRouteMatched: function () {
                this.setUpViewModel();
            },

            setUpViewModel: function () {
                var gWaveModel = this.getOwnerComponent().getModel();
                this.sModel = new JsonModel();
                this.getView().setModel(this.sModel, "sModel");
                var oSup_Switch = this.getView().byId("oSup_Switch");
                var oBkg_Switch = this.getView().byId("oBkg_Switch");
                var oRoc_Switch = this.getView().byId("oRoc_Switch");

                var that = this;

                gWaveModel.read('/SysConfigSet', {
                    success: function (oData) {
                        if (oData.results[0].Bname) {
                            that.sModel.setProperty("/helpLink", oData.results[0].HelpLink);
                            oSup_Switch.setState(oData.results[0].SupplyFlg);
                            oBkg_Switch.setState(oData.results[0].BacklogFlg);
                            oRoc_Switch.setState(oData.results[0].RocFlg);
                        } else {
                            oSup_Switch.setState(false);
                            oBkg_Switch.setState(false);
                            oRoc_Switch.setState(false);
                        }
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show('Error while reading data');
                    }
                });
            },

            onHandleInfo: function () {
                var url = this.getView().getModel("sModel").getProperty("/helpLink");
                if (url) {
                    var aTag = document.createElement('a');
                    aTag.setAttribute("href", url);
                    aTag.setAttribute("target", '_blank');
                    aTag.click();
                    aTag.remove();
                }
            },

            onHandleSave: function () {
                var gWaveModel = this.getOwnerComponent().getModel();

                var oSup_Switch = this.getView().byId("oSup_Switch");
                var oBkg_Switch = this.getView().byId("oBkg_Switch");
                var oRoc_Switch = this.getView().byId("oRoc_Switch");

                var xData = {
                    // Bname: AppCache.CurrentUname, //To be checked with backend team. 
                    "SupplyFlg": oSup_Switch.getState(),
                    "BacklogFlg": oBkg_Switch.getState(),
                    "RocFlg": oRoc_Switch.getState()
                };
                sap.ui.core.BusyIndicator.show(0);

                gWaveModel.create('/SysConfigSet', xData, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        if (oData.Bname) {
                            sap.m.MessageToast.show('Data Saved');
                        } else {
                            sap.m.MessageToast.show('Save Failed');
                        }
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show('Error while saving the data');
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }
        });

    });
