/*global QUnit*/

sap.ui.define([
	"comapplescpuidat/wavecreation/controller/Manu.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Manu Controller");

	QUnit.test("I should test the Manu controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
