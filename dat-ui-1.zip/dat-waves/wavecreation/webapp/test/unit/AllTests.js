sap.ui.define([
	"comapplescpuidat/wavecreation/test/unit/controller/Manu.controller"
], function () {
	"use strict";
});
