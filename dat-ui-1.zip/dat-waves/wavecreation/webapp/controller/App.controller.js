sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.apple.scp.ui.dat.wavecreation.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  