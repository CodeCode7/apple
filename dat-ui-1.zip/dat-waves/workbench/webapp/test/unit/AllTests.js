sap.ui.define([
	"comapplescpuidat/workbench/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
