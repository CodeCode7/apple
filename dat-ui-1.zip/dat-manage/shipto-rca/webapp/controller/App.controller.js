sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.apple.scp.ui.dat.shiptorca.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  