sap.ui.define([
	"comapplescpuidat/shipto-rca/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
