sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/ui/dat/controlcenter/model/models",
    "sap/base/util/UriParameters",
    "sap/ui/model/odata/v2/ODataModel",
    "com/apple/scp/ui/dat/controlcenter/localService/mockserver",
    "com/apple/scp/ui/dat/controlcenter/controller/fa"
],
    function (UIComponent, Device, models, UriParameters, ODataModel, MockServer) {
        "use strict";

        return UIComponent.extend("com.apple.scp.ui.dat.controlcenter.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");

                this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
                if (this.isMock) {
                    //ZOD_DAT_RCA_BY_PROFILE_SRV
                    this.oMockserver = MockServer.init("ZOD_DAT_RCA_BY_PROFILE_SRV", ["PORRegionSet"], "mainService");
                    var oModel = new ODataModel(this.oMockserver.sMockServerUrl, { json: true });
                    this.setModel(oModel);

                    //ZOD_DAT_CVC_WAVE_SRV
                    this.oMockserver2 = MockServer.init("ZOD_DAT_CVC_WAVE_SRV", ["WaveWeekSet", "UserAuthChkSet", "ProfileListSet", "DATUILockSet", "SysConfigSet", "SecprofileCVCSet", "WaveprofileSet"], "waveService");
                    var oModel2 = new ODataModel(this.oMockserver2.sMockServerUrl, { json: true });
                    this.setModel(oModel2, "waveService");

                    // //ZOD_NAD_SCREEN_VARIANT_SRV
                    this.oMockserver3 = MockServer.init("ZOD_NAD_SCREEN_VARIANT_SRV", ["VariantListSet"], "variantService");
                    var oModel3 = new ODataModel(this.oMockserver3.sMockServerUrl, { json: true });
                    this.setModel(oModel3, "variantService");

                    // //ZSRV_VARIANT_DETAILS_SRV
                    this.oMockserver4 = MockServer.init("ZSRV_VARIANT_DETAILS_SRV", ["LayoutSet"], "variantDetailsService");
                    var oModel4 = new ODataModel(this.oMockserver3.sMockServerUrl, { json: true });
                    this.setModel(oModel4, "variantDetailsService");
                } else {
                    var dataSources = this.getManifestEntry("/sap.app/dataSources");
                    // var 

                    for (var service in dataSources) {
                        // skip loop if the property is from prototype
                        if (!dataSources.hasOwnProperty(service)) continue;

                        var iService = dataSources[service];
                        var serviceAlias = "";
                        if (service !== "mainService") {
                            serviceAlias = service;
                        }
                        this.loadMetadata(iService.uri, serviceAlias);

                    }
                }
            },

            loadMetadata: function (sUri, sAlias) {
                var oParameters = {
                    defaultBindingMode: "TwoWay",
                    disableHeadRequestForToken: true,
                    headers: {
                        // appID: appId
                    }
                };
                
                var oModel = new sap.ui.model.odata.v2.ODataModel(sUri, oParameters);
                if (sAlias !== "") {
                    this.setModel(oModel, sAlias);
                }else {
                    this.setModel(oModel);
                }
            }
        });
    }
);