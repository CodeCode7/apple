sap.ui.define([
    "sap/ui/model/json/JSONModel",
    '../utils/utilities',
    'sap/ui/core/Fragment'

], function (JsonModel, utilities, Fragment) {
    "use strict";

    return {
        init: function (cReference) {
            this.cReference = cReference;
        },
        initialiseVariantModel: function () {
            this.cReference.saveVariantModel = new JsonModel();
            this.cReference.getView().setModel(this.cReference.saveVariantModel, "saveVariantModel");
            this.cReference.saveVariantModel.setProperty("/globalVariantExists", false);
            this.cReference.saveVariantModel.setProperty("/isInitialScreen", true);

            this.cReference.gVflg = 'X'; // Insert Cross profile variant
            this.cReference.gdefault_cvc_var = "";
            this.cReference.gVariantDesc = "";
        },

        onSaveVariantOk: function (cRef) {
            var oProfileForm_Profile = cRef.getView().byId("oProfileForm_Profile");

            if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() == '') {
                sap.m.MessageToast.show('Please select a profile');
                return;
            }

            if (!this._lz_checkCVCSel()) {
                return;
            }

            var error = false;
            var variant = cRef.saveVariantModel.getProperty("/variant");
            var vtext = cRef.saveVariantModel.getProperty("/variantText");

            //Validate mandatory fields
            if (!variant || variant === "") { //Filter
                cRef.saveVariantModel.setProperty("/variantValueState", "Error");
                error = true;
            } else {
                cRef.saveVariantModel.setProperty("/variantValueState", "None");
            }

            if (!vtext || vtext === "") { //Description
                cRef.saveVariantModel.setProperty("/variantTextValueState", "Error");
                error = true;
            } else {
                cRef.saveVariantModel.setProperty("/variantTextValueState", "None");
            }

            if (error)
                return; //Validation error

            var CVCSelLabelText = cRef.getView().byId("CVCSel_Label").getText();
            if (CVCSelLabelText === '') {
                //Global Variant exists - update variant value accordingly
                var sVariant = CVCSelLabelText.split('(')[0]
                if (sVariant == variant) {
                    variant = CVCSelLabelText;
                }
            }

            this._saveEVariant(variant, vtext);
        },

        _saveEVariant: function (variant, vtext) {
            // Cross profile variant
            var sVariant;
            var that = this;

            var CVCSel_Label = this.cReference.getView().byId("CVCSel_Label");
            if (CVCSel_Label.getText() == undefined ||
                CVCSel_Label.getText() == null ||
                CVCSel_Label.getText() == '') {
                sVariant = variant;
            } else {
                sVariant = variant.split('(')[0]
                var xVarPrf = CVCSel_Label.getText().split('(')[1];
                var Profile = xVarPrf.split(')')[0];
            }
            // Eoc Cross profile variant
            var EaVARData = [];
            var EaFiltersvar = [];
            var oProfileForm_Profile = this.cReference.getView().byId('oProfileForm_Profile');
            EaFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
            EaFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile.getSelectedKey()));
            EaFiltersvar.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, sVariant));

            var EvarPromise = $.Deferred();
            this.cReference.gVarModel.read('/VariantDtlSet', {
                filters: EaFiltersvar,
                success: function (oData) {
                    EaVARData = oData.results;
                    EvarPromise.resolve();
                },
                error: function () {
                    sap.m.MessageToast.show(txtVariantODer);
                }
            });
            EvarPromise.then($.proxy(function () {
                //Cross profile variant
                var oProfileForm_Profile = that.cReference.getView().byId("oProfileForm_Profile");
                if (EaVARData.length > 0) {
                    that.cReference.saveVariantModel.setProperty("/isMStripVisible", true);
                    if (Profile == oProfileForm_Profile.getSelectedKey()) {
                        that.cReference.saveVariantModel.setProperty("/mStripText", 'Do you want to overwrite variant ' + sVariant + '?');
                    } else {
                        that.cReference.saveVariantModel.setProperty("/mStripText", 'Do you want to overwrite variant ' + sVariant + ' under Profile ' + oProfileForm_Profile.getSelectedKey() + '?');
                    }

                    that.cReference.saveVariantModel.setProperty("/isInitialScreen", false);
                    sap.ui.core.BusyIndicator.hide();

                } else {
                    if (Profile == oProfileForm_Profile.getSelectedKey() || // Insert DV5K935302
                        Profile == undefined || Profile == null ||
                        Profile == '') {
                        that._saveVariant(sVariant, vtext);
                    } else {
                        that.cReference.saveVariantModel.setProperty("/isMStripVisible", true);
                        that.cReference.saveVariantModel.setProperty("/mStripText", 'Do you want to save variant ' + sVariant + ' under Profile ' + oProfileForm_Profile.getSelectedKey() + '?');
                        that.cReference.saveVariantModel.setProperty("/isInitialScreen", false);
                        sap.ui.core.BusyIndicator.hide();
                    }
                }
            }));
        },

        _saveVariant: function (variant, vtext) {
            var that = this;
            var items = [];
            var oinpoSFormCVCOPS = this.cReference.getView().byId("oinpoSFormCVCOPS");
            var oinpoSFormCVCSales = this.cReference.getView().byId("oinpoSFormCVCSales");
            var oinpoSFormCVCChan = this.cReference.getView().byId("oinpoSFormCVCChan");
            var oinpoSFormCVCMPN = this.cReference.getView().byId("oinpoSFormCVCMPN");
            var oinpoSFormCVCSoldTo = this.cReference.getView().byId("oinpoSFormCVCSoldTo");

            //OPS_SUBCLASS
            var tabOPS = oinpoSFormCVCOPS.getSelectedKeys();
            for (i = 0; i < tabOPS.length; i++) {
                items.push({
                    "Selname": "OPS_SUBCLASS",
                    "Kind": "S",
                    "Sign": "I",
                    "Zoption": "EQ",
                    "Low": tabOPS[i],
                    "High": " ",
                });

            }
            //Sales Org
            var tabVKO = oinpoSFormCVCSales.getSelectedKeys();
            for (i = 0; i < tabVKO.length; i++) {
                items.push({
                    "Selname": "VKORG",
                    "Kind": "S",
                    "Sign": "I",
                    "Zoption": "EQ",
                    "Low": tabVKO[i],
                    "High": " ",
                });

            }

            //Distribution Channel
            var tabDCH = oinpoSFormCVCChan.getSelectedKeys();
            for (i = 0; i < tabDCH.length; i++) {
                items.push({
                    "Selname": "ZDISTC",
                    "Kind": "S",
                    "Sign": "I",
                    "Zoption": "EQ",
                    "Low": tabDCH[i],
                    "High": " ",
                });

            }
            //MPN
            var len = oinpoSFormCVCMPN.getTokens().length;
            if (len > 0) {
                var mpnInc = false;
                var mpnExc = false;
                for (var i = 0; i < len; i++) {
                    var oToken = oinpoSFormCVCMPN.getTokens()[i].getProperty('key');
                    if (oToken == 'Include') {
                        mpnInc = true;
                    }
                    if (oToken == 'Exclude') {
                        mpnExc = true;
                    }
                }
                if (mpnInc) {
                    let incModel = this.cReference.cvcModel.getProperty("/MPNTokenIncl");
                    let len = incModel.length;
                    if (len > 0) {
                        for (let i = 0; i < len; i++) {
                            var iData = incModel[i];
                            var selnam = 'RULE_MATNR';
                            if (iData.Type === "A") {
                                selnam = 'RULE_MATNRA';
                            }

                            var xops = {
                                Selname: selnam,
                                Kind: 'S',
                                Sign: 'I',
                                Zoption: iData.Option,
                                Low: iData.Low,
                                High: '',

                            };
                            items.push(xops);
                        }
                    }
                }
                if (mpnExc) {
                    let excModel = this.cReference.cvcModel.getProperty("/MPNTokenExcl");
                    let len = excModel.length;
                    if (len > 0) {
                        for (let i = 0; i < len; i++) {
                            var eData = excModel[i];
                            var selnam = 'RULE_MATNR';
                            if (iData.Type === "A") {
                                selnam = 'RULE_MATNRA';
                            }

                            var xops = {
                                Selname: selnam,
                                Kind: 'S',
                                Sign: 'E',
                                Zoption: eData.Option,
                                Low: eData.Low,
                                High: '',
                            };
                            items.push(xops);
                        }
                    }
                }
            }
            //SOLD TO
            var incList = this.cReference.cvcModel.getProperty("/SoldToTokenIncl");
            var excList = this.cReference.cvcModel.getProperty("/SoldToTokenExcl");
            if (incList)
                var in_len = incList.length;
            if (excList)
                var out_len = excList.length;
            for (var i = 0; i < in_len; i++) {
                if (incList[i].Type == 'B') {
                    var Binc = {
                        Selname: 'KUNNR',
                        Kind: incList[i].Kind,
                        Sign: incList[i].Sign,
                        Zoption: incList[i].Option,
                        Low: incList[i].Low,
                        High: incList[i].High,
                    };
                    items.push(Binc);
                } else if (incList[i].Type == 'A') { //Advance

                    var Ainc = {
                        Selname: 'KUNNR_A',
                        Kind: incList[i].Kind,
                        Sign: incList[i].Sign,
                        Zoption: incList[i].Option,
                        Low: incList[i].Low,
                        High: incList[i].High,
                    };
                    items.push(Ainc);

                }
            }
            for (var i = 0; i < out_len; i++) {
                if (excList[i].Type == 'A') { //Advance

                    var Ainc = {
                        Selname: 'KUNNR_A',
                        Kind: excList[i].Kind,
                        Sign: excList[i].Sign,
                        Zoption: excList[i].Option,
                        Low: excList[i].Low,
                        High: excList[i].High,
                    };
                    items.push(Ainc);

                }
            }
            var lv_global = '';
            var lv_default = '';
            var cb_cvc_Default = this.cReference.saveVariantModel.getProperty("/default")
            var cb_cvc_global = this.cReference.saveVariantModel.getProperty("/global");
            var oProfileForm_Profile = this.cReference.getView().byId("oProfileForm_Profile");

            if (cb_cvc_Default) 
                lv_default = 'X';
            
            if (cb_cvc_global) 
                lv_global = 'X';
            
            var xVarObj = {
                Action: "SAVE",
                NAV_SESSHDR_VARHDR: [{
                    "Applid": "ZUI_DAT",
                    "Report": oProfileForm_Profile.getSelectedKey(),
                    "Variant": variant,
                    "Vtext": vtext,
                    "Default_Flg": lv_default,
                    "Global_Flg": lv_global,
                    "NAV_VARHDR_VARDTL": items,
                    "NAV_VARHDR_VARLST": [],
                    "NAV_VARHDR_MSGDTL": []
                }],
            };
            var xPromise = $.Deferred();
            var agVarData = [];
            this.cReference.gVarModel.create('/SessionHdrSet', xVarObj, {
                success: function (oData, ) {
                    agVarData = oData;
                    xPromise.resolve();
                },
                error: function (oError) {
                    sap.m.MessageToast.show('Error');
                    sap.ui.core.BusyIndicator.hide();
                }
            });
            xPromise.then($.proxy(function () {
                that.cReference.s_output = agVarData.NAV_SESSHDR_VARHDR.results[0];
                //get message
                if (that.cReference.s_output.NAV_VARHDR_MSGDTL.results.length > 0) {
                    var v_sucmsg = that.cReference.s_output.NAV_VARHDR_MSGDTL.results[0].Message;
                    if (v_sucmsg) {
                        jQuery.sap.require("sap.m.MessageToast");
                        sap.m.MessageToast.show(v_sucmsg);
                        that.cReference.diaVariantSave.close();
                    }
                }
                that.cReference.gESOPSSublassLength = oinpoSFormCVCOPS.getSelectedKeys().length;
                that.cReference.gESMPNLength = oinpoSFormCVCMPN.getTokens().length;
                that.cReference.gESSalesOrgLength = oinpoSFormCVCSales.getSelectedKeys().length;
                that.cReference.gESChannelLength = oinpoSFormCVCChan.getSelectedKeys().length;
                that.cReference.gESSoldToLength = oinpoSFormCVCSoldTo.getTokens().length;
                variant = variant + '(' + oProfileForm_Profile.getSelectedKey() + ')';
                
                var CVCSel_Label = that.cReference.getView().byId("CVCSel_Label");
                CVCSel_Label.setText(variant);
                that.cReference.gVariantDesc = vtext;
                sap.ui.core.BusyIndicator.hide();
            }));

        },

        _lz_checkCVCSel: function () {
            //Validate if at least one of the CVC selection is made
            var bReturn = true;;
            var view = this.cReference.getView()
            if (!(view.byId("oinpoSFormCVCOPS").getSelectedKeys().length > 0 ||
                view.byId("oinpoSFormCVCSales").getSelectedKeys().length > 0 ||
                view.byId("oinpoSFormCVCChan").getSelectedKeys().length > 0 ||
                view.byId("oinpoSFormCVCMPN").getTokens().length > 0 ||
                view.byId("oinpoSFormCVCSoldTo").getTokens().length > 0)) {
                bReturn = false;
                sap.m.MessageToast.show('Please select one or more cvc selections');
            }
            return bReturn;
        },

        onSaveVariantClose: function (cRef) {
            cRef.diaVariantSave.close(); //Close dialog

            //Clear fields 
            this.onClearSaveVariantFields(cRef);
            // if (!cRef.saveVariantModel.getProperty("/globalVariantExists")) {
            //     //No Global Variant - go ahead and clear
            //     cRef.saveVariantModel.setProperty("/variant", "");
            //     cRef.saveVariantModel.setProperty("/variantText", "");
            //     cRef.saveVariantModel.setProperty("/global", false);
            //     cRef.saveVariantModel.setProperty("/default", false);
            // }
        },

        onClearSaveVariantFields: function(cRef){
             //Clear fields 
             if (!cRef.saveVariantModel.getProperty("/globalVariantExists")) {
                //No Global Variant - go ahead and clear
                cRef.saveVariantModel.setProperty("/variant", "");
                cRef.saveVariantModel.setProperty("/variantText", "");
                cRef.saveVariantModel.setProperty("/global", false);
                cRef.saveVariantModel.setProperty("/default", false);
            }
        },

        onCVCSelChange: function (oEvent, cRef) {
            var cData = oEvent.getParameter("listItem").getBindingContext("saveVariantModel").getObject();

            cRef.sModel.setProperty("/CVCSelLabel", cData.Variant);
            cRef.saveVariantModel.setProperty("/globalVariantExists", true);
            cRef.gdefault_cvc_var = cData.Default_Flg;
            cRef.global_cvc_var = cData.Global_Flg;
            cRef.gVariantDesc = cData.Vtext;

            /* Reset MPN and SoldTo*/
            var oinpoSFormCVCMPN = cRef.getView().byId("oinpoSFormCVCMPN");
            var oinpoSFormCVCSoldTo = cRef.getView().byId("oinpoSFormCVCSoldTo");

            oinpoSFormCVCMPN.setValueState('None');
            oinpoSFormCVCMPN.setValueStateText('');
            oinpoSFormCVCSoldTo.setValue() == '';
            oinpoSFormCVCSoldTo.setValueState('None');
            oinpoSFormCVCSoldTo.setValueStateText('');

            var varnt = cData.Variant;
            if (varnt == "") {
                this.clear();
            }

            this._setVariant(varnt);
            cRef.CVCSel_Popover.close();
        },


        _setVariant: function (iSelVar) {
            var that = this;
            var sProfile;
            var sVariant;
            var CVCSel_Label = this.cReference.getView().byId("CVCSel_Label");
            var oinpoSFormCVCOPS = this.cReference.getView().byId("oinpoSFormCVCOPS");
            var oinpoSFormCVCSales = this.cReference.getView().byId("oinpoSFormCVCSales");
            var oinpoSFormCVCChan = this.cReference.getView().byId("oinpoSFormCVCChan");
            var oinpoSFormCVCMPN = this.cReference.getView().byId("oinpoSFormCVCMPN");
            var oinpoSFormCVCSoldTo = this.cReference.getView().byId("oinpoSFormCVCSoldTo");
            var oProfileForm_Profile = this.cReference.getView().byId("oProfileForm_Profile");

            if (CVCSel_Label.getText() == undefined ||
                CVCSel_Label.getText() == null ||
                CVCSel_Label.getText() == '') {
                sProfile = oProfileForm_Profile.getSelectedKey();
                sVariant = iSelVar;
            } else {
                sVariant = iSelVar.split('(')[0]
                var xVarPrf = iSelVar.split('(')[1];
                var Profile = xVarPrf.split(')')[0];
                sProfile = Profile;
            }
            oinpoSFormCVCOPS.setBusy(true);
            oinpoSFormCVCMPN.setBusy(true);
            oinpoSFormCVCSales.setBusy(true);
            oinpoSFormCVCChan.setBusy(true);
            oinpoSFormCVCSoldTo.setBusy(true);

            var aVARData = [];
            var aFiltersvar = [];
            aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
            aFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, sProfile));
            aFiltersvar.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, sVariant));

            var varPromise = $.Deferred();
            this.cReference.gVarModel.read('/VariantDtlSet', {
                filters: aFiltersvar,
                success: function (oData, resp) {
                    varPromise.resolve();
                    aVARData = oData.results;
                },
                error: function (oError) {
                    oinpoSFormCVCOPS.setBusy(false);
                    oinpoSFormCVCMPN.setBusy(false);
                    oinpoSFormCVCSales.setBusy(false);
                    oinpoSFormCVCChan.setBusy(false);
                    oinpoSFormCVCSoldTo.setBusy(false);
                    varPromise.resolve();
                    sap.m.MessageToast.show("Error");
                }
            });
            Promise.all(
                [
                    varPromise
                ]
            ).then($.proxy(function () {
                var tabval = aVARData;
                that._setVariantToCVC(tabval);

                oinpoSFormCVCOPS.setBusy(false);
                oinpoSFormCVCMPN.setBusy(false);
                oinpoSFormCVCSales.setBusy(false);
                oinpoSFormCVCChan.setBusy(false);
                oinpoSFormCVCSoldTo.setBusy(false);

            }));
        },

        //Variant Selection change - Set the CVC data.  
        _setVariantToCVC: function (tabval) {
            var that = this;
            if (tabval.length > 0) {
                var tabops = [];
                var tabvko = [];
                var tabdch = [];
                var mpnBasic = [];
                var mpnAdvInc = [];
                var mpnAdvExc = [];
                var soldToBasic = [];
                var soldToAdvInc = [];
                var soldToAdvExc = [];

                var oinpoSFormCVCOPS = this.cReference.getView().byId("oinpoSFormCVCOPS");
                var oinpoSFormCVCSales = this.cReference.getView().byId("oinpoSFormCVCSales");
                var oinpoSFormCVCChan = this.cReference.getView().byId("oinpoSFormCVCChan");
                var oinpoSFormCVCMPN = this.cReference.getView().byId("oinpoSFormCVCMPN");
                var oinpoSFormCVCSoldTo = this.cReference.getView().byId("oinpoSFormCVCSoldTo");

                //reset values
                oinpoSFormCVCOPS.setSelectedKeys(tabops);
                oinpoSFormCVCSales.setSelectedKeys(tabvko);
                oinpoSFormCVCChan.setSelectedKeys(tabdch);

                utilities.resetMultiInput("oinpoSFormCVCMPN", "MPN"); //MPN
                utilities.resetMultiInput("oinpoSFormCVCSoldTo", "SoldTo"); //SoldTo

                var MPNinclArray = [];
                var MPNexclArray = [];
                var soldToinclArray = [];
                var soldToexclArray = [];
                $.each(tabval, function (i, data) {
                    switch (data.Selname) {
                        case "OPS_SUBCLASS":
                            if (that.cReference.gCVCOpsSubclassMap.has(data.Low))
                                tabops.push(data.Low);
                            break;

                        case "VKORG":
                            if (that.cReference.gCVCSalesOrgMap.has(data.Low))
                                tabvko.push(data.Low);
                            break;

                        case "ZDISTC":
                            if (that.cReference.gCVCChannelMap.has(data.Low))
                                tabdch.push(data.Low);

                            break;

                        case "RULE_MATNR":
                            if (that.cReference.gCVCMPNMap.has(data.Low)) {
                                var xd = {
                                    Selname: '',
                                    Kind: '',
                                    Sign: data.Sign,
                                    Option: data.Zoption,
                                    Low: data.Low,
                                    High: data.High,
                                    Txtsh: that.cReference.gCVCMPNMap.get(data.Low), //'',
                                    Type: 'B'
                                };
                                if (data.Sign === "I") {
                                    MPNinclArray.push(xd);
                                } else {
                                    MPNexclArray.push(xd);
                                }
                                mpnBasic.push(xd);
                                xd = {};
                            }
                            break;

                        case "RULE_MATNRA":
                            var xd = {
                                Selname: '',
                                Kind: '',
                                Sign: data.Sign,
                                Option: data.Zoption,
                                Low: data.Low,
                                High: '',
                                Txtsh: that.cReference.gCVCMPNMap.get(data.Low), //'',
                                Type: 'A'
                            };

                            if (data.Sign === "I") {
                                mpnAdvInc.push(xd);
                                MPNinclArray.push(xd);
                            } else {
                                mpnAdvExc.push(xd);
                                MPNexclArray.push(xd)
                            }
                            xd = {};
                            break;

                        case "KUNNR": //basic
                            if (that.cReference.gCVCSoldToMap.has(data.Low)) {
                                var xd = {
                                    Selname: '',
                                    Kind: '',
                                    Sign: data.Sign,
                                    Option: data.Zoption,
                                    Low: data.Low,
                                    High: '',
                                    Txtsh: that.cReference.gCVCSoldToMap.get(data.Low), //'',
                                    Type: 'B'
                                };
                                if (data.Sign === "I") {
                                    soldToinclArray.push(xd);
                                } else {
                                    soldToexclArray.push(xd);
                                }
                                soldToBasic.push(xd);
                                xd = {};
                            }
                            break;
                        case "KUNNR_A": //Advance
                            var xd = {
                                Selname: '',
                                Kind: '',
                                Sign: data.Sign,
                                Option: data.Zoption,
                                Low: data.Low,
                                High: '',
                                Txtsh: that.cReference.gCVCSoldToMap.get(data.Low), //'',
                                Type: 'A'
                            };

                            if (data.Sign === "I") {
                                soldToAdvInc.push(xd);
                                soldToinclArray.push(xd);
                            } else {
                                soldToAdvExc.push(xd);
                                soldToexclArray.push(xd);
                            }
                            xd = {};
                            break;
                        default:
                            //execute code default
                            break;
                    } // Switch
                });

                this.cReference.cvcModel.setProperty("/MPNTokenIncl", MPNinclArray);
                this.cReference.cvcModel.setProperty("/MPNTokenExcl", MPNexclArray);
                this.cReference.cvcModel.setProperty("/SoldToTokenIncl", soldToinclArray);
                this.cReference.cvcModel.setProperty("/SoldToTokenExcl", soldToexclArray);
                this.cReference.cvcModel.setProperty("/MPNIncListData", mpnAdvInc);
                this.cReference.cvcModel.setProperty("/MPNExcListData", mpnAdvExc);
                this.cReference.cvcModel.setProperty("/CVCSTIncListData", soldToAdvInc);
                this.cReference.cvcModel.setProperty("/CVCSTExcListData", soldToAdvExc);

                oinpoSFormCVCOPS.setSelectedKeys(tabops);
                oinpoSFormCVCSales.setSelectedKeys(tabvko);
                oinpoSFormCVCChan.setSelectedKeys(tabdch);
                this.cReference.Sorg_Select(); //Insert DV5K934151

                utilities.setVariantToMultiInput('MPN', mpnBasic.length > 0);
                utilities.setVariantToMultiInput('SoldTo', soldToBasic.length > 0);

                this.cReference.gESOPSSublassLength = oinpoSFormCVCOPS.getSelectedKeys().length;
                this.cReference.gESMPNLength = oinpoSFormCVCMPN.getTokens().length;
                this.cReference.gESSalesOrgLength = oinpoSFormCVCSales.getSelectedKeys().length;
                this.cReference.gESChannelLength = oinpoSFormCVCChan.getSelectedKeys().length;
                this.cReference.gESSoldToLength = oinpoSFormCVCSoldTo.getTokens().length;
            }
        },

        onCVCOptions: function (oEvent) {
            //Triggered when ellipses on CVC panel is pressed
            var oButton = oEvent.getSource(),
                oView = this.getView(),
                that = this;

            // create popover
            if (!this.CVCOptions_Popover) {
                var oPromise = Fragment.load({
                    id: oView.getId(),
                    name: "com.apple.scp.ui.dat.controlcenter.fragment.variant.CVCOptions_Popover",
                    controller: this
                }).then(function (oPopover) {
                    oView.addDependent(oPopover);
                    that.CVCOptions_Popover = oPopover;
                    oPopover.openBy(oButton);
                });
            } else {
                that.CVCOptions_Popover.openBy(oButton);
            }

            return oPromise;
        },

        onCVCOptionsPopoverClose: function (oEvent) {
            //Triggers when CVC options popover is closed - Clear list selection
            oEvent.getSource().getContent()[0].removeSelections();
        },

        onVariantSaveClose: function () {
            //on close of Save dialog, set the initial screen to true
            this.saveVariantModel.setProperty("/isInitialScreen", true);
        },

        getVariant: function () {
            var aVARData = [];
            // Boc Cross profile variant
            var aVarData1 = [];
            var aFiltersvar = [];
            var that = this;

            aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
            aFiltersvar.push(new sap.ui.model.Filter("vFlg", sap.ui.model.FilterOperator.EQ, this.cReference.gVflg));
            // Eoc Cross profile variant
            var varPromise = $.Deferred();
            this.cReference.gVarModel.read('/VariantListSet', {
                filters: aFiltersvar,
                success: function (oData, resp) {
                    for (var i = 0; i < oData.results.length; i++) {
                        aVARData.push(oData.results[i]);
                    }
                    varPromise.resolve();
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Error");
                }
            });
            varPromise.then($.proxy(function () {
                // Boc Cross profile variant
                var oProfileForm_Profile = that.cReference.getView().byId("oProfileForm_Profile");
                var defVar, vtext;
                for (var i = 0; i < aVARData.length; i++) {
                    if (!(aVARData[i].Applid.split("")[0].toUpperCase() + aVARData[i].Applid.split("")[1] === "W_")) {
                        aVARData[i].Variant = aVARData[i].Variant + '(' + aVARData[i].Report + ')';

                        var cd = aVARData[i];
                        if (cd.Default_Flg == 'X') {
                            cd.StarV = '#e69900';
                            // Begin of DV5K935419
                            var xVarPrf = cd.Variant.split('(')[1];
                            var Profile = xVarPrf.split(')')[0];
                            if (Profile === oProfileForm_Profile.getSelectedKey()) {
                                that.cReference.sModel.setProperty("/CVCSelLabel", cd.Variant);
                                defVar = cd.Variant;
                                vtext = cd.Vtext;
                            } // End of DV5K935419
                        } else {
                            cd.StarV = '#ffffff';
                        }
                        if (cd.Global_Flg == 'X') {
                            cd.DelV = '#0070b1';
                        } else {
                            cd.DelV = '#ffffff';
                        }

                        aVarData1.push(cd);

                    }
                }

                if (defVar && defVar != '') {
                    that.cReference.gdefault_cvc_var = 'X';
                    that.cReference.gVariantDesc = vtext;
                    that._setVariant(defVar);
                }

                that.cReference.saveVariantModel.setProperty("/CVCSelListData", aVarData1)
            }));
        },

        onCVCOptionsChange: function (oEvent) {
            this.saveVariantModel.setProperty("/isMStripVisible", false);
            this.saveVariantModel.setProperty("/mStripText", '');

            var oView = this.getView();
            var selItem = oEvent.getParameter("listItem").getId();
            var oProfileForm_Profile = this.getView().byId("oProfileForm_Profile");
            var CVCSel_Label = this.getView().byId("CVCSel_Label");
            var that = this;

            if (selItem.includes("idSaveVariant")) {
                let existingVariant = this.sModel.getProperty("/CVCSelLabel");
                var variant;
                variant = (existingVariant) ? existingVariant.split('(')[0] : '';

                this.saveVariantModel.setProperty("/variant", variant);
                this.saveVariantModel.setProperty("/variantText", this.gVariantDesc);
                if (this.global_cvc_var === "X")
                    this.saveVariantModel.setProperty("/global", true);
                else
                    this.saveVariantModel.setProperty("/global", false);

                if (this.gdefault_cvc_var === "X")
                    this.saveVariantModel.setProperty("/default", true);
                else
                    this.saveVariantModel.setProperty("/default", false);

                //Save Variant selected, open save dialog 
                if (!this.diaVariantSave) {
                    Fragment.load({
                        id: oView.getId(),
                        name: "com.apple.scp.ui.dat.controlcenter.fragment.variant.diaVariantSave",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        that.diaVariantSave = oDialog;
                        oDialog.open()
                    });
                } else {
                    this.diaVariantSave.open();
                }

                this.CVCOptions_Popover.close(); //Close CVC Variant options popover
            } else if (selItem.includes("idDeleteVariant")) { 
                if (oProfileForm_Profile.getSelectedKey() == undefined
                    || oProfileForm_Profile.getSelectedKey() == null
                    || oProfileForm_Profile.getSelectedKey() == '') {
                    sap.m.MessageToast.show('Select a profile before select');
                } else {
                    if (CVCSel_Label.getText() == undefined
                        || CVCSel_Label.getText() == null
                        || CVCSel_Label.getText() == '') {
                        sap.m.MessageToast.show('Select a variant to delete');
                    } else {
                        // Boc Cross profile variant
                        var xVarPrf = CVCSel_Label.getText().split('(')[1];
                        var Profile = xVarPrf.split(')')[0];
                        if (Profile == oProfileForm_Profile.getSelectedKey()) {
                            // Eoc Cross profile variant
                            var dialog = new sap.m.Dialog({
                                title: 'Confirm',
                                type: 'Message',
                                content: new sap.m.Text({ text: 'Are you sure you want to delete variant?' }),
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        that.vm.okDeleteVar();
                                        that.vm.clear();
                                        that.vm.onClearSaveVariantFields(that);
                                        dialog.close();
                                    },
                                    type: 'Emphasized'
                                }).addStyleClass('zBtnBlue'),
                                endButton: new sap.m.Button({
                                    text: 'Cancel',
                                    press: function () {
                                        dialog.close();
                                    },
                                    type: 'Emphasized'
                                }).addStyleClass('zBtnBlue'),
                                afterClose: function () {
                                    dialog.close();
                                }
                            }).addStyleClass('sapUiSizeCompact appleUiDialogHTA');
                            dialog.open();
                            // Boc Cross profile variant
                        } else {
                            sap.m.MessageToast.show('Profile does not Matched'); // DV5K935671
                        }
                        // Eoc Cross profile variant
                    }
                }
                this.CVCOptions_Popover.close();
            } else if (selItem.includes("idClearVariant")) { 
                this.vm.clear();
                if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() == '') {
                    CVCSel_Label.setText('');
                } else {
                    CVCSel_Label.setText('');
                }
                this.CVCOptions_Popover.close();
            }
        },

        okDeleteVar: function () {
            var that = this.cReference;
            var CVCSel_Label = that.getView().byId("CVCSel_Label");
            var oProfileForm_Profile = that.getView().byId("oProfileForm_Profile");
            // Boc Cross profile variant
            var varnt = CVCSel_Label.getText().split('(')[0]
            // Eoc Cross profile variant
            var varntdesc = that.gVariantDesc;

            var aVARData = [];
            var xVarObj = {
                Action: "DEL",
                NAV_SESSHDR_VARHDR: [{
                    "Applid": "ZUI_DAT",
                    "Report": oProfileForm_Profile.getSelectedKey(),
                    "Variant": varnt,
                    "Vtext": varntdesc,
                    "Default_Flg": "",
                    "Global_Flg": "",
                    "NAV_VARHDR_VARDTL": [],
                    "NAV_VARHDR_VARLST": [],
                    "NAV_VARHDR_MSGDTL": []
                }],
            };
            var varPromise = $.Deferred();
            that.gVarModel.create('/SessionHdrSet', xVarObj, {
                success: function (oData, resp) {
                    aVARData = oData;
                    varPromise.resolve();
                },
                error: function (oError) {
                    sap.m.MessageToast.show(txtVariantODer);
                }
            });
            varPromise.then($.proxy(function () {
                that.s_output = aVARData.NAV_SESSHDR_VARHDR.results[0];
                if (that.s_output.NAV_VARHDR_MSGDTL.results.length > 0) {
                    var v_sucmsg = that.s_output.NAV_VARHDR_MSGDTL.results[0].Message;
                    if (v_sucmsg) {
                        sap.m.MessageToast.show(v_sucmsg);
                        CVCSel_Label.setText('');
                    }
                }
                sap.ui.core.BusyIndicator.hide();
            }));
        },

        clear: function () {
            var oinpoSFormCVCOPS = this.cReference.getView().byId("oinpoSFormCVCOPS");
            var oinpoSFormCVCSales = this.cReference.getView().byId("oinpoSFormCVCSales");
            var oinpoSFormCVCChan = this.cReference.getView().byId("oinpoSFormCVCChan");
            var oinpoSFormCVCMPN = this.cReference.getView().byId("oinpoSFormCVCMPN");
            var oinpoSFormCVCSoldTo = this.cReference.getView().byId("oinpoSFormCVCSoldTo");
            var Sorg_CheckBox = this.cReference.getView().byId("Sorg_CheckBox");

            oinpoSFormCVCOPS.setSelectedKeys([]);
            oinpoSFormCVCSales.setSelectedKeys([]);
            oinpoSFormCVCChan.setSelectedKeys([]);
            oinpoSFormCVCMPN.destroyTokens();
            oinpoSFormCVCSoldTo.destroyTokens();
            Sorg_CheckBox.setSelected(false); // Insert DV5K934151
        },

        onCvcDropdownPress: function (oEvent) {
            //Triggered on click of CVC Selection Variant Dropdown
            //Get available Variant list
            //Open Popup
            var oButton = oEvent.getSource(),
                oView = this.getView(),
                that = this;

            if (!this.CVCSel_Popover) {
                Fragment.load({
                    id: oView.getId(),
                    name: "com.apple.scp.ui.dat.controlcenter.fragment.variant.CVCSel_Popover",
                    controller: this
                }).then(function (oPopover) {
                    oView.addDependent(oPopover);
                    that.CVCSel_Popover = oPopover;
                    oPopover.openBy(oButton);
                });
            } else {
                that.CVCSel_Popover.openBy(oButton);
            }
        }
    };
});
