/* global QUnit */

sap.ui.require(["com/apple/scp/ui/dat/controlcenter/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
    QUnit.config.testTimeout = 120000;
	QUnit.start();
});
