sap.ui.define([
	"comapplescpuidat/controlcenter/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
