sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent"
], function (Controller, UIComponent) {
    "use strict";

    return Controller.extend("com.apple.scp.ui.dat.controlcenter.controller.BaseController", {
        getI18nText: function (idText, params) {
            if (!this.rBundle) {
                this.rBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            }

            if (!params) {
                var text = this.rBundle.getText(idText);
            } else {
                text = this.rBundle.getText(idText, [params]);
            }

            return text;
        }

        
    });
});
