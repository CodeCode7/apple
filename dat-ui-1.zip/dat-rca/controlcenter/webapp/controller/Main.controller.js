sap.ui.define([
    // "sap/ui/core/mvc/Controller",
    "./Base.controller",
    "sap/ui/model/json/JSONModel",
    '../utils/utilities',
    '../utils/variantManagementUtil',
    '../utils/gridUtil',
    "com/apple/scp/ui/dat/controlcenter/libs/ag-grid-enterprise.min"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JsonModel, utilities, vm, gridUtil) {
        "use strict";

        return Controller.extend("com.apple.scp.ui.dat.controlcenter.controller.Main", {
            utilities: utilities,
            vm: vm,
            gridUtil: gridUtil,
            initialseViewModel() {
                this.sModel = new JsonModel();
                this.getView().setModel(this.sModel, "sModel");
                this.sModel.setProperty("/PageTitle", this.getI18nText("appDescription", this.getI18nText("barTitleProfile")));

                //Initialse util
                utilities.init(this);
                utilities.initialiseCvcModel();

                vm.init(this);
                vm.initialiseVariantModel();

                gridUtil.init(this);
                gridUtil.onInitialiseGrid();
            },

            //Begin of DV5K930819
            datui_lock_check: function (errMessage, successCallBack) {
                var that = this;
                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this.gWaveProfileSelRegion));

                var xData = [];
                var dPromise = $.Deferred();
                this.gWaveModel.read('/DATUILockSet', {
                    filters: aFilters,
                    success: function (oData) {
                        xData = oData.results;
                        dPromise.resolve();
                    },
                    error: function (oError) {
                        dPromise.reject();
                    }
                });
                dPromise.then($.proxy(function () {
                    if (xData.length != undefined) {
                        var xLock = xData[0].LockCheck;
                        if (xLock == 'X') {
                            //if DAT UI Lock is set disable buttons
                            // that.getView().byId("wave_release").setEnabled(false);
                            // that.getView().byId("wave_param").setEnabled(false);
                            // that.getView().byId("SZeroWave_Button").setEnabled(false);
                            // that.getView().byId("SZeroWave_Button").setEnabled(false);
                            // that.getView().byId("UP_Wave").setEnabled(false);
                            that.gridModel.setProperty("/isLocked", true);
                            if (errMessage)
                                sap.m.MessageToast.show(errMessage);
                        } else {
                            // that.getView().byId("wave_release").setEnabled(true);
                            // that.getView().byId("wave_param").setEnabled(true);
                            // that.getView().byId("SZeroWave_Button").setEnabled(true);
                            // that.getView().byId("SZeroWave_Button").setEnabled(true);
                            // that.getView().byId("UP_Wave").setEnabled(true);
                            that.gridModel.setProperty("/isLocked", false);
                            if (successCallBack)
                                successCallBack(that.gridUtil);
                        }
                    }
                }));
            },
            //End of DV5K930819

            onInit: function () {
                // sap.ui.core.BusyIndicator.show(0);

                this.initialseViewModel();
                this.gRunlog = []
                this.gWaveProfile = [];
                this.gWaveProfile_w = [];
                this.gWaveProfileSelRegion = "";
                this.gCVCOpsSubclassMap = new Map([]);
                this.gCVCSalesOrgMap = new Map([]);
                this.gCVCChannelMap = new Map([]);
                this.gCVCMPNMap = new Map([]);
                this.gCVCSoldToMap = new Map([]);
                this.aVariantData = [];
                this.gWaveProfileSelRegion_w;
                this.gStrgOpsSubclassList = [];
                this.gStrgMPNList = [];
                this.gStrgSalesOrgList = [];
                this.gStrgDCList = [];
                this.gStrgSoldTo = [];
                this.gStrgStrat = [];
                this.gStrgSorcp = [];
                this.gNAVWaveSCVC = [];
                this.gNAVWaveSPluids = [];
                this.gNAVWaveSMPN = [];
                this.gNAVWaveSOPS = [];
                this.gNAVWaveSSAELS = [];
                this.gNAVWaveSChannel = [];
                this.gNAVWaveSSoldTo = [];
                this.gNAVWaveSStrat = [];
                this.gNAVWaveSSorcPlant = [];
                this.gSelWaveStrategyDesc = '';
                // this.gSelWaveTimerel = '';
                // this.gStrgSelCapToDesc = '';

                var component = this.getOwnerComponent();
                //Wave Service
                this.gWaveModel = component.getModel("waveService");
                this.gWaveModel.setSizeLimit(2000);
                //Variant Service
                this.gVarModel = component.getModel("variantService");
                this.gVarModel.setSizeLimit(2000);
                //profile Service
                this.gRollModel = component.getModel();
                this.gRollModel.setSizeLimit(2000);
                //Variant Service
                this.gAGridVarModel = component.getModel("variantDetailsService");
                this.gAGridVarModel.setSizeLimit(2000);

                this.gridUtil.resetByWaveGrid();

                this.getUserAuth();
                this.getWeekDD();
                this.set_agkey();
                this.get_region();
            },

            onProfileWeekChange: function (oEvent) {
                var oProfileForm_Profile = this.getView().byId("oProfileForm_Profile")
                var l_week = oEvent.getSource().getSelectedKey();
                this.getWeekProfile(l_week, oProfileForm_Profile);

                oProfileForm_Profile.setSelectedKey('');
                utilities.resetData();

                var xGrid = document.querySelector('#xsGrid');
                if (xGrid != null) {
                    xGrid.remove();
                    this.gGridOptions.rowData = [];
                }
            },

            onHandleInfo: function () {
                var url = this.sModel.getProperty("/helpLink");
                if (url) {
                    var aTag = document.createElement('a');
                    aTag.setAttribute("href", url);
                    aTag.setAttribute("target", '_blank');
                    aTag.click();
                    aTag.remove();
                }
            },

            onBtExport_w: function () {
                var xDate = new Date();
                var fTime;
                var xHours = xDate.getHours();
                if (xHours.toString().length == 1) {
                    xHours = '0' + xHours.toString();
                }
                var xMin = xDate.getMinutes();
                if (xMin.toString().length == 1)
                    xMin = '0' + xMin.toString();
                var xSec = xDate.getSeconds();
                if (xSec.toString().length == 1)
                    xSec = '0' + xSec.toString();
                var fTime = xHours.toString() + xMin.toString() + xSec.toString();
                var tmDt = xDate.toISOString().slice(0, 10) + "_" + fTime;

                if (this.gGridOptions != undefined) {
                    this.gByWaveGridOptions.api.exportDataAsExcel({
                        fileName: 'DAT_RCA_Wave_' + tmDt,
                        processRowGroupCallback: this.rowGroupCallback,
                    });
                }
                //begin of DV5K930019
                //Download Run Log
                setTimeout(() => {
                    downloadRun();
                }, 1000);
                //end of DV5K930019
            },

            onoButtonsetWPress: function (oEvent) {
                informVariantVARIANT.setValue('');
                informGridVariantVARIANT.setValue(oSelectGridvarWave.getSelectedKey());
                if (global_grid_var_w == 'X') {
                    cb_global.setEnabled(true);
                    cb_global.setSelected(true);
                    cb_Default.setEnabled(false);
                    cb_Default.setSelected(false);
                } else {
                    cb_Default.setEnabled(true);
                    cb_global.setSelected(false);
                }
                if (gdefault_grid_var_w == 'X') {
                    cb_global.setEnabled(false);
                    cb_global.setSelected(false);
                    cb_Default.setEnabled(true);
                    cb_Default.setSelected(true);
                } else {
                    cb_global.setEnabled(true);
                    cb_Default.setSelected(false);
                }
                diaGridVariant.open();

            },
            oSelectGridvarWaveChange: function () {
                var varnt = this.getView().byId("oSelectGridvarWave").getSelectedKey();
                this.processGRIDVariant(varnt, "AG_GRID_WAVE");
            },
            onIconBarSelect: function (oEvent) {
                var selKey = oEvent.getSource().getSelectedKey();
                if (selKey == 'KPROFILE') {
                    this.sModel.setProperty("/PageTitle", this.getI18nText("appDescription", this.getI18nText("barTitleProfile")));
                } else if (selKey == 'KWAVE') {
                    this.sModel.setProperty("/PageTitle", this.getI18nText("appDescription", this.getI18nText("barTitleWave")));
                }
            },
            onWaveChangeProfile: function () {
                this._getGridDataByWave();
                this.getView().byId("SummaryPanel").setExpanded(true);
                this.clearWaveSettings();
            },
            // getVariant_w: function () {
            //     var oProfileForm_Profile_w = this.getView().byId("oProfileForm_Profile_w");
            //     var aFiltersvar = [];
            //     aFiltersvar.push(new sap.ui.model.Filter("Applid", sap.ui.model.FilterOperator.EQ, "ZUI_DAT"));
            //     aFiltersvar.push(new sap.ui.model.Filter("Report", sap.ui.model.FilterOperator.EQ, oProfileForm_Profile_w.getSelectedKey()));

            //     this.gVarModel.read('/VariantListSet', {
            //         filters: aFiltersvar,
            //         success: function (oData, resp) {
            //             aVARData = oData.results;
            //         },
            //         error: function (oError) {
            //             sap.m.MessageToast.show("Error");
            //         }
            //     });
            // },
            formatColDefWave: function (agGridColumn) {
                var agData = agGridColumn;
                for (var i = 0; i < agData.length; i++) {
                    var ag = agData[i];
                    if (ag.headerName == 'Waves') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var cData = ag.children;
                                for (var k = 0; k < cData.length; k++) {
                                    var cd = cData[k];
                                    if (cd.field == 'PREV_WAVE_QTY') {
                                        cd.valueGetter = this.fnValueGetterPreWave;
                                        cd.aggFunc = this.fnAggPreWave;
                                        cd.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    }
                    if (ag.headerName == 'Ship Plan') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var spData = ag.children;
                                var spCount = 0;
                                for (var spIndex = 0; spIndex < spData.length; spIndex++) {
                                    spCount++;
                                    var sp = spData[spIndex];
                                    sp.cellClass = 'RCASTDC';
                                    if (spIndex == 0) {
                                        sp.cellClass = 'RCASTBC';
                                    }
                                    if (spCount == spData.length) {
                                        sp.cellClass = 'RCASTEC';
                                    }
                                }
                            }
                        }
                    } //end of Ship_plan
                    if (ag.headerName == 'Supply') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var supData = ag.children;
                                var supCount = 0;
                                for (var supIdx = 0; supIdx < supData.length; supIdx++) {
                                    var sup = supData[supIdx];
                                    if (sup.field.includes('PLANT_') || sup.field == 'LOCAL_SUPPLY' || sup.field == 'OEM_SUPPLY' || sup.field == 'USER_QTY' || sup
                                        .field == 'OPEN_PA') {
                                        supCount++;
                                        sup.valueGetter = this.fnVG_PLANT;
                                        sup.aggFunc = this.aggPLANT;
                                        sup.filterParams = this.gFilterOptions; //DV5K930341
                                        sup.cellClass = 'RCASTDC';
                                        if (supIdx == 0) {
                                            sup.cellClass = 'RCASTBC';
                                        }
                                        if (supCount == supData.length) {
                                            sup.cellClass = 'RCASTEC';
                                        }
                                    }
                                }
                            }
                        }
                    } //Supply
                    if (ag.headerName == 'Future Requirements') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var frData = ag.children;
                                var frCount = 0;
                                for (var frIndex = 0; frIndex < frData.length; frIndex++) {
                                    var fr = frData[frIndex];
                                    if (fr.field == 'FUT_REQ_CW_1' || fr.field == 'FUT_REQ_CW_2' || fr.field == 'FUT_REQ_CW_3' || fr.field ==
                                        'FUT_SHIP_PLAN_QTY_CW_1' || fr.field == 'FUT_SHIP_PLAN_QTY_CW_2' || fr.field ==
                                        'FUT_SHIP_PLAN_QTY_CW_3') { //Future Requirement
                                        fr.valueGetter = this.fnVG_FUT_REQ_CW;
                                        fr.aggFunc = this.aggFUT_REQ_CW;
                                        fr.filterParams = this.gFilterOptions; //DV5K930341
                                        frCount++;

                                        fr.cellClass = 'RCASTDC';
                                        if (frIndex == 0) {
                                            fr.cellClass = 'RCASTBC';
                                        }
                                        if (frCount == frData.length) {
                                            fr.cellClass = 'RCASTEC';
                                        }
                                    }
                                }
                            }
                        }
                    } //end of Future Req
                    if (ag.headerName == 'Backlog' || ag.headerName == 'User Plan') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var bkData = ag.children;
                                var bkCount = 0;
                                for (var bkIndex = 0; bkIndex < bkData.length; bkIndex++) {
                                    var bk = bkData[bkIndex];
                                    bkCount++;

                                    bk.cellClass = 'RCASTDC';
                                    if (bkIndex == 0) {
                                        bk.cellClass = 'RCASTBC';
                                    }
                                    if (bkCount == bkData.length) {
                                        bk.cellClass = 'RCASTEC';
                                    }
                                }
                            }
                        }
                    } //end of Future Req
                    if (ag.headerName == undefined) {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var cData1 = ag.children;
                                for (var j = 0; j < cData1.length; j++) {
                                    var cd1 = cData1[j];
                                    if (cd1.enableRowGroup) {
                                        var rowGrpE = JSON.parse(cd1.enableRowGroup);
                                        cd1.enableRowGroup = rowGrpE;
                                    }
                                    if (cd1.field == 'SAT_ALLOCATION') {
                                        cd1.valueGetter = this.fnValueGetterSAT;
                                        cd1.aggFunc = this.aggSAT;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'SAT_ALLOC_TOGO') { //Sat to go
                                        cd1.valueGetter = this.fnVG_SATALLOCTOGO;
                                        cd1.aggFunc = this.aggSATALLOCTOGO;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'HOLD_BUCK_QUAN') { //Holding bucket qty
                                        cd1.valueGetter = this.fnVG_HOLDBUCKQUAN;
                                        cd1.aggFunc = this.aggHOLDBUCKQUAN;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    }
                }
                return agData;
            },

            fnValueGetterPreWave: function (params) {
                if (!params.node.group) {
                    var satAlloc = 0;
                    var holdBuck = 0;
                    if (params.data.SAT_ALLOCATION != undefined) {
                        satAlloc = params.data.SAT_ALLOCATION;
                    }
                    if (params.data.HOLD_BUCK_QUAN != undefined) {
                        holdBuck = params.data.HOLD_BUCK_QUAN;
                    }
                    var cumwaveqty = satAlloc - holdBuck;
                    if (cumwaveqty < 0) {
                        cumwaveqty = 0;
                    }
                    var xd = {
                        cumwaveqty: cumwaveqty,
                        toString: function () {
                            return (cumwaveqty) ? cumwaveqty : 0;
                        }
                    };
                    return xd;
                }
            },

            fnAggPreWave: function (values) {
                var shipTo = "";
                var cumwaveqty = 0;
                values.forEach(function (value) {
                    cumwaveqty += value.cumwaveqty;
                });
                var xd = {
                    cumwaveqty: cumwaveqty,
                    toString: function () {
                        return (cumwaveqty) ? cumwaveqty : 0;
                    }
                };
                return xd;
            },
             fnValueGetterWave: function(params) {
                if (!params.node.group) {
                    var xValue = 0;
                    var xField = params.colDef.field;
                    var iMap = new Map([]);
                    var ccData = params.data.CELL_COLOR;
                    if (ccData != undefined && ccData != null) {
                        for (var i = 0; i < ccData.length; i++) {
                            var cc = ccData[i];
                            iMap.set(cc.FNAME, cc.COLOR.COL);
                        }
                    }
                    var sCol = '';
                    if (iMap.has(xField)) {
                        var sCol = iMap.get(xField);
                    }
                    xValue = params.data[xField];
                    /* We have matached the field
                    and we got the color of the field.
                    Field : W0001
                    Color: C6*/
                    var formattedCol = 'C' + sCol;
                    var xd = {
                        field: xField,
                        COLOR: formattedCol,
                        oValue: xValue,
                        shipTo: params.data.PKUNWE,
                        roc_soldto: params.data.ROC_SOLDTO, // 79366642 - DV5K935304
                        toString: function() {
                            return (xValue) ? xValue : 0;
                        }
                    };
                }
                return xd;
            },
             fnAggWave: function(values) {
                var pkunwe = "";
                var cValue = 0;
                var cColor = '';
                var cField = '';
                var cShipTo = '';
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function(value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        if (value.oValue != undefined) {
                            cValue += value.oValue;
                        }
                        cColor = value.COLOR;
                        cField = value.field;
                        cShipTo = value.shipTo;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    } else {
                        if (value.COLOR == 'C6') {} else {
                            if (value.oValue != undefined) {
                                cValue += value.oValue;
                            }
                            cColor = value.COLOR;
                            cField = value.field;
                            cShipTo = value.shipTo;
                            roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                        }
                    }
                });
                var xd = {
                    field: cField,
                    COLOR: cColor,
                    oValue: cValue,
                    shipTo: cShipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function() {
                        return (cValue) ? cValue : 0;
                    }
                };
                return xd;
            },
            _getGridDataByWave: function () {
                //HBoxsummary.setVisible(true);
                sap.ui.core.BusyIndicator.show(0);
                var oProfileForm_Profile_w = this.getView().byId("oProfileForm_Profile_w");
                var oProfileForm_Week_w = this.getView().byId("oProfileForm_Week_w");
                var oProfileForm_WAVE_w = this.getView().byId("oProfileForm_WAVE_w");
                var oSelectGridvarWave = this.getView().byId("oSelectGridvarWave");
                var aCVC = [];
                var xGridObj = {
                    Secprofile: oProfileForm_Profile_w.getSelectedKey(),
                    FiscWeek: oProfileForm_Week_w.getSelectedKey(),
                    Region: this.gWaveProfileSelRegion_w,
                    WaveNr: oProfileForm_WAVE_w.getSelectedKey(),
                    Prof_Desc: '',
                    NAV_WPROF_GRID: [],
                    NAV_WPROF_MSG: [],
                    NAVRCALog: [],
                    NAVWaveProfileCVC: aCVC
                };
                var agGridData = [];
                var agGridColumn = [];
                var agGridRow = [];
                if (oProfileForm_Profile_w.getSelectedKey() == undefined || oProfileForm_Profile_w.getSelectedKey() == null ||
                    oProfileForm_Profile_w.getSelectedKey() == '') {
                    sap.m.MessageToast.show('Please select the wave profile.');
                    sap.ui.core.BusyIndicator.hide();
                } else {
                    var xPromise = $.Deferred();
                    var that = this;
                    that.gWaveModel.create('/WaveprofileSet', xGridObj, {
                        success: function (oData, resp) {
                            xPromise.resolve();
                            agGridData = oData;
                            if (agGridData.NAV_WPROF_GRID != undefined) {
                                if (agGridData.NAV_WPROF_GRID.results != undefined) {
                                    if (agGridData.NAV_WPROF_GRID.results.length > 0) {
                                        agGridColumn = JSON.parse(agGridData.NAV_WPROF_GRID.results[0].Zcolumn);
                                        agGridRow = JSON.parse(agGridData.NAV_WPROF_GRID.results[0].Zrowdata);
                                        that.gRunlog = agGridData.NAVRCALog.results;
                                        if (agGridRow == undefined || agGridRow == null || agGridRow == '') {
                                            sap.m.MessageToast.show('No data found');
                                        } else {
                                            that.getView().byId("oVBoxCardbut_w").setVisible(true);
                                            that.getView().byId("PanelWaveGrid").setVisible(true);
                                        }
                                        var eGridDiv = document.querySelector('#xWaveGrid');
                                        if (eGridDiv == undefined) {
                                            var div = document.createElement("div");
                                            div.id = 'xWaveGrid';
                                            div.setAttribute("style", "width:auto;height:69vh");
                                            div.setAttribute("class", "ag-theme-alpine");
                                            // var oHBoxWave = that.getView().byId("oHBoxWave");
                                            var oGrid_HTM_w = that.getView().byId("oGrid_HTM_w");
                                            // var oGrid_HTM_w = new sap.ui.core.HTML("oGrid_HTM_w", {});
                                            oGrid_HTM_w.setDOMContent(div);
                                            var eGridDiv = document.querySelector('#xWaveGrid');
                                            var fgridColumn = that.formatColDefWave(agGridColumn);
                                            that.gByWaveGridOptions.columnDefs = fgridColumn;
                                            that.gByWaveGridOptions.rowData = agGridRow;
                                            // //Below will provide the checkbox
                                            that.gByWaveGridOptions.autoGroupColumnDef = {
                                                minWidth: 200,
                                                field: 'name',
                                                headerCheckboxSelection: false,
                                                headerCheckboxSelectionFilteredOnly: false,
                                                cellRenderer: 'agGroupCellRenderer',
                                                cellRendererParams: {
                                                    checkbox: false
                                                }
                                            };
                                            new agGrid.Grid(eGridDiv, that.gByWaveGridOptions);
                                            // oHBoxWave.addItem(oGrid_HTM_w);
                                        } else {
                                            var fgridColumn = that.formatColDefWave(agGridColumn);
                                            that.gByWaveGridOptions.columnDefs = fgridColumn;
                                            //gByWaveGridOptions.api.setColumnDefs(agGridColumn);
                                            that.gByWaveGridOptions.api.setRowData(agGridRow);
                                        }

                                        that.gByWaveGridOptions.api.closeToolPanel();
                                        /*Auto size the coulms*/
                                        var allColumnIds = [];
                                        that.gByWaveGridOptions.columnApi.getAllColumns().forEach(function (column) {
                                            allColumnIds.push(column.colId);
                                        });

                                        that.gByWaveGridOptions.columnApi.autoSizeColumns(allColumnIds);

                                        //AG GRID Personalization
                                        if (allColumnIds.length > 0) {
                                            //check if call variant is selected
                                            if (oSelectGridvarWave.getSelectedKey()) {
                                                that.processGRIDVariant(oSelectGridvarWave.getSelectedKey(), "AG_GRID_WAVE");
                                            } else {

                                                that.getGRIDVariant("AG_GRID_WAVE", "I");
                                                oSelectGridvarWave.setVisible(true);
                                                that.getView().byId("oButtonsetW").setVisible(true);
                                            }
                                        }
                                        //AG GRID Personalization
                                    }
                                }
                            }
                            sap.ui.core.BusyIndicator.hide();
                            that._getWaveSetting();
                        },
                        error: function (oError) {
                            sap.m.MessageToast.show('Error');
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });
                    Promise.all(
                        [
                            xPromise
                        ]
                    ).then($.proxy(function () { }));
                }
            },
            onProfRefresh: function () {
                sap.ui.core.BusyIndicator.show(0);
                this.onProfileChg();
                this.getView().byId("CO_Text").setVisible(false);
                this.getView().byId("SummaryPanel").setExpanded(false);
                this.clearWaveSettings();
            },
            clearWaveSettings: function () {
                this.getView().byId("CO_Text").setText('');
                this.getView().byId("CO_Text").setVisible(false);
                this.gNAVWaveSChannel = [];
                this.gNAVWaveSCVC = [];
                this.gNAVWaveSMPN = [];
                this.gNAVWaveSOPS = [];
                this.gNAVWaveSPluids = [];
                this.gNAVWaveSSAELS = [];
                this.gNAVWaveSSoldTo = [];
                this.gNAVWaveSSorcPlant = [];
                this.gNAVWaveSStrat = [];
                this.gSelWaveStrategyDesc = [];
                this.gStrgDCList = [];
                this.gStrgMPNList = [];
                this.gStrgOpsSubclassList = [];
                this.gStrgSalesOrgList = [];
                this.gStrgSoldTo = [];
                this.gStrgSorcp = [];
                this.gStrgStrat = [];
                this.getView().byId("oRDC_Icon").setVisible(false);
                this.getView().byId("oRDC_Text").setText('');
                this.getView().byId("oRMPN_Icon").setVisible(false);
                this.getView().byId("oRMPN_Text").setText('');
                this.getView().byId("oROPS_Icon").setVisible(false);
                this.getView().byId("oRSalesOrg_Icon").setVisible(false);
                this.getView().byId("oRSalesOrg_Text").setText('');
                this.getView().byId("oRSBL_Text").setText('');
                this.getView().byId("oRSBP_Text").setText('');
                this.getView().byId("oRSoldTo_Icon").setVisible(false);
                this.getView().byId("oRSoldTo_Text").setText('');
                this.getView().byId("oTextROPS_Text").setText('');
                this.getView().byId("oTextRStartegy").setText('');
                this.getView().byId("S_Text_Supply").setText('');
                this.getView().byId("SRel_Text").setText('');
                this.getView().byId("S_Icon_Supply").setVisible(false);
                this.getView().byId("S_Text_Supply").setText('');
            },
            _getWaveSetting: function () {
                var oRMPN_Text = this.getView().byId("oRMPN_Text");
                var oTextROPS_Text = this.getView().byId("oTextROPS_Text");
                var oRSalesOrg_Text = this.getView().byId("oRSalesOrg_Text");
                var oRDC_Text = this.getView().byId("oRDC_Text");
                var oRSoldTo_Text = this.getView().byId("oRSoldTo_Text");
                var oProfileForm_Profile_w = this.getView().byId("oProfileForm_Profile_w");
                var oProfileForm_Week_w = this.getView().byId("oProfileForm_Week_w");
                var oProfileForm_WAVE_w = this.getView().byId("oProfileForm_WAVE_w");

                oRMPN_Text.setBusy(true);
                oTextROPS_Text.setBusy(true);
                oRSalesOrg_Text.setBusy(true);
                oRDC_Text.setBusy(true);
                oRSoldTo_Text.setBusy(true);

                this.gStrgOpsSubclassList = [];
                this.gStrgMPNList = [];
                this.gStrgSalesOrgList = [];
                this.gStrgDCList = [];
                this.gStrgSoldTo = [];
                this.gStrgStrat = [];
                this.gStrgSorcp = [];

                var xData = {
                    Secprofile: oProfileForm_Profile_w.getSelectedKey(),
                    FiscWeek: oProfileForm_Week_w.getSelectedKey(),
                    Region: this.gWaveProfileSelRegion_w,
                    CVCVariant: '',
                    WaveNr: oProfileForm_WAVE_w.getSelectedKey(),
                    NAVWaveSPluids: [],
                    NAVWaveSCVC: [],
                    NAVWaveSSAELS: [],
                    NAVWaveSOPS: [],
                    NAVWaveSMPN: [],
                    NAVWaveSSoldTo: [],
                    NAVWaveSChannel: [],
                    NAVWaveSStrat: [],
                    NAVWaveSSorcPlant: []
                };
                var aCVC = [];
                //Grid selection Data
                if (this.gGridOptions.api == undefined) { } else {
                    var agGridSelRows = this.gGridOptions.api.getSelectedRows();
                    if (agGridSelRows.length > 0) { //selected something in grid
                        for (var i = 0; i < agGridSelRows.length; i++) {
                            var gd = agGridSelRows[i];
                            var xd = {
                                Pluid: gd.PLUID
                            };
                            xData.NAVWaveSPluids.push(xd);
                        }
                    }
                }
                var rData = []
                var xPromise = $.Deferred();
                var that = this;
                that.gWaveModel.create('/WaveSettingSet', xData, {
                    success: function (oData, resp) {
                        xPromise.resolve();
                        rData = oData;
                        //					that.getView().byId("StrgSelVarInfoHdr_Text").setText('Variant Name: ' + rData.CVCVariant);
                        that.gNAVWaveSCVC = rData.NAVWaveSCVC.results;
                        that.gNAVWaveSStrat = rData.NAVWaveSStrat.results;
                        that.gNAVWaveSSorcPlant = rData.NAVWaveSSorcPlant.results;
                        var mpnLen = rData.NAVWaveSMPN.results.length;
                        if (mpnLen == 0) {
                            that.getView().byId("oRMPN_Text").setText('');
                            that.getView().byId("oRMPN_Icon").setVisible(false);
                        } else if (mpnLen == 1) {
                            that.getView().byId("oRMPN_Text").setText(rData.NAVWaveSMPN.results[0].Low);
                            that.getView().byId("oRMPN_Icon").setVisible(false);
                        } else if (mpnLen > 1) {
                            that.getView().byId("oRMPN_Text").setText(mpnLen + ' Selected');
                            that.getView().byId("oRMPN_Icon").setVisible(true);
                            for (var i = 0; i < mpnLen; i++) {
                                var mData = rData.NAVWaveSMPN.results[i];
                                that.gStrgMPNList.push({
                                    Low: mData.Low,
                                    Txtsh: mData.Txtsh
                                });
                            }
                        }
                        //OPS Subclass
                        var opsLen = rData.NAVWaveSOPS.results.length;
                        if (opsLen == 0) {
                            that.getView().byId("oTextROPS_Text").setText('');
                            that.getView().byId("oROPS_Icon").setVisible(false);
                        } else if (opsLen == 1) {
                            that.getView().byId("oTextROPS_Text").setText(rData.NAVWaveSOPS.results[0].Low);
                            that.getView().byId("oROPS_Icon").setVisible(false);
                        } else if (opsLen > 1) {
                            that.getView().byId("oTextROPS_Text").setText(opsLen + ' Selected');
                            that.getView().byId("oROPS_Icon").setVisible(true);
                            for (var i = 0; i < opsLen; i++) {
                                var mData = rData.NAVWaveSOPS.results[i];
                                that.gStrgOpsSubclassList.push({
                                    Low: mData.Low,
                                    Txtsh: mData.Txtsh
                                });
                            }
                        }
                        //Sales Org
                        var soLen = rData.NAVWaveSSAELS.results.length;
                        if (soLen == 0) {
                            that.getView().byId("oRSalesOrg_Text").setText('');
                            that.getView().byId("oRSalesOrg_Icon").setVisible(false);
                        } else if (soLen == 1) {
                            that.getView().byId("oRSalesOrg_Text").setText(rData.NAVWaveSSAELS.results[0].Low);
                            that.getView().byId("oRSalesOrg_Icon").setVisible(false);
                        } else if (soLen > 1) {
                            that.getView().byId("oRSalesOrg_Text").setText(soLen + ' Selected');
                            that.getView().byId("oRSalesOrg_Icon").setVisible(true);
                            for (var i = 0; i < soLen; i++) {
                                var mData = rData.NAVWaveSSAELS.results[i];
                                that.gStrgSalesOrgList.push({
                                    Low: mData.Low,
                                    Txtsh: mData.Txtsh
                                });
                            }
                        }
                        //Dist channel
                        var dcLen = rData.NAVWaveSChannel.results.length;
                        if (dcLen == 0) {
                            oRDC_Text.setText('');
                            that.getView().byId("oRDC_Icon").setVisible(false);
                        } else if (dcLen == 1) {
                            oRDC_Text.setText(rData.NAVWaveSChannel.results[0].Low);
                            that.getView().byId("oRDC_Icon").setVisible(false);
                        } else if (dcLen > 1) {
                            oRDC_Text.setText(dcLen + ' Selected');
                            that.getView().byId("oRDC_Icon").setVisible(true);
                            for (var i = 0; i < dcLen; i++) {
                                var mData = rData.NAVWaveSChannel.results[i];
                                that.gStrgDCList.push({
                                    Low: mData.Low,
                                    Txtsh: mData.Txtsh
                                });
                            }
                        }
                        that.gSelWaveStrategyDesc = rData.Strategy;
                        that.getView().byId("oTextRStartegy").setText(that.gSelWaveStrategyDesc);
                        that.getView().byId("oRSBP_Text").setText(rData.BasePlan);
                        that.getView().byId("oRSBL_Text").setText(rData.BacklogCap);
                        that.getView().byId("S_Text_Supply").setText(rData.NAVWaveSSorcPlant.results.length + ' Selected');
                        that.getView().byId("S_Icon_Supply").setVisible(true);
                        that.getView().byId("SRel_Text").setText(rData.Release);
                        that.getView().byId("CO_Text").setText(rData.CreationDate);
                        that.getView().byId("CO_Text").setVisible(true);
                        //Sold To
                        var stLen = rData.NAVWaveSSoldTo.results.length;
                        if (stLen == 0) {
                            oRSoldTo_Text.setText('');
                            that.getView().byId("oRSoldTo_Icon").setVisible(false);
                        } else if (stLen == 1) {
                            oRSoldTo_Text.setText(rData.NAVWaveSSoldTo.results[0].Low);
                            that.getView().byId("oRSoldTo_Icon").setVisible(false);
                        } else if (stLen > 1) {
                            oRSoldTo_Text.setText(stLen + ' Selected');
                            that.getView().byId("oRSoldTo_Icon").setVisible(true);
                            for (var i = 0; i < stLen; i++) {
                                var mData = rData.NAVWaveSSoldTo.results[i];
                                that.gStrgSoldTo.push({
                                    Low: mData.Low,
                                    Txtsh: mData.Txtsh
                                });
                            }
                        }
                        oRMPN_Text.setBusy(false);
                        oTextROPS_Text.setBusy(false);
                        oRSalesOrg_Text.setBusy(false);
                        oRDC_Text.setBusy(false);
                        oRSoldTo_Text.setBusy(false);

                    },
                    error: function (oError) {
                        xPromise.resolve();
                        sap.m.MessageToast.show('Error');
                        sap.ui.core.BusyIndicator.hide();
                        oTextSProfile.setBusy(false);
                        oTextSMPN.setBusy(false);
                        oTextSOPSSubclass.setBusy(false);
                        oTextSSalesOrg.setBusy(false);
                        oTextSDistCh.setBusy(false);
                        oTextSSoldTo.setBusy(false);
                    }
                });
                Promise.all(
                    [
                        xPromise
                    ]
                ).then($.proxy(function () { }));
            },

            get_region: function () {
                this.gridModel.setProperty("/Regions", []);
                var that = this;
                this.gRollModel.read('/PORRegionSet', {
                    success: function (oData) {
                        that.gridModel.setProperty("/Regions", oData.results);
                    },
                    error: function (oError) {
                        sap.m.MessageToast('Error fetching Regions from service');
                    }
                });
            },

            getMainMenuItems: function (params) {
                var menuItems = [];

                for (var i = 0; i < params.defaultItems.length; i++) {
                    var menuItem = params.defaultItems[i];
                    if (menuItem != 'resetColumns') {
                        menuItems.push(menuItem);
                    }
                }
                return menuItems;
            },

            getUserAuth: function () {
                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("function", sap.ui.model.FilterOperator.EQ, "RC"));
                var uaPromise = $.Deferred();
                var that = this;
                this.gWaveModel.read('/UserAuthChkSet', {
                    filters: aFilters,
                    success: function (oData, resp) {
                        uaPromise.resolve();
                        if (oData.results[0].create === "X" || oData.results[0].change === "X") {
                            that.getView().byId("Upload_MenuButton").setVisible(true);
                            that.getView().byId("Adv_MenuButton").setVisible(true);
                            that.getView().byId("wave_release").setVisible(true);
                            that.getView().byId("SZeroWave_Button").setVisible(true);
                            that.getView().byId("wave_param").setVisible(true);
                            that.getView().byId("oButtondown").setVisible(true);
                        } else {
                            if (oData.results[0].display === "X") {
                                that.getView().byId("Upload_MenuButton").setVisible(false);
                                that.getView().byId("Adv_MenuButton").setVisible(false);
                                that.getView().byId("wave_release").setVisible(false);
                                that.getView().byId("SZeroWave_Button").setVisible(false);
                                that.getView().byId("wave_param").setVisible(false);
                                that.getView().byId("oButtondown").setVisible(true);
                            }
                        }
                    },
                    error: function (oError) {
                        // wpPromise.resolve();
                        // sap.m.MessageToast.show('error User Auth');
                    }
                });
                Promise.all(
                    [
                        uaPromise
                    ]
                ).then($.proxy(function () { }));
            },

            getWeekDD: function () {
                var that = this;
                that.getView().byId("oProfileForm_Week").removeAllItems();
                var fwPromise = $.Deferred();
                this.gWaveModel.read('/WaveWeekSet', {
                    success: function (oData, resp) {
                        fwPromise.resolve();
                        var len = oData.results.length;
                        var currWeekKey = '';
                        var profile = '';
                        var region = '';
                        for (var i = 0; i < len; i++) {
                            var wd = oData.results[i];
                            that.getView().byId("oProfileForm_Week").addItem(new sap.ui.core.Item({
                                key: wd.FiscWeek,
                                text: wd.Description
                            }));
                            that.getView().byId("oProfileForm_Week_w").addItem(new sap.ui.core.Item({
                                key: wd.FiscWeek,
                                text: wd.Description
                            }));
                            if (wd.CurrentWeek) {
                                currWeekKey = wd.FiscWeek;
                                profile = wd.Secprofile;
                                region = wd.Region;
                            }
                            that.sModel.setProperty("/helpLink", wd.HelpLink);
                        }
                        that.getView().byId("oProfileForm_Week").setSelectedKey(currWeekKey);
                        that.getView().byId("oProfileForm_Week_w").setSelectedKey(currWeekKey);
                        that.getWeekProfile(currWeekKey, null, profile, region);
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show('Error fetching Weeks')
                    }
                });
            },
            set_agkey: function () {
                this.gWaveModel.read('/agEnterpriseKeySet', {
                    success: function (oData) {
                        agGrid.LicenseManager.setLicenseKey(oData.results[0].Key);
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show("Error is setting ag-grid enterprise key");
                    }
                })
            },
            onProfileChange: function (oEvent) {
                this.onProfileChg_prof();
                let oView = this.getView();
                //Save Selected profile at backend as last selection
                this.saveDefProfile(oView.byId("oProfileForm_Profile").getSelectedKey(),
                    this.gWaveProfileSelRegion,
                    oView.byId("oProfileForm_Week").getSelectedKey());

            },

            saveDefProfile: function (Profile, Region, Week) {
                var xData = {
                    Bname: 'E0658289', //TODO TO BE REMOVED //AppCache.CurrentUname,
                    Secprofile: Profile,
                    Region: Region,
                    FiscWeek: Week,
                };
                sap.ui.core.BusyIndicator.show(0)
                var rData = []
                var xPromise = $.Deferred();
                this.gWaveModel.create('/SysConfigSet', xData, {
                    success: function (oData, resp) {
                        sap.ui.core.BusyIndicator.hide();
                        xPromise.resolve();
                        rData = oData;
                    },
                    error: function (oError) {
                        xPromise.resolve();
                        sap.m.MessageToast.show('Error in saving Profile');
                        sap.ui.core.BusyIndicator.hide();

                    }
                });
                Promise.all(
                    [
                        xPromise
                    ]
                ).then($.proxy(function () { }));
            },
            getWeekProfile: function (iFiscWeek, Profile, ProfileKey, Region) {
                if (Profile)
                    Profile.removeAllItems();
                else {
                    this.getView().byId("oProfileForm_Profile").removeAllItems();
                    this.getView().byId("oProfileForm_Profile_w").removeAllItems();
                }

                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, iFiscWeek));
                var that = this;
                that.gWaveModel.read('/ProfileListSet', {
                    filters: aFilters,
                    urlParameters: {
                        '$expand': 'NAVWeekProfile'
                    },
                    success: function (oData, resp) {
                        if (oData.results[0].NAVWeekProfile != undefined) {
                            that.gWaveProfile = oData.results[0].NAVWeekProfile.results;
                            that.gWaveProfile_w = oData.results[0].NAVWeekProfile.results;
                            var len = that.gWaveProfile.length;
                            for (var i = 0; i < len; i++) {
                                var pd = that.gWaveProfile[i];
                                if (Profile) {
                                    Profile.addItem(new sap.ui.core.Item({
                                        key: pd.Secprofile,
                                        text: pd.Prof_Desc
                                    }));
                                } else {
                                    that.getView().byId("oProfileForm_Profile").addItem(new sap.ui.core.Item({
                                        key: pd.Secprofile,
                                        text: pd.Prof_Desc
                                    }));
                                    that.getView().byId("oProfileForm_Profile_w").addItem(new sap.ui.core.Item({
                                        key: pd.Secprofile,
                                        text: pd.Prof_Desc
                                    }));
                                }

                                if (ProfileKey) {
                                    if (ProfileKey == pd.Secprofile && Region == pd.Region) {
                                        var xKey = pd.Secprofile;
                                    }
                                }
                            }
                            if (xKey) {
                                that.getView().byId("oProfileForm_Profile").setSelectedKey(xKey);
                                that.onProfileChg_prof();
                                that.getView().byId("oProfileForm_Profile_w").setSelectedKey(xKey);
                                that.onProfileChg();
                            } else {
                                //in case no default profile
                                sap.ui.core.BusyIndicator.hide();
                            }
                        }
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show('error week profile');
                    }
                });
            },

            onProfileChg_prof: function () {
                var that = this;
                var l_secprof = this.getView().byId("oProfileForm_Profile").getSelectedKey();
                var oinpoSFormCVCOPS = this.getView().byId("oinpoSFormCVCOPS");
                var oinpoSFormCVCSales = this.getView().byId("oinpoSFormCVCSales");
                var oinpoSFormCVCChan = this.getView().byId("oinpoSFormCVCChan");
                // var oinpoSFormCVCMPN = this.getView().byId("oinpoSFormCVCMPN");
                // var oinpoSFormCVCSoldTo = this.getView().byId("oinpoSFormCVCSoldTo");

                // var l_week = oProfileForm_Week.getSelectedKey();

                /*Siva Changes Begin*/
                for (var i = 0; i < this.gWaveProfile.length; i++) {
                    var wpd = this.gWaveProfile[i];
                    if (wpd.Secprofile == l_secprof) {
                        this.gWaveProfileSelRegion = wpd.Region;
                    }
                }
                //Check DAT Lock
                this.datui_lock_check();
                /*Refresh models and instances for each selection or else old data is retained*/
                oinpoSFormCVCOPS.removeAllItems(); //OPS Drop down
                oinpoSFormCVCSales.removeAllItems(); //Sales Org Drop down
                oinpoSFormCVCChan.removeAllItems(); //Channel Drop down

                this.gCVCOpsSubclassMap = new Map([]);
                this.gCVCSalesOrgMap = new Map([]);
                this.gCVCChannelMap = new Map([]);
                this.gCVCMPNMap = new Map([]);
                this.gCVCSoldToMap = new Map([]);

                utilities.resetMultiInput("oinpoSFormCVCMPN", "MPN", "mpnData", true); //MPN
                utilities.resetMultiInput("oinpoSFormCVCSoldTo", "SoldTo", "soldToData", true); //Sold-to

                var xGrid = document.querySelector('#xsGrid');
                if (xGrid != null) {
                    xGrid.remove();
                    this.gGridOptions.rowData = [];
                }

                // var aCVCData = [];
                var bCVCdata = [];
                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, l_secprof));
                aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, this.getView().byId("oProfileForm_Week").getSelectedKey()));
                aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this.gWaveProfileSelRegion));

                var cvcPromise = $.Deferred();
                this.gWaveModel.read('/SecprofileCVCSet', {
                    filters: aFilters,
                    urlParameters: {
                        '$expand': 'NavSecprofCVC'
                    },
                    success: function (oData, resp) {
                        cvcPromise.resolve();
                        // aCVCData = oData.results[0].NAVSecprofileCVCList.results;
                        bCVCdata = oData.results[0].NavSecprofCVC.results;
                    },
                    error: function (oError) {
                        cvcPromise.resolve();
                        sap.m.MessageToast.show('error week profile');
                    }
                });
                Promise.all(
                    [
                        cvcPromise
                    ]
                ).then($.proxy(function () {
                    for (var i = 0; i < bCVCdata.length; i++) {
                        var cvc = bCVCdata[i];
                        if (cvc.Selname == 'OPSSUBCLASS')
                            that.gCVCOpsSubclassMap.set(cvc.Low, cvc.Low);
                        if (cvc.Selname == 'MPN')
                            that.gCVCMPNMap.set(cvc.Low, cvc.Txtsh);
                        if (cvc.Selname == 'VKORG')
                            that.gCVCSalesOrgMap.set(cvc.Low, cvc.Txtsh);
                        if (cvc.Selname == 'ZDISTC')
                            that.gCVCChannelMap.set(cvc.Low, cvc.Low);
                        if (cvc.Selname == 'KUNNR')
                            that.gCVCSoldToMap.set(cvc.Low, cvc.Txtsh);

                        // gCVCOpsSubclassMap.set(cvc.OpsSubclass, cvc.OpsSubclass);
                        // gCVCMPNMap.set(cvc.MPN, cvc.MPNDesc);
                        // gCVCSalesOrgMap.set(cvc.Vkorg, cvc.VkorgDesc);
                        // gCVCChannelMap.set(cvc.Zdistc, cvc.ZdistcDesc);
                        // gCVCSoldToMap.set(cvc.SoldTo, cvc.SoldToDesc);
                    }
                    //OPS Subclass
                    const mapSClass = new Map([...that.gCVCOpsSubclassMap.entries()].sort());
                    for (let [key, value] of mapSClass) {
                        oinpoSFormCVCOPS.addItem(new sap.ui.core.Item({
                            key: key,
                            text: value
                        }));
                    }
                    //Sales Org
                    const mapSalesOrg = new Map([...that.gCVCSalesOrgMap.entries()].sort());
                    for (let [key, value] of mapSalesOrg) {
                        oinpoSFormCVCSales.addItem(new sap.ui.core.ListItem({
                            key: key,
                            text: key,
                            additionalText: value
                        }));
                    }
                    oinpoSFormCVCSales.setShowSecondaryValues(true);

                    //Channel
                    const mapChannel = new Map([...that.gCVCChannelMap.entries()].sort());
                    for (let [key, value] of mapChannel) {
                        oinpoSFormCVCChan.addItem(new sap.ui.core.Item({
                            key: key,
                            text: value
                        }));
                    }

                    // Fill MPN data.
                    var mpnData = [];
                    for (let [key, value] of that.gCVCMPNMap) {
                        var xd = {
                            Selname: '',
                            Kind: '',
                            Sign: '',
                            Option: '',
                            Low: key,
                            High: '',
                            Txtsh: value
                        };
                        mpnData.push(xd);
                    }
                    that.cvcModel.setProperty("/mpnData", mpnData);

                    //Sold To - CVC Selection
                    var soldToData = [];
                    for (let [key, value] of that.gCVCSoldToMap) {
                        var xd = {
                            Selname: '',
                            Kind: '',
                            Sign: 'I',
                            Option: 'EQ',
                            Low: key,
                            High: '',
                            Txtsh: value,
                            Type: 'B'
                        };
                        soldToData.push(xd);
                    }
                    that.cvcModel.setProperty("/soldToData", soldToData);

                    vm.getVariant();
                }));
            },

            onTableSelectionChange: function (oEvent, fieldName, tableId) {
                if (!tableId) {
                    tableId = oEvent.getSource();
                }
                this.cvcModel.setProperty(fieldName, tableId.getSelectedContextPaths().length);
            },

            Sorg_Select: function () {
                var oinpoSFormCVCSales = this.getView().byId("oinpoSFormCVCSales");
                var Sorg_CheckBox = this.getView().byId("Sorg_CheckBox");
                var allsorg = oinpoSFormCVCSales.getKeys().valueOf().length;
                var selsorg = oinpoSFormCVCSales.getSelectedKeys().length;

                if (allsorg > selsorg) {
                    // Deselect   Sorg_CheckBox when items removed from    oinpoSFormCVCSales
                    if (Sorg_CheckBox.getSelected()) {
                        Sorg_CheckBox.setSelected(false);
                    }

                } else if (allsorg == selsorg) {
                    Sorg_CheckBox.setSelected(true);
                }
            },

            onSBButtonPress: function (oEvent) {
                if (utilities.lz_cvcValidate()) {
                    this.getGridData();
                }
            },
            getGRIDVariant: function (tableName, mode) {
                var IconTabBar = this.getView().byId("IconTabBar");

                var l_app = "ZUI_DAT_RCA";
                var aFilters = [];

                aFilters.push(new sap.ui.model.Filter("AppName", sap.ui.model.FilterOperator.EQ, l_app));
                var that = this;
                that.gAGridVarModel.read('/LayoutSet', {
                    filters: aFilters,
                    success: function (oRetrievedResult) {
                        that.aVariantData = [];
                        that.gAgVariantData = oRetrievedResult.results;
                        var lv_tab = IconTabBar.getSelectedKey();
                        switch (lv_tab) {
                            case "KPROFILE":
                                var oSelectGridvarProf = that.getView().byId("oSelectGridvarProf");
                                oSelectGridvarProf.destroyItems();
                                for (var a = 0; a < that.gAgVariantData.length; a++) {

                                    if (that.gAgVariantData[a].TableName === tableName) {
                                        if (that.gAgVariantData[a].Default === "X" && that.gAgVariantData[a].TableName === tableName) {
                                            if (mode === 'I') {
                                                oSelectGridvarProf.setSelectedKey(that.gAgVariantData[a].Variant);
                                            }
                                        }
                                        oSelectGridvarProf.addItem(new sap.ui.core.Item({
                                            key: that.gAgVariantData[a].Variant,
                                            text: that.gAgVariantData[a].Variant
                                        }));
                                    }
                                }

                                if (oSelectGridvarProf.getSelectedKey()) {
                                    that.processGRIDVariant(oSelectGridvarProf.getSelectedKey(), tableName);
                                }
                                break;
                            case "KWAVE":
                                var oSelectGridvarWave = that.getView().byId("oSelectGridvarWave");
                                oSelectGridvarWave.destroyItems();

                                for (var a = 0; a < that.gAgVariantData.length; a++) {
                                    if (that.gAgVariantData[a].TableName === tableName) {
                                        if (that.gAgVariantData[a].Default === "X") {
                                            if (mode === 'I') {
                                                oSelectGridvarWave.setSelectedKey(that.gAgVariantData[a].Variant);
                                            }
                                        }

                                        oSelectGridvarWave.addItem(new sap.ui.core.Item({
                                            key: that.gAgVariantData[a].Variant,
                                            text: that.gAgVariantData[a].Variant
                                        }));
                                    }
                                }

                                if (oSelectGridvarWave.getSelectedKey()) {
                                    that.processGRIDVariant(oSelectGridvarWave.getSelectedKey(), tableName);
                                }
                                break;
                        }
                    }
                });
            },
            getGridData: function () {
                var oSelectGridvarProf = this.getView().byId("oSelectGridvarProf");
                var oButtonset = this.getView().byId("oButtonset");
                sap.ui.core.BusyIndicator.show(0);
                var aCVC = [];
                //Ops Subclass
                var ops = this.getView().byId("oinpoSFormCVCOPS").getSelectedKeys();
                if (ops.length > 0) {
                    for (var i = 0; i < ops.length; i++) {
                        var xops = {
                            Selname: 'OPSSUBCLASS',
                            Kind: 'S',
                            Sign: 'I',
                            Option: 'EQ',
                            Low: ops[i],
                            High: '',
                            Txtsh: ''
                        };
                        aCVC.push(xops);
                    }
                }
                //MPN
                var len = this.getView().byId("oinpoSFormCVCMPN").getTokens().length;
                if (len > 0) {
                    var mpnInc = false;
                    var mpnExc = false;
                    for (var i = 0; i < len; i++) {
                        var oToken = this.getView().byId("oinpoSFormCVCMPN").getTokens()[i].getProperty('key');
                        if (oToken == 'Include') {
                            mpnInc = true;
                        }
                        if (oToken == 'Exclude') {
                            mpnExc = true;
                        }
                    }
                    if (mpnInc) {
                        var inclModel = this.cvcModel.getProperty("/MPNTokenIncl");
                        var len = inclModel.length; //gMainMRef.getData().MPNIncListData.length;
                        if (len > 0) {
                            for (var i = 0; i < len; i++) {
                                var iData = inclModel[i];

                                var xops = {
                                    Selname: 'MPN',
                                    Kind: 'S',
                                    Sign: 'I',
                                    Option: iData.Option,
                                    Low: iData.Low,
                                    High: '',
                                    Txtsh: ''
                                };
                                aCVC.push(xops);
                            }
                        }
                    }
                    if (mpnExc) {
                        // var len = gMainMRef.getData().MPNExcListData.length;
                        var exclModel = this.cvcModel.getProperty("/MPNTokenExcl");
                        var len = exclModel.length;
                        if (len > 0) {
                            for (var i = 0; i < len; i++) {
                                var eData = exclModel[i];

                                var xops = {
                                    Selname: 'MPN',
                                    Kind: 'S',
                                    Sign: 'E',
                                    Option: eData.Option,
                                    Low: eData.Low,
                                    High: '',
                                    Txtsh: ''
                                };
                                aCVC.push(xops);
                            }
                        }
                    }
                }
                //Sales Org
                var so = this.getView().byId("oinpoSFormCVCSales").getSelectedKeys();
                if (so.length > 0) {
                    for (var i = 0; i < so.length; i++) {
                        var xops = {
                            Selname: 'SALESORG',
                            Kind: 'S',
                            Sign: 'I',
                            Option: 'EQ',
                            Low: so[i],
                            High: '',
                            Txtsh: ''
                        };
                        aCVC.push(xops);
                    }
                }
                //Channel
                var channel = this.getView().byId("oinpoSFormCVCChan").getSelectedKeys();
                if (channel.length > 0) {
                    for (var i = 0; i < channel.length; i++) {
                        var xops = {
                            Selname: 'CHANNEL',
                            Kind: 'S',
                            Sign: 'I',
                            Option: 'EQ',
                            Low: channel[i],
                            High: '',
                            Txtsh: ''
                        };
                        aCVC.push(xops);
                    }
                }
                //Sold To
                var len = this.getView().byId("oinpoSFormCVCSoldTo").getTokens().length;
                if (len > 0) {
                    var stInc = false;
                    var stExc = false;
                    for (var i = 0; i < len; i++) {
                        var oToken = this.getView().byId("oinpoSFormCVCSoldTo").getTokens()[i].getProperty('key');
                        if (oToken == 'Include') {
                            stInc = true;
                        }
                        if (oToken == 'Exclude') {
                            stExc = true;
                        }
                    }
                    if (stInc) {
                        var inclModel = this.cvcModel.getProperty("/SoldToTokenIncl");
                        var len = inclModel.length; //gMainMRef.getData().CVCSTIncListData.length;
                        if (len > 0) {
                            for (var i = 0; i < len; i++) {
                                var iData = inclModel[i];//gMainMRef.getData().CVCSTIncListData[i];

                                var xops = {
                                    Selname: 'SOLDTO',
                                    Kind: 'S',
                                    Sign: 'I',
                                    Option: iData.Option,
                                    Low: iData.Low,
                                    High: '',
                                    Txtsh: ''
                                };
                                aCVC.push(xops);
                            }
                        }
                    }
                    if (stExc) {
                        var exclModel = this.cvcModel.getProperty("/SoldToTokenExcl");
                        var len = exclModel.length; //gMainMRef.getData().CVCSTExcListData.length;
                        if (len > 0) {
                            for (var i = 0; i < len; i++) {
                                var eData = exclModel[i]; //gMainMRef.getData().CVCSTExcListData[i];

                                var xops = {
                                    Selname: 'SOLDTO',
                                    Kind: 'S',
                                    Sign: 'E',
                                    Option: eData.Option,
                                    Low: eData.Low,
                                    High: '',
                                    Txtsh: ''
                                };
                                aCVC.push(xops);
                            }
                        }
                    }
                }

                var xGrid = document.querySelector('#xsGrid');
                if (xGrid != null) {
                    xGrid.remove();
                    this.gGridOptions.rowData = [];
                }

                var xGridObj = {
                    Secprofile: this.getView().byId("oProfileForm_Profile").getSelectedKey(),
                    FiscWeek: this.getView().byId("oProfileForm_Week").getSelectedKey(),
                    Region: this.gWaveProfileSelRegion,
                    Prof_Desc: '',
                    NAV_WPROF_GRID: [],
                    NAV_WPROF_MSG: [],
                    NAVWaveProfileCVC: aCVC
                };

                var agGridData = [];
                var agGridColumn = [];
                var agGridRow = [];
                var oProfileForm_Profile = this.getView().byId("oProfileForm_Profile");
                if (oProfileForm_Profile.getSelectedKey() == undefined || oProfileForm_Profile.getSelectedKey() == null || oProfileForm_Profile.getSelectedKey() ==
                    '') {
                    sap.m.MessageToast.show('Please select the wave profile.');

                    sap.ui.core.BusyIndicator.hide();

                } else {
                    var xPromise = $.Deferred();
                    var that = this;
                    that.gWaveModel.create('/WaveprofileSet', xGridObj, {
                        success: function (oData, resp) {
                            agGridData = oData;
                            xPromise.resolve();
                        },
                        error: function (oError) {
                            sap.m.MessageToast.show('Error');
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });

                    xPromise.then($.proxy(function () {
                        if (agGridData.NAV_WPROF_GRID != undefined) {
                            if (agGridData.NAV_WPROF_GRID.results != undefined) {
                                if (agGridData.NAV_WPROF_GRID.results.length > 0) {

                                    agGridColumn = JSON.parse(agGridData.NAV_WPROF_GRID.results[0].Zcolumn);
                                    agGridRow = JSON.parse(agGridData.NAV_WPROF_GRID.results[0].Zrowdata);
                                    if (agGridRow == undefined || agGridRow == null || agGridRow == '') {
                                        sap.m.MessageToast.show('No data found');
                                    } else {
                                        that.getView().byId("Grid_Panel").setVisible(true);
                                        that.getView().byId("oVBoxCardbut").setVisible(true);
                                    }
                                    var eGridDiv = document.querySelector('#xsGrid');
                                    if (eGridDiv == undefined) {
                                        var div = document.createElement("div");
                                        div.id = 'xsGrid';
                                        div.setAttribute("style", "width:auto;height:69vh");
                                        div.setAttribute("class", "ag-theme-alpine");
                                        var Grid_HTML1 = that.getView().byId("Grid_HTML1"); //new sap.ui.core.HTML("Grid_HTML1", {});
                                        Grid_HTML1.setDOMContent(div);
                                        var eGridDiv = document.querySelector('#xsGrid');
                                        var fColDef = that.formatColDef(agGridColumn);
                                        that.gGridOptions.columnDefs = fColDef;
                                        that.gGridOptions.rowData = agGridRow;
                                        //Below will provide the checkbox
                                        that.gGridOptions.autoGroupColumnDef = {
                                            minWidth: 200,
                                            field: 'name',
                                            headerCheckboxSelection: true,
                                            headerCheckboxSelectionFilteredOnly: true,
                                            cellRenderer: 'agGroupCellRenderer',
                                            cellRendererParams: {
                                                checkbox: true
                                            }
                                        };
                                        new agGrid.Grid(eGridDiv, that.gGridOptions);
                                        // oHBoxWaverep.addItem(Grid_HTML1);
                                    } else {
                                        var fColDef1 = that.formatColDef(agGridColumn);
                                        that.gGridOptions.api.setColumnDefs([]);
                                        that.gGridOptions.api.setColumnDefs(fColDef1);
                                        that.gGridOptions.api.setRowData(agGridRow);
                                    }
                                    //gGridOptions.api.sizeColumnsToFit();
                                    that.gGridOptions.api.closeToolPanel();
                                    /*Auto size the coulms*/
                                    var allColumnIds = [];
                                    that.gGridOptions.columnApi.getAllColumns().forEach(function (column) {
                                        allColumnIds.push(column.colId);
                                    });
                                    that.gGridOptions.columnApi.autoSizeColumns(allColumnIds);

                                    //AG GRID Personalization
                                    if (allColumnIds.length > 0) {
                                        //check if call variant is selected
                                        if (oSelectGridvarProf.getSelectedKey()) {
                                            that.processGRIDVariant(oSelectGridvarProf.getSelectedKey(), "AG_GRID_PROF");
                                        } else {

                                            that.getGRIDVariant("AG_GRID_PROF", "I");
                                            oSelectGridvarProf.setVisible(true);
                                            oButtonset.setVisible(true);
                                        }
                                    }
                                    //AG GRID Personalization

                                }
                            }
                        }

                        sap.ui.core.BusyIndicator.hide();
                        if (agGridRow == undefined || agGridRow == null || agGridRow == '') {
                            sap.m.MessageToast.show('No data found');
                        }
                        if (agGridData.HanaError !== undefined && agGridData.HanaError !== null && agGridData.HanaError !== '') {
                            sap.m.MessageToast.show(agGridData.HanaError);
                        }
                    }));
                }
            },
            processGRIDVariant: function (variant, tableName) {
                var colmid
                var lv_table = tableName; //Replace with actual table name
                var l_app = "ZUI_DAT_RCA";
                var resultModel;
                var lv_tab = this.getView().byId("IconTabBar").getSelectedKey();
                var that = this;

                if (lv_tab == 'KPROFILE') {
                    this.gridModel.setProperty("/gridVariantP", variant);
                } else if (lv_tab == 'KWAVE') {
                    this.gridModel.setProperty("/gridVariantW", variant);
                }
                if (variant !== "") {
                    var aFilters = [];
                    aFilters.push(new sap.ui.model.Filter("AppName", sap.ui.model.FilterOperator.EQ, l_app));
                    aFilters.push(new sap.ui.model.Filter("TableName", sap.ui.model.FilterOperator.EQ, lv_table));
                    aFilters.push(new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, variant));
                    var pwPromise = $.Deferred();
                    this.gAGridVarModel.read('/ColumnSet', {
                        filters: aFilters,
                        success: function (oRetrievedResult) {
                            resultModel = oRetrievedResult;
                            pwPromise.resolve();
                        },
                        error: function () {
                            //set default
                            sap.m.MessageToast.show("Layout not found");
                        }
                    });
                    pwPromise.then($.proxy(function () {
                        var Columnlay = [];
                        var rowgrplay = [];
                        var rowgrpcol = [];
                        var autogrpcol = [];
                        var pinautogrpcol = [];
                        var rowgrpcoll = [];
                        var Columngrplay = [];
                        var columnsData;
                        var rowgrpidx;

                        //Get default or global variant columnsData
                        if (resultModel.results.length > 0) {
                            columnsData = resultModel.results[0].Columns.split("-");
                            if (tableName == 'AG_GRID_PROF') {
                                (resultModel.results[0].Default === 'X') ? that.gridModel.setProperty("/defaultP", true) : that.gridModel.setProperty("/defaultP", false);
                                (resultModel.results[0].Global === 'X') ? that.gridModel.setProperty("/globalP", true) : that.gridModel.setProperty("/globalP", false);
                            } else if (tableName == 'AG_GRID_WAVE') {
                                (resultModel.results[0].Default === 'X') ? that.gridModel.setProperty("/defaultW", true) : that.gridModel.setProperty("/defaultW", false);
                                (resultModel.results[0].Global === 'X') ? that.gridModel.setProperty("/globalW", true) : that.gridModel.setProperty("/globalW", false);
                                // that.global_grid_var_w = resultModel.results[0].Global;
                                // that.gdefault_grid_var_w = resultModel.results[0].Default;
                            }

                            if (lv_tab == 'KPROFILE') {
                                rowgrpcol = that.gGridOptions.columnApi.getRowGroupColumns();
                            } else if (lv_tab == 'KWAVE') {
                                rowgrpcol = that.gByWaveGridOptions.columnApi.getRowGroupColumns();
                            }

                            for (var i = 0; i < rowgrpcol.length; i++) {
                                var gd = rowgrpcol[i];
                                rowgrpcoll.push(gd.colId);
                            }
                            var allcol;
                            var selcol;

                            if (lv_tab == 'KPROFILE') {
                                that.gGridOptions.columnApi.removeRowGroupColumns(rowgrpcoll);
                                allcol = that.gGridOptions.columnApi.getAllColumns();
                                selcol = that.gGridOptions.columnApi.getAllDisplayedColumns();
                                that.gGridOptions.columnApi.setColumnsPinned(selcol, null);
                                that.gGridOptions.columnApi.setColumnsPinned(autogrpcol, null);
                            } else if (lv_tab == 'KWAVE') {
                                that.gByWaveGridOptions.columnApi.removeRowGroupColumns(rowgrpcoll);
                                allcol = that.gByWaveGridOptions.columnApi.getAllColumns();
                                selcol = that.gByWaveGridOptions.columnApi.getAllDisplayedColumns();
                                that.gByWaveGridOptions.columnApi.setColumnsPinned(selcol, null);
                                that.gByWaveGridOptions.columnApi.setColumnsPinned(autogrpcol, null);
                            }

                            rowgrpidx = 0;
                            $.each(columnsData, function (i, item1) {
                                var n = item1.includes("AGGRIDROWGRP.");

                                if (n === true) {
                                    var rowgrp = [];
                                    rowgrp = item1.split(".");
                                    colmid = rowgrp[1];
                                    rowgrpidx = rowgrpidx + 1;
                                } else {
                                    var k = item1.includes("AGGRIDCOLGRP.");
                                    if (k === true) {
                                        var colgrp = [];
                                        colgrp = item1.split(".");
                                        var vcolmngrpid = colgrp[1];
                                        var vcolgrp;
                                        var vAllChildren = [];
                                        if (lv_tab == 'KPROFILE') {
                                            that.gGridOptions.columnApi.setColumnGroupState([{
                                                groupId: vcolmngrpid,
                                                open: true
                                            }])
                                            vcolgrp = that.gGridOptions.columnApi.getColumnGroup(vcolmngrpid);
                                        } else if (lv_tab == 'KWAVE') {
                                            that.gByWaveGridOptions.columnApi.setColumnGroupState([{
                                                groupId: vcolmngrpid,
                                                open: true
                                            }])
                                            vcolgrp = that.gByWaveGridOptions.columnApi.getColumnGroup(vcolmngrpid);
                                        }
                                        if (vcolgrp) {
                                            vAllChildren = vcolgrp.getOriginalColumnGroup().getChildren();
                                        } else {
                                            if (lv_tab == 'KPROFILE') {
                                                vcolgrp = that.gGridOptions.columnApi.getOriginalColumnGroup(vcolmngrpid);
                                            } else if (lv_tab == 'KWAVE') {
                                                vcolgrp = that.gByWaveGridOptions.columnApi.getOriginalColumnGroup(vcolmngrpid);

                                            }
                                            if (vcolgrp) {
                                                vAllChildren = vcolgrp.getChildren();
                                            }
                                        }
                                        if (vAllChildren) {
                                            Columngrplay.push.apply(Columngrplay, vAllChildren);
                                        }
                                    } else {
                                        var m = item1.includes("AGGRIDPIN.");

                                        if (m === true) {
                                            var pincol = [];
                                            pincol = item1.split(".");
                                            var vpincol = pincol[1];
                                            colmid = pincol[2];
                                        } else {
                                            var h = item1.includes("AGGRIDAUTOPIN.");
                                            if (h === true) {
                                                var hcol = [];
                                                hcol = item1.split(".");
                                                var vhcol = hcol[1];
                                                var hcolmid = hcol[2];
                                                colmid = "";
                                                var xd = {
                                                    colname: hcolmid,
                                                    pinval: vhcol
                                                };
                                                pinautogrpcol.push(xd);
                                            } else {
                                                colmid = item1;
                                            }
                                        }

                                    }
                                }
                                if (colmid !== undefined) {
                                    $.each(allcol, function (j, item2) {
                                        //if (item2.colId.includes(colmid)) {
                                        if (item2.colId == colmid) {
                                            if (n === true) {
                                                rowgrplay.push(item2);
                                                //  column.getPinned(vpincol);
                                            } else {

                                                if (vpincol !== undefined) {
                                                    item2.setPinned(vpincol);
                                                }
                                                Columnlay.push(item2);
                                            }
                                        }
                                    });
                                }
                            });

                            //begin of DV5K930019
                            var vindex = [];
                            var vdex = '';
                            //Get all visible columngroup
                            for (var i in Columnlay) {
                                if (vdex !== Columnlay[i].getOriginalParent().groupId) {
                                    vdex = Columnlay[i].getOriginalParent().groupId;
                                    vindex.push(Columnlay[i]);
                                }
                            }

                            // var vdex1 = '';
                            var vdex2 = '';
                            var indx = 0;
                            var allColumns = allcol;
                            allColumns.reverse();
                            //Process to add hidden col group at same sequence as before
                            for (let a in allColumns) {
                                if (vdex2 !== allColumns[a].getOriginalParent().groupId) {
                                    var gfound = false;
                                    vdex2 = allColumns[a].getOriginalParent().groupId;
                                    for (var b in vindex) {
                                        if (vdex2 === vindex[b].getOriginalParent().groupId) {
                                            gfound = true;
                                        }
                                    }
                                    if (gfound == false) {
                                        vindex.splice(indx, 0, allColumns[a]);
                                    }
                                    indx++;
                                }
                            }

                            rowgrplay.reverse();
                            Columnlay.reverse();
                            if (lv_tab == 'KPROFILE') {
                                that.gGridOptions.columnApi.setColumnsVisible(selcol, false);
                                that.gGridOptions.columnApi.setColumnsVisible(Columnlay, true);

                                for (var f in vindex) {
                                    var dgrp = [];
                                    dgrp = vindex[f].getOriginalParent().children;
                                    var icolary = [];
                                    var viscol = [];
                                    var inviscol = [];
                                    for (var g in dgrp) {
                                        var ifound = false;
                                        for (var l in Columnlay) {
                                            if (Columnlay[l].colId === dgrp[g].colId) {
                                                ifound = true;
                                                var vcol = {
                                                    index: parseInt(l),
                                                    col: dgrp[g].colId
                                                };
                                                viscol.push(vcol);
                                            }
                                        }
                                        //if column not part of visible columns
                                        if (ifound == false) {
                                            var vcol = {
                                                index: parseInt(g),
                                                col: dgrp[g].colId
                                            };
                                            inviscol.push(vcol);
                                        }
                                    }

                                    //sort visible columns
                                    viscol.sort(that.fnNrSort);

                                    for (let v in viscol) {
                                        icolary.push(viscol[v].col);
                                    }

                                    for (let iv in inviscol) {
                                        let col = inviscol[iv].col;
                                        if (iv > icolary.length) {
                                            icolary.push(col);
                                        } else {
                                            icolary.splice(inviscol[iv].index, 0, col);
                                        }
                                    }

                                    //Set the group colum sequence for the layout
                                    that.gGridOptions.columnApi.moveColumns(icolary, []);
                                }
                                //end of DV5K930019
                                that.gGridOptions.columnApi.setColumnsVisible(Columngrplay, true);
                                that.gGridOptions.columnApi.addRowGroupColumns(rowgrplay);

                                for (var i in pinautogrpcol) {
                                    that.gGridOptions.columnApi.columnController.getGroupAutoColumns().forEach(function (autocolumn) {
                                        if (pinautogrpcol[i].colname === autocolumn.getColDef().showRowGroup) {
                                            that.gGridOptions.columnApi.setColumnPinned(autocolumn.colId, pinautogrpcol[i].pinval);
                                        }
                                    });
                                }
                            } else if (lv_tab == 'KWAVE') {
                                that.gByWaveGridOptions.columnApi.setColumnsVisible(selcol, false);
                                that.gByWaveGridOptions.columnApi.setColumnsVisible(Columnlay, true);

                                //begin of DV5K930019
                                for (var p in vindex) {
                                    var dgrpw = [];
                                    dgrpw = vindex[p].getOriginalParent().children;
                                    var icolaryw = [];
                                    var viscol = [];
                                    var inviscol = [];
                                    for (var g in dgrpw) {
                                        var ifound = false;
                                        for (var l in Columnlay) {
                                            if (Columnlay[l].colId === dgrpw[g].colId) {
                                                ifound = true;
                                                var vcol = {
                                                    index: parseInt(l),
                                                    col: dgrpw[g].colId
                                                };
                                                viscol.push(vcol);
                                            }
                                        }
                                        //if column not part of visible columns
                                        if (ifound == false) {
                                            var vcol = {
                                                index: parseInt(g),
                                                col: dgrpw[g].colId
                                            };
                                            inviscol.push(vcol);
                                        }
                                    }

                                    //sort visible columns
                                    viscol.sort(that.fnNrSort);

                                    for (var v in viscol) {
                                        icolaryw.push(viscol[v].col);
                                    }

                                    for (var iv in inviscol) {
                                        var col = inviscol[iv].col;
                                        if (iv > icolaryw.length) {
                                            icolaryw.push(col);
                                        } else {
                                            icolaryw.splice(inviscol[iv].index, 0, col);
                                        }
                                    }

                                    //Set the group colum sequence for the layout
                                    that.gByWaveGridOptions.columnApi.moveColumns(icolaryw, []);
                                }
                                //end of DV5K930019
                                that.gByWaveGridOptions.columnApi.setColumnsVisible(Columngrplay, true);
                                that.gByWaveGridOptions.columnApi.addRowGroupColumns(rowgrplay);

                                for (var i in pinautogrpcol) {
                                    that.gByWaveGridOptions.columnApi.columnController.getGroupAutoColumns().forEach(function (autocolumn) {
                                        if (pinautogrpcol[i].colname === autocolumn.getColDef().showRowGroup) {
                                            that.gByWaveGridOptions.columnApi.setColumnPinned(autocolumn.colId, pinautogrpcol[i].pinval);
                                        }
                                    });
                                }
                            }
                        }
                    }));
                }
            },
            fnNrSort: function (a, b) {
                if (a.index === b.index) {
                    return 0;
                } else {
                    return (a.index < b.index) ? -1 : 1;
                }
            },

            formatColDef: function (agGridColumn) {
                var agData = agGridColumn;
                for (var i = 0; i < agData.length; i++) {
                    var ag = agData[i];
                    if (ag.headerName == 'Waves') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var cData = ag.children;
                                for (var k = 0; k < cData.length; k++) {
                                    var cd = cData[k];
                                    if (cd.field.includes('WAVE_QTY_')) {
                                        cd.valueGetter = this.fnValueGetterWave;
                                        cd.aggFunc = this.fnAggWave;
                                        cd.filterParams = this.gFilterOptions; //DV5K930341
                                        cd.cellClassRules = {
                                            'C3': function (params) {
                                                if (!params.node.group) {
                                                    if (params.value != undefined && params.value != null) {
                                                        return params.value.COLOR === 'C3';
                                                    }
                                                }
                                            },
                                            'C5': function (params) {
                                                if (!params.node.group) {
                                                    if (params.value != undefined && params.value != null) {
                                                        return params.value.COLOR === 'C5';
                                                    }
                                                }
                                            },
                                            'C6': function (params) {
                                                if (!params.node.group) {
                                                    if (params.value != undefined && params.value != null) {
                                                        return params.value.COLOR === 'C6';
                                                    }
                                                }
                                            },
                                            'C7': function (params) {
                                                if (!params.node.group) {
                                                    if (params.value != undefined && params.value != null) {
                                                        return params.value.COLOR === 'C7';
                                                    }
                                                }
                                            },
                                        };
                                    } else if (cd.field == 'CUM_WAVE_QTY') { //Cum Wave qty
                                        cd.valueGetter = this.fnVG_CUMWAVEQTY;
                                        cd.aggFunc = this.aggCUMWAVEQTY;
                                        cd.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    }
                    if (ag.headerName == undefined) {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var cData1 = ag.children;
                                // sessionStorage.Aggr_Select = this.getView().byId("Aggr_Select").getSelectedKey();
                                for (var j = 0; j < cData1.length; j++) {
                                    var cd1 = cData1[j];
                                    if (cd1.enableRowGroup) {
                                        var rowGrpE = JSON.parse(cd1.enableRowGroup);
                                        cd1.enableRowGroup = rowGrpE;
                                    }
                                    if (cd1.field == 'SAT_ALLOCATION') {
                                        cd1.valueGetter = this.fnValueGetterSAT;
                                        cd1.aggFunc = this.aggSAT;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'SAT_ALLOC_TOGO') { //Sat to go
                                        cd1.valueGetter = this.fnVG_SATALLOCTOGO;
                                        cd1.aggFunc = this.aggSATALLOCTOGO;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'HOLD_BUCK_QUAN') { //Holding bucket qty
                                        cd1.valueGetter = this.fnVG_HOLDBUCKQUAN;
                                        cd1.aggFunc = this.aggHOLDBUCKQUAN;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'LEFT_TO_REL_QTY') {
                                        cd1.valueGetter = this.fnVG_LEFT_TO_REL;
                                        cd1.aggFunc = this.aggLEFT_TO_REL;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'ATTAIN_TO_SHIP') {
                                        cd1.valueGetter = this.fnSPValueGetter;
                                        cd1.aggFunc = this.fnSPAggr;
                                        cd1.valueFormatter = this.percFormatter;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'DELTA_PERCNT') { //Delta to % Dependency Release
                                        cd1.valueGetter = this.fnVG_PER_DELTA;
                                        cd1.valueFormatter = this.percFormatter;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'PERCT_SHIP_REL') { //Perc Ship Plan release
                                        cd1.valueGetter = this.fnVG_PER_SHIP_REL;
                                        cd1.aggFunc = this.aggPER_SHIP_REL;
                                        cd1.valueFormatter = this.percFormatter;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'CPERCENT') {
                                        cd1.valueGetter = this.fnPERCENT;
                                        cd1.valueFormatter = this.percFormatter;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'COMP_PERCNT') {
                                        cd1.valueGetter = this.fnPERCENT;
                                        cd1.valueFormatter = this.percFormatter;
                                        cd1.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (cd1.field == 'ALLOC_ROLL' || cd1.field == 'SHIP_PLAN_ROLL' || cd1.field == 'CUM_REL_GATP_QTY' || cd1.field == 'GATP_ALLOCATION_QTY' || cd1.field == 'OPEN_CSL' || cd1.field == 'CUM_DEL_QTY' ||
                                        cd1.field == 'DAT_ALL_QTY_GO' || cd1.field == 'CUM_REL_GATP_QTY' || cd1.field == 'GATP_ALLOCATION_QTY' || cd1.field == 'GATP_CONSUMPTION_QTY' || cd1.field == 'OPEN_CSL' || cd1.field ==
                                        'CUM_DEL_QTY' || cd1.field == 'GATP_ALLOC_TOGO' || cd1.field == 'LEFT_TO_REL_QTY') {
                                        cd1.valueFormatter = this.vgNumber;
                                    }

                                }
                            }
                        }
                    }
                    if (ag.headerName == 'Ship Plan') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var spData = ag.children;
                                var spCount = 0;
                                for (var spIndex = 0; spIndex < spData.length; spIndex++) {
                                    spCount++;
                                    var sp = spData[spIndex];
                                    sp.cellClass = 'RCASTDC';
                                    if (spIndex == 0) {
                                        sp.cellClass = 'RCASTBC';
                                    }
                                    if (spCount == spData.length) {
                                        sp.cellClass = 'RCASTEC';
                                    }
                                    sp.valueFormatter = this.vgNumber;
                                }
                            }
                        }
                    } //end of Ship_plan
                    if (ag.headerName == 'Supply') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var supCount = 0;
                                var supData = ag.children;
                                for (var supIdx = 0; supIdx < supData.length; supIdx++) {
                                    supCount++;
                                    var sup = supData[supIdx];
                                    sup.cellClass = 'RCASTDC';
                                    if (supIdx == 0) {
                                        sup.cellClass = 'RCASTBC';
                                    }
                                    if (supCount == supData.length) {
                                        sup.cellClass = 'RCASTEC';
                                    }
                                    if (sup.field.includes('PLANT_')) {
                                        sup.valueGetter = this.fnVG_PLANT;
                                        sup.aggFunc = this.aggPLANT;
                                        sup.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    } //Supply
                    if (ag.headerName == 'Backlog' || ag.headerName == 'User Plan') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var blgCount = 0;
                                var blgData = ag.children;
                                for (var blgIdx = 0; blgIdx < blgData.length; blgIdx++) {
                                    blgCount++;
                                    var blg = blgData[blgIdx];
                                    blg.cellClass = 'RCASTDC';
                                    if (blgIdx == 0) {
                                        blg.cellClass = 'RCASTBC';
                                    }
                                    if (blgCount == blgData.length) {
                                        sp.cellClass = 'RCASTEC';
                                    }
                                    blg.valueGetter = this.fnVG_BKLG;
                                    blg.aggFunc = this.aggBKLG;
                                    blg.valueFormatter = this.vgNumber;
                                    blg.filterParams = this.gFilterOptions; //DV5K930341
                                }
                            }
                        }
                    }
                    if (ag.headerName == 'User Plan') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var upCount = 0;
                                var upData = ag.children;
                                for (var upIdx = 0; upIdx < blgData.length; upIdx++) {
                                    upCount++;
                                    var up = upData[upIdx];
                                    up.cellClass = 'RCASTDC';
                                    if (upIdx == 0) {
                                        up.cellClass = 'RCASTBC';
                                    }
                                    if (upCount == blgData.length) {
                                        sp.cellClass = 'RCASTEC';
                                    }
                                    up.valueFormatter = this.vgNumber;
                                }
                            }
                        }
                    }
                    if (ag.headerName == 'Gating Factor') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var gfCount = 0;
                                var gtData = ag.children;
                                // sessionStorage.Aggr_Select = this.getView().byId("Aggr_Select").getSelectedKey();

                                for (var gtIndex = 0; gtIndex < gtData.length; gtIndex++) {
                                    gfCount++;
                                    var gt = gtData[gtIndex];
                                    gt.cellClass = 'RCASTDC';
                                    if (gtIndex == 0) {
                                        gt.cellClass = 'RCASTBC';
                                    }
                                    if (gfCount == gtData.length) {
                                        gt.cellClass = 'RCASTEC';
                                    }
                                    if (gt.field == 'GAT_BLG') { //Gating factor backlog
                                        gt.valueGetter = this.fnVG_GAT_BLG;
                                        gt.aggFunc = this.aggGAT_BLG;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (gt.field == 'SUPPLY_SHIPPLAN') { //Supply > Ship Plan
                                        gt.valueGetter = this.fnVG_SUP_SHIPPLAN;
                                        gt.aggFunc = this.aggGAT_SUP_SHIPPLAN;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (gt.field == 'GAT_SUPPLY') { //Gating factor Supply
                                        gt.valueGetter = this.fnVG_GAT_SUP;
                                        gt.aggFunc = this.aggGAT_SUP;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (gt.field == 'GAT_SAT_ALLOC') { //Gating factor SAT
                                        gt.valueGetter = this.fnVG_GAT_SAT;
                                        gt.aggFunc = this.aggGAT_SAT;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (gt.field == 'GAT_SHIP_PLAN') { //Gating Ship Plan
                                        gt.valueGetter = this.fnVG_GAT_SHIP_PLAN;
                                        gt.aggFunc = this.aggGAT_SHIP_PLAN;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    } else if (gt.field == 'GAT_USR_PLAN') { //User base Plan
                                        gt.valueGetter = this.fnVG_GAT_USR_PLAN;
                                        gt.aggFunc = this.aggGAT_USR_PLAN;
                                        gt.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    } //end of Gating factor
                    if (ag.headerName == 'Future Req') {
                        ag.marryChildren = true;
                        if (ag.children != undefined) {
                            if (ag.children.length > 0) {
                                var frCount = 0;
                                var frData = ag.children;
                                for (var frIndex = 0; frIndex < frData.length; frIndex++) {
                                    frCount++;
                                    var fr = frData[frIndex];
                                    fr.cellClass = 'RCASTDC';
                                    if (frIndex == 0) {
                                        fr.cellClass = 'RCASTBC';
                                    }
                                    if (frCount == frData.length) {
                                        fr.cellClass = 'RCASTEC';
                                    }
                                    if (fr.field == 'FUT_REQ_CW_1' || fr.field == 'FUT_REQ_CW_2' || fr.field == 'FUT_REQ_CW_3') { //Future Requirement
                                        fr.valueGetter = this.fnVG_FUT_REQ_CW;
                                        fr.aggFunc = this.aggFUT_REQ_CW;
                                        fr.filterParams = this.gFilterOptions; //DV5K930341
                                    }
                                }
                            }
                        }
                    } //end of Future Req
                }
                return agData;
            },
            fnSPValueGetter: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = params.data.SHIP_PLAN_QTY_CW;
                        var wtd = 0;
                        if (params.data.CAL_DEL_QTY != undefined) {
                            wtd = params.data.CAL_DEL_QTY;
                        }
                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304
                        var shipTo = params.data.PKUNWE;
                        var xd = {
                            wtd: wtd,
                            shipplan: shipplan,
                            shipTo: shipTo,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            toString: function () {
                                var calF = (wtd && shipplan) ? ((wtd * 100) / shipplan) : 0;
                                var fcalc = (parseFloat(calF)).toFixed(1);
                                return fcalc;
                            }
                        };
                        return xd;
                    }
                } else {
                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 + shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        var wtd = 0;
                        if (params.data.CAL_DEL_QTY != undefined) {
                            wtd = params.data.CAL_DEL_QTY;
                        }
                        var shipTo = params.data.PKUNWE;
                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304
                        var xd = {
                            wtd: wtd,
                            shipplan: shipplan,
                            shipTo: shipTo,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            toString: function () {
                                var calF = (wtd && shipplan) ? ((wtd * 100) / shipplan) : 0;
                                var fcalc = (parseFloat(calF)).toFixed(1);
                                return fcalc;
                            }
                        };
                        return xd;
                    }
                }
            },

            fnSPAggr: function (values) {
                var wtdSum = 0;
                var shipplanSum = 0;
                var shipTo = '';
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value && value.wtd && value.shipTo.includes('+') && value.roc_soldto === "") {
                        wtdSum += value.wtd;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                    if (value && value.shipplan && value.shipTo.includes('+') && value.roc_soldto === "") {
                        shipplanSum += value.shipplan;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                });
                shipTo = '+';
                var xd = {
                    wtd: wtdSum,
                    shipplan: shipplanSum,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        var calF = (wtdSum && shipplanSum) ? ((wtdSum * 100) / shipplanSum) : 0;
                        var fcalc = (parseFloat(calF)).toFixed(1);
                        return fcalc;
                    }
                };
                return xd;
            },
            fnVG_LEFT_TO_REL: function (params) {
                if (!params.node.group) {
                    var lefttoRel = 0;
                    var relTogatp = 0;
                    var sat_allocation = 0;
                    if (params.data.SAT_ALLOCATION != undefined) {
                        sat_allocation = params.data.SAT_ALLOCATION;
                    }
                    if (params.data.LEFT_TO_REL_QTY != undefined) {
                        lefttoRel = params.data.LEFT_TO_REL_QTY;
                    }
                    if (params.data.CUM_REL_GATP_QTY != undefined) {
                        relTogatp = params.data.CUM_REL_GATP_QTY;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    var xd = {
                        pkunwe: params.data.PKUNWE,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        sat_allocation: sat_allocation,
                        relTogatp: relTogatp,
                        lefttoRel: lefttoRel,
                        toString: function () {
                            return (lefttoRel) ? lefttoRel : 0;
                        }
                    };
                    return xd;
                }
            },

            aggLEFT_TO_REL: function (values) {
                var lefttoRel = 0;
                var relTogatp = 0;
                var sat_allocation = 0;
                var roc_soldto = ""; //79366642 - DV5K935304
                var pkunwe = '';
                values.forEach(function (value) {
                    if (value.pkunwe !== undefined) {
                        // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                        if (value.pkunwe.includes("+") && value.roc_soldto === "") {
                            sat_allocation += value.sat_allocation;
                            roc_soldto = value.roc_soldto; //79366642 - DV5K935304
                        }
                        pkunwe = value.pkunwe;
                    }
                    relTogatp += value.relTogatp;
                });

                lefttoRel = sat_allocation - relTogatp;
                var xd = {
                    pkunwe: '++++++++',
                    roc_soldto: roc_soldto, //79366642 - DV5K935304
                    sat_allocation: sat_allocation,
                    relTogatp: relTogatp,
                    lefttoRel: lefttoRel,

                    toString: function () {
                        return (lefttoRel) ? lefttoRel : 0;
                    }
                };
                return xd;
            },
            fnValueGetterSAT: function (params) {
                if (!params.node.group) {
                    var sat_allocation = 0;
                    if (params.data.SAT_ALLOCATION != undefined) {
                        sat_allocation = params.data.SAT_ALLOCATION;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    //End of Insert 79366642 - DV5K935304

                    var xd = {
                        pkunwe: params.data.PKUNWE,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        sat_allocation: sat_allocation,
                        toString: function () {
                            return (sat_allocation) ? sat_allocation : 0;
                        }
                    };
                    return xd;
                }
            },
            aggSAT: function (values) {
                var pkunwe = "";
                var sat_allocation = 0;
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    if (value.pkunwe !== undefined) {
                        // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                        if (value.pkunwe.includes("+") && value.roc_soldto === "") {
                            sat_allocation += value.sat_allocation;
                            roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                        }
                        pkunwe = value.pkunwe;
                    }
                });
                var xd = {
                    pkunwe: '++++++++',
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    sat_allocation: sat_allocation,
                    toString: function () {
                        return (sat_allocation) ? sat_allocation : 0;
                    }
                };
                return xd;
            },
            //Sat To got
            fnVG_SATALLOCTOGO: function (params) {
                if (!params.node.group) {
                    var satToGo = 0;
                    if (params.data.SAT_ALLOC_TOGO != undefined) {
                        satToGo = params.data.SAT_ALLOC_TOGO;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    //End of Insert 79366642 - DV5K935304
                    var shipTo = params.data.PKUNWE;
                    var xd = {
                        satToGo: satToGo,
                        shipTo: shipTo,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        toString: function () {
                            return (satToGo) ? satToGo : 0;
                        }
                    };
                    return xd;
                }
            },
            aggSATALLOCTOGO: function (values) {
                var shipTo = "";
                var satToGo = 0;
                var roc_soldto = ""; // 79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        satToGo += value.satToGo;
                        shipTo = value.shipTo;
                        roc_soldto = value.roc_soldto;
                    }
                });
                var xd = {
                    satToGo: satToGo,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (satToGo) ? satToGo : 0;
                    }
                };
                return xd;
            },
            //Holding buckets
            fnVG_HOLDBUCKQUAN: function (params) {
                if (!params.node.group) {
                    var holdbq = 0;
                    if (params.data.HOLD_BUCK_QUAN != undefined) {
                        holdbq = params.data.HOLD_BUCK_QUAN;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    //End of Insert 79366642 - DV5K935304
                    var shipTo = params.data.PKUNWE;
                    var xd = {
                        holdbq: holdbq,
                        shipTo: shipTo,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        toString: function () {
                            return (holdbq) ? holdbq : 0;
                        }
                    };
                    return xd;
                }
            },

            aggHOLDBUCKQUAN: function (values) {
                var holdbq = 0;
                var shipTo = "";
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        holdbq += value.holdbq;
                        shipTo = value.shipTo;
                        roc_soldto = value.roc_soldto;
                    }
                });
                var xd = {
                    holdbq: holdbq,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (holdbq) ? holdbq : 0;
                    }
                };
                return xd;
            },

            fnVG_PLANT: function (params) {
                if (!params.node.group) {
                    var xValue = 0;
                    var xField = params.colDef.field;
                    xValue = params.data[xField];

                    var xd = {
                        mpn: params.data.RULE_MATNR,
                        supply: xValue,
                        field: xField,
                        toString: function () {
                            return (xValue) ? xValue : 0;
                        }
                    };
                }
                return xd;
            },
            aggPLANT: function (values) {
                var mpn = "";
                var supply = 0;
                var cField = '';
                values.sort(function (a, b) {
                    return a.mpn > b.mpn ? 1 : -1;
                });
                values.forEach(function (value) {
                    if (value && value.supply) {
                        if (mpn === value.mpn) {
                            if (!supply) {
                                supply = value.supply;
                            }
                        } else {
                            supply += value.supply;
                        }
                        mpn = value.mpn;
                    }
                });
                var xd = {
                    mpn: mpn,
                    supply: supply,
                    field: cField,
                    toString: function () {
                        return (supply) ? supply : 0;
                    }
                };
                return xd;
            },
            fnVG_BKLG: function (params) {
                if (!params.node.group) {
                    var xValue = 0;
                    var xField = params.colDef.field;
                    if (params.data[xField] != undefined) {
                        xValue = params.data[xField];
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    var xd = {
                        shipTo: params.data.PKUNWE,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        bklg: xValue,
                        field: xField,
                        toString: function () {
                            return (xValue) ? xValue : 0;
                        }
                    };
                }
                return xd;
            },
            aggBKLG: function (values) {
                var shipTo = "";
                var bklg = 0;
                var cField = '';
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    if (value && value.bklg) {
                        // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                        if (value.shipTo.includes('+') && value.roc_soldto === "") {
                            bklg += value.bklg;
                            roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                        }
                        shipTo = value.shipTo;
                    }
                });
                var xd = {
                    shipTo: '++++++',
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    bklg: bklg,
                    field: cField,
                    toString: function () {
                        return (bklg) ? bklg : 0;
                    }
                };
                return xd;
            },
            //Cum Wave qty
            fnVG_CUMWAVEQTY: function (params) {
                if (!params.node.group) {
                    var satAlloc = 0;
                    var holdBuck = 0;
                    if (params.data.SAT_ALLOCATION != undefined) {
                        satAlloc = params.data.SAT_ALLOCATION;
                    }
                    if (params.data.HOLD_BUCK_QUAN != undefined) {
                        holdBuck = params.data.HOLD_BUCK_QUAN;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    //End of Insert 79366642 - DV5K935304
                    var cumwaveqty = satAlloc - holdBuck;
                    if (cumwaveqty < 0) {
                        cumwaveqty = 0;
                    }
                    var shipTo = params.data.PKUNWE;
                    var xd = {
                        cumwaveqty: cumwaveqty,
                        shipTo: shipTo,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        toString: function () {
                            return (cumwaveqty) ? cumwaveqty : 0;
                        }
                    };
                    return xd;
                }
            },
            aggCUMWAVEQTY: function (values) {
                var shipTo = "";
                var cumwaveqty = 0;
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        cumwaveqty += value.cumwaveqty;
                        shipTo = value.shipTo;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                });
                var xd = {
                    cumwaveqty: cumwaveqty,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (cumwaveqty) ? cumwaveqty : 0;
                    }
                };
                return xd;
            },
            fnVG_GAT_BLG: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = 0;
                        var backlog = 0;
                        if (params.data.WK_BLG_CAP_SHP != undefined) {
                            backlog = params.data.WK_BLG_CAP_SHP;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        //NOT Needed 
                        // //Begin of Insert 79366642 - DV5K935304
                        // // Add Roc Sold To for aggregation
                        // var roc_soldto = "";
                        // if (params.data.ROC_SOLDTO != undefined) {
                        //     roc_soldto = params.data.ROC_SOLDTO;
                        // }
                        //End of Insert 79366642 - DV5K935304
                        var gatBlg = shipplan - backlog;
                        if (gatBlg < 0) {
                            gatBlg = 0;
                        }
                        var xd = {
                            gatBlg: gatBlg,
                            toString: function () {
                                return (gatBlg) ? gatBlg : 0;
                            }
                        };
                        return xd;
                    }
                } else {
                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 + shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        var backlog = 0;
                        if (params.data.WK_BLG_CAP_SHP != undefined) {
                            backlog = params.data.WK_BLG_CAP_SHP;
                        }
                        var gatBlg = shipplan - backlog;
                        if (gatBlg < 0) {
                            gatBlg = 0;
                        }
                        var xd = {
                            gatBlg: gatBlg,
                            shipplan: shipplan,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            backlog: backlog,
                            shipTo: params.data.PKUNWE,
                            toString: function () {
                                return (gatBlg) ? gatBlg : 0;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggGAT_BLG: function (values) {
                var gatBlg = 0;
                var shipplan = 0;
                var shipTo = '';
                var backlog = 0;
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    //begin of DV5K931690
                    var _backlog = 0;
                    var _shipPlan = 0;
                    var _gatBlg = 0;
                    //end of DV5K931690
                    if (value.backlog) {
                        // backlog += value.backlog;    //DV5K931690
                        _backlog = value.backlog; //DV5K931690
                    }

                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipplan && value.shipTo.includes('+') && value.roc_soldto === "") {
                        //begin of DV5K931690
                        // shipplan += value.shipplan;
                        _shipPlan = value.shipplan;
                        _gatBlg = _shipPlan - _backlog;
                        if (_gatBlg < 0) {
                            _gatBlg = 0;
                        }
                        //end of DV5K931690
                    }
                    //begin of DV5K932397
                    //else if(value.gatBlg && value.shipTo.includes('+') ) {   //DV5K932416
                    //    gatblg += value.gatBlg;       //DV5K932416
                    else if (value.gatBlg && value.shipTo.includes('+') && value.roc_soldto === "") { //DV5K932416
                        _gatBlg += value.gatBlg; //DV5K932416
                    }
                    //end of DV5K932397

                    gatBlg += _gatBlg; //DV5K931690
                });

                // gatBlg = shipplan - backlog;
                if (gatBlg < 0) {
                    gatBlg = 0;
                }

                shipTo = '+';

                var xd = {
                    gatBlg: gatBlg,
                    shipplan: shipplan,
                    backlog: backlog,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (gatBlg) ? gatBlg : 0;
                    }
                };
                return xd;
            },
            /* supply> ship plan begin*/
            fnVG_SUP_SHIPPLAN: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = 0;
                        var supply = 0;
                        var consump = 0;
                        if (params.data.PLANT_LOCAL_SUPPLY != undefined) {
                            supply = params.data.PLANT_LOCAL_SUPPLY;
                        }
                        if (params.data.PLANT_OEM_SUPPLY != undefined) {
                            supply += params.data.PLANT_OEM_SUPPLY;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.GATP_CONSUMPTION_QTY != undefined) {
                            consump = params.data.GATP_CONSUMPTION_QTY;
                        }

                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }

                        var supShip = supply - (shipplan - consump);

                        if (supShip < 0) {
                            supShip = 0;
                        }
                        var xd = {
                            mpn: params.data.RULE_MATNR,
                            shipplan: shipplan,
                            supply: supply,
                            consump: consump,
                            supShip: supShip,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            toString: function () {
                                return (supShip) ? supShip : 0;
                            }
                        };
                        return xd;
                    }
                } else {
                    var shipplan = 0;
                    var supply = 0;
                    var consump = 0;

                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 +
                                shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        if (params.data.PLANT_LOCAL_SUPPLY != undefined) {
                            supply = params.data.PLANT_LOCAL_SUPPLY;
                        }
                        if (params.data.PLANT_OEM_SUPPLY != undefined) {
                            supply += params.data.PLANT_OEM_SUPPLY;
                        }
                        if (params.data.GATP_CONSUMPTION_QTY != undefined) {
                            consump = params.data.GATP_CONSUMPTION_QTY;
                        }

                        var supShip = supply - (shipplan - consump);

                        if (supShip < 0) {
                            supShip = 0;
                        }

                        var xd = {
                            mpn: params.data.RULE_MATNR,
                            shipplan: shipplan,
                            supply: supply,
                            consump: consump,
                            supShip: supShip,
                            shipTo: params.data.PKUNWE,
                            toString: function () {
                                return (supShip) ? supShip : 0;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggGAT_SUP_SHIPPLAN: function (values) {
                var supShip = 0;
                var supply = 0;
                var shipplan = 0;
                var consump = 0;
                var mpn = '';
                var shipTo = '';
                var roc_soldto = ""; //79366642 - DV5K935304
                values.sort(function (a, b) {
                    return a.mpn > b.mpn ? 1 : -1;
                });
                values.forEach(function (value) {
                    if (value) {
                        if (mpn === value.mpn) {
                            if (!supply) {
                                supply = value.supply;
                            }
                        } else {
                            supply += value.supply;
                        }
                        // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                        if (value.shipTo.includes('+') && value.roc_soldto === "") {
                            shipplan += value.shipplan;
                            roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                        }
                        consump += value.consump;
                        mpn = value.mpn;
                    }
                });

                supShip = supply - (shipplan - consump);
                if (supShip < 0) {
                    supShip = 0;
                }

                shipTo = '+';

                var xd = {
                    mpn: mpn,
                    shipplan: shipplan,
                    supply: supply,
                    consump: consump,
                    supShip: supShip,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (supShip) ? supShip : 0;
                    }
                };
                return xd;
            },
            /* supply > ship plan */
            fnVG_GAT_SUP: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = 0;
                        var supply = 0;
                        var consump = 0;
                        if (params.data.PLANT_LOCAL_SUPPLY != undefined) {
                            supply = params.data.PLANT_LOCAL_SUPPLY;
                        }
                        if (params.data.PLANT_OEM_SUPPLY != undefined) {
                            supply += params.data.PLANT_OEM_SUPPLY;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.GATP_CONSUMPTION_QTY != undefined) {
                            consump = params.data.GATP_CONSUMPTION_QTY;
                        }
                        var gatSup = shipplan - (supply + consump);
                        if (gatSup < 0) {
                            gatSup = 0;
                        }
                        var xd = {
                            mpn: params.data.RULE_MATNR,
                            shipplan: shipplan,
                            supply: supply,
                            consump: consump,
                            gatSup: gatSup,
                            toString: function () {
                                return (gatSup) ? gatSup : 0;
                            }
                        };
                        return xd;
                    }
                } else {
                    var shipplan = 0;
                    var supply = 0;
                    var consump = 0;

                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 +
                                shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        if (params.data.PLANT_LOCAL_SUPPLY != undefined) {
                            supply = params.data.PLANT_LOCAL_SUPPLY;
                        }
                        if (params.data.PLANT_OEM_SUPPLY != undefined) {
                            supply += params.data.PLANT_OEM_SUPPLY;
                        }
                        if (params.data.GATP_CONSUMPTION_QTY != undefined) {
                            consump = params.data.GATP_CONSUMPTION_QTY;
                        }

                        var gatSup = shipplan - (supply + consump);
                        if (gatSup < 0) {
                            gatSup = 0;
                        }

                        var xd = {
                            mpn: params.data.RULE_MATNR,
                            shipplan: shipplan,
                            supply: supply,
                            consump: consump,
                            gatSup: gatSup,
                            shipTo: params.data.PKUNWE,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            toString: function () {
                                return (gatSup) ? gatSup : 0;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggGAT_SUP: function (values) {
                var gatSup = 0;
                var shipplan = 0;
                var supply = 0;
                var consump = 0;
                var mpn = "";
                var shipTo = '';
                var roc_soldto = ""; //79366642 - DV5K935304
                values.sort(function (a, b) {
                    return a.mpn > b.mpn ? 1 : -1;
                });
                values.forEach(function (value) {
                    if (value) {
                        if (mpn === value.mpn) {
                            if (!supply) {
                                supply = value.supply;
                            }
                        } else {
                            supply += value.supply;
                        }
                        // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                        if (value.shipTo.includes('+') && value.roc_soldto === "") {
                            shipplan += value.shipplan;
                            roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                        }
                        consump += value.consump;
                        mpn = value.mpn;
                    }
                });

                gatSup = shipplan - (supply + consump);
                if (gatSup < 0) {
                    gatSup = 0;
                }

                shipTo = '+';

                var xd = {
                    mpn: mpn,
                    shipplan: shipplan,
                    supply: supply,
                    consump: consump,
                    gatSup: gatSup,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (gatSup) ? gatSup : 0;
                    }
                };
                return xd;
            },
            fnVG_GAT_SAT: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = 0;
                        var satAlloc = 0;
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304
                        var gatSat = satAlloc - shipplan;
                        if (gatSat < 0) {
                            gatSat = 0;
                        }
                        var shipTo = params.data.PKUNWE;
                        var xd = {
                            gatSat: gatSat,
                            shipplan: shipplan,
                            satAlloc: satAlloc,
                            shipTo: shipTo,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            toString: function () {
                                return (gatSat) ? gatSat : 0;
                            }
                        };
                        return xd;
                    }
                } else {
                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 +
                                shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        var satAlloc = 0;
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }
                        var gatSat = shipplan - satAlloc;
                        if (gatSat < 0) {
                            gatSat = 0;
                        }
                        var shipTo = params.data.PKUNWE;
                        var xd = {
                            gatSat: gatSat,
                            shipplan: shipplan,
                            satAlloc: satAlloc,
                            shipTo: shipTo,
                            toString: function () {
                                return (gatSat) ? gatSat : 0;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggGAT_SAT: function (values) {
                var gatSat = 0;
                var shipTo = "";
                var satAlloc = 0;
                var shipplan = 0;
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        satAlloc += value.satAlloc;
                        shipplan += value.shipplan;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                });
                shipTo = "++++++";
                gatSat = shipplan - satAlloc;
                if (gatSat < 0) {
                    gatSat = 0;
                }

                var xd = {
                    gatSat: gatSat,
                    shipplan: shipplan,
                    satAlloc: satAlloc,
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    toString: function () {
                        return (gatSat) ? gatSat : 0;
                    }
                };
                return xd;
            },
            fnVG_PER_DELTA: function (params) {
                if (!params.node.group) {
                    var cpercent = 0;
                    var comp_percent = 0;

                    if (params.data.CPERCENT != undefined) {
                        cpercent = params.data.CPERCENT;
                    }
                    if (params.data.COMP_PERCNT != undefined) {
                        comp_percent = params.data.COMP_PERCNT;
                    }

                    var delta_percent = 0;
                    //if current percent is blank make it 100%
                    if (cpercent == 0) {
                        cpercent = 100;
                    }

                    delta_percent = cpercent - comp_percent;

                    if (delta_percent < 0) {
                        delta_percent = 0;
                    }

                    var xd = {
                        delta_percent: delta_percent,
                        toString: function () {
                            return (delta_percent) ? delta_percent : 0;
                        }
                    };
                    return xd;
                }
            },
            fnVG_PER_SHIP_REL: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                // var that = this;
                // var Aggr_Select = that.getView().byId("Aggr_Select");
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = params.data.SHIP_PLAN_QTY_CW;
                        var relGATP = 0;
                        if (params.data.CAL_REL_GATP_QTY != undefined) {
                            relGATP = params.data.CAL_REL_GATP_QTY;
                        }
                        var shipTo = params.data.PKUNWE;
                        var xd = {
                            relGATP: relGATP,
                            shipplan: shipplan,
                            shipTo: shipTo,
                            toString: function () {
                                var calF = (relGATP && shipplan) ? ((relGATP * 100) / shipplan) : 0;
                                var fcalc = (parseFloat(calF)).toFixed(1);
                                return fcalc;
                            }
                        };
                        return xd;
                    }
                } else {
                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAlloc = 0;

                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 + shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        var relGATP = 0;
                        if (params.data.CAL_REL_GATP_QTY != undefined) {
                            relGATP = params.data.CAL_REL_GATP_QTY;
                        }
                        var shipTo = params.data.PKUNWE;
                        var xd = {
                            relGATP: relGATP,
                            shipplan: shipplan,
                            shipTo: shipTo,
                            toString: function () {
                                var calF = (relGATP && shipplan) ? ((relGATP * 100) / shipplan) : 0;
                                var fcalc = (parseFloat(calF)).toFixed(1);
                                return fcalc;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggPER_SHIP_REL: function (values) {
                var relGATP = 0;
                var shipplanSum = 0;
                var shipTo = '';
                values.forEach(function (value) {
                    if (value && value.relGATP && value.shipTo.includes('+')) {
                        relGATP += value.relGATP;
                    }
                    if (value && value.shipplan && value.shipTo.includes('+')) {
                        shipplanSum += value.shipplan;
                    }
                });
                shipTo = '+';
                var xd = {
                    relGATP: relGATP,
                    shipplan: shipplanSum,
                    shipTo: shipTo,
                    toString: function () {
                        var calF = (relGATP && shipplanSum) ? ((relGATP * 100) / shipplanSum) : 0;
                        var fcalc = (parseFloat(calF)).toFixed(1);
                        return fcalc;
                    }
                };
                return xd;
            },
            percFormatter: function (params) {
                //Add % symbol just after the value
                var l_value = 0;
                if (params.value) {
                    l_value = params.value;
                }
                //begin of DV5K930019
                // if (!params.node.group) {
                //     if (params.colDef.field == 'CPERCENT') {
                //         if (params.value) {
                //             l_value = (parseFloat(params.value)).toFixed(1);
                //         } else {
                //             l_value = 100;
                //         }
                //     } else if (params.colDef.field == 'COMP_PERCNT') {
                //         if (params.value) {
                //             var fcalc = (parseFloat(params.value)).toFixed(1);
                //             l_value = fcalc;
                //         }
                //     }
                // }
                //end of DV5K930019
                return l_value + '%';
            },
            //begin of DV5K930019
            fnPERCENT: function (params) {
                if (!params.node.group) {
                    var l_value = 0;
                    if (params.colDef.field == 'CPERCENT') {
                        //if (params.value) {               //DV5K930534
                        if (params.data.CPERCENT != undefined && params.data.CPERCENT != null && params.data.CPERCENT != '') { //DV5K930534
                            l_value = (parseFloat(params.data.CPERCENT)).toFixed(1);
                            //l_value = (parseFloat(params.value)).toFixed(1);
                        } else {
                            l_value = 100;
                        }
                    } else if (params.colDef.field == 'COMP_PERCNT') {
                        //if (params.value) {               //DV5K930534
                        if (params.data.COMP_PERCNT != undefined && params.data.COMP_PERCNT != null && params.data.COMP_PERCNT != '') { //DV5K930534
                            var fcalc = (parseFloat(params.data.COMP_PERCNT)).toFixed(1);
                            //var fcalc = (parseFloat(params.value)).toFixed(1);
                            l_value = fcalc;
                        }
                    }
                    var xd = {
                        toString: function () {
                            return (l_value) ? l_value : 0;
                        }
                    };
                    return xd;
                }
            },
            //end of DV5K930019
            fnVG_GAT_SHIP_PLAN: function (params) {
                var Aggr_Select_Key = sessionStorage.Aggr_Select;
                if (Aggr_Select_Key == undefined || Aggr_Select_Key == '') {
                    if (!params.node.group) {
                        var shipplan = 0;
                        var satAll = 0;
                        var gatShip = 0;
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAll = params.data.SAT_ALLOCATION;
                        }
                        gatShip = satAll - shipplan;
                        if (gatShip < 0) {
                            gatShip = 0;
                        }
                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304
                        var xd = {
                            shipTo: params.data.PKUNWE,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            gatShip: gatShip,
                            toString: function () {
                                return (gatShip) ? gatShip : 0;
                            }
                        };
                        return xd;
                    }
                } else {
                    var popupKey = Aggr_Select_Key;
                    if (!params.node.group) {
                        var shipplan = 0;
                        var shipplan1 = 0;
                        var shipplan2 = 0;
                        var shipplan3 = 0;
                        var rollShip = 0;
                        var satAll = 0;
                        var gatShip = 0;
                        var satAlloc = 0;

                        var popupKey = Aggr_Select_Key;
                        if (params.data.SHIP_PLAN_QTY_CW != undefined) {
                            shipplan = params.data.SHIP_PLAN_QTY_CW;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_1 != undefined) {
                            shipplan1 = params.data.SHIP_PLAN_QTY_CW_1;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_2 != undefined) {
                            shipplan2 = params.data.SHIP_PLAN_QTY_CW_2;
                        }
                        if (params.data.SHIP_PLAN_QTY_CW_3 != undefined) {
                            shipplan3 = params.data.SHIP_PLAN_QTY_CW_3;
                        }
                        if (params.data.SHIP_PLAN_ROLL != undefined) {
                            rollShip = params.data.SHIP_PLAN_ROLL;
                        }
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAlloc = params.data.SAT_ALLOCATION;
                        }

                        if (popupKey == 'SHIP_PLAN_QTY_CW') {
                            var calShp = shipplan;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_1') {
                            var calShp = shipplan + shipplan1;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_2') {
                            var calShp = shipplan + shipplan1 + shipplan2;
                        } else if (popupKey == 'SHIP_PLAN_QTY_CW_3') {
                            var calShp = shipplan + shipplan1 + shipplan2 + shipplan3;
                        } else if (popupKey == 'SHIP_PLAN_ROLL') {
                            var calShp = rollShip;
                        } else if (popupKey == 'SAT_ALLOCATION') {
                            var calShp = satAlloc;
                        }

                        shipplan = calShp;
                        if (params.data.SAT_ALLOCATION != undefined) {
                            satAll = params.data.SAT_ALLOCATION;
                        }
                        gatShip = satAll - shipplan;
                        if (gatShip < 0) {
                            gatShip = 0;
                        }

                        //Begin of Insert 79366642 - DV5K935304
                        // Add Roc Sold To for aggregation
                        var roc_soldto = "";
                        if (params.data.ROC_SOLDTO != undefined) {
                            roc_soldto = params.data.ROC_SOLDTO;
                        }
                        //End of Insert 79366642 - DV5K935304

                        var xd = {
                            shipTo: params.data.PKUNWE,
                            roc_soldto: roc_soldto, // 79366642 - DV5K935304
                            gatShip: gatShip,
                            toString: function () {
                                return (gatShip) ? gatShip : 0;
                            }
                        };
                        return xd;
                    }
                }
            },
            aggGAT_SHIP_PLAN: function (values) {
                var gatShip = 0;
                var shipTo = "";
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        gatShip += value.gatShip;
                        shipTo = value.shipTo;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                });
                var xd = {
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    gatShip: gatShip,
                    toString: function () {
                        return (gatShip) ? gatShip : 0;
                    }
                };
                return xd;
            },
            fnVG_GAT_USR_PLAN: function (params) {
                if (!params.node.group) {
                    var userplan = 0;
                    var satAll = 0;
                    var gatUser = 0;
                    if (params.data.SAT_ALLOCATION != undefined) {
                        satAll = params.data.SAT_ALLOCATION;
                    }
                    if (params.data.USER_PLAN_1_QTY != undefined) {
                        userplan = params.data.USER_PLAN_1_QTY;
                    }
                    //Begin of Insert 79366642 - DV5K935304
                    // Add Roc Sold To for aggregation
                    var roc_soldto = "";
                    if (params.data.ROC_SOLDTO != undefined) {
                        roc_soldto = params.data.ROC_SOLDTO;
                    }
                    //End of Insert 79366642 - DV5K935304
                    gatUser = satAll - userplan;
                    if (gatUser < 0) {
                        gatUser = 0;
                    }

                    var xd = {
                        shipTo: params.data.PKUNWE,
                        roc_soldto: roc_soldto, // 79366642 - DV5K935304
                        gatUser: gatUser,
                        toString: function () {
                            return (gatUser) ? gatUser : 0;
                        }
                    };
                    return xd;
                }
            },
            aggGAT_USR_PLAN: function (values) {
                var gatUser = 0;
                var shipTo = "";
                var roc_soldto = ""; //79366642 - DV5K935304
                values.forEach(function (value) {
                    // Add Roc Sold To for aggregation - 79366642 - DV5K935304
                    if (value.shipTo.includes('+') && value.roc_soldto === "") {
                        gatUser += value.gatUser;
                        shipTo = value.shipTo;
                        roc_soldto = value.roc_soldto; // 79366642 - DV5K935304
                    }
                });
                var xd = {
                    shipTo: shipTo,
                    roc_soldto: roc_soldto, // 79366642 - DV5K935304
                    gatUser: gatUser,
                    toString: function () {
                        return (gatUser) ? gatUser : 0;
                    }
                };
                return xd;
            },
            fnVG_FUT_REQ_CW: function (params) {
                if (!params.node.group) {
                    var xField = params.colDef.field;
                    var futReq = params.data[xField];
                    var xd = {
                        mpn: params.data.RULE_MATNR,
                        futReq: futReq,
                        toString: function () {
                            return (futReq) ? futReq : 0;
                        }
                    };
                    return xd;
                }
            },
            aggFUT_REQ_CW: function (values) {
                var futReq = 0;
                var mpn = "";
                values.sort(function (a, b) {
                    return a.mpn > b.mpn ? 1 : -1;
                });
                values.forEach(function (value) {
                    if (value && value.futReq) {
                        if (mpn === value.mpn) {
                            if (!futReq) {
                                futReq = value.futReq;
                            }
                        } else {
                            futReq += value.futReq;
                        }
                        mpn = value.mpn;
                    }
                });
                var xd = {
                    mpn: mpn,
                    futReq: futReq,
                    toString: function () {
                        return (futReq) ? futReq : 0;
                    }
                };
                return xd;
            },
            vgNumber: function (params) {
                return (params.value) ? params.value : 0;
            },
            onProfileChg: function () {
                var l_secprof = this.getView().byId("oProfileForm_Profile_w").getSelectedKey();
                var l_week = this.getView().byId("oProfileForm_Week_w").getSelectedKey();
                this.getProfileWeeks_w(l_week, l_secprof);

                for (var i = 0; i < this.gWaveProfile_w.length; i++) {
                    var wpd = this.gWaveProfile_w[i];
                    if (wpd.Secprofile == l_secprof) {
                        this.gWaveProfileSelRegion_w = wpd.Region;
                    }
                }
                this.gridUtil.resetByWaveGrid();
            },
            onProfileChg_prof_w: function () {
                let oView = this.getView();
                this.onProfileChg();
                oView.byId("CO_Text").setVisible(false);
                oView.byId("SummaryPanel").setExpanded(false);
                this.clearWaveSettings();
                //Save Selected profile at backend as last selection
                this.saveDefProfile(oView.byId("oProfileForm_Profile_w").getSelectedKey(),
                    this.gWaveProfileSelRegion, oView.byId("oProfileForm_Week_w").getSelectedKey());

            },

            onProfileWeek_w: function () {
                this.onWeekChg();
                this.getView().byId("CO_Text").setVisible(false);
                this.getView().byId("SummaryPanel").setExpanded(false);
                this.clearWaveSettings();
            },
            onWeekChg: function () {
                let oView = this.getView();
                let oProfileForm_Profile_w = oView.byId("oProfileForm_Profile_w");
                let oProfileForm_Week_w = oView.byId("oProfileForm_Week_w");
                let oProfileForm_WAVE_w = oView.byId("oProfileForm_WAVE_w");
                var l_week = oProfileForm_Week_w.getSelectedKey();
                oProfileForm_Profile_w.removeAllItems();
                this.getWeekProfile(l_week, oProfileForm_Profile_w);
                oProfileForm_WAVE_w.removeAllItems();
                this.gridUtil.resetByWaveGrid();
            },
            getProfileWeeks_w: function (iFiscWeek, iSecProf) {
                this.getView().byId("oProfileForm_WAVE_w").removeAllItems();
                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("FiscWeek", sap.ui.model.FilterOperator.EQ, iFiscWeek));
                aFilters.push(new sap.ui.model.Filter("Secprofile", sap.ui.model.FilterOperator.EQ, iSecProf));
                var that = this;
                that.gWaveModel.read('/ProfileWavesSet', {
                    filters: aFilters,
                    success: function (oData, resp) {
                        var len = oData.results.length; //gProfileWaves_w.length;
                        var text = "";
                        for (var i = 0; i < len; i++) {
                            var pw = oData.results[i];
                            that.getView().byId("oProfileForm_WAVE_w").addItem(new sap.ui.core.Item({
                                key: pw.WaveNr,
                                text: text.concat(pw.WaveNr, " (", pw.WaveDesc, ")")
                            }));
                        }
                        sap.ui.core.BusyIndicator.hide();

                        // folllow on action
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show('Error While reading waves for Selected Profile');
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }
        });
    });
