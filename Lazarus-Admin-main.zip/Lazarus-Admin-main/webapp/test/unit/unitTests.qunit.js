/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/apple/ui5/ZUI5_AC_SHIP_ADMIN/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});