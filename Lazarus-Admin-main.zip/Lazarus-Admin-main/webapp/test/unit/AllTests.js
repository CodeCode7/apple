sap.ui.define([
	"com/apple/ui5/ZUI5_AC_SHIP_ADMIN/test/unit/controller/Main.controller"
], function () {
	"use strict";
});