sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/apple/ui5/ZUI5_AC_SHIP_ADMIN/formatter/formatter"
], function (Controller, JSONModel, MessageBox, formatter) {
	"use strict";
	return Controller.extend("com.apple.ui5.ZUI5_AC_SHIP_ADMIN.controller.Main", {
		formatter: formatter,
		onInit: function () {

			this._oBusyDialog = new sap.m.BusyDialog();
			this.RegionModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this.RegionModel, "RegionModel");
			this.RCTypeModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this.RCTypeModel, "RCTypeModel");
			this.oAdminViewModel = new JSONModel();
			this.getView().setModel(this.oAdminViewModel, "oAdminViewModel");
			this.oAdminViewModel.setSizeLimit(2000);
			this.oAdminUserViewModel = new JSONModel();
			this.getView().setModel(this.oAdminUserViewModel, "oAdminUserViewModel");
			this.oAdminUserViewModel.setSizeLimit(2000);
			this.UserDetailsModel = new JSONModel();
			this.getView().setModel(this.UserDetailsModel, "UserDetailsModel");
			this.AccessTypeModel = new JSONModel();
			this.getView().setModel(this.AccessTypeModel, "AccessTypeModel");
			this.getRegion();
			/*BOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
			this.oAdminUserHeaderModel = new JSONModel();
			this.getView().setModel(this.oAdminUserHeaderModel, "oAdminUserHeaderModel");
			/*EOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
		},
		/*Admin Main Page Details*/
		getRegion: function () {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/RegionSet", {
				success: function (oData) {
					that.RegionModel.setData(oData);
				},
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			oModel.read("/RCTypeSet", {
				success: function (oData) {
					that.RCTypeModel.setData(oData);
				},
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			oModel.read("/AccessTypeSet", {
				success: function (oData) {
					that.AccessTypeModel.setData(oData);
				},
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		handleRegionChange: function (oEvent) {
			if (this.getView().byId("idRCTypeCombox").getSelectedKey()) {
				this.handleRCTypeChange();
			}
		},
		handleRCTypeChange: function (oEvent) {
			if (!this.getView().byId("idRegionCombox").getSelectedKey()) {
				MessageBox.error("Enter Region");
				return;
			}
			this._oBusyDialog.open();
			var selectedRegionKey = this.getView().byId("idRegionCombox").getSelectedKey();
			var selectedRCTypeKey = this.getView().byId("idRCTypeCombox").getSelectedKey();
			var oModel = this.getOwnerComponent().getModel();
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, selectedRegionKey));
			aFilter.push(new sap.ui.model.Filter("RcType", sap.ui.model.FilterOperator.EQ, selectedRCTypeKey));
			var that = this;
			oModel.read("/RepairCenterSet", {
				filters: aFilter,
				success: function (oData) {
					that._oBusyDialog.close();
					if (oData.results.length > 0) {
						that.getView().byId("idMainContainer").setVisible(true);
						that.oAdminViewModel.setData(oData);
					} else {
						that.oAdminViewModel.setData({});
						MessageBox.success("No Data Found");
					}
				},
				error: function (oError) {
					that._oBusyDialog.close();
					that.oAdminViewModel.setData({});
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		/*Admin User Details*/
		handleUserDetails: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oAdminViewModel").getPath();
			this.rowProperty = this.getView().getModel("oAdminViewModel").getProperty(rowPath);
			var Region = this.getView().byId("idRegionCombox").getSelectedKey();
			var RcType = this.getView().byId("idRCTypeCombox").getSelectedKey();
			var shipper = this.rowProperty.RcCode;
			var aFilter = [];
			this._oBusyDialog.open();
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			aFilter.push(new sap.ui.model.Filter("Zshipper", sap.ui.model.FilterOperator.EQ, shipper));
			oModel.read("/RCUserSet", {
				filters: aFilter,
				success: function (oData) {
					that._oBusyDialog.close();
					if (oData.results.length > 0) { // ++/*INC080175920*/		
						oData.results[0].RcName = that.rowProperty.RcName;
						oData.results[0].RcCode = that.rowProperty.RcCode;
						oData.results[0].Region = Region;
						oData.results[0].RcType = RcType;
						that.oAdminUserViewModel.setData(oData);
						/*BOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
						that.oAdminUserHeaderModel.setData(oData);
					} else {
						MessageBox.error("No External Users found");
						var oData1 = {
							results: [{}]
						};
						oData1.results[0].RcName = that.rowProperty.RcName;
						oData1.results[0].Region = Region;
						oData1.results[0].RcCode = that.rowProperty.RcCode;
						oData1.results[0].RcType = RcType;
						that.oAdminUserHeaderModel.setData(oData1);
						that.oAdminUserViewModel.setData({});
					}
					/*EOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/

				},
				error: function (oError) {
					that._oBusyDialog.close();
					that.oAdminUserViewModel.setData({});
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			this.getView().byId("idMainPanel").setVisible(false);
			this.getView().byId("idUserDetailsPanel").setVisible(true);
		},
		handleUserDetailsBack: function (oEvent) {
			this.getView().byId("idMainPanel").setVisible(true);
			this.getView().byId("idUserDetailsPanel").setVisible(false);
		},
		onUserDetailsRefresh: function () {
			// var rowProperty = this.getView().getModel("oAdminViewModel").getProperty(rowPath);
			var Region = this.getView().byId("idRegionCombox").getSelectedKey();
			var RcType = this.getView().byId("idRCTypeCombox").getSelectedKey();
			var shipper = this.rowProperty.RcCode;
			var aFilter = [];
			this._oBusyDialog.open();
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			aFilter.push(new sap.ui.model.Filter("Zshipper", sap.ui.model.FilterOperator.EQ, shipper));
			oModel.read("/RCUserSet", {
				filters: aFilter,
				success: function (oData) {
					that._oBusyDialog.close();
					if (oData.results.length > 0) { // ++/*INC080175920*/	
						oData.results[0].RcName = that.rowProperty.RcName;
						oData.results[0].RcCode = that.rowProperty.RcCode;
						oData.results[0].Region = Region;
						oData.results[0].RcType = RcType;
						that.oAdminUserViewModel.setData(oData);
						that.oAdminUserViewModel.refresh();
						/*BOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
						that.oAdminUserHeaderModel.setData(oData);
						that.oAdminUserHeaderModel.refresh();
					} else {
						// MessageBox.error("No External Users found");
						var oData1 = {
							results: [{}]
						};
						oData1.results[0].RcName = that.rowProperty.RcName;
						oData1.results[0].Region = Region;
						oData1.results[0].RcCode = that.rowProperty.RcCode;
						oData1.results[0].RcType = RcType;
						that.oAdminUserHeaderModel.setData(oData1);
						that.oAdminUserHeaderModel.refresh();
						that.oAdminUserViewModel.setData({});
					}
					/*EOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
				},
				error: function (oError) {
					that._oBusyDialog.close();
					that.oAdminUserViewModel.setData({});
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			this.getView().byId("idMainPanel").setVisible(false);
			this.getView().byId("idUserDetailsPanel").setVisible(true);
		},
		/*Admin Delete Functionality */
		onAdminDeleteBtnPress: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			// var data = [];
			var selectedRows = this.getView().byId("oUserAdminTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			var Deletekey = "";
			this._oBusyDialog.open();
			oModel.setDeferredGroups(["AdminUserbatchDelete"]);
			if (selectedRows.length > 0) {
				for (var i = 0; i < selectedRows.length; i++) {
					// var temp = {};
					Deletekey = "";
					rowPath = this.getView().byId("oUserAdminTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oAdminUserViewModel").getProperty(rowPath);
					//* INC080175920*/
					rowProperty.Zshipper = this.getView().byId("idUserRcCode").getText();
					Deletekey = "Zshipper='" + rowProperty.Zshipper + "'" + "," + "PersonDsid='" + rowProperty.PersonDsid + "'";
					var sPath = "/RCUserSet(" + Deletekey + ")";
					oModel.remove(sPath, {
						method: "POST",
						batchGroupId: "AdminUserbatchDelete"
					});
				}
				var that = this;
				oModel.submitChanges({
					batchGroupId: "AdminUserbatchDelete",
					changeSetId: 1,
					success: function (oData, oResponse) {
						that._oBusyDialog.close();
						if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
							MessageBox.success("Selected record(s) deleted successfully");
							that.onUserDetailsRefresh();
						} else {
							MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						}
					},
					error: function (oError) {
						that._oBusyDialog.close();
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
					//* INC080175920*/
				// that._oBusyDialog.close();
				this._oBusyDialog.close();
				MessageBox.error("Please select atleast one record");
			}
		},
		/*Admin Add User Functionality*/
		onAdminAddtnPress: function (oEvent) {
			var oView = this.getView();
			if (this._AddUser) {
				this._AddUser.destroy();
				this._AddUser = null;
			}
			if (!this._AddUser) {
				this._AddUser = sap.ui.xmlfragment("AddUser", "com.apple.ui5.ZUI5_AC_SHIP_ADMIN.fragment.AddUserDetails", this);
				oView.addDependent(this._AddUser);
			}
			this.getView().getModel("UserDetailsModel").setData({});
			this._AddUser.open();
		},
		onAddCancelBtnPress: function (oEvent) {
			if (this._AddUser) {
				this._AddUser.destroy();
				this._AddUser = null;
			}
		},
		onADDSubmitBtnPress: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var UserDetailsModel = this.getView().getModel("UserDetailsModel").getData();
			// var oAdminUserViewModel = this.getView().getModel("oAdminUserViewModel").getData(); /*INC080175920*/
			var userDetails = {};
			userDetails.Uname = UserDetailsModel.Uname;
			/*BOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
			//Read from label text
			// userDetails.Zshipper = oAdminUserViewModel.results[0].RcCode;
			userDetails.Zshipper = this.getView().byId("idUserRcCode").getText();
			/*EOC https://hcl.apple.com/tkt.do?tkt=INC080175920*/
			userDetails.PersonDsid = UserDetailsModel.PersonDsid;
			userDetails.EmailId = UserDetailsModel.EmailId;
			userDetails.ContactDetails = UserDetailsModel.ContactDetails;
			var startDate = sap.ui.core.Fragment.byId("AddUser", "idUserStartDate").getValue();
			var endDate = sap.ui.core.Fragment.byId("AddUser", "idEndDate").getValue();
			var time = new Date();
			var currentTime = "T" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds();
			userDetails.UserStartDate = startDate.slice(0, 4) + "-" + startDate.slice(4, 6) + "-" + startDate.slice(6, 8) + currentTime;
			userDetails.UserEndDate = endDate.slice(0, 4) + "-" + endDate.slice(4, 6) + "-" + endDate.slice(6, 8) + currentTime;
			userDetails.AccessType = sap.ui.getCore().byId("AddUser--idAccessType").getSelectedKey();
			this._oBusyDialog.open();
			var that = this;
			oModel.create("/RCUserSet", userDetails, {
				success: function (oData, oResponse) {
					that._oBusyDialog.close();
					// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
					MessageBox.success("Created successfully");
					that.onAddCancelBtnPress();
					that.onUserDetailsRefresh();
					// } else {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// }
				},
				error: function (oError) {
					that._oBusyDialog.close();
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		/*Admin Edit User Functionality*/
		handleEditUserDetails: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oAdminUserViewModel").getPath();
			var rowProperty = this.getView().getModel("oAdminUserViewModel").getProperty(rowPath);
			this.UserDetailsModel.setData(rowProperty);
			var oView = this.getView();
			if (this._EditUser) {
				this._EditUser.destroy();
				this._EditUser = null;
			}
			if (!this._EditUser) {
				this._EditUser = sap.ui.xmlfragment("EditUser", "com.apple.ui5.ZUI5_AC_SHIP_ADMIN.fragment.EditUserDetails", this);
				sap.ui.core.Fragment.byId("EditUser", "idUserStartDate").setDateValue(new Date(this.UserDetailsModel.getData().UserStartDate.getFullYear(),
					this.UserDetailsModel.getData().UserStartDate.getMonth(), this.UserDetailsModel.getData().UserStartDate.getDate()));
				sap.ui.core.Fragment.byId("EditUser", "idEndDate").setDateValue(new Date(this.UserDetailsModel.getData().UserEndDate.getFullYear(),
					this.UserDetailsModel.getData().UserEndDate.getMonth(), this.UserDetailsModel.getData().UserEndDate.getDate()));
				oView.addDependent(this._EditUser);
			}
			this._EditUser.open();
		},
		onEditCancelBtnPress: function (oEvent) {
			if (this._EditUser) {
				this._EditUser.destroy();
				this._EditUser = null;
			}
		},
		onEditSubmitBtnPress: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var UserDetailsModel = this.getView().getModel("UserDetailsModel").getData();
			var userDetails = {};
			userDetails.Zshipper = UserDetailsModel.Zshipper;
			userDetails.Uname = UserDetailsModel.Uname;
			userDetails.PersonDsid = UserDetailsModel.PersonDsid;
			userDetails.EmailId = UserDetailsModel.EmailId;
			userDetails.ContactDetails = UserDetailsModel.ContactDetails;
			var startDate = sap.ui.core.Fragment.byId("EditUser", "idUserStartDate").getValue();
			var endDate = sap.ui.core.Fragment.byId("EditUser", "idEndDate").getValue();
			var time = new Date();
			var currentTime = "T" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds();
			userDetails.UserStartDate = startDate.slice(0, 4) + "-" + startDate.slice(4, 6) + "-" + startDate.slice(6, 8) + currentTime;
			userDetails.UserEndDate = endDate.slice(0, 4) + "-" + endDate.slice(4, 6) + "-" + endDate.slice(6, 8) + currentTime;
			userDetails.AccessType = UserDetailsModel.AccessType;
			var UpdateKey = "Zshipper='" + UserDetailsModel.Zshipper + "'" + "," + "PersonDsid='" + UserDetailsModel.PersonDsid + "'";
			var sPath = "/RCUserSet(" + UpdateKey + ")";
			var that = this;
			oModel.update(sPath, userDetails, {
				success: function (oData, oResponse) {
					// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
					MessageBox.success("Selected record updated successfully");
					that.onEditCancelBtnPress();
					that.onUserDetailsRefresh();
					// } else {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// }
				},
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		}
	});
});