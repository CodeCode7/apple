sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "com/apple/scp/ui/pallets/model/models",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, JSONModel, models, Fragment, MessageBox) {
        "use strict";

        return Controller.extend("com.apple.scp.ui.pallets.controller.Main", {
            onInit: function () {
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        this.appId = variables;
                        this.gModelPalletConfig = {
                            headers: { appid: variables },
                            defaultBindingMode: "TwoWay",
                            defaultCountMode: "Inline",
                            useBatch: true
                        };

                        this.ui5_ppModel = new sap.ui.model.odata.v2.ODataModel("/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/", this.gModelPalletConfig);

                        if (!this._destDialogPallet) {
                            this._destDialogPallet = sap.ui.xmlfragment(this.getView().getId(),
                                "com.apple.scp.ui.pallets.fragment.Palletization.CustomerDialog", this);
                            this.getView().addDependent(this._destDialogPallet);
                        }
                        this._destDialogPallet.open();
                    });

                fetch("/getPackType")
                    .then(res2 => res2.json())
                    .then(apiPalletDest => {
                        this.getView().setModel(new JSONModel({
                            aPalletDestData: apiPalletDest
                        }), "oPalletDestModel");
                    });

                this.getView().setModel(new JSONModel({
                    aCreatePalletStorageLocs: [],
                    aCreatePalletCustomer: [],
                    aCreatePalletPlant: []
                }), "oGenPalletIdModel");

                this.getView().setModel(new JSONModel({
                    aCreatePalletBoxIds: [],
                    aModPalletBoxIds: []
                }), "oSerialNosModel");

                this.getView().setModel(new JSONModel({
                    aCPValidAndPrint: [],
                    aMPValidAndPrint: []
                }), "oValidAndPrintModel");

                this.palletItemsError = "";
                this.cpSNError = "";
                this.mpSNError = "";
                this.bNoPalletItems = false;
                this.bProceed = true;
                this.receivedBoxIds = [];
                this.bBoxIDsChanged = false;
                this.originalBoxIds = [];

                this.getView().setModel(new JSONModel({
                    appBusy: false
                }), "busyModel");

                this.initialSettings();
            },

            initialSettings: function (oEvent) {
                this.getView().setModel(new JSONModel({
                    bPallet: false,
                    bPalletModEdit: true,
                    palletTabSelKey: "createPallet",
                    palletSubTabSelKey: "genPalletId",
                    palletModSubSelKey: "scanPalletId",
                    sCreatePalletPlantSelKey: "",
                    sCreatePalletStorageLocSelKey: "",
                    sCreatePalletCustomerSelKey: "",
                    sCreatePalletCustName: "",
                    sModPalletCustomer: "",
                    sModPalletCustName: "",
                    sCreatePalletId: "",
                    sPalletIdMod: "",
                    sPalletPlant: "",
                    sPalletStorageLoc: "",
                    sModPalletPlant: "",
                    sModPalletStorageLoc: "",
                    bNextEnabled: true,
                    sPalletDestSelKey: "AS-IS",
                    bSubs: false
                }), "oGlobalModel");
            },

            footerButtonSettings: function (prmBtnText, secBtnText) {
                this.getView().byId("prmBtn").setText(prmBtnText);
                this.getView().byId("secBtn").setText(secBtnText);
            },

            modifyBtnTxt: function (oEvent) {
                if (this.getView().getModel("oGlobalModel").getProperty("/palletTabSelKey") === "createPallet") {
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                    this.footerButtonSettings("Create Pallet ID", "Cancel");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "scanPalletBoxID");
                    this.footerButtonSettings("Next", "Cancel");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "scanPalletBoxID");
                }

            },

            onPalletCancel: function (oEvent) {

                if (this.getView().getModel("oGlobalModel").getProperty("/palletTabSelKey") === "createPallet") {
                    this.onCreatePalletIdCancel(this.getView().getModel("oGlobalModel").getProperty("/palletSubTabSelKey"));
                } else if (this.getView().getModel("oGlobalModel").getProperty("/palletTabSelKey") === "modifyPallet") {
                    this.onModifyPalletCancel(this.getView().getModel("oGlobalModel").getProperty("/palletModSubSelKey"));
                }


                this.getView().getModel("oGlobalModel").refresh(true);
            },

            onCreatePalletPress: function (oEvent) {

                if (this.getView().getModel("oGlobalModel").getProperty("/palletTabSelKey") === "createPallet") {
                    this.validateCreatePalletId(this.getView().getModel("oGlobalModel").getProperty("/palletSubTabSelKey"));
                } else if (this.getView().getModel("oGlobalModel").getProperty("/palletTabSelKey") === "modifyPallet") {
                    this.validateModifyPallet(this.getView().getModel("oGlobalModel").getProperty("/palletModSubSelKey"));
                }

            },

            selPalletTab: function (oEvent) {
                var oPalletIconHeader = this.getView().byId("idCreatePallet");
                var oPalletIconTabFilter = oPalletIconHeader.getItems();
                oPalletIconHeader.setSelectedKey("createPallet");
                oPalletIconHeader.fireSelect({
                    item: oPalletIconTabFilter[0],
                    key: "createPallet"
                });
            },

            onCreatePalletTabSel: function (oEvent) {
                var oCreateContent = this.getView().byId("createPalletMainSub");
                var oModifyContent = this.getView().byId("modifyPalletSub");
                this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", true);
                if (this.getView().byId("idCreatePallet").getSelectedKey() === "createPallet") {

                    if (!this.ofragPalletCreateSub) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.apple.scp.ui.pallets.fragment.Palletization.CreatePalletSub",
                            controller: this
                        }).then(function (fragPalletCreateSub) {
                            this.ofragPalletCreateSub = fragPalletCreateSub;

                            this.getView().addDependent(fragPalletCreateSub);
                            oCreateContent.addItem(fragPalletCreateSub);
                            this.getView().getModel("oGlobalModel").setProperty("/palletTabSelKey", "createPallet");
                            this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                            this.setCreatePalletPlantsDefaults();
                            this.modifyBtnTxt();
                        }.bind(this));
                    } else {
                        oCreateContent.removeAllItems(true);
                        oCreateContent.addItem(this.ofragPalletCreateSub);
                        this.getView().getModel("oGlobalModel").setProperty("/palletTabSelKey", "createPallet");
                        this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                        this.setCreatePalletPlantsDefaults();
                        this.modifyBtnTxt();
                    }
                } else {
                    if (!this.ofragPalletModSub) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.apple.scp.ui.pallets.fragment.Palletization.ModifyPalletSub",
                            controller: this
                        }).then(function (fragPalletModSub) {
                            this.ofragPalletModSub = fragPalletModSub;
                            this.getView().addDependent(fragPalletModSub);
                            oModifyContent.addItem(fragPalletModSub);
                            this.getView().getModel("oGlobalModel").setProperty("/palletTabSelKey", "modifyPallet");
                            this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                            this.modifyBtnTxt();
                        }.bind(this));
                    } else {
                        oModifyContent.removeAllItems(true);
                        oModifyContent.addItem(this.ofragPalletModSub);
                        this.getView().getModel("oGlobalModel").setProperty("/palletTabSelKey", "modifyPallet");
                        this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                        this.modifyBtnTxt();
                    }
                }
            },

            setCreatePalletPlantsDefaults: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.PalletMetadatamodel.read("/Plants", {
                    success: function (oData, oResponse) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGenPalletIdModel").setProperty("/aCreatePalletPlant", oData.results);
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletPlantSelKey", "5601");
                                that.setGenPalletIdDefaults("5601");
                            } else {
                                that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletPlantSelKey", oData.results[0].Plant);
                                that.setGenPalletIdDefaults(oData.results[0].Plant);
                            }

                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            setGenPalletIdDefaults: function (sPalletPlantSelKey) {
                var that = this;
                var aFilter = [];
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPalletPlantSelKey));
                this.PalletMetadatamodel.read("/StorageLocations", {
                    filters: aFilter,
                    success: function (data) {
                        if (data.results.length > 0) {
                            that.getView().getModel("oGenPalletIdModel").setProperty("/aCreatePalletStorageLocs", data.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletStorageLocSelKey", data.results[0].StorageLocation);
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.getPalletCustomerName([]);
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            }
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            getPalletCustomerName: function (aPalletFilter) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.bPalFilter = false;
                if (aPalletFilter.length > 0) {
                    this.bPalFilter = true;
                }
                this.PalletMetadatamodel.read("/Customer", {
                    filters: aPalletFilter,
                    success: function (oData) {
                        
                        if (oData.results.length > 0) {
                            if (that.bPalFilter) {
                                that.getView().getModel("oGlobalModel").setProperty("/sModPalletCustName", oData.results[0].CustomerName);
                            } else {
                                that.getView().getModel("oGlobalModel").setProperty("/sModPalletCustName", "");
                            }
                            that.getView().getModel("oGenPalletIdModel").setProperty("/aCreatePalletCustomer", oData.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletCustomerSelKey", oData.results[0].CustomerId);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/sModPalletCustName", "");
                            that.getView().getModel("oGenPalletIdModel").setProperty("/aCreatePalletCustomer", []);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletCustomerSelKey", "");
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });
            },

            onPalletPlantChange: function (oEvent) {
                this.setGenPalletIdDefaults(oEvent.getSource().getSelectedKey());
            },

            setPalletService: function () {
                this.Palletmodel = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/pallet-service/`, this.gModelPalletConfig);
                this.Palletmodel.sDefaultUpdateMethod = "PATCH";
            },

            validateCreatePalletId: function (sPalletSubTabSelKey) {
                if (sPalletSubTabSelKey === "genPalletId") {
                    this.setPalletService();
                    this.createPalletId();
                } else if (sPalletSubTabSelKey === "scanPalletBoxID") {
                    this.getPalletSerialNumberDetails("CP");
                } else if (sPalletSubTabSelKey === "valdAndPrint") {
                    this.completeCreatePallet();
                }
            },

            createPalletId: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var createPalletIDPayload = {
                    "Plant": that.getView().getModel("oGlobalModel").getProperty("/sCreatePalletPlantSelKey"),
                    "StorageLocation": that.getView().getModel("oGlobalModel").getProperty("/sCreatePalletStorageLocSelKey")
                }

                if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    createPalletIDPayload.Customer = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletCustomerSelKey");
                    this.getView().getModel("oGlobalModel").setProperty("/sCreatePalletCustName", this.getView().byId("palletCust").getSelectedItem().getAdditionalText());
                    createPalletIDPayload.Type = "B";
                } else {
                    createPalletIDPayload.Customer = "";
                    this.getView().getModel("oGlobalModel").setProperty("/sCreatePalletCustName", "");
                    createPalletIDPayload.Type = "A";
                }

                this.Palletmodel.create("/Pallets", createPalletIDPayload, {

                    success: function (data) {
                        that.getView().getModel("oGlobalModel").setProperty("/sCreatePalletId", data.PalletID);
                        var aNewScanBoxIds = [];
                        for (var s = 0; s < 64; s++) {
                            var oNewScanBoxIds = {
                                palletSequence: (s + 1).toString(),
                                BoxID: ""
                            };
                            aNewScanBoxIds.push(oNewScanBoxIds);
                        }
                        that.getView().getModel("oSerialNosModel").setProperty("/aCreatePalletBoxIds", aNewScanBoxIds);
                        that.footerButtonSettings("Next", "Back");
                        that.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "scanPalletBoxID");
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (createPalletError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(createPalletError.responseText).error.message.value);
                    }
                });

            },

            getPalletSerialNumberDetails: function (sSelBoxTab) {
                var aPalletBoxIDs = [];
                var sBoxIds = "",
                    oBoxIdsReturn;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (sSelBoxTab === "CP") {
                    if (this.checkDuplicateBoxIds(sSelBoxTab)) {
                        if (this.cpSNError.length === 0) {
                            this.cpSNError = "Duplicate Box IDs Exists";
                        }
                        MessageBox.error(this.cpSNError);
                        this.cpSNError = "";
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        return;
                    }
                    aPalletBoxIDs = this.getView().getModel("oSerialNosModel").getProperty("/aCreatePalletBoxIds");
                    oBoxIdsReturn = this.prepareCPBoxIdsPayload(aPalletBoxIDs, sBoxIds);
                } else {
                    if (this.checkDuplicateBoxIds(sSelBoxTab)) {
                        if (this.mpSNError.length === 0) {
                            this.mpSNError = "Duplicate Box IDs Exists";
                        }
                        MessageBox.error(this.mpSNError);
                        this.mpSNError = "";
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        return;
                    }
                    aPalletBoxIDs = this.getView().getModel("oSerialNosModel").getProperty("/aModPalletBoxIds");
                    oBoxIdsReturn = this.prepareMPBoxIdsPayload(aPalletBoxIDs, sBoxIds);

                }

                this.getPalletContents(sSelBoxTab, oBoxIdsReturn);

            },

            checkDuplicateBoxIds: function (selTab) {
                var bResp;
                if (selTab === "CP") {
                    bResp = this.checkCreatePalletDuplicates();
                    return bResp;
                } else if (selTab === "MP") {
                    bResp = this.checkModifyPalletDuplicates();
                    return bResp;
                }
            },

            checkCreatePalletDuplicates: function () {
                var aSortedBoxIds = [];
                var aBoxIds = this.getView().getModel("oSerialNosModel").getProperty("/aCreatePalletBoxIds");

                for (let p of aBoxIds) {
                    if (p.BoxID.trim() !== "") {
                        aSortedBoxIds.push(p.BoxID.trim());
                    }
                }
                if (aSortedBoxIds.length > 0) {
                    aSortedBoxIds.sort((a, b) => (a.BoxID > b.BoxID) ? 1 : -1);
                    for (var i = 0; i < aSortedBoxIds.length - 1; i++) {
                        if (aSortedBoxIds[i + 1] === aSortedBoxIds[i]) {
                            this.cpSNError = "";
                            return true;
                        }
                    }

                } else {
                    this.cpSNError = "Please enter at least one Box ID";
                    return true;
                }
                return false;
            },

            prepareCPBoxIdsPayload: function (aPalletBoxIDs, sBoxIds) {
                var oCPBoxIdsReturn = {
                    bAtleastOneBIDExists: false,
                    sBoxIds: ""
                };
                var bAtleastOneBIDExists = false;

                for (let t of aPalletBoxIDs) {
                    if (t.BoxID.trim()) {
                        if (sBoxIds.length > 0) {
                            sBoxIds = sBoxIds + "," + t.BoxID;
                        } else {
                            sBoxIds = t.BoxID;
                        }
                        bAtleastOneBIDExists = true;
                    }

                }
                oCPBoxIdsReturn.bAtleastOneBIDExists = bAtleastOneBIDExists;
                oCPBoxIdsReturn.sBoxIds = sBoxIds;
                return oCPBoxIdsReturn;
            },

            getPalletContents: function (sSelBoxTab, oMPBoxIdsReturn) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var sPalletID = this.setPalletID(sSelBoxTab);

                if (oMPBoxIdsReturn.bAtleastOneBIDExists) {
                    this.Palletmodel.setDeferredGroups(["GetPalletContentGroup"]);
                    var oPalletBoxIDsPayload = {
                        palletID: sPalletID,
                        boxID: oMPBoxIdsReturn.sBoxIds
                    };
                    this.Palletmodel.callFunction("/getPalletContents", {
                        urlParameters: oPalletBoxIDsPayload,
                        method: "GET",
                        batchGroupId: "GetPalletContentGroup"
                    });
                    this.Palletmodel.submitChanges({
                        batchGroupId: "GetPalletContentGroup",
                        async: false,
                        success: function (oData, oResponse) {
                            var data = oData.__batchResponses[0].data;
                            if (data) {
                                for (var a = 0; a < data.results.length; a++) {
                                    data.results[a].PalletSequence = (a + 1).toString();
                                }
                                that.setValdAndPrintData(sSelBoxTab, data);
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                            }
                        },
                        error: function (oError) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        }
                    });

                }
            },

            setPalletID: function (sSelBoxTab) {
                var sPalletID = "";
                if (sSelBoxTab === "CP") {
                    sPalletID = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletId");
                } else {
                    sPalletID = this.getView().getModel("oGlobalModel").getProperty("/sPalletIdMod");
                }
                return sPalletID;
            },

            setValdAndPrintData: function (sSelBoxTab, data) {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (sSelBoxTab === "CP") {
                    this.getView().getModel("oValidAndPrintModel").setProperty("/aCPValidAndPrint", data.results);
                    this.footerButtonSettings("Complete & Print Labels", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "valdAndPrint");
                } else {
                    this.getView().getModel("oValidAndPrintModel").setProperty("/aMPValidAndPrint", data.results);
                    this.originalBoxIds = this.getView().getModel("oSerialNosModel").getProperty("/aModPalletBoxIds");
                    this.footerButtonSettings("Complete & Print Labels", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "valdAndPrint");
                    this.bNoPalletItems = false;
                }
                this.getView().getModel("busyModel").setProperty("/appBusy", false);
            },

            completeCreatePallet: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aValdAndPrint = this.getView().getModel("oValidAndPrintModel").getProperty("/aCPValidAndPrint");
                var aCPBoxIdsPayload = [];

                for (let s of aValdAndPrint) {
                    var oBoxId = {
                        BoxID_BoxID: s.BoxID_BoxID
                    };
                    aCPBoxIdsPayload.push(oBoxId);
                }
                var aCreatePalletCompletePayload = {
                    "Plant": this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletPlantSelKey"),
                    "toPalletItems": aCPBoxIdsPayload
                };
                this.Palletmodel.update("/Pallets('" + this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletId") + "')", aCreatePalletCompletePayload, {
                    success: function (data, oResponse) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                            that.onCreatePalletPrintLabelPress_MC();
                        } else {
                            that.createPalletPrintLabels();
                        }
                    },
                    error: function (completePalletError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (completePalletError.responseJSON) {
                            MessageBox.error(completePalletError.responseJSON.error.message);
                        } else {
                            MessageBox.error(completePalletError.responseText);
                        }
                    }
                });

            },

            onModPalletPrintLabelPress_MC: function (oEvent) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["subsModPalletbatchDownload"]);
                var aModPalletPrintLabelData_MC = this.getView().getModel("oValidAndPrintModel").getProperty("/aMPValidAndPrint");
                var iTotalBoxQty = 0;

                for (let r of aModPalletPrintLabelData_MC) {
                    if (r.Quantity !== "" && r.Quantity !== null) {
                        iTotalBoxQty += r.Quantity;
                    } else {
                        r.Quantity = 0;
                    }
                }

                var iTotBoxCount = aModPalletPrintLabelData_MC.length;
                for (let i of aModPalletPrintLabelData_MC) {
                    var tempModPallet_MC = {};
                    tempModPallet_MC.BoxID = i.BoxID_BoxID;
                    tempModPallet_MC.BoxQuantity = JSON.stringify(i.Quantity);
                    tempModPallet_MC.Customer = this.getView().getModel("oGlobalModel").getProperty("/sModPalletCustomer") + " - " + this.getView().getModel("oGlobalModel").getProperty("/sModPalletCustName");
                    tempModPallet_MC.PalletID = this.getView().getModel("oGlobalModel").getProperty("/sPalletIdMod");
                    tempModPallet_MC.TotalBoxCount = JSON.stringify(iTotBoxCount);
                    tempModPallet_MC.TotalBoxQuantity = JSON.stringify(iTotalBoxQty);

                    this.ui5_ppModel.callFunction("/GenerateARTSPalletLabel", {
                        urlParameters: tempModPallet_MC,
                        method: "POST",
                        batchGroupId: "subsModPalletbatchDownload"
                    });

                }
                
                this.ui5_ppModel.submitChanges({
                    batchGroupId: "subsModPalletbatchDownload",
                    changeSetId: 1,
                    success: function (oData, oResponse) {
                        
                        if (oData.__batchResponses[0].data === undefined) {
                            var ModPalletFileGUID_MC = oData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (ModPalletFileGUID_MC === "") {
                                sap.m.MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/ARTSPalletLabelPDFSet(GUID='${ModPalletFileGUID_MC}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl);
                            }

                            that.footerButtonSettings("Next", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", "");
                            that.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oCPPData.__batchResponses[0].response.body).error.message.value);
                        }
                        

                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.footerButtonSettings("Next", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", "");
                        that.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });
            },

            onCreatePalletPrintLabelPress_MC: function (oEvent) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["subsPalletbatchDownload"]);
                var aCreatePalletPrintLabelData_MC = this.getView().getModel("oValidAndPrintModel").getProperty("/aCPValidAndPrint");
                var iTotalBoxQty = 0;

                for (let k of aCreatePalletPrintLabelData_MC) {
                    if (k.Quantity !== "" && k.Quantity !== null) {
                        iTotalBoxQty += k.Quantity;
                    } else {
                        k.Quantity = 0;
                    }
                }

                var iTotalBoxCnt = aCreatePalletPrintLabelData_MC.length;
                for (let c of aCreatePalletPrintLabelData_MC) {
                    var tempCreatePallet_MC = {};
                    tempCreatePallet_MC.BoxID = c.BoxID_BoxID;
                    tempCreatePallet_MC.BoxQuantity = JSON.stringify(c.Quantity);
                    tempCreatePallet_MC.Customer = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletCustomerSelKey") + " - " + this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletCustName");
                    tempCreatePallet_MC.PalletID = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletId");
                    tempCreatePallet_MC.TotalBoxCount = JSON.stringify(iTotalBoxCnt);
                    tempCreatePallet_MC.TotalBoxQuantity = JSON.stringify(iTotalBoxQty);

                    this.ui5_ppModel.callFunction("/GenerateARTSPalletLabel", {
                        urlParameters: tempCreatePallet_MC,
                        method: "POST",
                        batchGroupId: "subsPalletbatchDownload"
                    });

                }
                
                this.ui5_ppModel.submitChanges({
                    batchGroupId: "subsPalletbatchDownload",
                    changeSetId: 1,
                    success: function (oData, oResponse) {
                        
                        if (oData.__batchResponses[0].data === undefined) {
                            var CreatePalletFileGUID_MC = oData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (CreatePalletFileGUID_MC === "") {
                                sap.m.MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/ARTSPalletLabelPDFSet(GUID='${CreatePalletFileGUID_MC}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl);
                            }

                            that.footerButtonSettings("Create Pallet ID", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.setCreatePalletPlantsDefaults();
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oCPPData.__batchResponses[0].response.body).error.message.value);
                        }
                        

                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                        that.footerButtonSettings("Create Pallet ID", "Cancel");
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        that.setCreatePalletPlantsDefaults();
                    }

                });
            },

            validateModifyPallet: function (sPalletModSubTabSelKey) {
                if (sPalletModSubTabSelKey === "scanPalletId") {
                    this.setPalletService();
                    this.getPalletItems();
                } else if (sPalletModSubTabSelKey === "scanPalletBoxID") {
                    this.getPalletSerialNumberDetails("MP")
                } else if (sPalletModSubTabSelKey === "valdAndPrint") {
                    this.completeModifyPallet();
                }
            },

            getPalletItems: function () {
                var that = this;
                var y = true;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.Palletmodel.read("/Pallets('" + this.getView().getModel("oGlobalModel").getProperty("/sPalletIdMod") + "')", {
                    urlParameters: {
                        "$expand": "toPalletItems"
                    },
                    success: function (data) {
                        if (data.Status === "3") {
                            MessageBox.error(`Pallet ${data.PalletID} is already Shipped`);
                            that.bProceed = false;
                            y = false;
                        } else {
                            that.bProceed = true;
                            if (data.toPalletItems.results.length > 0) {
                                data = that.addPalletItems(data);
                                that.getView().getModel("oSerialNosModel").setProperty("/aModPalletBoxIds", data.toPalletItems.results);
                                that.originalBoxIds = JSON.stringify(data.toPalletItems.results);
                                that.receivedBoxIds = JSON.stringify(data.toPalletItems.results);
                                that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", data.PalletID);
                                y = false;
                            } else {
                                that.bNoPalletItems = true;
                                y = true;
                                that.getView().getModel("oSerialNosModel").setProperty("/aModPalletBoxIds", []);
                                that.originalBoxIds = [];
                                that.receivedBoxIds = [];
                                that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", data.PalletID);
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/sModPalletPlant", data.Plant);
                            that.getView().getModel("oGlobalModel").setProperty("/sModPalletStorageLoc", data.StorageLocation);
                            that.setCustomerData(data);

                        }
                        that.navToSBID(y);
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (getPalletsError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.bProceed = false;
                        y = false;
                        MessageBox.error(JSON.parse(getPalletsError.responseText).error.message.value);
                        that.navToSBID(y);
                    }
                });

            },

            addPalletItems: function (data) {
                for (var x = 0; x < data.toPalletItems.results.length; x++) {
                    data.toPalletItems.results[x].PalletSequence = (x + 1).toString();
                }
                for (var m = data.toPalletItems.results.length + 1; m <= 64; m++) {
                    var oPalletModNewRow = {
                        PalletSequence: (m).toString(),
                        BoxID_BoxID: ""
                    };
                    data.toPalletItems.results.push(oPalletModNewRow);
                }
                return data;
            },

            setCustomerData: function (data) {
                this.getView().getModel("oGlobalModel").setProperty("/sModPalletCustomer", data.Customer);
                if (data.Customer !== "" && data.Customer !== undefined &&
                    this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    this.setModPalletCustName(data.Customer);
                }
            },

            setModPalletCustName: function (customerId) {
                var aPalletFilter = [];
                aPalletFilter.push(new sap.ui.model.Filter("CustomerId", sap.ui.model.FilterOperator.EQ, customerId));
                this.getPalletCustomerName(aPalletFilter);
            },

            navToSBID: function (y) {
                if (!y) {
                    if (this.bProceed) {
                        this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletBoxID");
                        this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", true);
                        this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                        this.footerButtonSettings("Next", "Back");
                    }

                } else {
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletBoxID");
                    this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", true);
                    this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                    var aEmptyBIds = [];
                    for (var a = 0; a < 64; a++) {
                        var oEmptyBIdRow = {
                            PalletSequence: (a + 1).toString(),
                            BoxID_BoxID: ""
                        };
                        aEmptyBIds.push(oEmptyBIdRow);
                    }
                    this.getView().getModel("oSerialNosModel").setProperty("/aModPalletBoxIds", aEmptyBIds);
                }
            },

            onEditBoxID: function (oEvent) {
                if (this.getView().getModel("oGlobalModel").getProperty("/bPalletModEdit")) {
                    this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", false);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", true);
                }
            },

            onPalletModBoxIdDelete: function (oEvent) {
                var selRowIndexPath = oEvent.getSource().getBindingContext("oSerialNosModel").getPath();
                oEvent.getSource().getModel("oSerialNosModel").getProperty(selRowIndexPath).BoxID_BoxID = "";
                this.getView().getModel("oSerialNosModel").refresh(true);
            },

            checkModifyPalletDuplicates: function () {
                var aBoxIds = this.getView().getModel("oSerialNosModel").getProperty("/aModPalletBoxIds");
                var aSortedBoxIds = [];

                for (let q of aBoxIds) {
                    if (q.BoxID_BoxID.trim() !== "") {
                        aSortedBoxIds.push(q.BoxID_BoxID.trim());
                    }
                }
                if (aSortedBoxIds.length > 0) {
                    aSortedBoxIds.sort((a, b) => (a.BoxID_BoxID > b.BoxID_BoxID) ? 1 : -1);
                    for (var i = 0; i < aSortedBoxIds.length - 1; i++) {
                        if (aSortedBoxIds[i + 1] === aSortedBoxIds[i]) {
                            this.mpSNError = "";
                            return true;
                        }
                    }

                } else {
                    this.mpSNError = "Please enter at least one Box ID";
                    return true;
                }
                this.comparePalletBoxes(aSortedBoxIds);
                
                return false;
            },

            comparePalletBoxes: function(aSortedBoxIds) {
                if (this.receivedBoxIds.length === 0) {
                    this.bBoxIDsChanged = true;
                } else {
                    this.aReceivedBoxIDs = [];
                    this.receivedBoxIds = JSON.parse(this.receivedBoxIds);

                    for (let d of this.receivedBoxIds) {
                        if (d.BoxID_BoxID !== "") {
                            this.aReceivedBoxIDs.push(d);
                        }
                    }
                    if (aSortedBoxIds.length !== this.aReceivedBoxIDs.length) {
                        this.bBoxIDsChanged = true;
                    } else {
                        this.checkBoxIDsChanged(aSortedBoxIds);
                    }
                    this.receivedBoxIds = JSON.stringify(this.receivedBoxIds);
                }
            },

            checkBoxIDsChanged: function (aSortedBoxIds) {
                var iCount = 0;

                for (let p of this.aReceivedBoxIDs) {
                    for (let r of aSortedBoxIds) {
                        if (p.BoxID_BoxID === r) {
                            iCount++;
                            break;
                        }
                    }
                }

                if (iCount === this.aReceivedBoxIDs.length) {
                    this.bBoxIDsChanged = false;
                } else {
                    this.bBoxIDsChanged = true;
                }
            },

            prepareMPBoxIdsPayload: function (aPalletBoxIDs, sBoxIds) {
                var oMPBoxIdsReturn = {
                    bAtleastOneBIDExists: false,
                    sBoxIds: ""
                };
                var bAtleastOneBIDExists = false;

                for (let f of aPalletBoxIDs) {
                    if (f.BoxID_BoxID.trim()) {
                        if (sBoxIds.length > 0) {
                            sBoxIds = sBoxIds + "," + f.BoxID_BoxID;
                        } else {
                            sBoxIds = f.BoxID_BoxID;
                        }
                        bAtleastOneBIDExists = true;
                    }

                }
                oMPBoxIdsReturn.bAtleastOneBIDExists = bAtleastOneBIDExists;
                oMPBoxIdsReturn.sBoxIds = sBoxIds;
                return oMPBoxIdsReturn;
            },

            completeModifyPallet: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (this.bBoxIDsChanged) {
                    var aValdAndPrint = this.getView().getModel("oValidAndPrintModel").getProperty("/aMPValidAndPrint");
                    var aMPBoxIdsPayload = [];

                    for (let x of aValdAndPrint) {
                        var oBoxId = {
                            BoxID_BoxID: x.BoxID_BoxID
                        };
                        aMPBoxIdsPayload.push(oBoxId);
                    }
                    var aModPalletCompletePayload = {
                        "Plant": this.getView().getModel("oGlobalModel").getProperty("/sModPalletPlant"),
                        "toPalletItems": aMPBoxIdsPayload
                    };

                    this.Palletmodel.update("/Pallets('" + this.getView().getModel("oGlobalModel").getProperty("/sPalletIdMod") + "')", aModPalletCompletePayload, {
                        success: function (data, oResponse) {
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.onModPalletPrintLabelPress_MC();
                            } else {
                                that.modPalletPrintLabels();
                            }
                        },
                        error: function (modPalletCompError) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            if (modPalletCompError.responseJSON) {
                                MessageBox.error(modPalletCompError.responseJSON.error.message);
                            } else {
                                MessageBox.error(modPalletCompError.responseText);
                            }
                        }
                    });

                } else {
                    if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                        that.onModPalletPrintLabelPress_MC();
                    } else {
                        that.modPalletPrintLabels();
                    }
                }

            },

            onCreatePalletIdCancel: function (sPalletSubTabSelKey) {
                if (sPalletSubTabSelKey === "genPalletId") {
                    this.setCreatePalletPlantsDefaults();
                    var oCreateContent = this.getView().byId("createPalletMainSub");
                    oCreateContent.removeAllItems(true);
                    this.getView().getModel("oGlobalModel").setProperty("/palletTabSelKey", "createPallet");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                    this.modifyBtnTxt();
                    this._destDialogPallet.open();
                } else if (sPalletSubTabSelKey === "scanPalletBoxID") {
                    this.footerButtonSettings("Create Pallet ID", "Cancel");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                } else if (sPalletSubTabSelKey === "valdAndPrint") {
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "scanPalletBoxID");
                }
            },

            onModifyPalletCancel: function (sPalletModSubTabSelKey) {
                if (sPalletModSubTabSelKey === "scanPalletId") {
                    this.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", "");
                } else if (sPalletModSubTabSelKey === "scanPalletBoxID") {
                    this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", true);
                    if (this.getView().getModel("oGlobalModel").getProperty("/bPalletModEdit")) {
                        this.footerButtonSettings("Next", "Cancel");
                        this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                        this.bNoPalletItems = false;
                    } else if (!this.getView().getModel("oGlobalModel").getProperty("/bPalletModEdit")) {
                        this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                        this.footerButtonSettings("Next", "Back");
                        this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", true);
                        this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletBoxID");
                    }
                    this.getView().getModel("oSerialNosModel").setProperty("/aModPalletBoxIds", JSON.parse(this.originalBoxIds));
                } else if (sPalletModSubTabSelKey === "valdAndPrint") {
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/bPalletModEdit", false);
                    this.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletBoxID");
                }
            },

            createPalletPrintLabels: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["PalletbatchDownload"]);
                var aPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aCPValidAndPrint");
                var iTotalBoxQty = 0;

                for (let k of aPrintLabelData) {
                    if (k.Quantity !== "" && k.Quantity !== null) {
                        iTotalBoxQty += k.Quantity;
                    } else {
                        k.Quantity = 0;
                    }
                }

                var iTotPrintLabCnt = aPrintLabelData.length;
                for (let q of aPrintLabelData) {
                    var tempCreatePalletPrintLab = {};
                    tempCreatePalletPrintLab.BoxQuantity = JSON.stringify(q.Quantity);
                    tempCreatePalletPrintLab.TotalBoxCount = JSON.stringify(iTotPrintLabCnt);
                    tempCreatePalletPrintLab.TotalBoxQuantity = JSON.stringify(iTotalBoxQty);
                    tempCreatePalletPrintLab.BoxID = q.BoxID_BoxID;
                    tempCreatePalletPrintLab.AcRfbPartNumber = q.AsIsPartNumber;
                    tempCreatePalletPrintLab.FgPartNumber = q.FinishedGoodsMPN;
                    tempCreatePalletPrintLab.Plant = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletPlantSelKey");
                    tempCreatePalletPrintLab.StorageLocation = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletStorageLocSelKey");
                    tempCreatePalletPrintLab.PalletID = this.getView().getModel("oGlobalModel").getProperty("/sCreatePalletId");
                    tempCreatePalletPrintLab.CountryOfOrigin = q.CountryOfOrigin;

                    this.ui5_ppModel.callFunction("/GeneratePalletManifest", {
                        method: "POST",
                        urlParameters: tempCreatePalletPrintLab,
                        batchGroupId: "PalletbatchDownload"
                    });

                }
                
                this.ui5_ppModel.submitChanges({
                    changeSetId: 2,
                    batchGroupId: "PalletbatchDownload",
                    success: function (oCPPData, oResponse) {
                        
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            var CreatePalletFileGUID = oCPPData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (CreatePalletFileGUID === "") {
                                MessageBox.error(oCPPData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl2 = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/PalletManifestPDFSet(GUID='${CreatePalletFileGUID}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl2);
                            }
                            that.footerButtonSettings("Create Pallet ID", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.setCreatePalletPlantsDefaults();
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oCPPData.__batchResponses[0].response.body).error.message.value);
                        }

                    },
                    error: function (oCPPError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.getView().getModel("oGlobalModel").setProperty("/palletSubTabSelKey", "genPalletId");
                        that.footerButtonSettings("Create Pallet ID", "Cancel");
                        MessageBox.error(JSON.parse(oCPPError.responseText).error.message.value);
                        that.setCreatePalletPlantsDefaults();
                    }
                });

            },

            modPalletPrintLabels: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["PalletbatchDownload"]);
                var aModPalletPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aMPValidAndPrint");

                var iTotalBoxQty1 = 0;

                for (let m of aModPalletPrintLabelData) {
                    if (m.Quantity !== "" && m.Quantity !== null) {
                        iTotalBoxQty1 += m.Quantity;
                    } else {
                        m.Quantity = 0;
                    }
                }

                var iTotModPalPrintLabCnt = aModPalletPrintLabelData.length;
                for (let i of aModPalletPrintLabelData) {
                    var tempModPalletPrintLab = {};
                    tempModPalletPrintLab.StorageLocation = this.getView().getModel("oGlobalModel").getProperty("/sModPalletStorageLoc");
                    tempModPalletPrintLab.PalletID = this.getView().getModel("oGlobalModel").getProperty("/sPalletIdMod");
                    tempModPalletPrintLab.BoxID = i.BoxID_BoxID;
                    tempModPalletPrintLab.AcRfbPartNumber = i.AsIsPartNumber;
                    tempModPalletPrintLab.BoxQuantity = JSON.stringify(i.Quantity);
                    tempModPalletPrintLab.TotalBoxCount = JSON.stringify(iTotModPalPrintLabCnt);
                    tempModPalletPrintLab.TotalBoxQuantity = JSON.stringify(iTotalBoxQty1);
                    tempModPalletPrintLab.FgPartNumber = i.FinishedGoodsMPN;
                    tempModPalletPrintLab.Plant = this.getView().getModel("oGlobalModel").getProperty("/sModPalletPlant");
                    tempModPalletPrintLab.CountryOfOrigin = i.CountryOfOrigin;

                    this.ui5_ppModel.callFunction("/GeneratePalletManifest", {
                        urlParameters: tempModPalletPrintLab,
                        batchGroupId: "PalletbatchDownload",
                        method: "POST"
                    });

                }

                this.ui5_ppModel.submitChanges({
                    changeSetId: 2,
                    batchGroupId: "PalletbatchDownload",
                    success: function (oMPPData, oResponse) {
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            var ModPalletFileGUID = oMPPData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (ModPalletFileGUID === "") {
                                MessageBox.error(oMPPData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl3 = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/PalletManifestPDFSet(GUID='${ModPalletFileGUID}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl3);
                            }
                            that.footerButtonSettings("Next", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", "");
                            that.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oMPPData.__batchResponses[0].response.body).error.message.value);
                        }
                        
                    },
                    error: function (oMPPError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oMPPError.responseText).error.message.value);
                        that.footerButtonSettings("Next", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/sPalletIdMod", "");
                        that.getView().getModel("oGlobalModel").setProperty("/palletModSubSelKey", "scanPalletId");
                    }
                });
            },

            setDestination: function (oDestName) {
                this.PalletMetadatamodel = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/metadata-service/`, this.gModelPalletConfig);
                this.getView().setModel(this.PalletMetadatamodel);
                if (oDestName === "SUBS") {
                    this.getView().getModel("oGlobalModel").setProperty("/bSubs", true);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bSubs", false);
                }
            },

            onDestSel: function () {
                this.sDestName = this.getView().getModel("oGlobalModel").getProperty("/sPalletDestSelKey");
                this.getView().getModel("oGlobalModel").setProperty("/sPackagingKey", this.sDestName);
                this.setDestination(this.sDestName);
                this.getView().getModel("oPalletDestModel").refresh(true);
                this._destDialogPallet.close();
                if (this.getView().byId("idCreatePallet").getSelectedKey() === "createPallet") {
                    var oCreateContent = this.getView().byId("createPalletMainSub");
                    oCreateContent.addItem(this.ofragPalletCreateSub);
                } else {
                    var oModifyContent = this.getView().byId("modifyPalletSub");
                    oModifyContent.addItem(this.ofragPalletModSub);
                }

                this.onCreatePalletTabSel();
            }
        });
    });