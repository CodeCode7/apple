sap.ui.define([
	"comapple.scp.ui./pallets/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
