sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/apple/scp/ui/manifestreport/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (UIComponent, models, JSONModel, MessageBox) {
    "use strict";

    return UIComponent.extend("com.apple.scp.ui.manifestreport.Component", {

        metadata: {
            manifest: "json"
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            // call the base component's init function
            if (window.parent.location.href.includes("epweb")) {
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                this.setModel(new JSONModel({
                    appId_ManifestReport: "",
                    appBusy: false
                }), "busyModel");

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
            } else {
                MessageBox.show(
                    "Please access ACSC from Enterprise Portal", {
                    icon: MessageBox.Icon.ERROR,
                    title: "Access From Enterprise Portal",
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });
            }
        }
    });
});
