sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/model/type/String",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageBox, typeString, Spreadsheet, exportLibrary) {
        "use strict";
        var EdmType = exportLibrary.EdmType;
        return Controller.extend("com.apple.scp.ui.manifestreport.controller.Main", {
            onInit: function () {
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {

                        this.gModelMRConfig = {
                            headers: { appid: variables },
                            defaultBindingMode: "TwoWay",
                            defaultCountMode: "Inline",
                            useBatch: true
                        };
                        this.Metadatamodel = new sap.ui.model.odata.v2.ODataModel("/ui5/v1/ac/metadata-service/", this.gModelMRConfig);

                        this.getPlants();
                    });
                this.initialSettings();
                this._oMultiInputBox = this.getView().byId("multiInputBoxId");
                this._oMultiInputPallet = this.getView().byId("multiInputPalletId");
                this._oMultiInputSN = this.getView().byId("multiInputSNs");
                this.getView().byId("DRS1").setMaxDate(new Date());
                this.getView().byId("DRS2").setMaxDate(new Date());
                this.oDateFormatUTC = sap.ui.core.format.DateFormat.getDateInstance({
                    pattern: "yyyy-MM-dd",
                    UTC: false
                });
            },

            initialSettings: function () {
                this.getView().setModel(new JSONModel({
                    sMRPlantSelKey: "",
                    aMRPlants: [],
                    dBCFromDate: null,
                    dBCToDate: null,
                    dPCFromDate: null,
                    dPCToDate: null,
                    aMRView: [{
                        view: "Header"
                    }, {
                        view: "Item"
                    }],
                    sMRViewSelKey: "Header",
                    aBoxHeaderData: [],
                    aPalletHeaderData: [],
                    aBoxItemData: [],
                    aPalletItemData: [],
                    aItemData: [],
                    aSNItemData: [],
                    aHeaderData: [],
                    sDisplayTable: "BH",
                    aConfigVals: []
                }), "oGlobalModel");
                this.getView().getModel("oGlobalModel").setSizeLimit(40000);
            },

            getPlants: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.Metadatamodel.read("/Plants", {
                    success: function (oData) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGlobalModel").setProperty("/aMRPlants", oData.results);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });

            },

            onBoxIdValueHelpRequested: function () {
                this._oBoxValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                    "com.apple.scp.ui.manifestreport.fragment.ManifestReport.BoxIdValueHelpDialog", this);
                this.getView().addDependent(this._oBoxValueHelpDialog);
                this._oBoxValueHelpDialog.setRangeKeyFields([{
                    label: "Box ID",
                    key: "BoxID",
                    type: "Integer",
                    typeInstance: new typeString({}, {
                        maxLength: 20
                    })
                }]);

                this._oBoxValueHelpDialog.setTokens(this._oMultiInputBox.getTokens());
                this._oBoxValueHelpDialog.open();
            },

            onBoxIdValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this._oMultiInputBox.setTokens(aTokens);
                this._oBoxValueHelpDialog.close();
            },

            onBoxIdValueHelpCancelPress: function () {
                this._oBoxValueHelpDialog.close();
            },

            onBoxIdValueHelpAfterClose: function () {
                this._oBoxValueHelpDialog.destroy();
            },

            onPalletIdValueHelpRequested: function () {
                this._oPalletValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                    "com.apple.scp.ui.manifestreport.fragment.ManifestReport.PalletIdValueHelpDialog", this);
                this.getView().addDependent(this._oPalletValueHelpDialog);
                this._oPalletValueHelpDialog.setRangeKeyFields([{
                    label: "Pallet ID",
                    key: "PalletID",
                    type: "Integer",
                    typeInstance: new typeString({}, {
                        maxLength: 20
                    })
                }]);

                this._oPalletValueHelpDialog.setTokens(this._oMultiInputPallet.getTokens());
                this._oPalletValueHelpDialog.open();
            },

            onPalletIdValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this._oMultiInputPallet.setTokens(aTokens);
                this._oPalletValueHelpDialog.close();
            },

            onPalletIdValueHelpCancelPress: function () {
                this._oPalletValueHelpDialog.close();
            },

            onPalletIdValueHelpAfterClose: function () {
                this._oPalletValueHelpDialog.destroy();
            },

            onSNValueHelpRequested: function () {
                this._oSNValueHelpDialog = sap.ui.xmlfragment(this.getView().getId(),
                    "com.apple.scp.ui.manifestreport.fragment.ManifestReport.SNValueHelpDialog", this);
                this.getView().addDependent(this._oSNValueHelpDialog);
                this._oSNValueHelpDialog.setRangeKeyFields([{
                    label: "Serial Number",
                    key: "Serial Number",
                    type: "Integer",
                    typeInstance: new typeString({}, {
                        maxLength: 20
                    })
                }]);

                this._oSNValueHelpDialog.setTokens(this._oMultiInputSN.getTokens());
                this._oSNValueHelpDialog.open();
            },

            onSNValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this._oMultiInputSN.setTokens(aTokens);
                this._oSNValueHelpDialog.close();
            },

            onSNValueHelpCancelPress: function () {
                this._oSNValueHelpDialog.close();
            },

            onSNValueHelpAfterClose: function () {
                this._oSNValueHelpDialog.destroy();
            },

            onClearPress: function () {
                var aPlants = this.getView().getModel("oGlobalModel").getProperty("/aMRPlants");
                var sPlant = "";
                if (aPlants.length > 0) {
                    sPlant = aPlants[0].Plant;
                }
                this.getView().setModel(new JSONModel({
                    sMRPlantSelKey: sPlant,
                    dBCFromDate: null,
                    dBCToDate: null,
                    dPCFromDate: null,
                    dPCToDate: null,
                    sMRViewSelKey: "Header",
                    aHeaderData: [],
                    aItemData: []
                }), "clearModel");
                this._oMultiInputPallet.setTokens([]);
                this._oMultiInputBox.setTokens([]);
                Object.assign(this.getView().getModel("oGlobalModel").getData(), this.getView().getModel("clearModel").getData());
                this.getView().getModel("oGlobalModel").setProperty("/sDisplayTable", "BH");
                this.getView().getModel("oGlobalModel").refresh(true);
            },

            onReportSel: function (oEvent) {
                if (oEvent.getSource().getSelectedKey() === "manifestReport") {
                    this.onClearPress();
                } else {
                    this.onSNClearPress();
                }
            },

            onSNClearPress: function () {
                this._oMultiInputSN.setTokens([]);
                this.getView().getModel("oGlobalModel").setProperty("/aSNItemData", []);
                this.getView().getModel("oGlobalModel").refresh(true);
            },

            onSearchPress: function () {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var bBoxFilter = false;
                var bPalletFilter = false;
                var aFinalFilter = [];
                var bBoxDateFilter = false;
                var bPalletDateFilter = false;
                var sPlant1 = this.getView().getModel("oGlobalModel").getProperty("/sMRPlantSelKey");
                var dBCFromDate = this.getView().getModel("oGlobalModel").getProperty("/dBCFromDate");
                var dBCToDate = this.getView().getModel("oGlobalModel").getProperty("/dBCToDate");
                var dPCFromDate = this.getView().getModel("oGlobalModel").getProperty("/dPCFromDate");
                var dPCToDate = this.getView().getModel("oGlobalModel").getProperty("/dPCToDate");


                if (!this.ValidateMRFilters(sPlant1)) {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                    return;
                } else {
                    this.ManifestReportmodel = new sap.ui.model.odata.v2.ODataModel("/ui5/v1/ac/manifest-report-service/", this.gModelMRConfig);

                    aFinalFilter.push(new sap.ui.model.Filter("PLANT", sap.ui.model.FilterOperator.EQ, sPlant1));

                    if (this._oMultiInputBox.getTokens().length > 0) {
                        aFinalFilter = this.setBoxTokens(aFinalFilter);
                        bBoxFilter = true;
                    } else if (this._oMultiInputPallet.getTokens().length > 0) {
                        aFinalFilter = this.setPalletTokens(aFinalFilter);
                        bPalletFilter = true;
                    }

                    if (dBCFromDate !== null && dBCToDate !== null) {
                        bBoxDateFilter = true;
                        dBCFromDate = this.oDateFormatUTC.format(dBCFromDate);
                        dBCToDate = this.oDateFormatUTC.format(dBCToDate);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXCREATEDATE", sap.ui.model.FilterOperator.BT, dBCFromDate + "T00:00:00.000Z", dBCToDate + "T23:59:59.000Z"));

                    } else if (dPCFromDate !== null && dPCToDate !== null) {
                        bPalletDateFilter = true;
                        dPCFromDate = this.oDateFormatUTC.format(dPCFromDate);
                        dPCToDate = this.oDateFormatUTC.format(dPCToDate);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETCREATEDATE", sap.ui.model.FilterOperator.BT, dPCFromDate + "T00:00:00.000Z", dPCToDate + "T23:59:59.000Z"));
                    }
                    this.getView().getModel("oGlobalModel").setProperty("/aItemData", []);
                    this.getView().getModel("oGlobalModel").setProperty("/aHeaderData", []);

                    if (bBoxFilter || bBoxDateFilter) {
                        this.fetchBoxesData(aFinalFilter);
                    } else if (bPalletFilter || bPalletDateFilter) {
                        this.fetchPalletsData(aFinalFilter);
                    } else {
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                }


            },

            setBoxTokens: function (aFinalFilter) {
                var aBoxTokens = this._oMultiInputBox.getTokens();
                var aBoxBetween = [];
                for (var b of aBoxTokens) {
                    var sBoxText = b.getText();
                    if (sBoxText.includes('!(=')) {
                        sBoxText = sBoxText.substring(3);
                        sBoxText = sBoxText.substring(0, sBoxText.length - 1);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.NE, sBoxText));
                    }

                    if (sBoxText.includes('...')) {
                        aBoxBetween = sBoxText.split("...");
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.BT, aBoxBetween[0], aBoxBetween[1]));
                    }

                    if (sBoxText.includes('<=')) {
                        sBoxText = sBoxText.substring(2);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.LE, sBoxText));
                    }
                    if (sBoxText.includes('>=')) {
                        sBoxText = sBoxText.substring(2);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.GE, sBoxText));
                    }

                    if (sBoxText.includes('=')) {
                        sBoxText = sBoxText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.EQ, sBoxText));
                    }

                    if (sBoxText.includes('>')) {
                        sBoxText = sBoxText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.GT, sBoxText));
                    }
                    if (sBoxText.includes('<')) {
                        sBoxText = sBoxText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("BOXID", sap.ui.model.FilterOperator.LT, sBoxText));
                    }


                }
                return aFinalFilter;
            },

            setPalletTokens: function (aFinalFilter) {
                var aPalletTokens = this._oMultiInputPallet.getTokens();
                var aPalletBetween = [];
                for (var p of aPalletTokens) {
                    var sPalletText = p.getText();
                    if (sPalletText.includes('!=')) {
                        sPalletText = sPalletText.substring(3);
                        sPalletText = sPalletText.substring(0, sPalletText.length - 1);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.NE, sPalletText));
                    }

                    if (sPalletText.includes('...')) {
                        aPalletBetween = sPalletText.split("...");
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.BT, aPalletBetween[0], aPalletBetween[1]));
                    }

                    if (sPalletText.includes('<=')) {
                        sPalletText = sPalletText.substring(2);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.LE, sPalletText));
                    }
                    if (sPalletText.includes('>=')) {
                        sPalletText = sPalletText.substring(2);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.GE, sPalletText));
                    }

                    if (sPalletText.includes('=')) {
                        sPalletText = sPalletText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.EQ, sPalletText));
                    }

                    if (sPalletText.includes('>')) {
                        sPalletText = sPalletText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.GT, sPalletText));
                    }
                    if (sPalletText.includes('<')) {
                        sPalletText = sPalletText.substring(1);
                        aFinalFilter.push(new sap.ui.model.Filter("PALLETID", sap.ui.model.FilterOperator.LT, sPalletText));
                    }


                }
                return aFinalFilter;
            },

            fetchBoxesData: function (aFinalFilter) {
                if (this.getView().getModel("oGlobalModel").getProperty("/sMRViewSelKey") === "Item") {
                    this.getView().getModel("oGlobalModel").setProperty("/sDisplayTable", "BI");
                    this.callBoxItems(aFinalFilter);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/sDisplayTable", "BH");
                    this.callBoxHeaders(aFinalFilter);
                }
            },

            fetchPalletsData: function (aFinalFilter) {
                if (this.getView().getModel("oGlobalModel").getProperty("/sMRViewSelKey") === "Item") {
                    this.getView().getModel("oGlobalModel").setProperty("/sDisplayTable", "PI");
                    this.callPalletItems(aFinalFilter);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/sDisplayTable", "PH");
                    this.callPalletHeaders(aFinalFilter);
                }
            },

            onSNSearchPress: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aSNFinalFilter = [];

                if (this._oMultiInputSN.getTokens().length > 0) {
                    aSNFinalFilter = this.setSNTokens(aSNFinalFilter);

                } else {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                    MessageBox.error("Please input at least one Serial Number");
                    return;
                }
                this.ManifestReportmodel = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/manifest-report-service/`, this.gModelMRConfig);
                this.ManifestReportmodel.read("/ManifestSerialNumberDetails", {
                    filters: aSNFinalFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGlobalModel").setProperty("/aSNItemData", oData.results);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aSNItemData", []);
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (snItemsError1) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (JSON.parse(snItemsError1.responseText).fault !== undefined) {
                            if ((JSON.parse(snItemsError1.responseText).fault.detail.errorcode).includes("protocol.http.TooBigBody")) {
                                MessageBox.error("Too Many records to display. Could you please refine the search criteria");
                            }
                        } else {
                            MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
                        }
                    }
                });
            },

            setSNTokens: function (aSNFinalFilter) {
                var aSNTokens = this._oMultiInputSN.getTokens();
                var aSNBetween = [];
                for (var b of aSNTokens) {
                    var sSNText = b.getText();
                    if (sSNText.includes('!(=')) {
                        sSNText = sSNText.substring(3);
                        sSNText = sSNText.substring(0, sSNText.length - 1);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.NE, sSNText));
                    }

                    if (sSNText.includes('...')) {
                        aSNBetween = sSNText.split("...");
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.BT, aSNBetween[0], aSNBetween[1]));
                    }

                    if (sSNText.includes('<=')) {
                        sSNText = sSNText.substring(2);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.LE, sSNText));
                    }
                    if (sSNText.includes('>=')) {
                        sSNText = sSNText.substring(2);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.GE, sSNText));
                    }

                    if (sSNText.includes('=')) {
                        sSNText = sSNText.substring(1);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.EQ, sSNText));
                    }

                    if (sSNText.includes('>')) {
                        sSNText = sSNText.substring(1);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.GT, sSNText));
                    }
                    if (sSNText.includes('<')) {
                        sSNText = sSNText.substring(1);
                        aSNFinalFilter.push(new sap.ui.model.Filter("SERIALNUMBER", sap.ui.model.FilterOperator.LT, sSNText));
                    }

                }
                return aSNFinalFilter;
            },

            callBoxItems: function (aBIFinalFilter) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ManifestReportmodel.read("/ManifestItemReportByBox", {
                    filters: aBIFinalFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGlobalModel").setProperty("/aItemData", oData.results);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aItemData", []);
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (boxItemsError1) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (JSON.parse(boxItemsError1.responseText).fault !== undefined) {
                            if ((JSON.parse(boxItemsError1.responseText).fault.detail.errorcode).includes("protocol.http.TooBigBody")) {
                                MessageBox.error("Too Many records to display. Could you please refine the search criteria");
                            }
                        } else {
                            MessageBox.error(JSON.parse(boxItemsError1.responseText).error.message.value);
                        }
                    }
                });

            },

            callPalletItems: function (aPIFinalFilter) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ManifestReportmodel.read("/ManifestItemReportByPallet", {
                    filters: aPIFinalFilter,
                    success: function (palletItems) {
                        if (palletItems.results.length > 0) {
                            that.getView().getModel("oGlobalModel").setProperty("/aItemData", palletItems.results);

                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aItemData", []);
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (palletItemsError1) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (JSON.parse(palletItemsError1.responseText).fault !== undefined) {
                            if ((JSON.parse(palletItemsError1.responseText).fault.detail.errorcode).includes("protocol.http.TooBigBody")) {
                                MessageBox.error("Too Many records to display. Could you please refine the search criteria");
                            }
                        } else {
                            MessageBox.error(JSON.parse(palletItemsError1.responseText).error.message.value);
                        }
                    }
                });

            },

            callBoxHeaders: function (aBHFinalFilter) {
                var that = this;
                var aAsIsFGHBData = [];
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ManifestReportmodel.read("/ManifestHeaderReportByBox", {
                    filters: aBHFinalFilter,
                    success: function (boxHeaders2) {
                        if (boxHeaders2.results.length > 0) {
                            aAsIsFGHBData = boxHeaders2.results;
                            for (var z of aAsIsFGHBData) {
                                if (z.STORAGEBIN_FG !== null) {
                                    z.STORAGEBIN = z.STORAGEBIN_FG;
                                } else {
                                    z.STORAGEBIN = z.STORAGEBIN_ASIS;
                                }
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/aHeaderData", aAsIsFGHBData);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aHeaderData", []);
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (boxError2) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (JSON.parse(boxError2.responseText).fault !== undefined) {
                            if ((JSON.parse(boxError2.responseText).fault.detail.errorcode).includes("protocol.http.TooBigBody")) {
                                MessageBox.error("Too Many records to display. Could you please refine the search criteria");
                            }
                        } else {
                            MessageBox.error(JSON.parse(boxError2.responseText).error.message.value);
                        }
                    }
                });

            },

            callPalletHeaders: function (aPHFinalFilter) {
                var that = this;
                var aAsIsFGHPData = [];
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ManifestReportmodel.read("/ManifestHeaderReportByPallet", {
                    filters: aPHFinalFilter,
                    success: function (palletHeaders1) {
                        if (palletHeaders1.results.length > 0) {

                            aAsIsFGHPData = palletHeaders1.results;
                            for (var y of aAsIsFGHPData) {
                                if (y.STORAGEBIN_FG !== null) {
                                    y.STORAGEBIN = y.STORAGEBIN_FG;
                                } else {
                                    y.STORAGEBIN = y.STORAGEBIN_ASIS;
                                }
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/aHeaderData", aAsIsFGHPData);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aHeaderData", []);
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (palletError1) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        if (JSON.parse(palletError1.responseText).fault !== undefined) {
                            if ((JSON.parse(palletError1.responseText).fault.detail.errorcode).includes("protocol.http.TooBigBody")) {
                                MessageBox.error("Too Many records to display. Could you please refine the search criteria");
                            }
                        } else {
                            MessageBox.error(JSON.parse(palletError1.responseText).error.message.value);
                        }
                    }
                });

            },

            ValidateMRFilters: function (sPlant1) {
                if (sPlant1 === "") {
                    MessageBox.error("Plant cannot be blank");
                    return false;
                }
                if (this._oMultiInputBox.getTokens().length === 0 && this._oMultiInputPallet.getTokens().length === 0
                    && this.getView().getModel("oGlobalModel").getProperty("/dBCFromDate") === null && this.getView().getModel("oGlobalModel").getProperty("/dBCToDate") === null
                    && this.getView().getModel("oGlobalModel").getProperty("/dPCFromDate") === null && this.getView().getModel("oGlobalModel").getProperty("/dPCToDate") === null) {
                    MessageBox.error("Please enter Box/Pallet ID or Date Range");
                    return false;
                } else if ((this.getView().getModel("oGlobalModel").getProperty("/dBCFromDate") === null && this.getView().getModel("oGlobalModel").getProperty("/dBCToDate") !== null)
                    || (this.getView().getModel("oGlobalModel").getProperty("/dBCFromDate") !== null && this.getView().getModel("oGlobalModel").getProperty("/dBCToDate") === null)) {
                    MessageBox.error("Please enter complete Box Created Date Range");
                    return false;
                } else if ((this.getView().getModel("oGlobalModel").getProperty("/dPCFromDate") === null && this.getView().getModel("oGlobalModel").getProperty("/dPCToDate") !== null)
                    || (this.getView().getModel("oGlobalModel").getProperty("/dPCFromDate") !== null && this.getView().getModel("oGlobalModel").getProperty("/dPCToDate") === null)) {
                    MessageBox.error("Please enter complete Pallet Created Date Range");
                    return false;
                } else {
                    return true;
                }
            },

            onExportToExcelPress: function () {
                var sDispTable = this.getView().getModel("oGlobalModel").getProperty("/sDisplayTable");
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                switch (sDispTable) {
                    case "BH":
                    case "PH":
                        if (this.getView().getModel("oGlobalModel").getProperty("/aHeaderData").length > 0) {
                            this.exportTableData("headerData", "H");
                        } else {
                            MessageBox.error("No Data to export");
                        }
                        break;
                    case "BI":
                    case "PI":
                        if (this.getView().getModel("oGlobalModel").getProperty("/aItemData").length > 0) {
                            this.exportTableData("itemData", "I");
                        } else {
                            MessageBox.error("No Data to export");
                        }
                        break;
                    default:
                        break;
                }
            },

            onSNExportToExcelPress: function () {
                if (this.getView().getModel("oGlobalModel").getProperty("/aSNItemData").length > 0) {
                    this.exportTableData("snItemData", "I");
                } else {
                    MessageBox.error("No Data to export");
                }
            },

            createHeaderColumnConfig: function () {
                var aCols1 = [];

                aCols1.push({
                    property: 'PALLETID',
                    label: 'Pallet ID',
                    type: EdmType.String
                });

                aCols1.push({
                    type: EdmType.String,
                    label: 'Box ID',
                    property: 'BOXID'
                });

                aCols1.push({
                    property: 'ASISPARTNUMBER',
                    label: 'AS IS PN',
                    type: EdmType.String
                });

                aCols1.push({
                    property: 'FINISHEDGOODSMPN',
                    label: 'FG MPN',
                    type: EdmType.String
                });

                aCols1.push({
                    property: 'SSCC18',
                    label: 'SSCC18',
                    type: EdmType.String
                });

                aCols1.push({
                    type: EdmType.String,
                    label: 'Bin Location',
                    property: 'STORAGEBIN'
                });

                aCols1.push({
                    property: 'QUANTITY',
                    label: 'Box Qty',
                    type: EdmType.String
                });

                aCols1.push({
                    property: 'SHIPMENTNUMBER',
                    label: 'Shipment Number',
                    type: EdmType.String
                });

                return aCols1;
            },

            createItemColumnConfig: function () {
                var aCols = [];

                aCols.push({
                    label: 'Pallet ID',
                    property: 'PALLETID',
                    type: EdmType.String
                });

                aCols.push({
                    label: 'Box ID',
                    type: EdmType.String,
                    property: 'BOXID'
                });

                aCols.push({
                    label: 'AS IS PN',
                    property: 'ASISPARTNUMBER',
                    type: EdmType.String
                });

                aCols.push({
                    label: 'FG MPN',
                    property: 'FGMPN',
                    type: EdmType.String
                });

                aCols.push({
                    label: 'Serial No.',
                    property: 'SERIALNUMBER',
                    type: EdmType.String
                });

                aCols.push({
                    label: 'Position',
                    property: 'BOXSEQUENCE',
                    type: EdmType.Number
                });

                aCols.push({
                    label: 'IMEI 1',
                    property: 'IMEI1',
                    type: EdmType.String
                });

                aCols.push({
                    label: 'IMEI 2',
                    property: 'IMEI2',
                    type: EdmType.String
                });

                return aCols;
            },

            exportTableData: function (id, view) {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aCols, oRowBinding, oSettings, oSheet, oTable;

                oTable = this.getView().byId(id);
                oRowBinding = oTable.getBinding('rows');
                if (view === "I") {
                    aCols = this.createItemColumnConfig();
                } else {
                    aCols = this.createHeaderColumnConfig();
                }

                var sFileName = "";
                if (id === "snItemData") {
                    sFileName = "Serail Number Items Report.xlsx";
                } else {
                    sFileName = "Manifest Report.xlsx"
                }

                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: 'Level'
                    },
                    dataSource: oRowBinding,
                    fileName: sFileName,
                    worker: false
                };

                oSheet = new Spreadsheet(oSettings);
                this.getView().getModel("busyModel").setProperty("/appBusy", false);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },

        });
    });