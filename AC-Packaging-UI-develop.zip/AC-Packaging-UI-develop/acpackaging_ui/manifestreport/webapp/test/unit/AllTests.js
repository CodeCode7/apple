sap.ui.define([
	"comapple.scp.ui./manifestreport/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
