sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageBox) {
        "use strict";

        return Controller.extend("com.apple.scp.ui.admin.controller.Main", {
            onInit: function () {
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        let gModelConfig = {
                            headers: { appid: variables },
                            defaultBindingMode: "TwoWay",
                            defaultCountMode: "Inline",
                            useBatch: true
                        };
                        this.Admin_model = new sap.ui.model.odata.v2.ODataModel("/ui5/v1/ac/admin-service/", gModelConfig);
                        this.onAdminPress();
                    });
                this.getView().setModel(new JSONModel({
                    aNumberRanges: [],
                    aConfigValues: [],
                    aNewNumberRange: [],
                    aUpdateNumberRange: [],
                    aNewConfigVals: [],
                    aUpdateConfigVals: []
                }), "oAdminModel");
                this.getView().setModel(this.Admin_model);
                this.oAddNumberRangesBtn = this.byId("addNumRange");
                this.oEditNumberRangesBtn = this.byId("editNumRange");
                this.editConfigValsBtn = this.byId("editConfigVals");
                this.addConfigValsBtn = this.byId("addConfigVals");
                this.initialSettings();
            },

            initialSettings: function () {
                this.getView().setModel(new JSONModel({
                    adminTabSelKey: "numberRange",
                    sNumberRangeType: "",
                    aNumberRangesTypes: [],
                    aEntitySets: [{
                        sEntitySet: "NumberRanges"
                    }, {
                        sEntitySet: "ConfigValues"
                    }],
                    sEntitySetSelKey: "NumberRanges",
                    sInitialFields: "Plant,Type,StartingNumber,MaxNumber,CurrentNumber"
                }), "oGlobalModel");
                this.getView().getModel("oGlobalModel").setProperty("/sNumberRangeType", "");
                this._userModel = new JSONModel();
                var that = this;
                let me = this;
                fetch("/getUserInfo")
                    .then(res => res.json())
                    .then(data => {
                        me._userModel.setProperty("/", data);
                        var oToken = me._userModel.getProperty("/");
                        for (var i in oToken.decodedJWTToken) {
                            if (oToken.decodedJWTToken[i].includes("Admin")) {
                                that.oAddNumberRangesBtn.setVisible(true);
                                that.oEditNumberRangesBtn.setVisible(true);
                                that.editConfigValsBtn.setVisible(true);
                                that.addConfigValsBtn.setVisible(true);
                            }
                        }

                    })
                    .catch();
            },
            onAdminPress: function () {
                this.getView().getModel("oGlobalModel").setProperty("/adminTabSelKey", "numberRange");
                this.getAdminDetails();
                this.getNumberRangeTypes();
            },

            onAdminTabSel: function () {
                this.getAdminDetails();
            },
            getNumberRangeTypes: function () {
                this.getView().getModel("oGlobalModel").setProperty("/aNumberRangesTypes", []);
                var that = this;
                this.Admin_model.read("/getNumberRangeTypes", {
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGlobalModel").setProperty("/aNumberRangesTypes", oData.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sNumberRangeType", oData.results[0].type);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/aNumberRangesTypes", []);
                            that.getView().getModel("oGlobalModel").setProperty("/sNumberRangeType", "");
                        }

                    },
                    error: function (oError) {
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });
            },

            getAdminDetails: function () {
                if (this.getView().getModel("oGlobalModel").getProperty("/adminTabSelKey") === "numberRange") {
                    this.getNumberRanges();
                    this.getView().getModel("oGlobalModel").setProperty("/adminTabSelKey", "numberRange");
                } else if (this.getView().getModel("oGlobalModel").getProperty("/adminTabSelKey") === "configVal") {
                    this.getConfigValues();
                    this.getView().getModel("oGlobalModel").setProperty("/adminTabSelKey", "configVal");
                }

            },

            getNumberRanges: function () {
                var that = this;
                this.Admin_model.read("/NumberRanges", {
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oAdminModel").setProperty("/aNumberRanges", oData.results);
                        }
                    },
                    error: function (oError) {
                        console.log(oError);
                    }
                });
            },

            getConfigValues: function () {
                var that = this;
                that.Admin_model.read("/ConfigValues", {
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oAdminModel").setProperty("/aConfigValues", oData.results);
                        }
                    },
                    error: function (oError) {
                        console.log(oError);
                    }
                });

            },

            onAddNewNumRangeRow: function () {
                var aNumRanges = this.getView().getModel("oAdminModel").getProperty("/aNewNumberRange");
                var aBoxTypes = this.getView().getModel("oGlobalModel").getProperty("/aNumberRangesTypes");
                this.getView().getModel("oGlobalModel").setProperty("/sNumberRangeType", aBoxTypes[0].type);
                var sBoxType = this.getView().getModel("oGlobalModel").getProperty("/sNumberRangeType");
                aNumRanges.push({
                    "Plant": "",
                    "Type": sBoxType
                });
                this.getView().getModel("oAdminModel").setProperty("/aNewNumberRange", aNumRanges);
                this.getView().getModel("oAdminModel").refresh(true);
            },

            onAddNewConfigValRow: function () {
                var aConfigVals = this.getView().getModel("oAdminModel").getProperty("/aNewConfigVals");
                aConfigVals.push({
                    "Name": "",
                    "Value": ""
                });
                this.getView().getModel("oAdminModel").setProperty("/aNewConfigVals", aConfigVals);
                this.getView().getModel("oAdminModel").refresh(true);
            },

            onAddConfigVals: function () {
                if (!this._addNewConfigValFrg) {
                    this._addNewConfigValFrg = sap.ui.xmlfragment(this.getView().getId(),
                        "com.apple.scp.ui.admin.fragment.Admin.AddConfigValues", this);
                    this.getView().addDependent(this._addNewConfigValFrg);
                }
                this.getView().getModel("oAdminModel").setProperty("/aNewConfigVals", []);
                this._addNewConfigValFrg.open();
                this.onAddNewConfigValRow();
            },

            onNewConfigValCancel: function () {
                this.getView().byId("configValTbl").removeSelections();
                this._addNewConfigValFrg.close();
            },

            onAddNewNumRange: function () {
                if (!this._addNewNumRagenFrg) {
                    this._addNewNumRagenFrg = sap.ui.xmlfragment(this.getView().getId(),
                        "com.apple.scp.ui.admin.fragment.Admin.AddNewNumberRange", this);
                    this.getView().addDependent(this._addNewNumRagenFrg);
                }
                this.getView().getModel("oAdminModel").setProperty("/aNewNumberRange", []);
                this._addNewNumRagenFrg.open();
                this.onAddNewNumRangeRow();
            },

            onEditNumRange: function () {
                var aSelRowsPath = this.getView().byId("numRangeTbl").getSelectedContextPaths();
                if (aSelRowsPath.length > 0) {
                    if (!this._updateNumRagenFrg) {
                        this._updateNumRagenFrg = sap.ui.xmlfragment(this.getView().getId(),
                            "com.apple.scp.ui.admin.fragment.Admin.UpdateNumberRange", this);
                        this.getView().addDependent(this._updateNumRagenFrg);
                    }
                    var aSelRows = [];
                    for (var a of aSelRowsPath) {
                        aSelRows.push(this.getView().getModel("oAdminModel").getProperty(a));
                    }
                    this.getView().getModel("oAdminModel").setProperty("/aUpdateNumberRange", aSelRows);
                    this._updateNumRagenFrg.open();
                } else {
                    sap.m.MessageBox.error("Please select at least one row to update");
                }


            },

            onEditConfigVals: function () {
                var aSelRowsPath = this.getView().byId("configValTbl").getSelectedContextPaths();
                if (aSelRowsPath.length > 0) {
                    if (!this._updateConfigValsFrg) {
                        this._updateConfigValsFrg = sap.ui.xmlfragment(this.getView().getId(),
                            "com.apple.scp.ui.admin.fragment.Admin.UpdateConfigVals", this);
                        this.getView().addDependent(this._updateConfigValsFrg);
                    }
                    var aSelRows = [];
                    for (var a of aSelRowsPath) {
                        aSelRows.push(this.getView().getModel("oAdminModel").getProperty(a));
                    }
                    this.getView().getModel("oAdminModel").setProperty("/aUpdateConfigVals", aSelRows);
                    this._updateConfigValsFrg.open();
                } else {
                    sap.m.MessageBox.error("Please select at least one row to update");
                }
            },

            onNewNumRangeCancel: function () {
                this.getView().byId("numRangeTbl").removeSelections();
                this._addNewNumRagenFrg.close();
            },

            onNumRangeUpdateCancel: function () {
                this.getView().byId("numRangeTbl").removeSelections();
                this._updateNumRagenFrg.close();
            },

            onNewNumRangeSave: function () {
                var that = this;
                var aNewNumRangePayload = this.getView().getModel("oAdminModel").getProperty("/aNewNumberRange");
                if (aNewNumRangePayload[0].Plant === "") {
                    MessageBox.error("Plant cannot be blank");
                    return;
                } else if (this.getView().getModel("oGlobalModel").getProperty("/sNumberRangeType") === "") {
                    MessageBox.error("Type cannot be blank");
                    return;
                }
                var oNewNumRanges = {};
                for (var b of aNewNumRangePayload) {
                    oNewNumRanges = {
                        "Plant": b.Plant,
                        "Type": this.getView().getModel("oGlobalModel").getProperty("/sNumberRangeType"),
                        "StartingNumber": parseInt(b.StartingNumber, 10),
                        "MaxNumber": parseInt(b.MaxNumber, 10),
                        "CurrentNumber": parseInt(b.CurrentNumber, 10)

                    };
                }
                this.Admin_model.create("/NumberRanges", oNewNumRanges, {
                    success: function () {
                        that.onNewNumRangeCancel();
                        that.getAdminDetails();
                    },
                    error: function (error) {
                        that.onNewNumRangeCancel();
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });

            },

            onNumRangeUpdate: function () {
                var that = this;
                var aUpdateNumRangePayload = this.getView().getModel("oAdminModel").getProperty("/aUpdateNumberRange");
                if (aUpdateNumRangePayload[0].Plant === "") {
                    MessageBox.error("Plant cannot be blank");
                    return;
                } else if (aUpdateNumRangePayload[0].Type === "") {
                    MessageBox.error("Type cannot be blank");
                    return;
                }
                
                var oEditedNumRanges = this.prepareEditNumPayload(aUpdateNumRangePayload);
                var updatekey = "Plant='" + aUpdateNumRangePayload[0].Plant + "',Type='" + aUpdateNumRangePayload[0].Type + "'";

                that.Admin_model.update("/NumberRanges(" + updatekey + ")", oEditedNumRanges, {
                    success: function () {
                        that.onNumRangeUpdateCancel();
                        that.getAdminDetails();
                    },
                    error: function (error) {
                        that.onNumRangeUpdateCancel();
                        if (error.statusText) {
                            sap.m.MessageBox.error(error.statusText);
                        } else if (error.responseJSON.error.message) {
                            sap.m.MessageBox.error(error.responseJSON.error.message);
                        }
                    }
                });

            },

            prepareEditNumPayload: function(aUpdateNumRangePayload) {
                var oEditedNumRanges = {};
                for (var x of aUpdateNumRangePayload) {
                    if (x.StartingNumber === "" || x.StartingNumber === null) {
                        x.StartingNumber = 0;
                    } else {
                        x.StartingNumber = parseInt(x.StartingNumber);
                    }

                    if (x.MaxNumber === "" || x.MaxNumber === null) {
                        x.MaxNumber = 0;
                    } else {
                        x.MaxNumber = parseInt(x.MaxNumber);
                    }

                    if (x.CurrentNumber === "" || x.CurrentNumber === null) {
                        x.CurrentNumber = 0;
                    } else {
                        x.CurrentNumber = parseInt(x.CurrentNumber);
                    }
                    oEditedNumRanges = {
                        "Plant": x.Plant,
                        "Type": x.Type,
                        "StartingNumber": x.StartingNumber,
                        "MaxNumber": x.MaxNumber,
                        "CurrentNumber": x.CurrentNumber
                    };
                }
                return oEditedNumRanges;
            },

            onConfigValsUpdate: function() {
                var that = this;
                var aUpdateConfigValsPayload = this.getView().getModel("oAdminModel").getProperty("/aUpdateConfigVals");
                if (aUpdateConfigValsPayload[0].Name === "") {
                    MessageBox.error("Name cannot be blank");
                    return;
                }
                var oEditedConfigVals = {}
;                for (var j of aUpdateConfigValsPayload) {
                    oEditedConfigVals = {
                        "Name": j.Name,
                        "Value": j.Value
                    };
                    }
    
                    this.Admin_model.update("/ConfigValues('" + aUpdateConfigValsPayload[0].Name + "')", oEditedConfigVals, {
                    success: function () {
                        that.onConfigValsUpdateCancel();
                        that.getAdminDetails();
                    },
                    error: function (error) {
                        that.onConfigValsUpdateCancel();
                        if (error.statusText) {
                            sap.m.MessageBox.error(error.statusText);
                        } else if (error.responseJSON.error.message) {
                            sap.m.MessageBox.error(error.responseJSON.error.message);
                        }
                    }
                });

            },

            onConfigValsUpdateCancel: function () {
                this.getView().byId("configValTbl").removeSelections();
                this._updateConfigValsFrg.close();
            },

            onNewConfigValSave: function () {
                var that = this;
                var aNewConfigValsPayload = this.getView().getModel("oAdminModel").getProperty("/aNewConfigVals");
                if (aNewConfigValsPayload[0].Name === "") {
                    MessageBox.error("Name cannot be blank");
                    return;
                }
                var oNewConfigVals = {};
                for (var k of aNewConfigValsPayload) {
                    oNewConfigVals = {
                        "Name": k.Name,
                        "Value": k.Value
                    };
                }

                this.Admin_model.create("/ConfigValues", oNewConfigVals, {
                    success: function () {
                        that.onNewConfigValCancel();
                        that.getAdminDetails();
                    },
                    error: function (error) {
                        that.onNewConfigValCancel();
                        if (error.responseJSON.message) {
                            sap.m.MessageBox.error(error.responseJSON.message);
                        } else if (error.responseJSON.error.message) {
                            sap.m.MessageBox.error(error.responseJSON.error.message);
                        }
                    }
                });

            }
        });
    });