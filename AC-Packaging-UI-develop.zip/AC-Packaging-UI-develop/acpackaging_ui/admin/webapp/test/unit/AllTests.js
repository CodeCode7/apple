sap.ui.define([
	"comapple.scp.ui./admin/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
