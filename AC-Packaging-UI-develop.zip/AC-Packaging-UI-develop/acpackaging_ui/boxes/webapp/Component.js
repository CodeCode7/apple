sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/apple/scp/ui/boxes/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (UIComponent, models, JSONModel, MessageBox) {
    "use strict";

    return UIComponent.extend("com.apple.scp.ui.boxes.Component", {

        metadata: {
            manifest: "json", 
            config: { 
                fullWidth: true 
            }
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            // call the base component's init function
            if (window.parent.location.href.includes("epweb")) {
                UIComponent.prototype.init.apply(this, arguments);

                this.setModel(new JSONModel({
                    appBusy: false
                }), "busyModel");

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
            } else {
                MessageBox.show(
                    "Please access ACSC from Enterprise Portal", {
                    icon: MessageBox.Icon.ERROR,
                    title: "Access From Enterprise Portal",
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });
            }

        }
    });
});
