/*global QUnit*/

sap.ui.define([
	"comapple.scp.ui./boxes/controller/Main.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Main Controller");

	QUnit.test("I should test the Main controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
    });
    
    QUnit.test("Test get Plants", function (assert) {
        var oAppController = new Controller();
        oAppController.initialSettings();
        oAppController.setCreateBoxPlantsDefaults();
        assert.ok(this.getView().getModel("oGenBoxIdModel").getProperty("/aCreateBoxPlant").length > 0);
		assert.equal(this.getView().getModel("oGenBoxIdModel").getProperty("/aCreateBoxPlant").length > 0, true);
	});

});
