sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "com/apple/scp/ui/boxes/model/models",
    "com/apple/scp/ui/boxes/controller/BaseController",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment"

],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, models, BaseController, MessageBox, Fragment) {
        "use strict";

        return BaseController.extend("com.apple.scp.ui.boxes.controller.Main", {
            onInit: function () {
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        this.appId = variables;
                        this.gModelBoxConfig = {
                            headers: { appid: variables },
                            defaultBindingMode: "TwoWay",
                            defaultCountMode: "Inline",
                            useBatch: true
                        };

                        this.ui5_ppModel = new sap.ui.model.odata.v2.ODataModel("/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/", this.gModelBoxConfig);

                        if (!this._destDialog) {
                            this._destDialog = sap.ui.xmlfragment(this.getView().getId(),
                                "com.apple.scp.ui.boxes.fragment.BoxCreation.CustomerDialog", this);
                            this.getView().addDependent(this._destDialog);
                        }
                        this._destDialog.open();
                    });
                fetch("/getPackType")
                    .then(res1 => res1.json())
                    .then(apiDest => {
                        this.getView().setModel(new JSONModel({
                            aBoxDestData: apiDest
                        }), "oBoxDestModel");

                    });
                this.getView().setModel(new JSONModel({
                    aCreateBoxPlant: [],
                    aCreateBoxStorageLocs: [],
                    aCreateBoxLobs: [],
                    aCreateBoxBoxTypes: [],
                    aCreateBoxCustomer: []
                }), "oGenBoxIdModel");

                this.getView().setModel(new JSONModel({
                    aCreateBoxSerialNos: [],
                    aModBoxSerialNos: []
                }), "oSerialNosModel");

                this.getView().setModel(new JSONModel({
                    aCBValidAndPrint: [],
                    aMBValidAndPrint: []
                }), "oValidAndPrintModel");

                this.initialSettings();

                this.cbSNError = "";
                this.mbSNError = "";
                this.cbCompError = "";
                this.boxItemsCount = 0;
                this.actualSNs = 0;
                this.bNoBoxItems = false;
                this.modified = false;
                this.bProceed = true;
                this.mbAsIsPN = "";
                this.originalSNs = [];
                this.receivedSNs = [];
                this.bSNsChanged = false;
                this.sDestName = "";

            },

            selBoxTab: function (oEvent) {
                var oIconHeader = this.getView().byId("idCreateBox");
                var oIconTabFilter = oIconHeader.getItems();
                oIconHeader.setSelectedKey("createBox");
                oIconHeader.fireSelect({
                    item: oIconTabFilter[0],
                    key: "createBox"
                });
            },

            initialSettings: function (oEvent) {
                this.getView().setModel(new JSONModel({
                    boxTabSelKey: "createBox",
                    boxSubTabSelKey: "genBoxId",
                    boxModSubSelKey: "scanBoxId",
                    bBoxModEdit: true,
                    sCreateBoxPlantSelKey: "",
                    sCreateBoxStorageLocSelKey: "",
                    sCreateBoxLOBSelKey: "",
                    sCreateBoxBoxTypeSelKey: "",
                    sCreateBoxId: "",
                    sCreateBoxCustomer: "",
                    sCreateBoxCustName: "",
                    sModBoxCustomer: "",
                    sModBoxCustName: "",
                    sBoxIdMod: "",
                    sBoxPlant: "",
                    sBoxStorageLoc: "",
                    sCreateBoxACRFB: "",
                    sCreateBoxFGPN: "",
                    sModBoxACRFB: "",
                    sModBoxFGPN: "",
                    bNextEnabled: true,
                    sBoxDestSelKey: "AS-IS",
                    bSubs: false,
                    bBoxStatus: false
                }), "oGlobalModel");
            },

            onCreateBoxTabSel: function (oEvent) {
                var oCreateContent = this.getView().byId("createBoxMainSub");
                var oModifyContent = this.getView().byId("modifyBoxSub");
                this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", true);
                this.boxItemsCount = 0;
                this.actualSNs = 0;
                this.mbAsIsPN = "";
                if (this.getView().byId("idCreateBox").getSelectedKey() === "createBox" || oEvent.getSource().getSelectedKey() === "") {
                    if (!this.ofragBoxCreateSub) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.apple.scp.ui.boxes.fragment.BoxCreation.CreateBoxSub",
                            controller: this
                        }).then(function (fragBoxCreateSub) {
                            this.ofragBoxCreateSub = fragBoxCreateSub;
                            this.getView().addDependent(fragBoxCreateSub);
                            oCreateContent.addItem(fragBoxCreateSub);
                            this.getView().getModel("oGlobalModel").setProperty("/boxTabSelKey", "createBox");
                            this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                            this.setCreateBoxPlantsDefaults();
                            this.modifyBtnTxt();
                        }.bind(this));
                    } else {
                        oCreateContent.removeAllItems(true);
                        oCreateContent.addItem(this.ofragBoxCreateSub);
                        this.getView().getModel("oGlobalModel").setProperty("/boxTabSelKey", "createBox");
                        this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                        this.setCreateBoxPlantsDefaults();
                        this.modifyBtnTxt();
                    }
                } else {
                    if (!this.ofragBoxModSub) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.apple.scp.ui.boxes.fragment.BoxCreation.ModifyBoxSub",
                            controller: this
                        }).then(function (fragBoxModSub) {
                            this.ofragBoxModSub = fragBoxModSub;
                            this.getView().addDependent(fragBoxModSub);
                            oModifyContent.addItem(fragBoxModSub);
                            this.getView().getModel("oGlobalModel").setProperty("/boxTabSelKey", "modifyBox");
                            this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                            this.modifyBtnTxt();
                        }.bind(this));
                    } else {
                        oModifyContent.removeAllItems(true);
                        oModifyContent.addItem(this.ofragBoxModSub);
                        this.getView().getModel("oGlobalModel").setProperty("/boxTabSelKey", "modifyBox");
                        this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                        this.modifyBtnTxt();
                    }
                    this.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                }
            },

            setCreateBoxPlantsDefaults: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.Metadatamodel.read("/Plants", {
                    success: function (oData, oResponse) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxPlant", oData.results);
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxPlantSelKey", "5601");
                                that.setGenBoxIdDefaults("5601");
                            } else {
                                that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxPlantSelKey", oData.results[0].Plant);
                                that.setGenBoxIdDefaults(oData.results[0].Plant);
                            }

                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            setGenBoxIdDefaults: function (sPlantSelKey) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aFilter = [];
                aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlantSelKey));
                this.Metadatamodel.read("/StorageLocations", {
                    filters: aFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxStorageLocs", oData.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxStorageLocSelKey", oData.results[0].StorageLocation);
                            that.storageLocationDefaults(sPlantSelKey, oData.results[0].StorageLocation);

                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            onBoxPlantChange: function (oEvent) {
                this.setGenBoxIdDefaults(oEvent.getSource().getSelectedKey());
            },

            onStorageLocChange: function (oEvent) {
                var sPlantSelKey = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey");
                this.storageLocationDefaults(sPlantSelKey, oEvent.getSource().getSelectedKey());
            },

            storageLocationDefaults: function (sPlantSelKey, sStorageLoc) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aFilter = [];
                aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlantSelKey));
                aFilter.push(new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc));
                that.Metadatamodel.read("/LOBs", {
                    filters: aFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxLobs", oData.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxLOBSelKey", oData.results[0].LOB);
                            that.lobDefaults(sPlantSelKey, sStorageLoc, oData.results[0].LOB);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            onLOBChange: function (oEvent) {
                var sPlantSelKey = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey");
                this.lobDefaults(sPlantSelKey, this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxStorageLocSelKey"), oEvent.getSource().getSelectedKey());
            },

            lobDefaults: function (sPlantSelKey, sStorageLoc, sLOB) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aFilter = [];
                aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlantSelKey));
                aFilter.push(new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc));
                aFilter.push(new sap.ui.model.Filter("LOB", sap.ui.model.FilterOperator.EQ, sLOB));
                that.Metadatamodel.read("/BoxTypes", {
                    filters: aFilter,
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxBoxTypes", oData.results);
                            that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxBoxTypeSelKey", oData.results[0].MaxQuantity);
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.getBoxCustomerName([]);
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            }
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });

            },

            getBoxCustomerName: function (aFilter) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.bFilter = false;
                if (aFilter.length > 0) {
                    this.bFilter = true;
                }
                this.Metadatamodel.read("/Customer", {
                    filters: aFilter,
                    success: function (oData) {
                        
                        if (oData.results.length > 0) {
                            if (that.bFilter) {
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxCustName", oData.results[0].CustomerName);
                            } else {
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxCustName", "");
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxCustomer", oData.results[0].CustomerId);
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxCustomer", oData.results);
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxCustomer", "");
                            that.getView().getModel("oGenBoxIdModel").setProperty("/aCreateBoxCustomer", []);
                            that.getView().getModel("oGlobalModel").setProperty("/sModBoxCustName", "");
                        }
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);

                    }
                });
            },

            onCancel: function (oEvent) {

                if (this.getView().getModel("oGlobalModel").getProperty("/boxTabSelKey") === "createBox") {
                    this.onCreateBoxIdCancel(this.getView().getModel("oGlobalModel").getProperty("/boxSubTabSelKey"));
                } else if (this.getView().getModel("oGlobalModel").getProperty("/boxTabSelKey") === "modifyBox") {
                    this.onModifyBoxCancel(this.getView().getModel("oGlobalModel").getProperty("/boxModSubSelKey"));
                }
                this.getView().getModel("oGlobalModel").refresh(true);
            },

            onCreateBoxPress: function (oEvent) {

                if (this.getView().getModel("oGlobalModel").getProperty("/boxTabSelKey") === "createBox") {
                    this.validateCreateBoxId(this.getView().getModel("oGlobalModel").getProperty("/boxSubTabSelKey"));
                } else if (this.getView().getModel("oGlobalModel").getProperty("/boxTabSelKey") === "modifyBox") {
                    this.validateModifyBox(this.getView().getModel("oGlobalModel").getProperty("/boxModSubSelKey"));
                }

            },

            footerButtonSettings: function (prmBtnText, secBtnText) {
                this.byId("prmBtn").setText(prmBtnText);
                this.byId("secBtn").setText(secBtnText);
            },

            onCreateBoxIdCancel: function (sBoxSubTabSelKey) {
                if (sBoxSubTabSelKey === "genBoxId") {
                    var oCreateContent = this.byId("createBoxMainSub");
                    oCreateContent.removeAllItems(true);
                    this.getView().getModel("oGlobalModel").setProperty("/boxTabSelKey", "createBox");
                    this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                    this.modifyBtnTxt();
                    this._destDialog.open();
                } else if (sBoxSubTabSelKey === "scanSN") {
                    this.footerButtonSettings("Create Box ID", "Cancel");
                    this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                } else if (sBoxSubTabSelKey === "valdAndPrint") {
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "scanSN");
                }
            },

            onModifyBoxCancel: function (sBoxModSubTabSelKey) {
                if (sBoxModSubTabSelKey === "scanBoxId") {
                    this.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                } else if (sBoxModSubTabSelKey === "scanSN") {
                    if (this.getView().getModel("oGlobalModel").getProperty("/bBoxModEdit")) {
                        this.footerButtonSettings("Next", "Cancel");
                        this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                        this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", true);
                        this.bNoBoxItems = false;
                    } else if (!this.getView().getModel("oGlobalModel").getProperty("/bBoxModEdit")) {
                        this.footerButtonSettings("Next", "Back");
                        this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", true);
                        this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanSN");
                        this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                    }
                    this.getView().getModel("oSerialNosModel").setProperty("/aModBoxSerialNos", JSON.parse(this.originalSNs));
                } else if (sBoxModSubTabSelKey === "valdAndPrint") {
                    this.originalSNs = JSON.stringify(this.originalSNs);
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", false);
                    this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanSN");
                    this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                }
            },

            onSNLiveChange: function () {
                this.checkBoxItemsForSNs();
            },

            setBoxService: function() {
                this.Boxmodel = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/box-service/`, this.gModelBoxConfig);
                this.Boxmodel.sDefaultUpdateMethod = "PATCH";
            },

            validateCreateBoxId: function (sBoxSubTabSelKey) {
                if (sBoxSubTabSelKey === "genBoxId") {
                    this.mbAsIsPN = "";
                    this.setBoxService();
                    this.createBoxID();
                } else if (sBoxSubTabSelKey === "scanSN") {
                    this.getSerialNumberDetails("CB");
                } else if (sBoxSubTabSelKey === "valdAndPrint") {
                    this.completeBoxCreation();
                }
            },

            createBoxID: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var maxBoxQty = 0;
                if (this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxBoxTypeSelKey")) {
                    maxBoxQty = parseInt(this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxBoxTypeSelKey"));
                }
                this.maxCreateBoxQty = maxBoxQty;

                var createBoxIDPayload = {
                    "Plant": this.getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey"),
                    "StorageLocation": this.getModel("oGlobalModel").getProperty("/sCreateBoxStorageLocSelKey"),
                    "MaxBoxQuantity": maxBoxQty
                }

                if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    createBoxIDPayload.Customer = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxCustomer");
                    this.getView().getModel("oGlobalModel").setProperty("/sCreateBoxCustName", this.getView().byId("customer").getSelectedItem().getAdditionalText());
                    createBoxIDPayload.Type = "B";
                } else {
                    createBoxIDPayload.Customer = "";
                    createBoxIDPayload.Type = "A";
                    this.getView().getModel("oGlobalModel").setProperty("/sCreateBoxCustName", "");
                }

                this.Boxmodel.create("/Boxes", createBoxIDPayload, {
                    success: function (data) {
                        that.getView().getModel("oGlobalModel").setProperty("/sCreateBoxId", data.BoxID);
                        var aSerialNos = [];
                        for (var s = 0; s < maxBoxQty; s++) {
                            var oNewSerialNo = {
                                sequencePositions: (s + 1).toString(),
                                serialNumbers: ""
                            };
                            aSerialNos.push(oNewSerialNo);
                        }
                        that.getView().getModel("oSerialNosModel").setProperty("/aCreateBoxSerialNos", aSerialNos);
                        that.footerButtonSettings("Next", "Back");
                        that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "scanSN");
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (createBoxIdError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(createBoxIdError.responseText).error.message.value);
                    }
                });

            },

            getSerialNumberDetails: function (sSelBoxTab) {
                var aNewSerialNumbers = [],
                    boxId = "";
                var sSerialNumbers = "",
                    sSeqPositions = "",
                    oSNReturn;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (sSelBoxTab === "CB") {
                    if (this.checkDuplicateSNs(sSelBoxTab)) {
                        if (this.cbSNError.length > 0) {
                            MessageBox.error(this.cbSNError);
                            this.cbSNError = "";
                        }
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        return;
                    }
                    aNewSerialNumbers = this.getView().getModel("oSerialNosModel").getProperty("/aCreateBoxSerialNos");
                    boxId = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxId");
                    oSNReturn = this.prepareCBSNPayload(aNewSerialNumbers, sSeqPositions, sSerialNumbers);

                } else {
                    if (this.checkDuplicateSNs(sSelBoxTab)) {
                        if (this.mbSNError.length > 0) {
                            MessageBox.error(this.mbSNError);
                            this.mbSNError = "";
                        }
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        return;
                    }
                    aNewSerialNumbers = this.getView().getModel("oSerialNosModel").getProperty("/aModBoxSerialNos");
                    boxId = this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod");
                    oSNReturn = this.prepareMBSNPayload(aNewSerialNumbers, sSeqPositions, sSerialNumbers);
                }

                if (this.sDestName === "AS-IS") {
                    this.validateSerialNumberDetails(sSelBoxTab, boxId, oSNReturn);
                } else {
                    this.callSerialNumberDetails(sSelBoxTab, boxId, oSNReturn);
                }


            },

            validateSerialNumberDetails: function (sSelBoxTab, boxId, oSNReturn) {

                if (oSNReturn.bAtleastOneSNExists) {
                    var that = this;
                    this.getView().getModel("busyModel").setProperty("/appBusy", true);
                    this.sSelBoxTab1 = sSelBoxTab;
                    this.boxId = boxId;
                    this.oSNReturn = oSNReturn;
                    this.Boxmodel.setDeferredGroups(["ValidateSerialNumberGroup"]);
                    var tempValSN = {};
                    tempValSN.boxID = boxId;
                    tempValSN.serialNumbers = oSNReturn.sSerialNumbers;
                    this.Boxmodel.callFunction("/validateSerialNumbers", {
                        urlParameters: tempValSN,
                        method: "GET",
                        batchGroupId: "ValidateSerialNumberGroup"
                    });
                    this.Boxmodel.submitChanges({
                        batchGroupId: "ValidateSerialNumberGroup",
                        async: false,
                        success: function (oDataVSN, oResponseVSN) {
                            
                            if (oResponseVSN.data.__batchResponses[0].response === undefined) {
                                that.valSNResponse = oDataVSN.__batchResponses[0].data.validateSerialNumbers;
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                if (that.valSNResponse.MultipleParts === "X") {
                                    that.handleMultiPart();
                                } else {
                                    that.callSerialNumberDetailsJava(that.valSNResponse.AsIsPartNumber, that.valSNResponse.ConfigID);
                                }

                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                MessageBox.error(JSON.parse(oDataVSN.__batchResponses[0].response.body).error.message.value);
                            }

                        },
                        error: function (oError) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    });

                } else {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                }
            },

            handleMultiPart: function () {
                var aMultiParts = [];
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aAsIsPartNumbers = this.valSNResponse.AsIsPartNumber.split(",");
                for (var asIs of aAsIsPartNumbers) {
                    var oAsIsPartNumber = {
                        sAsIsPartNumber: asIs
                    }
                    aMultiParts.push(oAsIsPartNumber);
                }
                if (this.mbAsIsPN === "") {
                    this.getView().getModel("oGlobalModel").setProperty("/sAsIsPartNumberKey", aMultiParts[0].sAsIsPartNumber);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/sAsIsPartNumberKey", this.mbAsIsPN);
                }

                this.getView().getModel("oGlobalModel").setProperty("/aAsIsPartNumbers", aMultiParts);
                if (!this._asIsPartNumDialog) {
                    this._asIsPartNumDialog = sap.ui.xmlfragment(this.getOwnerComponent().getId(),
                        "com.apple.scp.ui.boxes.fragment.BoxCreation.MultiPartDialog", this);
                    this.getView().addDependent(this._asIsPartNumDialog);
                }
                this.getView().getModel("busyModel").setProperty("/appBusy", false);
                this._asIsPartNumDialog.open();
            },

            checkSNsChanged: function (aSortedSNs) {
                var iCount = 0;

                for (var receivedSN of this.aReceivedSNs) {
                    for (var sortedSN of aSortedSNs) {
                        if (receivedSN.SerialNumber === sortedSN) {
                            iCount++;
                            break;
                        }
                    }
                }

                if (iCount === this.aReceivedSNs.length) {
                    this.bSNsChanged = false;
                } else {
                    this.bSNsChanged = true;
                }

            },

            onEditSN: function (oEvent) {
                if (this.getView().getModel("oGlobalModel").getProperty("/bBoxModEdit")) {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", false);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", true);
                }
            },

            onBoxModSNDelete: function (oEvent) {
                var selRowPath = oEvent.getSource().getBindingContext("oSerialNosModel").getPath();
                oEvent.getSource().getModel("oSerialNosModel").getProperty(selRowPath).SerialNumber = "";

                if (this.boxStatus === "2") {
                    this.checkBoxItemsForSNs();
                }

                this.getView().getModel("oSerialNosModel").refresh(true);
            },

            checkBoxItemsForSNs: function () {
                var aBoxItems = this.getView().getModel("oSerialNosModel").getProperty("/aModBoxSerialNos");
                var iCount = 0;

                for (var boxItem of aBoxItems) {
                    if (boxItem.SerialNumber.trim() === "") {
                        iCount++;
                    }
                }
                if (iCount === aBoxItems.length) {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxStatus", true);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxStatus", false);
                }

            },

            onBoxDeletePress: function () {
                var that = this;
                if (this.boxStatus === "2") {
                    MessageBox.show("Box already palletized, remove the Box from Pallet and proceed", {
                        icon: MessageBox.Icon.WARNING,
                        title: "Box Items Deletion",
                        actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                        onClose: function (oAction) {
                            if (oAction === "YES") {
                                that.getView().getModel("busyModel").setProperty("/appBusy", true);
                                that.callBoxItemsDelete();
                            }
                        }.bind(this)
                    }
                    );
                } else {
                    MessageBox.show("Are you sure you want to delete Box ID completely ?", {
                        icon: MessageBox.Icon.WARNING,
                        title: "Box Deletion",
                        actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                        onClose: function (oAction) {
                            if (oAction === "YES") {
                                that.getView().getModel("busyModel").setProperty("/appBusy", true);
                                that.callBoxDelete();
                            }
                        }.bind(this)
                    }
                    );
                }


            },

            callBoxDelete: function () {
                var that = this;
                this.Boxmodel.remove(`/Boxes(BoxID='${this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod")}')`, {
                    method: "DELETE",
                    success: function (oData, oResponse) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.footerButtonSettings("Next", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                        that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                        MessageBox.success("Box ID is deleted successfully");
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });
            },

            callBoxItemsDelete: function () {
                var that = this;
                var sModBoxId = this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod");
                this.Boxmodel.setDeferredGroups(["deleteBoxItemsGrp"]);
                if (this.savedBoxItems.length > 0) {

                    for (var savedBoxItem of this.savedBoxItems) {
                        if (savedBoxItem.SerialNumber.length > 0) {
                            this.Boxmodel.remove(`/BoxItems(BoxID_BoxID='${sModBoxId}',AsIsPartNumber='${savedBoxItem.AsIsPartNumber}',SerialNumber='${savedBoxItem.SerialNumber}')`, {
                                method: "DELETE",
                                batchGroupId: "deleteBoxItemsGrp"
                            });
                        }
                    }

                    this.Boxmodel.submitChanges({
                        batchGroupId: "deleteBoxItemsGrp",
                        async: false,
                        success: function (oData, oResponse) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.footerButtonSettings("Next", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                            that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                            MessageBox.success("Box Items deleted successfully");
                        },
                        error: function (oError) {
                            MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        }
                    });

                } else {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                }
            },

            checkModifyBoxBoxDuplicates: function () {
                var aSNs = this.getView().getModel("oSerialNosModel").getProperty("/aModBoxSerialNos");
                var aSortedSNs = [];

                for (var z of aSNs) {
                    if (z.SerialNumber.trim() !== "") {
                        aSortedSNs.push(z.SerialNumber.trim());
                    }
                }
                if (aSortedSNs.length > 0) {
                    aSortedSNs.sort((a, b) => (a.SerialNumber > b.SerialNumber) ? 1 : -1);
                    for (var i = 0; i < aSortedSNs.length - 1; i++) {
                        if (aSortedSNs[i + 1] === aSortedSNs[i]) {
                            this.mbSNError = "Duplicate Serial Numbers Exists.";
                            return true;
                        }
                    }

                } else {
                    MessageBox.error("Please enter at least one Serial Number");
                    return true;
                }
                this.actualSNs = aSortedSNs.length;
                this.compareModBoxSNs();

                return false;
            },

            compareModBoxSNs: function () {
                if (this.receivedSNs.length === 0) {
                    this.bSNsChanged = true;
                } else {
                    this.aReceivedSNs = [];
                    this.receivedSNs = JSON.parse(this.receivedSNs);

                    for (let x of this.receivedSNs) {
                        if (x.SerialNumber !== "") {
                            this.aReceivedSNs.push(x);
                        }
                    }
                    if (this.actualSNs !== this.aReceivedSNs.length) {
                        this.bSNsChanged = true;
                    } else {
                        this.checkSNsChanged(this.aReceivedSNs);
                    }
                    this.receivedSNs = JSON.stringify(this.receivedSNs);
                }
            },

            prepareMBSNPayload: function (aNewSerialNumbers, sSeqPositions, sSerialNumbers) {
                var oMBSNReturn = {
                    bAtleastOneSNExists: false,
                    sSeqPositions: "",
                    sSerialNumbers: ""
                };
                var sSerialNumbers2 = sSerialNumbers;
                var bAtleastOneSNExists = false;

                for (let j of aNewSerialNumbers) {
                    if (j.SerialNumber.trim()) {
                        if (sSeqPositions === "") {
                            sSeqPositions = (j.BoxSequence).toString();
                            sSerialNumbers2 = j.SerialNumber;
                        } else {
                            sSeqPositions = sSeqPositions + "," + j.BoxSequence;
                            sSerialNumbers2 = sSerialNumbers2 + "," + j.SerialNumber;
                        }
                        bAtleastOneSNExists = true;
                    }

                }
                oMBSNReturn.bAtleastOneSNExists = bAtleastOneSNExists;
                oMBSNReturn.sSeqPositions = sSeqPositions;
                oMBSNReturn.sSerialNumbers = sSerialNumbers2;
                return oMBSNReturn;
            },

            checkDuplicateSNs: function (selTab) {
                var bResp;
                if (selTab === "CB") {
                    bResp = this.checkCreateBoxDuplicates();
                    return bResp;

                } else if (selTab === "MB") {
                    bResp = this.checkModifyBoxBoxDuplicates();
                    return bResp;
                }

            },

            checkCreateBoxDuplicates: function () {
                var aSortedSNs = [];
                var aSNs = this.getView().getModel("oSerialNosModel").getProperty("/aCreateBoxSerialNos");

                for (let x of aSNs) {
                    if (x.serialNumbers.trim() !== "") {
                        aSortedSNs.push(x.serialNumbers.trim());
                    }
                }
                if (aSortedSNs.length > 0) {
                    aSortedSNs.sort((a, b) => (a.serialNumbers > b.serialNumbers) ? 1 : -1);
                    for (var i = 0; i < aSortedSNs.length - 1; i++) {
                        if (aSortedSNs[i + 1] === aSortedSNs[i]) {
                            this.cbSNError = "Duplicate Serial Numbers Exists.";
                            return true;
                        }
                    }

                } else {
                    MessageBox.error("Please enter at least one Serial Number");
                    return true;
                }
                return false;
            },

            prepareCBSNPayload: function (aNewSerialNumbers, sSeqPositions, sSerialNumbers) {
                var oCBSNReturn = {
                    bAtleastOneSNExists: false,
                    sSeqPositions: "",
                    sSerialNumbers: ""
                };
                var sSerialNumbers1 = sSerialNumbers;
                var bAtleastOneSNExists = false;

                for (let k of aNewSerialNumbers) {
                    if (k.serialNumbers.trim()) {
                        if (sSeqPositions === "") {
                            sSeqPositions = (k.sequencePositions).toString();
                            sSerialNumbers1 = k.serialNumbers;
                        } else {
                            sSeqPositions = sSeqPositions + "," + k.sequencePositions;
                            sSerialNumbers1 = sSerialNumbers1 + "," + k.serialNumbers;
                        }
                        bAtleastOneSNExists = true;
                    }

                }
                oCBSNReturn.bAtleastOneSNExists = bAtleastOneSNExists;
                oCBSNReturn.sSeqPositions = sSeqPositions;
                oCBSNReturn.sSerialNumbers = sSerialNumbers1;
                return oCBSNReturn;
            },

            callSerialNumberDetails: function (sSelBoxTab, boxId, oSNReturn) {

                if (oSNReturn.bAtleastOneSNExists) {
                    var that = this;
                    this.getView().getModel("busyModel").setProperty("/appBusy", true);
                    this.Boxmodel.setDeferredGroups(["CheckDuplicateSerialNumberGroup"]);
                    var oCheckDuplicateSNPayload = {
                        boxID: boxId,
                        serialNumbers: oSNReturn.sSerialNumbers
                    };
                    this.Boxmodel.callFunction("/checkDuplicateSerialNumbers", {
                        urlParameters: oCheckDuplicateSNPayload,
                        method: "GET",
                        batchGroupId: "CheckDuplicateSerialNumberGroup"
                    });
                    this.Boxmodel.submitChanges({
                        batchGroupId: "CheckDuplicateSerialNumberGroup",
                        async: false,
                        success: function (oData, oResponse) {
                            if (oData.__batchResponses[0].data !== undefined) {
                                if (oData.__batchResponses[0].data.checkDuplicateSerialNumbers === 0) {
                                    that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                    that.ValidateRMASNsForBoxType(sSelBoxTab, boxId, oSNReturn);
                                }
                            } else if (oData.__batchResponses[0].data === undefined) {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            }

                        },
                        error: function (oError) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        }
                    });

                } else {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                }
            },

            ValidateRMASNsForBoxType: function (sSelBoxTab, boxId, oSNReturn) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var tempValRMAForBoxType = {};
                tempValRMAForBoxType.boxID = boxId;
                tempValRMAForBoxType.serialNumbers = oSNReturn.sSerialNumbers;
                tempValRMAForBoxType.sequencePositions = oSNReturn.sSeqPositions;

                this.oSNReturn = oSNReturn;
                this.boxId = boxId;
                this.sSelBoxTab1 = sSelBoxTab;
                if (sSelBoxTab === "CB") {
                    tempValRMAForBoxType.Plant = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey");
                    tempValRMAForBoxType.StorageLocation = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxStorageLocSelKey");
                    tempValRMAForBoxType.CustomerNumber = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxCustomer");
                } else {
                    tempValRMAForBoxType.Plant = this.getView().getModel("oGlobalModel").getProperty("/sBoxPlant");
                    tempValRMAForBoxType.StorageLocation = this.getView().getModel("oGlobalModel").getProperty("/sBoxStorageLoc");
                    tempValRMAForBoxType.CustomerNumber = this.getView().getModel("oGlobalModel").getProperty("/sModBoxCustomer");
                }

                if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    tempValRMAForBoxType.Type = "B";
                } else {
                    tempValRMAForBoxType.Type = "A";
                }
                
                this.ui5_ppModel.setDeferredGroups(["validateRMASNsForBoxTypeGrp"]);
                this.ui5_ppModel.callFunction("/validateSerialNumbersForBoxType", {
                    urlParameters: tempValRMAForBoxType,
                    method: "GET",
                    batchGroupId: "validateRMASNsForBoxTypeGrp"
                });
                this.ui5_ppModel.submitChanges({
                    batchGroupId: "validateRMASNsForBoxTypeGrp",
                    async: false,
                    success: function (oData, oResponse) {
                        
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            if (oData.__batchResponses[0].data.results.length > 0) {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                that.callSerialNumberDetailsJavaMC(oData.__batchResponses[0].data.results, "");
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            }
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
                        }


                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });
            },

            callSerialNumberDetailsJavaMC: function (aAsIsPartNum, sConfigId) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var tempCallSNDetsMC = {
                    serialNumbers: this.oSNReturn.sSerialNumbers,
                    sequencePositions: this.oSNReturn.sSeqPositions,
                    asIsPartNumber: "",
                    finishedGoodsMPN: ""
                };
                this.Boxmodel.setDeferredGroups(["GetSerialNumberHLGroup"]);

                for (let y of aAsIsPartNum) {
                    if (tempCallSNDetsMC.asIsPartNumber === "") {
                        tempCallSNDetsMC.asIsPartNumber = y.AsIsPartNumber;
                    } else {
                        tempCallSNDetsMC.asIsPartNumber = tempCallSNDetsMC.asIsPartNumber + "," + y.AsIsPartNumber;
                    }

                    if (tempCallSNDetsMC.finishedGoodsMPN === "") {
                        tempCallSNDetsMC.finishedGoodsMPN = y.FinishedGoodsMPN;
                    } else {
                        tempCallSNDetsMC.finishedGoodsMPN = tempCallSNDetsMC.finishedGoodsMPN + "," + y.FinishedGoodsMPN;
                    }
                }

                tempCallSNDetsMC.boxID = this.boxId;
                tempCallSNDetsMC.configID = sConfigId;
                this.Boxmodel.callFunction("/serialNumberDetails", {
                    urlParameters: tempCallSNDetsMC,
                    method: "GET",
                    batchGroupId: "GetSerialNumberHLGroup"
                });

                this.Boxmodel.submitChanges({
                    batchGroupId: "GetSerialNumberHLGroup",
                    async: false,
                    success: function (oData, oResponse) {
                        
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                if (that.sSelBoxTab1 === "CB") {
                                    that.getView().getModel("oValidAndPrintModel").setProperty("/aCBValidAndPrint", oData.__batchResponses[0].data.results);
                                    that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "valdAndPrint");
                                } else {
                                    that.getView().getModel("oValidAndPrintModel").setProperty("/aMBValidAndPrint", oData.__batchResponses[0].data.results);
                                    that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "valdAndPrint");
                                }
                                that.footerButtonSettings("Complete & Print Labels", "Back");
                            }
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });
            },

            onAsIsPartNumClose: function () {
                this._asIsPartNumDialog.close();
            },

            onAsIsPartNumOk: function (oEvent) {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.onAsIsPartNumClose();
                this.callSerialNumberDetailsJava(this.getView().getModel("oGlobalModel").getProperty("/sAsIsPartNumberKey"), this.valSNResponse.ConfigID);
            },

            callSerialNumberDetailsJava: function (sAsIsPartNum, sConfigId) {
                var tempCallSNDetsMC = {};
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                tempCallSNDetsMC.boxID = this.boxId;
                tempCallSNDetsMC.serialNumbers = this.oSNReturn.sSerialNumbers;
                tempCallSNDetsMC.sequencePositions = this.oSNReturn.sSeqPositions;
                tempCallSNDetsMC.configID = sConfigId;
                tempCallSNDetsMC.asIsPartNumber = sAsIsPartNum;
                this.Boxmodel.setDeferredGroups(["GetSerialNumberGroup"]);
                this.Boxmodel.callFunction("/serialNumberDetails", {
                    urlParameters: tempCallSNDetsMC,
                    method: "GET",
                    batchGroupId: "GetSerialNumberGroup"
                });
                this.Boxmodel.submitChanges({
                    batchGroupId: "GetSerialNumberGroup",
                    async: false,
                    success: function (oData, oResponse) {
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            
                            if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                                that.footerButtonSettings("Complete & Print Labels", "Back");
                                if (that.sSelBoxTab1 === "CB") {
                                    that.getView().getModel("oValidAndPrintModel").setProperty("/aCBValidAndPrint", oData.__batchResponses[0].data.results);
                                    that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "valdAndPrint");
                                } else {
                                    that.getView().getModel("oValidAndPrintModel").setProperty("/aMBValidAndPrint", oData.__batchResponses[0].data.results);
                                    that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "valdAndPrint");
                                }
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            } else {
                                that.getView().getModel("busyModel").setProperty("/appBusy", false);
                                that.handleSuccess(oData, oResponse);
                            }

                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    }
                });
            },

            handleSuccess: function (oData, oResponse) {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (oData.__batchResponses[0].data.results.length > 0) {

                    for (let u of oData.__batchResponses[0].data.results) {
                        if (u.MessageType === "E") {
                            MessageBox.error(u.MessageText);
                            this.getView().getModel("busyModel").setProperty("/appBusy", false);
                            return;
                        }
                    }
                    this.handleSuccessData = oData.__batchResponses[0].data.results;
                    if (this.sSelBoxTab1 === "CB") {
                        this.getView().getModel("oValidAndPrintModel").setProperty("/aCBValidAndPrint", oData.__batchResponses[0].data.results);
                        this.getView().getModel("oGlobalModel").setProperty("/sCreateBoxACRFB", oData.__batchResponses[0].data.results[0].AsIsPartNumber);
                        this.getView().getModel("oGlobalModel").setProperty("/sCreateBoxFGPN", oData.__batchResponses[0].data.results[0].FinishedGoodsMPN);
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        this.getConfigValues(false, this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey"));
                    } else {
                        this.getView().getModel("oValidAndPrintModel").setProperty("/aMBValidAndPrint", oData.__batchResponses[0].data.results);
                        this.getView().getModel("oGlobalModel").setProperty("/sBoxACRFB", oData.__batchResponses[0].data.results[0].AsIsPartNumber);
                        this.getView().getModel("oGlobalModel").setProperty("/sBoxFGPN", oData.__batchResponses[0].data.results[0].FinishedGoodsMPN);
                        this.checkModification(this.getView().getModel("oSerialNosModel").getProperty("/aModBoxSerialNos"));
                        this.originalSNs = this.getView().getModel("oSerialNosModel").getProperty("/aModBoxSerialNos");
                        this.bNoBoxItems = false;
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        this.getConfigValues(false, this.getView().getModel("oGlobalModel").getProperty("/sBoxPlant"));
                    }

                } else {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                }
            },

            getStorageBins: function (sMaterial) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var sPlantSB = "",
                    sStorageLocSB = "";
                if (this.sSelBoxTab1 === "CB") {
                    sPlantSB = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey");
                    sStorageLocSB = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxStorageLocSelKey");
                } else {
                    sPlantSB = this.getView().getModel("oGlobalModel").getProperty("/sBoxPlant");
                    sStorageLocSB = this.getView().getModel("oGlobalModel").getProperty("/sBoxStorageLoc");
                }

                var aFilter = [];
                aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlantSB));
                aFilter.push(new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial));
                aFilter.push(new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLocSB));
                this.Metadatamodel.read("/StorageBins", {
                    filters: aFilter,
                    async: false,
                    success: function (data, oResponse) {
                        if (data.results.length > 0) {
                            that.sStorageBin = data.results[0].StorageBin;
                        }
                        if (that.sSelBoxTab1 === "CB") {
                            that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "valdAndPrint");
                        } else {
                            that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "valdAndPrint");
                        }

                        that.footerButtonSettings("Complete & Print Labels", "Back");
                        that.sSelBoxTab1 = "";
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                });

            },

            checkModification: function (aSNData) {

                var aOriginalSNs = [];
                if (this.originalSNs.length > 0) {
                    if (this.originalSNs.length !== 20) {
                        aOriginalSNs = JSON.parse(this.originalSNs);
                    }

                    this.compareNewnOriginalSNs(aSNData, aOriginalSNs);

                } else {
                    this.modified = true;
                }


            },

            compareNewnOriginalSNs: function (aSNData, aOriginalSNs) {
                var aFilledSNData = [];
                var aFilledOriginalSNs = [];
                for (let g of aSNData) {
                    if (g.SerialNumber.trim() !== "") {
                        aFilledSNData.push(g);
                    }
                }

                for (let h of aOriginalSNs) {
                    if (h.SerialNumber.trim() !== "") {
                        aFilledOriginalSNs.push(h);
                    }
                }
                if (aFilledSNData.length !== aFilledOriginalSNs.length) {
                    this.modified = true;
                } else {
                    this.modified = false;
                }
            },

            completeBoxCreation: function () {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (!this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    if (this.sStorageBin === "0") {
                        this.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error("Storage bin is empty");
                    } else {
                        this.callBoxComplete();
                    }
                } else {
                    this.callBoxComplete();
                }

            },

            callBoxComplete: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                var aToBoxItems = [];
                var aVldPrint = this.getView().getModel("oValidAndPrintModel").getProperty("/aCBValidAndPrint");

                for (let k of aVldPrint) {
                    var oToBoxItems = {};
                    oToBoxItems.AsIsPartNumber = k.AsIsPartNumber;
                    oToBoxItems.BoxID_BoxID = k.BoxID_BoxID;
                    oToBoxItems.BoxSequence = parseInt(k.BoxSequence);
                    oToBoxItems.CountryOfOrigin = k.CountryOfOrigin;
                    oToBoxItems.FinishedGoodsMPN = k.FinishedGoodsMPN;
                    oToBoxItems.IMEI1 = k.IMEI1;
                    oToBoxItems.IMEI2 = k.IMEI2;
                    oToBoxItems.ModelNumber = k.ModelNumber;
                    oToBoxItems.SerialNumber = k.SerialNumber;
                    oToBoxItems.CreatedAt = null;
                    oToBoxItems.CreatedBy = null;
                    aToBoxItems.push(oToBoxItems);
                }
                var aBoxCreateCompletePayload = {
                    "Plant": this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxPlantSelKey"),
                    "toBoxItems": aToBoxItems
                };

                if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    aBoxCreateCompletePayload.Customer = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxCustomer");
                    aBoxCreateCompletePayload.Type = "B";
                } else {
                    aBoxCreateCompletePayload.Customer = "";
                    aBoxCreateCompletePayload.Type = "A";
                }
                
                this.Boxmodel.update("/Boxes('" + this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxId") + "')", aBoxCreateCompletePayload, {
                    success: function (data, oResponse) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.getSSCC18();
                    },
                    error: function (boxCompError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(boxCompError.responseText).error.message.value);
                    }
                });

            },

            getSSCC18: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.Boxmodel.read("/Boxes('" + this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxId") + "')", {

                    success: function (data) {
                        if (that.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                            that.onSubsBoxPrintLabelPress();
                        } else {
                            that.createBoxPrintLabels(data.SSCC18);
                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });
            },

            completeModifyBox: function () {
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                if (this.sStorageBin === "0") {
                    this.getView().getModel("busyModel").setProperty("/appBusy", false);
                    MessageBox.error("Storage bin is empty");
                } else if (this.bSNsChanged) {
                    this.callModBoxComplete();
                } else {
                    if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                        this.onSubsModBoxPrintLabelPress();
                    } else {
                        this.modBoxPrintLabels(this.sSSCC18);
                    }
                }
            },

            callModBoxComplete: function () {
                var that = this;
                if (this.bSNsChanged) {
                    this.getView().getModel("busyModel").setProperty("/appBusy", true);
                    var aToBoxItems1 = [];
                    var aVldPrint1 = this.getView().getModel("oValidAndPrintModel").getProperty("/aMBValidAndPrint");

                    for (let l of aVldPrint1) {
                        var oToBoxItems1 = {};
                        oToBoxItems1.AsIsPartNumber = l.AsIsPartNumber;
                        oToBoxItems1.BoxID_BoxID = l.BoxID_BoxID;
                        oToBoxItems1.BoxSequence = parseInt(l.BoxSequence);
                        oToBoxItems1.CountryOfOrigin = l.CountryOfOrigin;
                        oToBoxItems1.FinishedGoodsMPN = l.FinishedGoodsMPN;
                        oToBoxItems1.IMEI1 = l.IMEI1;
                        oToBoxItems1.IMEI2 = l.IMEI2;
                        oToBoxItems1.ModelNumber = l.ModelNumber;
                        oToBoxItems1.SerialNumber = l.SerialNumber;
                        oToBoxItems1.CreatedAt = null;
                        oToBoxItems1.CreatedBy = null;
                        aToBoxItems1.push(oToBoxItems1);
                    }
                    var aModBoxCompletePayload = {
                        "Plant": this.getView().getModel("oGlobalModel").getProperty("/sBoxPlant"),
                        "toBoxItems": aToBoxItems1
                    };
                    
                    this.Boxmodel.update("/Boxes('" + this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod") + "')", aModBoxCompletePayload, {
                        success: function (data, oResponse) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.handlePrintLabel();
                        },
                        error: function (modBoxCompError) {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.handleModBoxCompleteError(modBoxCompError);
                        }
                    });

                } else {
                    that.handlePrintLabel();
                }
            },

            handleModBoxCompleteError: function (modBoxCompError) {
                if (modBoxCompError.responseJSON) {
                    MessageBox.error(modBoxCompError.responseJSON.error.message);
                } else {
                    MessageBox.error(modBoxCompError.responseText);
                }
            },

            handlePrintLabel: function () {
                if (this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    this.onSubsModBoxPrintLabelPress();
                } else {
                    this.modBoxPrintLabels(this.sSSCC18);
                }
            },

            createBoxPrintLabels: function (sSSCC18) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["BoxbatchDownload"]);
                var aPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aCBValidAndPrint");
                var boxQty1 = aPrintLabelData.length;

                for (let i of aPrintLabelData) {
                    var tempCreateBoxPrintLab = {};
                    tempCreateBoxPrintLab.BoxID = i.BoxID_BoxID;
                    tempCreateBoxPrintLab.AcRfbPartNumber = i.AsIsPartNumber;
                    tempCreateBoxPrintLab.FgPartNumber = i.FinishedGoodsMPN;
                    tempCreateBoxPrintLab.SerialNumber = i.SerialNumber;
                    tempCreateBoxPrintLab.IMEI1 = i.IMEI1;
                    tempCreateBoxPrintLab.IMEI2 = i.IMEI2;
                    tempCreateBoxPrintLab.BoxQuantity = boxQty1;
                    tempCreateBoxPrintLab.CountryOfOrigin = i.CountryOfOrigin;
                    tempCreateBoxPrintLab.EAN11 = i.EAN11;
                    tempCreateBoxPrintLab.StorageBin = this.sStorageBin;
                    tempCreateBoxPrintLab.SSCC18 = sSSCC18;
                    tempCreateBoxPrintLab.ModelNo = i.ModelNumber;
                    this.ui5_ppModel.callFunction("/GenerateBoxLabel", {
                        urlParameters: tempCreateBoxPrintLab,
                        method: "POST",
                        batchGroupId: "BoxbatchDownload"
                    });
                }
                

                this.ui5_ppModel.submitChanges({
                    batchGroupId: "BoxbatchDownload",
                    changeSetId: 1,
                    success: function (oCBPData, oResponse) {
                        if (oCBPData.__batchResponses[0].data === undefined) {
                            var createBoxPrintLabFileGUID = oCBPData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (createBoxPrintLabFileGUID === "") {
                                MessageBox.error(oCBPData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/BoxLabelPDFSet(GUID='${createBoxPrintLabFileGUID}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl);
                            }
                            that.footerButtonSettings("Create Box ID", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.setCreateBoxPlantsDefaults();
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oCBPData.__batchResponses[0].response.body).error.message.value);
                        }

                    },
                    error: function (oCBPError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oCBPError.responseText).error.message.value);
                        that.footerButtonSettings("Create Box ID", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                        that.setCreateBoxPlantsDefaults();
                    }
                });

            },

            modBoxPrintLabels: function (sSSCC18) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["BoxbatchDownload"]);
                var aPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aMBValidAndPrint");
                var boxQty = aPrintLabelData.length;

                for (let j of aPrintLabelData) {
                    var tempModBoxPrintLab = {};
                    tempModBoxPrintLab.BoxID = j.BoxID_BoxID;
                    tempModBoxPrintLab.StorageBin = this.sStorageBin;
                    tempModBoxPrintLab.SSCC18 = sSSCC18;
                    tempModBoxPrintLab.ModelNo = j.ModelNumber;
                    tempModBoxPrintLab.SerialNumber = j.SerialNumber;
                    tempModBoxPrintLab.AcRfbPartNumber = j.AsIsPartNumber;
                    tempModBoxPrintLab.FgPartNumber = j.FinishedGoodsMPN;
                    tempModBoxPrintLab.IMEI1 = j.IMEI1;
                    tempModBoxPrintLab.IMEI2 = j.IMEI2;
                    tempModBoxPrintLab.BoxQuantity = boxQty;
                    tempModBoxPrintLab.CountryOfOrigin = j.CountryOfOrigin;
                    tempModBoxPrintLab.EAN11 = j.EAN11;

                    this.ui5_ppModel.callFunction("/GenerateBoxLabel", {
                        method: "POST",
                        urlParameters: tempModBoxPrintLab,
                        batchGroupId: "BoxbatchDownload"
                    });
                }

                this.ui5_ppModel.submitChanges({
                    batchGroupId: "BoxbatchDownload",
                    changeSetId: 1,
                    success: function (oMBPData, oResponse) {
                        
                        if (oResponse.data.__batchResponses[0].response === undefined) {
                            var modBoxPrintLabFileGUID = oMBPData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (modBoxPrintLabFileGUID === "") {
                                MessageBox.error(oMBPData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl1 = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/BoxLabelPDFSet(GUID='${modBoxPrintLabFileGUID}')/$value?appid=${that.appId}`;
                                sap.m.URLHelper.redirect(sUrl1);
                            }
                            that.footerButtonSettings("Next", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                            that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oMBPData.__batchResponses[0].response.body).error.message.value);
                        }


                    },
                    error: function (oMBPError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(oMBPError.responseText).error.message.value);

                    }
                });

            },

            onSubsModBoxPrintLabelPress: function () {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["subsModBoxbatchDownload"]);
                var aPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aMBValidAndPrint");
                var boxQty1 = aPrintLabelData.length;
                var tempSubsModBoxPrintLab = {};
                tempSubsModBoxPrintLab.BoxID = this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod");
                tempSubsModBoxPrintLab.BoxQuantity = boxQty1;
                tempSubsModBoxPrintLab.Customer = this.getView().getModel("oGlobalModel").getProperty("/sModBoxCustomer") + " - " + this.getView().getModel("oGlobalModel").getProperty("/sModBoxCustName");
                this.ui5_ppModel.callFunction("/GenerateARTSBoxLabel", {
                    method: "POST",
                    urlParameters: tempSubsModBoxPrintLab,
                    batchGroupId: "subsModBoxbatchDownload"
                });
                
                this.ui5_ppModel.submitChanges({
                    batchGroupId: "subsModBoxbatchDownload",
                    changeSetId: 1,
                    success: function (oData, oResponse) {
                        
                        if (oData.__batchResponses[0].data === undefined) {
                            var subsModBoxPrintLabFileGUID = oData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (subsModBoxPrintLabFileGUID === "") {
                                sap.m.MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/ARTSBoxLabelPDFSet(GUID='${subsModBoxPrintLabFileGUID}')/$value?appid=${that.appId}`
                                sap.m.URLHelper.redirect(sUrl);
                            }

                            that.footerButtonSettings("Next", "Cancel");
                            that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                            that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        that.footerButtonSettings("Next", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", "");
                        that.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                    }
                });
            },

            onSubsBoxPrintLabelPress: function (oEvent) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.ui5_ppModel.setDeferredGroups(["subsBoxbatchDownload"]);
                var aPrintLabelData = this.getView().getModel("oValidAndPrintModel").getProperty("/aCBValidAndPrint");
                var boxQty1 = aPrintLabelData.length;
                var tempCreateBoxSubsPrintLab = {};
                tempCreateBoxSubsPrintLab.BoxID = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxId");
                tempCreateBoxSubsPrintLab.BoxQuantity = boxQty1;
                tempCreateBoxSubsPrintLab.Customer = this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxCustomer") + " - " + this.getView().getModel("oGlobalModel").getProperty("/sCreateBoxCustName");
                this.ui5_ppModel.callFunction("/GenerateARTSBoxLabel", {
                    urlParameters: tempCreateBoxSubsPrintLab,
                    batchGroupId: "subsBoxbatchDownload",
                    method: "POST"
                });
                
                this.ui5_ppModel.submitChanges({
                    batchGroupId: "subsBoxbatchDownload",
                    changeSetId: 1,
                    success: function (oData, oResponse) {
                        
                        if (oData.__batchResponses[0].data === undefined) {

                            var createBoxSubsFileGUID = oData.__batchResponses[0].__changeResponses[0].data.GUID;
                            if (createBoxSubsFileGUID === "") {
                                sap.m.MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MessageText);
                            } else {
                                var sUrl = `/ui5_pp/sap/opu/odata/sap/zod_ac_packaging_srv/ARTSBoxLabelPDFSet(GUID='${createBoxSubsFileGUID}')/$value?appid=${that.appId}`
                                sap.m.URLHelper.redirect(sUrl);
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                            that.footerButtonSettings("Create Box ID", "Cancel");
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            that.setCreateBoxPlantsDefaults();

                        } else {
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        }
                    },
                    error: function (oError) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        that.footerButtonSettings("Create Box ID", "Cancel");
                        that.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                        that.setCreateBoxPlantsDefaults();
                    }
                });
            },

            validateModifyBox: function (sBoxModSubTabSelKey) {
                if (sBoxModSubTabSelKey === "scanBoxId") {
                    this.setBoxService();
                    this.getBoxItems();
                } else if (sBoxModSubTabSelKey === "scanSN") {
                    this.getSerialNumberDetails("MB");
                } else if (sBoxModSubTabSelKey === "valdAndPrint") {
                    this.completeModifyBox();
                }
            },

            getBoxItems: function () {
                var that = this;
                var x = true;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.Boxmodel.read("/Boxes('" + this.getView().getModel("oGlobalModel").getProperty("/sBoxIdMod") + "')", {
                    urlParameters: {
                        "$expand": "toBoxItems"
                    },
                    success: function (data) {
                        that.boxStatus = data.Status;
                        that.setBoxStatus(data);
                        if (data.Status === "3") {
                            MessageBox.error(`Box ${data.BoxID} is already Shipped`);
                            that.bProceed = false;
                            x = false;
                        } else {
                            that.sSSCC18 = data.SSCC18;
                            that.bProceed = true;
                            if (data.toBoxItems.results.length > 0) {
                                that.mbAsIsPN = data.toBoxItems.results[0].AsIsPartNumber;
                                that.boxItemsCount = data.toBoxItems.results.length;
                                that.savedBoxItems = data.toBoxItems.results;
                                data.toBoxItems = that.mapBoxSequence(data.toBoxItems.results);
                                that.getView().getModel("oSerialNosModel").setProperty("/aModBoxSerialNos", data.toBoxItems);
                                that.receivedSNs = JSON.stringify(data.toBoxItems);
                                that.originalSNs = JSON.stringify(data.toBoxItems);
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxACRFB", data.toBoxItems[0].AsIsPartNumber);
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxFGPN", data.toBoxItems[0].FinishedGoodsMPN);
                                x = false;
                            } else {
                                that.savedBoxItems = [];
                                that.bNoBoxItems = true;
                                that.mbAsIsPN = "";
                                x = true;
                                that.boxItemsCount = 0;
                                that.getView().getModel("oSerialNosModel").setProperty("/aModBoxSerialNos", []);
                                that.receivedSNs = [];
                                that.originalSNs = [];
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxACRFB", "");
                                that.getView().getModel("oGlobalModel").setProperty("/sModBoxFGPN", "");
                            }
                            that.getView().getModel("oGlobalModel").setProperty("/sBoxIdMod", data.BoxID);
                            that.getView().getModel("oGlobalModel").setProperty("/sBoxPlant", data.Plant);

                            that.getView().getModel("oGlobalModel").setProperty("/sModBoxCustomer", data.Customer);
                            that.setCustNameAndStorageLoc(data);

                        }
                        that.navToSSN(x);
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        that.bProceed = false;
                        x = false;
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                        that.navToSSN(x);

                    }
                });

            },

            setBoxStatus: function (data) {
                if (data.Status === "0" || data.Status === "1") {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxStatus", true);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxStatus", false);
                }
            },

            setCustNameAndStorageLoc: function (data) {
                if (data.Customer !== "" && data.Customer !== undefined &&
                    this.getView().getModel("oGlobalModel").getProperty("/bSubs")) {
                    this.setModBoxCustName(data.Customer);
                }
                if (data.StorageLocation !== undefined && data.StorageLocation !== null) {
                    this.getView().getModel("oGlobalModel").setProperty("/sBoxStorageLoc", data.StorageLocation);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/sBoxStorageLoc", "");
                }
            },

            setModBoxCustName: function (customerId) {
                var aFilter = [];
                aFilter.push(new sap.ui.model.Filter("CustomerId", sap.ui.model.FilterOperator.EQ, customerId));
                this.getBoxCustomerName(aFilter);
            },

            navToSSN: function (x) {
                if (!x) {
                    if (this.bProceed) {
                        this.footerButtonSettings("Next", "Back");
                        this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanSN");
                        this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", true);
                        this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                    }

                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bBoxModEdit", true);
                    this.getView().getModel("oGlobalModel").setProperty("/bNextEnabled", false);
                    var aEmptySNs = [];
                    for (var a = 0; a < 20; a++) {
                        var oEmptySNRow = {
                            BoxSequence: (a + 1).toString(),
                            SerialNumber: ""
                        };
                        aEmptySNs.push(oEmptySNRow);
                    }
                    this.getView().getModel("oSerialNosModel").setProperty("/aModBoxSerialNos", aEmptySNs);
                    this.footerButtonSettings("Next", "Back");
                    this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanSN");
                }
            },

            mapBoxSequence: function (BoxItems) {
                var aArray = [];
                for (var l = 1; l <= 20; l++) {
                    var oBoxModNewRow = {
                        BoxSequence: l,
                        SerialNumber: ""
                    };
                    aArray.push(oBoxModNewRow);
                }

                for (let z of BoxItems) {
                    for (let a of aArray) {
                        if (z.BoxSequence === a.BoxSequence) {
                            a.SerialNumber = z.SerialNumber;
                        }
                    }
                }
                BoxItems = aArray;
                return BoxItems;
            },

            modifyBtnTxt: function (oEvent) {
                if (this.getView().getModel("oGlobalModel").getProperty("/boxTabSelKey") === "createBox") {
                    this.getView().getModel("oGlobalModel").setProperty("/boxSubTabSelKey", "genBoxId");
                    this.footerButtonSettings("Create Box ID", "Cancel");
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/boxModSubSelKey", "scanBoxId");
                    this.footerButtonSettings("Next", "Cancel");
                }
            },

            getConfigValues: function (bOriginal, sPlant) {
                var that = this;
                this.getView().getModel("busyModel").setProperty("/appBusy", true);
                this.sStorageBin = "0";

                var sPlants = "";

                this.Admin_model = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/admin-service/`, this.gModelBoxConfig);
                this.Admin_model.read("/FGPlants", {
                    success: function (data) {
                        if (bOriginal) {
                            if (data.results.length > 0) {
                                that.getView().getModel("oAdminModel").setProperty("/aConfigValues", data.results);
                            }
                            that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        } else {
                            sPlants = that.checkStorageBinPlant(data);

                            that.setMaterial(sPlants, sPlant);

                        }
                    },
                    error: function (error) {
                        that.getView().getModel("busyModel").setProperty("/appBusy", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });

            },

            checkStorageBinPlant: function (data) {
                var sPlants = "";
                if (data.results.length > 0) {

                    for (let d of data.results) {
                        if (d.ConfigName === "STORAGE_BIN_PLANT") {
                            sPlants = d.Plants;
                            break;
                        }
                    }
                }
                return sPlants;
            },

            setMaterial: function (sPlants, sPlant) {
                var sMaterial = "";
                var aPlants = [];
                if (sPlants === "") {
                    sMaterial = this.handleSuccessData[0].AsIsPartNumber;
                } else {
                    if (sPlants.includes(",")) {
                        aPlants = sPlants.split(",");

                        for (let x of aPlants) {
                            if (sPlant === x) {
                                sMaterial = this.handleSuccessData[0].FinishedGoodsMPN;
                                break;
                            }
                        }
                    } else if (sPlants === sPlant) {
                        sMaterial = this.handleSuccessData[0].FinishedGoodsMPN;
                    } else {
                        sMaterial = this.handleSuccessData[0].AsIsPartNumber;
                    }
                }
                this.getStorageBins(sMaterial)
            },

            setDestination: function (oDestName) {
                this.Metadatamodel = new sap.ui.model.odata.v2.ODataModel(`/ui5/v1/ac/metadata-service/`, this.gModelBoxConfig);
                this.setModel(this.Metadatamodel);
                if (oDestName === "SUBS") {
                    this.getView().getModel("oGlobalModel").setProperty("/bSubs", true);
                } else {
                    this.getView().getModel("oGlobalModel").setProperty("/bSubs", false);
                }
            },

            onDestSel: function (oEvent) {
                this.sDestName = this.getView().getModel("oGlobalModel").getProperty("/sBoxDestSelKey");
                this.getView().getModel("oGlobalModel").setProperty("/sPackagingKey", this.sDestName);
                this.setDestination(this.sDestName);
                this.getView().getModel("oBoxDestModel").refresh(true);
                this._destDialog.close();
                if (this.byId("idCreateBox").getSelectedKey() === "createBox") {
                    var oCreateContent = this.byId("createBoxMainSub");
                    oCreateContent.addItem(this.ofragBoxCreateSub);
                } else {
                    var oModifyContent = this.byId("modifyBoxSub");
                    oModifyContent.addItem(this.ofragBoxModSub);
                }

                this.onCreateBoxTabSel();
            }

        });
    });