sap.ui.define([
	"comapple.scp.ui./acsclogonui/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
