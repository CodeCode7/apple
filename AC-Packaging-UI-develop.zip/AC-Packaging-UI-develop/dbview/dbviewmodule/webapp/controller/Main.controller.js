sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/core/Fragment"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, SmartTable, SmartFilterBar, Fragment) {
        "use strict";
        return Controller.extend("com.apple.scp.dbviewmodule.controller.Main", {
            onInit: function () {
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        this.gModelConfig = {
                            headers: { appid: variables },
                            defaultBindingMode: "TwoWay",
                            defaultCountMode: "Inline",
                            useBatch: true
                        };
                    });
                this.initialSettings();
                fetch("/getTableDetails")
                    .then(res => res.json())
                    .then(tabledetails => {
                        this.getView().getModel("oGlobalModel").setProperty("/aEntitySets", tabledetails);
                        this.setODataModel(tabledetails[0].Path);
                        this.loadSmartTable();
                    });
            },
            initialSettings: function () {
                this.getView().setModel(new JSONModel({
                    sEntitySetSelKey: "NumberRanges"
                }), "oGlobalModel");
            },
            loadSmartTable: function () {
                this.getView().byId("idVBoxST").destroyItems(true);
                var aSmartFilterBar = new SmartFilterBar({
                    id: "smartFilterBar",
                    entitySet: this.getView().getModel("oGlobalModel").getProperty("/sEntitySetSelKey")
                });
                var aSmartTable = new SmartTable({
                    entitySet: this.getView().getModel("oGlobalModel").getProperty("/sEntitySetSelKey"),
                    smartFilterId: "smartFilterBar",
                    header: this.getView().byId("entitySetId").getSelectedItem().getText(),
                    showRowCount: true,
                    useVariantManagement: false,
                    useTablePersonalisation: true,
                    tableType: "ResponsiveTable",
                    editable: false,
                    useExportToExcel: true,
                    enableAutoBinding: true
                });
                this.getView().byId("idVBoxST").addItem(aSmartFilterBar);
                this.getView().byId("idVBoxST").addItem(aSmartTable);

            },
            onEntitySetChange: function (oEvent) {
                var selIndex = oEvent.getSource().getSelectedIndex();
                var selRow = this.getView().getModel("oGlobalModel").getProperty("/aEntitySets/" + selIndex);
                this.setODataModel(selRow.Path);
                this.getView().getModel("oGlobalModel").refresh(true);
                this.loadSmartTable();
            },
            setODataModel: function (oModelName) {
                this.oSmartTableModel = new sap.ui.model.odata.v2.ODataModel(`/ACSC_SUBS/odata/v2/${oModelName}/`, this.gModelConfig);
                this.getView().setModel(this.oSmartTableModel);
            }
        });
    });
