sap.ui.define([
	"com/apple/scp/dbviewmodule/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
