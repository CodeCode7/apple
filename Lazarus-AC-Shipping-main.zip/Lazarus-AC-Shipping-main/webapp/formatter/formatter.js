sap.ui.define([], function () {
	"use strict";
	return {
		formatHeaderCnt: function (subText, count) {
			if (count === undefined) {
				count="0";
				return subText + "("+ count +")";
			} else {
				return subText + "( " + count + ")";
			}
		},
		blankValueCheck: function (checkBlank) {
			if (checkBlank === "" || checkBlank === "0") {
				return "";
			} else {
				return checkBlank;
			}
		}
	};
});