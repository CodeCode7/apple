sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/routing/History"], function (e, t) {
	"use strict";
	return e.extend("com.apple.ui5.ZUI5_AC_SHIPMENT.views.BaseController", {
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},
		geti18n: function (e, t) {
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			var n = this._oComponent.getModel("i18n").getResourceBundle();
			return n.getText(e, Array.isArray(t) ? t : []);
		},
		getDefaultModel: function () {
			return this.getOwnerComponent().getModel("DC_SHIP");
		},
		getCustShipModel: function () {
			return this.getOwnerComponent().getModel("CUST_SHIP");
		},
		getLeanReceiptsModel: function () {
			return this.getOwnerComponent().getModel("LEAN_RECEIPTS");
		},

		getCVMValuesModel: function () {
			return this.getOwnerComponent().getModel("CVM_VALUES");
		}
	});
});