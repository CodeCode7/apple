sap.ui.define([
	"com/apple/ui5/ZUI5_AC_SHIPMENT/controller/BaseController",
	// "sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/apple/ui5/ZUI5_AC_SHIPMENT/formatter/formatter",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/util/Export",
	"sap/m/MessageToast",
	"sap/ui/model/type/String",
	'sap/m/Token',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	'sap/m/ColumnListItem',
	'sap/m/Label'
], function (BaseController, JSONModel, formatter, ODataModel, Spreadsheet, Export, MessageToast, typeString, Token, Filter,
	FilterOperator, MessageBox, ColumnListItem, Label) {
	"use strict";
	return BaseController.extend("com.apple.ui5.ZUI5_AC_SHIPMENT.controller.Main", {
		formatter: formatter,
		onInit: function () {
			this._oBusyDialog = new sap.m.BusyDialog;
			// var columnsModel = {
			// 	"cols": [{
			// 		"label": "Region",
			// 		"template": "Key",
			// 		"width": "5rem"
			// 	}, {
			// 		"label": "Short Description",
			// 		"template": "ShortDescription"
			// 	}]
			// };
			// this.oColModel = new JSONModel(columnsModel);
			// this.oRegionsModel = new JSONModel();
			// this.getView().setModel("oRegionsModel",this.oRegionsModel);

			this.oRegionTypeModel = new JSONModel();
			this.getView().setModel(this.oRegionTypeModel, "oRegionTypeModel");
			this.getUserDetails();

			this._oDCRegionInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCRegion"));
			this._oCustRegionInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCRegion"));
			this._oLeanRegionInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCRegion"));
			this._oCVMRegionInput = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMValuesRegion"));

			this._oDCSerNotNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCSerNotNo"));
			this._oCustSerNotNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCSerNotNo"));
			this._oLeanSerNotNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCSerNotNo"));

			this._oDCDispatchIdMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCDispatchiD"));
			this._oCustDispatchIdMultiInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCDispatchiD"));
			this._oLeanDispatchIdMultiInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCDispatchiD"));

			this._oDCModSerNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCModSerNo"));
			this._oCustModSerNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCModSerNo"));
			this._oLeanModSerNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCModSerNo"));

			this._oDCPurchaseOrderMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCPO"));
			this._oCustPurchaseOrderMultiInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCPO"));
			// this._oLeanPurchaseOrderMultiInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCPO"));

			this._oCustShiptoPartnerMultiInput = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCShipTo"));
			this._oLeanShiptoPartnerMultiInput = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCShipTo"));

			this._oDCMaxRows = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCMaxRows"));
			this._oCustMaxRows = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCMaxRows"));
			this._oLeanMaxRows = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCMaxRows"));
			this._oCVMMaxRows = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMMaxRows"));

			this._oDCMaxRows.setValue("500");
			this._oCustMaxRows.setValue("500");
			this._oLeanMaxRows.setValue("500");
			this._oCVMMaxRows.setValue("500");

			this._oDCShipfromPartnerMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCShipFrom"));
			this._oDCRMAMultiInput = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCMRMA"));
			this._oCVMCondType = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMConType"));
			this._oCVMPartNoMultiInput = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMPartNo"));
			this._oCVMSourCountryMultiInput = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMSourCountry"));
			this._oCVMDestCountryMultiInput = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMDestCountry"));

			// this.setViewJSONModel();
			// var sRootPath = jQuery.sap.getModulePath("com.apple.ui5.ZUI5_AC_SHIPMENT");
			// this.byId("oMainCustShip").setIcon(sRootPath + "/images/Cshipments.png");
			// this.byId("oMainDCShip").setIcon(sRootPath + "/images/DCshipments.png");
			// this.byId("oMainLeanRecipt").setIcon(sRootPath + "/images/Lean.png");
			// this.byId("oMainCVMValues").setIcon(sRootPath + "/images/CVM.png");

			this.fileShip = false;
			this.userType = "";
			this.CVMValuesFlag = "";
			this.excelData = {};
			this.ShipmentFileType = "";
			this.oFreightOrderModelRevert = {};
			this.oViewHeaderModel = new JSONModel();
			this.getView().setModel(this.oViewHeaderModel, "oViewHeaderModel");

			this.oFreightOrderModel = new JSONModel();
			this.getView().setModel(this.oFreightOrderModel, "oFreightOrderModel");

			this.oViewModel = new JSONModel();
			this.getView().setModel(this.oViewModel, "oViewModel");
			this.oViewModel.setSizeLimit(5000);

			this.oCustShipNEWSmartTable = this.getView().byId("idCustShipNEWSmartTable");
			this.oCustShipCDRSmartTable = this.getView().byId("idCustShipCDRSmartTable");
			this.oCustShipRFSSmartTable = this.getView().byId("idCustShipRFSSmartTable");
			this.oCustShipERRSmartTable = this.getView().byId("idCustShipERRSmartTable");
			this.oDCShipPPRSmartTable = this.getView().byId("idDCShipPPRSmartTable");
			this.oDCShipCDRSmartTable = this.getView().byId("idDCShipCDRSmartTable");
			this.oDCShipRFSSmartTable = this.getView().byId("idDCShipRFSSmartTable");
			this.oDCShipERRSmartTable = this.getView().byId("idDCShipERRSmartTable");
			this.oLeanNEWSmartTable = this.getView().byId("idLeanReceiptsNewSmartTable");
			this.oLeanGRSmartTable = this.getView().byId("idLeanReceiptsGRSmartTable");
			this.oCVMValuesSmartTable = this.getView().byId("idCVMValuesSmartTable");
			this.CDRBatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipCDRFreightOrderFragment", "idBatteryStatus"));
			this.RFSBatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipRFSFreightOrderFragment", "idBatteryStatus"));
			this.UpdBatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipNewPACUpdateCarrFragment", "idBatteryStatus"));

			this.oCustERDate = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idCratedDate"));
			this.oCustERDate.setFrom(new Date(this.dateFromTo(180).fromDate));
			this.oCustERDate.setTo(new Date(this.dateFromTo(180).toDate));

			this.oDCERDate = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idCratedDate"));
			this.oDCERDate.setFrom(new Date(this.dateFromTo(180).fromDate));
			this.oDCERDate.setTo(new Date(this.dateFromTo(180).toDate));

			this.oLeanERDate = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idCratedDate"));
			this.oLeanERDate.setFrom(new Date(this.dateFromTo(180).fromDate));
			this.oLeanERDate.setTo(new Date(this.dateFromTo(180).toDate));

			this.oCustCDRShipFreightOrderPanel = this.getView().byId("idCustShipCDRFreightOrderPanel");
			this.oCustShipPACFreightOrderPanel = this.getView().byId("idCustShipNewPACUpdateCarrPanel");
			this.oCustShipRFSFreightOrderPanel = this.getView().byId("idCustShipRFSFreightOrderPanel");

			this.oDCShipPACFreightOrderPanel = this.getView().byId("idDCShipNewPACUpdateCarrPanel");
			this.oDCShipCDRFreightOrderPanel = this.getView().byId("idDCShipCDRFreightOrderPanel");
			this.oDCShipRFSFreightOrderPanel = this.getView().byId("idDCShipRFSFreightOrderPanel");

			// this.oCVMERDate = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCratedDate"));
			// this.oCVMERDate.setFrom(new Date(this.dateFromTo(180).fromDate));
			// this.oCVMERDate.setTo(new Date(this.dateFromTo(180).toDate));
		},
		/*AX Radar*/
		onAfterRendering: function () {
			//jQuery.sap.delayedCall(3000, this, function () {
			document.getElementById("__xmlview0--shell-content").setAttribute('role', 'main'),
				document.getElementById("__xmlview0--shell-content").setAttribute('aria-label', 'Shipments'),
				document.getElementById("__xmlview0--page-title").setAttribute('aria-level', '1'),
				document.getElementById("__xmlview0--page-intHeader").setAttribute('role', 'presentation');
			var doc = document.getElementById("__xmlview0--page").getElementsByTagName("header")[0];
			doc.setAttribute("class", " sapMPageHeader zA11y"),
				doc.setAttribute("role", "presentation");
			// AX rdar://74513250 - Start
			// var oDCRegion = this._oDCRegionInput.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		document.getElementById("__xmlview0--idDCFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('role'),
			// 			document.getElementById("__xmlview0--idDCFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-readonly'),
			// 			document.getElementById("__xmlview0--idDCFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-expanded'),
			// 			document.getElementById("__xmlview0--idDCFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-haspopup')

			// 	}
			// }, this._oDCRegionInput);
			// var oCustRegion = this._oCustRegionInput.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		document.getElementById("__xmlview0--idCustFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('role'),
			// 			document.getElementById("__xmlview0--idCustFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-readonly'),
			// 			document.getElementById("__xmlview0--idCustFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-expanded'),
			// 			document.getElementById("__xmlview0--idCustFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-haspopup')
			// 	}
			// }, this._oCustRegionInput);
			// var oLeanRegion = this._oLeanRegionInput.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('role'),
			// 			document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCRegion-hiddenSelect").removeAttribute(
			// 				'aria-readonly'),
			// 			document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCRegion-hiddenSelect").removeAttribute(
			// 				'aria-expanded'),
			// 			document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCRegion-hiddenSelect").removeAttribute(
			// 				'aria-haspopup')
			// 	}
			// }, this._oLeanRegionInput);
			// var oCVMRegion = this._oCVMRegionInput.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('role'),
			// 			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-readonly'),
			// 			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-expanded'),
			// 			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idDCRegion-hiddenSelect").removeAttribute('aria-haspopup')
			// 	}
			// }, this._oCVMRegionInput);
			// AX rdar://74513250 - End
			/* AX issue Adding  Ttile for Expand and Collapse icon for Filter Panel- Start*/
			//Var declaration for below addEventDelegate	
			var oCustPanelFilterby = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "oCustPanelFilterby"));
			var oDCPanelFilterby = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "oDCPanelFilterby"));
			var oLeanPanelFilterby = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "oDCPanelFilterby"));
			var oCVMPanelFilterby = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "oCVMValuesFilterby"));
			oCustPanelFilterby.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--oCustPanelFilterby-CollapsedImg").setAttribute('title',
							'Filter Expand/Collapse'),
						document.getElementById("__xmlview0--idCustFilterByFragment--oCustPanelFilterby-CollapsedImg").setAttribute('aria-label',
							'Filter Expand/Collapse')

				}
			}, oCustPanelFilterby);
			oDCPanelFilterby.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--oDCPanelFilterby-CollapsedImg").setAttribute('title',
							'Filter Expand/Collapse'),
						document.getElementById("__xmlview0--idDCFilterByFragment--oDCPanelFilterby-CollapsedImg").setAttribute('aria-label',
							'Filter Expand/Collapse')

				}
			}, oDCPanelFilterby);
			oLeanPanelFilterby.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--oDCPanelFilterby-CollapsedImg").setAttribute('title',
							'Filter Expand/Collapse'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--oDCPanelFilterby-CollapsedImg").setAttribute(
							'aria-label',
							'Filter Expand/Collapse')
				}
			}, oLeanPanelFilterby);
			oCVMPanelFilterby.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--oCVMValuesFilterby-CollapsedImg").setAttribute('title',
						'Filter Expand/Collapse')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--oCVMValuesFilterby-CollapsedImg").setAttribute('aria-label',
						'Filter Expand/Collapse')
				}
			}, oCVMPanelFilterby);
			/* AX issue Adding  Ttile for Expand and Collapse icon for Filter Panel- End*/
			//Changed Date date picker accessibility Customer Shipment
			var oDateCustFilter = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCChgDate"));
			var oDateFilterBy = oDateCustFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('title', 'Select Changed Date'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-inner").removeAttribute('aria-describedby')
				}
			}, oDateCustFilter);
			//Customer Shipment Created Date AX fixes
			var oCreatedDateCustFilter = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idCratedDate"));
			var oCreatedDateFilterBy = oCreatedDateCustFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('title', 'Select Changed Date'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idCratedDate-inner").removeAttribute('aria-describedby')
				}
			}, oCreatedDateCustFilter);
			//Changed Date date picker accessibility DC Shipment
			var oDateDCFilter = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCChgDate"));
			var oDateDCFilterBy = oDateDCFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('title', 'Select Changed Date'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-inner").removeAttribute('aria-describedby')
				}
			}, oDateDCFilter);
			//DC Shipment Created Date AX fixes
			var oCreatedDateDCFilter = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idCratedDate"));
			var oCreatedDateDCFilterBy = oCreatedDateDCFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('title', 'Select Changed Date'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idCratedDate-inner").removeAttribute('aria-describedby')
				}
			}, oCreatedDateDCFilter);

			//Changed Date date picker accessibility Lean Receipts
			var oDateLRFilter = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCChgDate"));
			var oDateLRFilterBy = oDateLRFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('title',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-inner").removeAttribute('aria-describedby')
				}
			}, oDateLRFilter);
			//DC Shipment Created Date AX fixes
			var oCreatedDateLRFilter = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idCratedDate"));
			var oCreatedDateLRFilterBy = oCreatedDateLRFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('title',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idCratedDate-inner").removeAttribute('aria-describedby')
				}
			}, oCreatedDateLRFilter);

			//Changed Date date picker accessibility CVM
			var oDateCVMFromFilter = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMFrom"));
			var oDateCVMFromFilterBy = oDateCVMFromFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('title',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-inner").removeAttribute('aria-describedby')
				}
			}, oDateCVMFromFilter);

			var oDateCVMToFilter = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMTo"));
			var oDateCVMToFilterBy = oDateCVMToFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('title', 'Select Changed Date'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('aria-label',
							'Select Changed Date'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-icon").setAttribute('aria-hidden', 'false'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-inner").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-inner").removeAttribute('aria-autocomplete'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-inner").removeAttribute('aria-haspopup'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-inner").removeAttribute('aria-expanded'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-inner").removeAttribute('aria-describedby')
				}
			}, oDateCVMToFilter);

			var oImgCustFilter = this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idImageOr"));
			var oImgFilterBy = oImgCustFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('role', 'text'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").removeAttribute('title')
						// 	document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-label', 'OR'),
						// 	document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-hidden', 'true')
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").removeAttribute('aria-hidden')
				}
			}, oImgCustFilter);

			var oImgDCFilter = this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idImageOr"));
			var oImgDCFilterBy = oImgDCFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idImageOr").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr-img").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-label',	'OR'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-hidden','true')
						document.getElementById("__xmlview0--idDCFilterByFragment--idImageOr").removeAttribute('title')
				}
			}, oImgDCFilter);

			var oImgLRFilter = this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idImageOr"));
			var oImgLRFilterBy = oImgLRFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idImageOr").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr-img").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-label',	'OR'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-hidden','true')
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idImageOr").removeAttribute('title')
				}
			}, oImgLRFilter);

			var oImgCVMFilter = this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idImageOr"));
			var oImgCVMFilterBy = oImgCVMFilter.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idImageOr").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr-img").setAttribute('role', 'text'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-label',	'OR'),
						// document.getElementById("__xmlview0--idCustFilterByFragment--idImageOr").setAttribute('aria-hidden','true')
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idImageOr").removeAttribute('title')
				}
			}, oImgCVMFilter);

			/*Radar#75209170 AX issues - Start*/
			//Customer Shipment
			this._oCustDispatchIdMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-label', 'Disptach ID'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustDispatchIdMultiInput);
			this._oCustSerNotNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-label',
							'Service Notification No.'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustSerNotNoMultiInput);
			this._oCustShiptoPartnerMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").setAttribute('aria-label', 'Ship-To Partner')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustShiptoPartnerMultiInput);
			this._oCustModSerNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-label',
							'Module Serial Number')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustModSerNoMultiInput);
			this._oCustPurchaseOrderMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").setAttribute('aria-label', 'Purchase Order')
					document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustPurchaseOrderMultiInput);
			//DC Shipment
			this._oDCModSerNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-label',
							'Module Serial Number')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-vhi").removeAttribute('aria-hidden')

				}
			}, this._oDCDispatchIdMultiInput);
			this._oDCShipfromPartnerMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").setAttribute('aria-label', 'Ship-From Partner')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-vhi").removeAttribute('aria-hidden')
				}
			}, this._oDCShipfromPartnerMultiInput);
			this._oDCPurchaseOrderMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").setAttribute('aria-label', 'Purchase Order')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-vhi").removeAttribute('aria-hidden')
				}
			}, this._oDCPurchaseOrderMultiInput);
			this._oDCRMAMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").setAttribute('aria-label', 'RMA')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-vhi").removeAttribute('aria-hidden')
				}
			}, this._oDCRMAMultiInput);
			this._oDCDispatchIdMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-label', 'Disptach ID')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-vhi").removeAttribute('aria-hidden')
				}
			}, this._oDCDispatchIdMultiInput);
			this._oDCSerNotNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-label',
							'Service Notification No.')
					document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oDCSerNotNoMultiInput);
			//Lean Receipts
			this._oLeanDispatchIdMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").setAttribute('aria-label',
							'Disptach ID')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-vhi").removeAttribute('aria-hidden')
				}
			}, this._oLeanDispatchIdMultiInput);
			this._oLeanSerNotNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").setAttribute('aria-label',
							'Service Notification No.')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oLeanSerNotNoMultiInput);
			this._oLeanShiptoPartnerMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").setAttribute('aria-label',
							'Ship-To Partner')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCustShiptoPartnerMultiInput);
			this._oLeanModSerNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").setAttribute('aria-label',
							'Module Serial Number'),
						document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oLeanModSerNoMultiInput);
			//CVM Values
			
			this._oCVMPartNoMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").setAttribute('aria-haspopup', 'dialog'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").setAttribute('aria-label', 'Part Numer')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCVMPartNoMultiInput);
			this._oCVMSourCountryMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").setAttribute('aria-label',
							'Source Country')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCVMSourCountryMultiInput);
			this._oCVMDestCountryMultiInput.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-inner").setAttribute('aria-hidden', 'true'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-inner").setAttribute('tabindex', '-1')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").setAttribute('role', 'button'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").setAttribute('aria-haspopup',
							'dialog'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").setAttribute('tabindex', '0'),
						document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").setAttribute('aria-label',
							'Destination Country')
					document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-vhi").removeAttribute('aria-hidden')
				}
			}, this._oCVMDestCountryMultiInput);
			/*Radar#75209170 AX issues - END*/
			/* rdar://75733823 rdar://75774502  rdar://75799032  rdar://76094467 AX Select All issue -START */
			this.oCustShipNEWSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oCustShipSubMenuNew").removeAttribute('role'),
						document.getElementById("__xmlview0--oCustShipSubMenuNew").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End
					// 	// rdar://75799032 AX Select All
					// 	document.getElementById("__xmlview0--oCustNewTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oCustNewTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oCustNewTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oCustNewTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }
					// var oHeader = document.getElementById("__xmlview0--oCustNewTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oCustNewTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oCustNewTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oCustNewTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oCustNewTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }
					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idCustShipNEWSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog');
				}
			}, this.oCustShipNEWSmartTable);
			this.oCustShipCDRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oCustShipSubMenuCDR").removeAttribute('role'),
						document.getElementById("__xmlview0--oCustShipSubMenuCDR").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oCustCDRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oCustCDRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oCustCDRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oCustCDRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oCustCDRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oCustCDRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oCustCDRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oCustCDRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oCustCDRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }
					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idCustShipCDRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oCustShipCDRSmartTable);
			this.oCustShipRFSSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oCustShipSubMenuRFS").removeAttribute('role'),
						document.getElementById("__xmlview0--oCustShipSubMenuRFS").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oCustRFSTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oCustRFSTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oCustRFSTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oCustRFSTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oCustRFSTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oCustRFSTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oCustRFSTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oCustRFSTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oCustRFSTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idCustShipRFSSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oCustShipRFSSmartTable);
			this.oCustShipERRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oCustShipSubMenuERR").removeAttribute('role'),
						document.getElementById("__xmlview0--oCustShipSubMenuERR").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oCustERRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oCustERRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oCustERRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oCustERRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oCustERRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oCustERRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oCustERRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oCustERRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }

					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oCustERRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idCustShipERRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oCustShipERRSmartTable);

			this.oDCShipPPRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oDCShipSubMenuPPRContainer").removeAttribute('role'),
						document.getElementById("__xmlview0--oDCShipSubMenuPPRContainer").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End
					// 	document.getElementById("__xmlview0--oDCPPRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oDCPPRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oDCPPRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oDCPPRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oDCPPRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oDCPPRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oDCPPRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oDCPPRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oDCPPRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idDCShipPPRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oDCShipPPRSmartTable);
			this.oDCShipCDRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oDCShipSubMenuCDRContainer").removeAttribute('role'),
						document.getElementById("__xmlview0--oDCShipSubMenuCDRContainer").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oDCCDRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oDCCDRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oDCCDRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oDCCDRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oDCCDRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oDCCDRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oDCCDRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oDCCDRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oDCCDRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idDCShipCDRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oDCShipCDRSmartTable);
			this.oDCShipRFSSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oDCShipSubMenuRFSContainer").removeAttribute('role'),
						document.getElementById("__xmlview0--oDCShipSubMenuRFSContainer").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// document.getElementById("__xmlview0--oDCRFSTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oDCRFSTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oDCRFSTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oDCRFSTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }
					// var oHeader = document.getElementById("__xmlview0--oDCRFSTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oDCRFSTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oDCRFSTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oDCRFSTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oDCRFSTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idDCShipRFSSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oDCShipRFSSmartTable);
			this.oDCShipERRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--oDCShipSubMenuERRContainer").removeAttribute('role'),
						document.getElementById("__xmlview0--oDCShipSubMenuERRContainer").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oDCERRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oDCERRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oDCERRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oDCERRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oDCERRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oDCERRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oDCERRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oDCERRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oDCERRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idDCShipERRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oDCShipERRSmartTable);

			this.oLeanNEWSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--idLeanReceiptsNewPanel").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsNewPanel").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oLeanReceiptsNewTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oLeanReceiptsNewTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oLeanReceiptsNewTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oLeanReceiptsNewTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }
					// var oHeader = document.getElementById("__xmlview0--oLeanReceiptsNewTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oLeanReceiptsNewTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oLeanReceiptsNewTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oLeanReceiptsNewTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oLeanReceiptsNewTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idLeanReceiptsNewSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oLeanNEWSmartTable);
			this.oLeanGRSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--idLeanReceiptsGRPanel").removeAttribute('role'),
						document.getElementById("__xmlview0--idLeanReceiptsGRPanel").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oLeanReceiptsGRTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oLeanReceiptsGRTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oLeanReceiptsGRTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oLeanReceiptsGRTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }

					// var oHeader = document.getElementById("__xmlview0--oLeanReceiptsGRTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oLeanReceiptsGRTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oLeanReceiptsGRTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oLeanReceiptsGRTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oLeanReceiptsGRTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idLeanReceiptsGRSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oLeanGRSmartTable);

			this.oCVMValuesSmartTable.addEventDelegate({
				onAfterRendering: function () {
					//rdar:75733823 - VoiceOver does not read the toolbar - Start
					document.getElementById("__xmlview0--idCVMValuesPanel").removeAttribute('role'),
						document.getElementById("__xmlview0--idCVMValuesPanel").removeAttribute('aria-labelledby')
					var oTableToolBar = this.$().find('.sapMIBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
						//rdar:75733823 - VoiceOver does not read the toolbar - End

					// 	document.getElementById("__xmlview0--oCVMValuesTable-selall").setAttribute('role', 'checkbox'),
					// 	document.getElementById("__xmlview0--oCVMValuesTable-selall").setAttribute('aria-checked', true),
					// 	document.getElementById("__xmlview0--oCVMValuesTable-selall").setAttribute('aria-label', 'Select All');
					// //Row Checkboxes.
					// var oRowCheckBox = document.getElementById("__xmlview0--oCVMValuesTable-sapUiTableRowHdrScr");
					// var d = oRowCheckBox.childNodes;
					// for (var j = 0; j < d.length; j++) {
					// 	d[j].setAttribute('role', 'checkbox'),
					// 		d[j].setAttribute('aria-checked', true),
					// 		d[j].setAttribute('aria-label', 'Select Row' + j)
					// }
					// var oHeader = document.getElementById("__xmlview0--oCVMValuesTable-header");
					// var k = oHeader.childNodes[1].childNodes[0];
					// document.getElementById("__xmlview0--oCVMValuesTable-sapUiTableGridCnt").removeAttribute('aria-labelledby'),
					// 	/* AX:Adding AX Caption context to table */
					// 	document.getElementById("__xmlview0--oCVMValuesTable-sapUiTableGridCnt").setAttribute('aria-label',
					// 		'New Customer Shipments (To perform row selection use spacebar or Enter key)'),
					// 	/*AX: Making unnecessary wrapper div hidden from voice over by adding aria-hidden  true and role as presentation*/
					// 	document.getElementById("__xmlview0--oCVMValuesTable-rsz").setAttribute('aria-hidden', 'true')
					// var oDiv1 = this.$().find('.sapUiTableColHdrCnt');
					// oDiv1[0].setAttribute('role', 'presentation'),
					// 	/*AX:Setting role rowgroup to tbody of the table header*/
					// 	oHeader.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX:Changing AX attributes on chikdnodes of tr of the tbody of the table header in dom */
					// for (var i = 0; i < k.childElementCount - 1; i++) {
					// 	oHeader.childNodes[1].childNodes[0].childNodes[i].removeAttribute('aria-haspopup'),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('aria-haspopup',
					// 			true),
					// 		oHeader.childNodes[1].childNodes[0].childNodes[i].childNodes[0].childNodes[0].childNodes[0].setAttribute('role', 'button')
					// }
					// /*AX:Setting role rowgroup to tbody of the table data*/
					// var t = document.getElementById("__xmlview0--oCVMValuesTable-table");
					// t.childNodes[1].setAttribute('role', 'rowgroup');
					// /*AX: Changing attributes of td of each trs of the table data */
					// for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
					// 	for (var m = 0; m < t.childNodes[1].childNodes[l].childElementCount - 1; m++) {
					// 		t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-labelledby'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('headers'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].removeAttribute('aria-selected'),
					// 			t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].setAttribute('role', 'presentation')
					// 	}
					// }

					// /*AX:Variant rdar://76094467*/
					// document.getElementById("__xmlview0--idCVMValuesSmartTable-variant-trigger").setAttribute('aria-haspopup', 'dialog')
				}
			}, this.oCVMValuesSmartTable);
			/*rdar://75733823 rdar://75774502 rdar://75799032  rdar://76094467 AX issues -END*/
			/*Radar #76417562 #76419557 #76437734- Start*/
			this.oCustCDRShipFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelledby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oCustCDRShipFreightOrderPanel);
			this.oCustShipPACFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelleby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oCustShipPACFreightOrderPanel);
			this.oCustShipRFSFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelleby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oCustShipRFSFreightOrderPanel);

			this.oDCShipPACFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelleby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oDCShipPACFreightOrderPanel);
			this.oDCShipCDRFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelleby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oDCShipCDRFreightOrderPanel);
			this.oDCShipRFSFreightOrderPanel.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMPanel');
					for (var i = 0; i < oPanel.length; i++) {
						document.getElementById(oPanel[i].id).removeAttribute('role');
						document.getElementById(oPanel[i].id).removeAttribute('aria-labelleby');
					}
					var oTableToolBar = this.$().find('.zTableToolBar');
					document.getElementById(oTableToolBar[0].id).setAttribute('role', 'group')
					document.getElementById(oTableToolBar[0].id).setAttribute('aria-label', 'Toolbar')
					var oLabel = document.getElementsByClassName('zFreightOrderLabel');
					document.getElementById(oLabel[0].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[0].id).setAttribute('aria-label', '2')
					document.getElementById(oLabel[1].id).setAttribute('role', 'heading')
					document.getElementById(oLabel[1].id).setAttribute('aria-label', '2')
				}
			}, this.oDCShipRFSFreightOrderPanel);
			/*Radar #76417562 #76419557 #76437734 - END*/
			// });
		},
		/*AX Radar #76321283,#76338275, #76389088 ,#74234740 - Start*/
		_showMessageBoxError: function (message) {
			var that = this;
			MessageBox.error(message, {
				onClose: function (oAction) {
					that._modalKeyFocusOut();
				}
			});
			that._modalKeyFocusIn();
		},
		_showMessageBoxSuccess: function (message) {
			var that = this;
			var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.success(message, {
				styleClass: bCompact ? "sapUiSizeCompact" : "",
				actions: [MessageBox.Action.OK],
				initialFocus: MessageBox.Action.OK,
				onClose: function (oAction) {}
			});
			var oHeader = document.getElementsByClassName('sapMDialogTitle');
			oHeader[0].setAttribute('role', 'presentation');
			var oFooter = document.getElementsByClassName('sapMDialogFooter');
			oFooter[0].setAttribute('role', 'presentation');
			var oDialogId = document.getElementsByClassName('sapMMessageBoxSuccess')[0].id;
			document.getElementById(oDialogId + "-firstfe").removeAttribute('tabindex');
			document.getElementById(oDialogId + "-header").removeAttribute('role');
			document.getElementById(oDialogId + "-header").removeAttribute('aria-level');
			document.getElementById(oDialogId + "-footer").removeAttribute('role');
		},
		_showMessageBoxShow: function () {
			var oHeader = document.getElementsByClassName('sapMDialogTitle');
			oHeader[0].setAttribute('role', 'presentation');
			var oFooter = document.getElementsByClassName('sapMDialogFooter');
			oFooter[0].setAttribute('role', 'presentation');
			var oDialogId = document.getElementsByClassName('sapMMessageBoxStandard')[0].id;
			document.getElementById(oDialogId + "-firstfe").removeAttribute('tabindex');
			document.getElementById(oDialogId + "-header").removeAttribute('role');
			document.getElementById(oDialogId + "-header").removeAttribute('aria-level');
			document.getElementById(oDialogId + "-footer").removeAttribute('role');
		},
		_showMessageBoxWarning: function () {
			var oHeader = document.getElementsByClassName('sapMDialogTitle');
			oHeader[0].setAttribute('role', 'presentation');
			var oFooter = document.getElementsByClassName('sapMDialogFooter');
			oFooter[0].setAttribute('role', 'presentation');
			var oDialogId = document.getElementsByClassName('sapMDialogWarning')[0].id;
			document.getElementById(oDialogId + "-firstfe").removeAttribute('tabindex');
			document.getElementById(oDialogId + "-header").removeAttribute('role');
			document.getElementById(oDialogId + "-header").removeAttribute('aria-level');
			document.getElementById(oDialogId + "-footer").removeAttribute('role');
		},
		_modalKeyFocusIn: function () {
			document.getElementById('content').setAttribute('aria-hidden', 'true');
			document.getElementById('content').tabIndex = "-1";

			var oHeader = document.getElementsByClassName('sapMDialogTitle');
			oHeader[0].setAttribute('role', 'presentation');

			var oFooter = document.getElementsByClassName('sapMDialogFooter');
			oFooter[0].setAttribute('role', 'presentation');

			var oDialogId = document.getElementsByClassName('sapMMessageBoxError')[0].id;
			document.getElementById(oDialogId + "-firstfe").removeAttribute('tabindex');
			document.getElementById(oDialogId + "-header").removeAttribute('role');
			document.getElementById(oDialogId + "-header").removeAttribute('aria-level');
			document.getElementById(oDialogId + "-footer").removeAttribute('role');
		},
		_modalKeyFocusOut: function () {
			document.getElementById('content').removeAttribute("aria-hidden");
			document.getElementById('content').removeAttribute('tabIndex');
		},
		/*AX Radar #76321283,#76338275, #76389088 ,#74234740  - End*/
		// /*AX 76359260*/
		// _cdrCustEmptyCellDomHandle: function (oData) {
		// 	/*AX 76359260 : Aria-Hidden true for empty reference no and freight no*/
		// 	var cdrCount = oData.results.length;
		// 	var t = document.getElementById("__xmlview0--oCustCDRTable-table");
		// 	for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
		// 		// 		// for (var m = 0; m < 2; m++) {
		// 		// 			// if (m < 2) {
		// 		// 				// if (!t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].childNodes[0].firstChild) {
		// 		if (!oData.results[l].FreightOrder) {
		// 			t.childNodes[1].childNodes[l].childNodes[0].setAttribute('aria-hidden', 'true')
		// 		}
		// 		if (!oData.results[l].ReferenceNo) {
		// 			t.childNodes[1].childNodes[l].childNodes[1].setAttribute('aria-hidden', 'true')
		// 		}
		// 		// 			// }}
		// 		// 		}
		// 	}
		// },
		// _cdrDCEmptyCellDomHandle: function (oData) {
		// 	/*AX 76359260 : Aria-Hidden true for empty reference no and freight no*/
		// 	var cdrCount = oData.results.length;
		// 	var t = document.getElementById("__xmlview0--oDCCDRTable-table");
		// 	for (var l = 0; l < t.childNodes[1].childElementCount; l++) {
		// 		// 		// for (var m = 0; m < 2; m++) {
		// 		// 			// if (m < 2) {
		// 		// 				// if (!t.childNodes[1].childNodes[l].childNodes[m].childNodes[0].childNodes[0].firstChild) {
		// 		if (!oData.results[l].FreightOrder) {
		// 			t.childNodes[1].childNodes[l].childNodes[0].setAttribute('aria-hidden', 'true')
		// 		}
		// 		if (!oData.results[l].ReferenceNo) {
		// 			t.childNodes[1].childNodes[l].childNodes[1].setAttribute('aria-hidden', 'true')
		// 		}
		// 		// 			// }
	// } }
		// 	}
		// },

		/*Radar #74739617,74854728 - Start*/
		onCustChangeDate: function () {
			document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-cal--Head-next").setAttribute('aria-label', 'Next month'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-cal--Head-next").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-cal--Head-prev").setAttribute('aria-label',
					'Previous month'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-cal--Head-prev").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-RP-popover-cont").removeAttribute('role'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-RP-popover-firstfe").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idCustFilterByFragment--idDCChgDate-RP-popover").setAttribute('aria-label', 'Date picker')
		},
		onDCChangeDate: function () {
			document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-cal--Head-next").setAttribute('aria-label', 'Next month'),
				document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-cal--Head-next").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-cal--Head-prev").setAttribute('aria-label',
					'Previous month'),
				document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-cal--Head-prev").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-RP-popover-cont").removeAttribute('role'),
				document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-RP-popover-firstfe").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idDCFilterByFragment--idDCChgDate-RP-popover").setAttribute('aria-label', 'Date picker')
		},
		onLeanChangeDate: function () {
			document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-cal--Head-next").setAttribute('aria-label',
					'Next month'),
				document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-cal--Head-next").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-cal--Head-prev").setAttribute('aria-label',
					'Previous month'),
				document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-cal--Head-prev").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-RP-popover-cont").removeAttribute('role'),
				document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-RP-popover-firstfe").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCChgDate-RP-popover").setAttribute('aria-label',
					'Date picker')
		},
		onCVMFromDate: function () {
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-cal--Head-next").setAttribute('aria-label',
					'Next month'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-cal--Head-next").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-cal--Head-prev").setAttribute('aria-label',
					'Previous month'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-cal--Head-prev").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-RP-popover-cont").removeAttribute('role'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-RP-popover-firstfe").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMFrom-RP-popover").setAttribute('aria-label', 'Date picker')
		},
		onCVMToDate: function () {
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-cal--Head-next").setAttribute('aria-label', 'Next month'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-cal--Head-next").removeAttribute('tabindex'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-cal--Head-prev").setAttribute('aria-label',
					'Previous month'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-cal--Head-prev").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-RP-popover-cont").removeAttribute('role'),
				document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-RP-popover-firstfe").removeAttribute('tabindex')
			document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMTo-RP-popover").setAttribute('aria-label', 'Date picker')
		},
		/*Radar #74739617,74854728 - END*/
		getUserDetails: function () {
			this._oBusyDialog.open();
			this.gCustShipment = this.getCustShipModel();
			this.getView().setModel(this.gCustShipment);
			this.gCustShipment.read("/UserDateFormatSet('')", {
				success: function (oDataUserProfile) {
					this.UserDateFormat = oDataUserProfile.DateFormat.replace("DD", "dd");
				}.bind(this),
				error: function (oError) {
					this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			var that = this;
			that.gCustShipment.read("/UserSet('')", {
				success: function (oData) {
					that.userType = oData.UserType;
					that.CVMValuesFlag = oData.CVMValues;
					if (oData.CVMValues === "X") {
						that.getView().byId("oMainCVMValues").setVisible(true);
					}
					if (oData.UserType === "I") {
						that.gCustShipment.read("/InternalSet", {
							success: function (odata) {
								if (odata.results.length > 0) {
									odata.results[0].userType = that.userType
									odata.DateFormat = that.UserDateFormat;
									odata.CVMValues = that.CVMValuesFlag;
									that.oRegionTypeModel.setData(odata);
									that._oCustRegionInput.setSelectedKey(odata.results[0].Key);
									that._oDCRegionInput.setSelectedKey(odata.results[0].Key);
									that._oLeanRegionInput.setSelectedKey(odata.results[0].Key);
									// that._oCVMRegionInput.setSelectedKey(odata.results[0].Key);
									that.getCustShip("NEW", "ToNew");
									that.oMainSelectedKey = "CUSTSHIP";
								} else {
									that._oBusyDialog.close();
									that._showMessageBoxError("No Authorization");
									//MessageBox.error("No Authorization");
								}
							},
							error: function (oError) {
								that._oBusyDialog.close();
								that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
								//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}
						});
					} else if (oData.UserType === "E") {
						that.gCustShipment.read("/ExternalSet", {
							success: function (odata) {
								if (odata.results.length > 0) {
									odata.userType = that.userType;
									odata.DateFormat = that.UserDateFormat;
									// odata.Region = "PAC";
									that.oRegionTypeModel.setData(odata);
									that._oDCRegionInput.setSelectedKey(odata.results[0].Key);
									that._oCustRegionInput.setSelectedKey(odata.results[0].Key);
									that._oLeanRegionInput.setSelectedKey(odata.results[0].Key);
									// that_oCVMRegionInput.setSelectedKey(odata.results[0].Key);
									that.getCustShip("NEW", "ToNew");
									that.oMainSelectedKey = "CUSTSHIP";
								} else {
									that._oBusyDialog.close();
									that._showMessageBoxError("No Authorization");
									//MessageBox.error("No Authorization");
								}
							},
							error: function (oError) {
								that._oBusyDialog.close();
								that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
								//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}
						});
					}

				}.bind(that),
				error: function (oError) {
					that._oBusyDialog.close();
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onMainMenuSelect: function (oEvent) {
			var oMainMenu = this.getView().byId("oMainMenuBar");
			if (oMainMenu.getSelectedKey() === "CUSTSHIP") {
				this.fileShip = false;
				this.oMainSelectedKey = "CUSTSHIP";
				this.getView().byId("oCustShipSubMenu").setSelectedKey("CUSTNEW");
				this.getCustShip("NEW", "ToNew");
			} else if (oMainMenu.getSelectedKey() === "DCSHIP") {
				this.gDCShipment = this.getDefaultModel();
				this.getView().setModel(this.gDCShipment);
				this.fileShip = false;
				this.oMainSelectedKey = "DCSHIP";
				this.getView().byId("oDCShipSubMenu").setSelectedKey("DCPPR");
				this.getDCShip("PPR", "ToPartsPendingReturn");
			} else if (oMainMenu.getSelectedKey() === "LEANREC") {
				this.gLeanReceipts = this.getLeanReceiptsModel();
				this.getView().setModel(this.gLeanReceipts);
				this.fileShip = false;
				this.oMainSelectedKey = "LEANREC";
				this.getView().byId("oLeanReceiptsSubMenu").setSelectedKey("NEW");
				this.getLean("NEW", "ToNew");
			} else if (oMainMenu.getSelectedKey() === "CVMVALUES") {
				this.getCVMValues = this.getCVMValuesModel();
				this.getView().setModel(this.getCVMValues);
				this.fileShip = false;
				this.oMainSelectedKey = "CVMVALUES";
				// this.getCVMVal();
			}
		},
		onSubCustShipMenuSelect: function (oEvent) {
			if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTNEW") {
				this.getCustShip("NEW", "ToNew");
			}
			if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTCDR") {
				this.getCustShip("CDR", "ToCarrierDetermined");
			}
			if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTRFS") {
				this.getCustShip("RFS", "ToReadyForShipment");
			}
			if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTERR") {
				this.getCustShip("ERR", "ToError");
			}
		},
		onSubDCShipMenuSelect: function (oEvent) {
			if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCPPR") {
				this.getDCShip("PPR", "ToPartsPendingReturn");
			}
			if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCCDR") {
				this.getDCShip("CDR", "ToCarrierDetermined");
			}
			if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCRFS") {
				this.getDCShip("RFS", "ToReadyForShip");
			}
			if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCERR") {
				this.getDCShip("ERR", "ToError");
			}
		},
		onSubLeanReceiptsMenuSelect: function (oEvent) {
			if (this.getView().byId("oLeanReceiptsSubMenu").getSelectedKey() === "NEW") {
				this.getLean("NEW", "ToNew");
			}
			if (this.getView().byId("oLeanReceiptsSubMenu").getSelectedKey() === "GRC") {
				this.getLean("GRC", "ToGRCompleted");
			}
		},
		handleChange: function (oEvent) {
			var sFrom = oEvent.getParameter("from"),
				sTo = oEvent.getParameter("to");
		},
		dateFromTo: function (days) {
			var currentDate = new Date();
			var newDate = new Date(currentDate);
			// newDate.setDate(newDate.getDate() - days);
			// var fromDate = (newDate.getFullYear() + "," + ("0" + (newDate.getMonth() + 1)).slice(-2) + "," + newDate.getDate());
			// var toDate = (currentDate.getFullYear() + "," + ("0" + (currentDate.getMonth() + 1)).slice(-2) + "," + currentDate.getDate());
			return {
				fromDate: newDate.setDate(newDate.getDate() - days),
				toDate: currentDate
			};
		},
		getCustShip: function (sSelect, oExpand) {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("CUSTSHIP", sSelect);
			} else {
				aFilter = this.getFileFilter(sSelect, this.excelData, this.ShipmentFileType, this._oCustRegionInput.getSelectedKey());
			}
			var that = this;
			var expand = oExpand + "," + "ToCounts";
			that.gCustShipment.read('/SearchSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': expand
				},
				success: function (oData, resp) {
					oData.results[0].ToCounts.results[0].Type = sSelect;
					oData.results[0].ToCounts.results[0].Region = that._oCustRegionInput.getSelectedKey();
					that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
					if (sSelect === "NEW") {
						that.oViewModel.setData(oData.results[0].ToNew);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oCustShipSubMenuNew").setVisible(true);
						that.getView().byId("idCustShipNewPACUpdateCarrPanel").setVisible(false);
					}
					if (sSelect === "CDR") {
						that.oViewModel.setData(oData.results[0].ToCarrierDetermined);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oCustShipSubMenuCDR").setVisible(true);
						that.getView().byId("idCustShipCDRFreightOrderPanel").setVisible(false);
					}
					if (sSelect === "RFS") {
						that.oViewModel.setData(oData.results[0].ToReadyForShipment);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oCustShipSubMenuRFS").setVisible(true);
						that.getView().byId("idCustShipRFSFreightOrderPanel").setVisible(false);
					}
					if (sSelect === "ERR") {
						that.oViewModel.setData(oData.results[0].ToError);
						that.oViewHeaderModel.refresh(true);
					}
					that.clearCustTableColumnFilters();
					that._oBusyDialog.close();
					// /*AX: Function call to do dom changes once CDR data is update in dom*/
					// if (sSelect === "CDR") {
					// 	that._cdrCustEmptyCellDomHandle(oData.results[0].ToCarrierDetermined);
					// }
				}.bind(that),
				error: function (oError) {
					that.oViewModel.setData({});
					that._oBusyDialog.close();
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		getDCShip: function (sSelect, oExpand) {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("DCSHIP", sSelect);
			} else {
				aFilter = this.getFileFilter(sSelect, this.excelData, this.ShipmentFileType, this._oDCRegionInput.getSelectedKey());
			}
			var that = this;
			var expand = oExpand + "," + "ToCounts";
			that.gDCShipment.read('/SearchRequestSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': expand
				},
				success: function (oData, resp) {
					that.clearDCTableColumnFilters();
					oData.results[0].ToCounts.results[0].Type = sSelect;
					oData.results[0].ToCounts.results[0].Region = that._oDCRegionInput.getSelectedKey();
					that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
					if (sSelect === "PPR") {
						that.oViewModel.setData(oData.results[0].ToPartsPendingReturn);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oDCShipSubMenuPPRContainer").setVisible(true);
						that.getView().byId("idDCShipNewPACUpdateCarrPanel").setVisible(false);
					}
					if (sSelect === "CDR") {
						that.oViewModel.setData(oData.results[0].ToCarrierDetermined);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oDCShipSubMenuCDRContainer").setVisible(true);
						that.getView().byId("idDCShipCDRFreightOrderPanel").setVisible(false);
					}
					if (sSelect === "RFS") {
						that.oViewModel.setData(oData.results[0].ToReadyForShip);
						that.oViewHeaderModel.refresh(true);
						that.getView().byId("oDCShipSubMenuRFSContainer").setVisible(true);
						that.getView().byId("idDCShipRFSFreightOrderPanel").setVisible(false);
					}
					if (sSelect === "ERR") {
						that.oViewModel.setData(oData.results[0].ToError);
						that.oViewHeaderModel.refresh(true);
					}
					// that.resetDCShipFilterBy();
					that._oBusyDialog.close();
					// /*AX: Function call to do dom changes once CDR data is update in dom*/
					// if (sSelect === "CDR") {
					// 	that._cdrDCEmptyCellDomHandle(oData.results[0].ToCarrierDetermined);
					// }
				}.bind(that),
				error: function (oError) {
					that.oViewModel.setData({});
					// that.oViewHeaderModel.setData({});
					that._oBusyDialog.close();
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		getLean: function (sSelect, oExpand) {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("LEANREC", sSelect);
			} else {
				aFilter = this.getFileFilter(sSelect, this.excelData, this.ShipmentFileType, this._oLeanRegionInput.getSelectedKey());
			}
			var that = this;
			var expand = oExpand + "," + "ToCounts";
			that.gLeanReceipts.read('/SearchSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': expand
				},
				success: function (oData, resp) {
					that.clearDCTableColumnFilters();
					oData.results[0].ToCounts.results[0].Type = sSelect;
					oData.results[0].ToCounts.results[0].Region = that._oLeanRegionInput.getSelectedKey();
					that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
					if (sSelect === "NEW") {
						that.oViewModel.setData(oData.results[0].ToNew);
						that.oViewHeaderModel.refresh(true);
						that.oViewModel.refresh(true);
					}
					if (sSelect === "GRC") {
						that.oViewModel.setData(oData.results[0].ToGRCompleted);
						that.oViewHeaderModel.refresh(true);
						that.oViewModel.refresh(true);
					}
					that.clearLeanTableColumnFilters();
					that._oBusyDialog.close();
				}.bind(that),
				error: function (oError) {
					that.oViewModel.setData({});
					that._oBusyDialog.close();
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		getCVMVal: function () {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("CVMVALUES");
			} else {
				aFilter = this.getFileFilter("", this.excelData, this.ShipmentFileType);
			}
			var that = this;
			that.getView().byId("oCVMValuesTable").setVisibleRowCount(0);
			that.getCVMValues.read('/SearchSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': 'ToCVMValues'
				},
				success: function (oData, resp) {
					if (oData.results.length > 0) {
						that.getView().byId("oCVMValuesTable").setVisibleRowCount(13);
						that.oViewModel.setData(oData.results[0].ToCVMValues);
						that.oViewModel.refresh();
						that._oBusyDialog.close();
					} else {
						that.getView().byId("oCVMValuesTable").setVisibleRowCount(0);
						that._oBusyDialog.close();
					}
				}.bind(that),
				error: function (error) {
					that._oBusyDialog.close();
					that._showMessageBoxError(JSON.parse(error.responseText).error.message.value);
					// MessageBox.error(JSON.parse(error.responseText).error.message.value);
					that.getView().byId("oCVMValuesTable").setVisibleRowCount(0);
					if (that.fileShip === true) {
						that._showMessageBoxError(JSON.parse(error.responseText).error.message.value);
						//MessageBox.error(JSON.parse(error.responseText).error.message.value);
					}
				}
			});
		},
		/*Search Functionality*/
		onDCShipSearch: function (fileFilter) {
			this._oBusyDialog.open();
			var aFilter = [];
			var that = this;
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("DCSHIP", "");
			} else {
				aFilter = fileFilter;
			}
			that.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "oDCPanelFilterby")).setExpanded(false);
			that.clearDCTableColumnFilters();
			that.gDCShipment.read('/SearchRequestSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': 'ToPartsPendingReturn,ToCarrierDetermined,ToReadyForShip,ToError,ToCounts'
				},
				success: function (oData, resp) {
					oData.results[0].ToCounts.results[0].Region = that._oDCRegionInput.getSelectedKey();
					if (oData.results[0].Type === "") {
						that.oViewModel.setData({});
						that.oViewHeaderModel.setData({});
					} else {
						if (oData.results[0].Type === "PPR") {
							that.getView().byId("oDCShipSubMenu").setSelectedKey("DCPPR");
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							//						that.oViewHeaderModel.setProperty("/dcShipList", oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToPartsPendingReturn);
							that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "CDR") {
							that.getView().byId("oDCShipSubMenu").setSelectedKey("DCCDR");
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToCarrierDetermined);
							that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "RFS") {
							that.getView().byId("oDCShipSubMenu").setSelectedKey("DCRFS");
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToReadyForShip);
							that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "ERR") {
							that.getView().byId("oDCShipSubMenu").setSelectedKey("DCERR");
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToError);
							that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
					}
					// that.getView().byId("oDCShipSubMenuMainContainer").setVisible(true);
					// that.getView().byId("idDCShipFreightOrderPanel").setVisible(false);
					that._oBusyDialog.close();
				},
				error: function (oError) {
					that._oBusyDialog.close();
					that.oViewModel.setData({});
					that.oViewHeaderModel.setData({});
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onCustShipSearch: function (fileFilter) {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("CUSTSHIP", "");
			} else {
				// aFilter = this.getFileFilter("", that.excelData, that.ShipmentFileType);
				aFilter = fileFilter;
			}
			var that = this;
			that.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "oCustPanelFilterby")).setExpanded(false);
			//			that.clearCustTableColumnFilters();
			that.gCustShipment.read('/SearchSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': 'ToNew,ToCarrierDetermined,ToReadyForShipment,ToError,ToCounts'
				},
				success: function (oData, resp) {
					oData.results[0].ToCounts.results[0].Region = that._oCustRegionInput.getSelectedKey();
					if (oData.results[0].Type === "") {
						that.oViewModel.setData({});
						that.oViewHeaderModel.setData({});
					} else {
						if (oData.results[0].Type === "NEW") {
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.getView().byId("oCustShipSubMenu").setSelectedKey("CUSTNEW");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToNew);
							// that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "CDR") {
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.getView().byId("oCustShipSubMenu").setSelectedKey("CUSTCDR");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToCarrierDetermined);
							// that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "RFS") {
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.getView().byId("oCustShipSubMenu").setSelectedKey("CUSTRFS");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToReadyForShipment);
							// that.oViewModel.refresh();
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "ERR") {
							oData.results[0].ToCounts.results[0].Type = oData.results[0].Type;
							that.getView().byId("oCustShipSubMenu").setSelectedKey("CUSTERR");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToError);
							that._oBusyDialog.close();
						}
					}
					// that.getView().byId("oCustShipSubMenuMainContainer").setVisible(true);
					// that.getView().byId("idCustShipFreightOrderPanel").setVisible(false);
					that._oBusyDialog.close();
				}.bind(that),
				error: function (oError) {
					that._oBusyDialog.close();
					that.oViewModel.setData({});
					that.oViewHeaderModel.setData({});
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onLeanReceiptsSearch: function (fileFilter) {
			this._oBusyDialog.open();
			var aFilter = [];
			if (this.fileShip === false) {
				aFilter = this.getFilterByFilter("LEANREC", "");
			} else {
				// aFilter = this.getFileFilter("", that.excelData, that.ShipmentFileType);
				aFilter = fileFilter;
			}
			var that = this;
			that.gLeanReceipts.read('/SearchSet', {
				filters: aFilter,
				urlParameters: {
					'$expand': 'ToNew,ToGRCompleted,ToCounts'
				},
				success: function (oData, resp) {
					oData.results[0].ToCounts.results[0].Region = that._oCustRegionInput.getSelectedKey();
					if (oData.results[0].Type === "") {
						that.oViewModel.setData({});
						that.oViewHeaderModel.setData({});
					} else {
						if (oData.results[0].Type === "NEW") {
							that.getView().byId("oLeanReceiptsSubMenu").setSelectedKey("NEW");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToNew);
							that._oBusyDialog.close();
						}
						if (oData.results[0].Type === "GRC") {
							that.getView().byId("oLeanReceiptsSubMenu").setSelectedKey("GRC");
							that.oViewHeaderModel.setData(oData.results[0].ToCounts.results[0]);
							that.oViewModel.setData(oData.results[0].ToGRCompleted);
							that._oBusyDialog.close();
						}
					}
					that._oBusyDialog.close();
				}.bind(that),
				error: function (oError) {
					that._oBusyDialog.close();
					that.oViewModel.setData({});
					that.oViewHeaderModel.setData({});
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onCVMSearch: function (fileFilter) {
			if (this.fileShip === false) {
				if (this._oCVMSourCountryMultiInput.getTokens().length === 0) {
					this._showMessageBoxError("Please enter Source Country");
					//MessageBox.error("Please enter Source Country");
					return;
				}
				if (this._oCVMDestCountryMultiInput.getTokens().length === 0) {
					this._showMessageBoxError("Please enter Destination Country");
					//MessageBox.error("Please enter Destination Country");
					return;
				}
				if (this._oCVMCondType.getValue() === "") {
					this._showMessageBoxError("Entered CVM type is not valid for ZCVM condition types");
					//MessageBox.error("Entered CVM type is not valid for ZCVM condition types");
					return;
				}
				this.getCVMVal();
			} else {
				this.getCVMVal();
			}
		},
		getFilterByFilter: function (mainType, type) {
			var aFilter = [];
			var changeDate, maxRows, region, DispatchMultiInput, ServiceNotificationNoMulInput, PurchaseOrderMultiInput,
				ModuleSerialNoMultiInput, PartToPartnerMulInput, ShipFromPartnerMulInput, RMAMulInput, PartNo, SourceCountry, DestinationCountry,
				ConditionType,
				FromDate, ToDate, BatchNo, ERDate;
			if (mainType === "CUSTSHIP") {
				region = this._oCustRegionInput.getSelectedKey();
				DispatchMultiInput = this._oCustDispatchIdMultiInput;
				ServiceNotificationNoMulInput = this._oCustSerNotNoMultiInput;
				PurchaseOrderMultiInput = this._oCustPurchaseOrderMultiInput;
				ModuleSerialNoMultiInput = this._oCustModSerNoMultiInput;
				PartToPartnerMulInput = this._oCustShiptoPartnerMultiInput;
				changeDate = (this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCChgDate"))).getValue();
				maxRows = this._oCustMaxRows.getValue();
				ERDate = this.oCustERDate;
			} else if (mainType === "DCSHIP") {
				region = this._oDCRegionInput.getSelectedKey();
				ShipFromPartnerMulInput = this._oDCShipfromPartnerMultiInput;
				RMAMulInput = this._oDCRMAMultiInput;
				DispatchMultiInput = this._oDCDispatchIdMultiInput;
				ServiceNotificationNoMulInput = this._oDCSerNotNoMultiInput;
				ModuleSerialNoMultiInput = this._oDCModSerNoMultiInput;
				PurchaseOrderMultiInput = this._oDCPurchaseOrderMultiInput;
				changeDate = (this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCChgDate"))).getValue();
				maxRows = this._oDCMaxRows.getValue();
				ERDate = this.oDCERDate;
			} else if (mainType === "LEANREC") {
				region = this._oLeanRegionInput.getSelectedKey();
				DispatchMultiInput = this._oLeanDispatchIdMultiInput;
				ServiceNotificationNoMulInput = this._oLeanSerNotNoMultiInput;
				// PurchaseOrderMultiInput = this._oLeanPurchaseOrderMultiInput;
				ModuleSerialNoMultiInput = this._oLeanModSerNoMultiInput;
				PartToPartnerMulInput = this._oLeanShiptoPartnerMultiInput;
				changeDate = (this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCChgDate"))).getValue();
				maxRows = this._oLeanMaxRows.getValue();
				ERDate = this.oLeanERDate;
			} else if (mainType === "CVMVALUES") {
				// region=this._oCVMRegionInput.getSelectedKey();
				PartNo = this._oCVMPartNoMultiInput
				SourceCountry = this._oCVMSourCountryMultiInput
				DestinationCountry = this._oCVMDestCountryMultiInput
				maxRows = this._oCVMMaxRows.getValue();
				ConditionType = this._oCVMCondType.getValue();
				FromDate = (this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMFrom"))).getValue();
				ToDate = (this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMTo"))).getValue();
				BatchNo = (this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMBatchNo"))).getValue();
				// ERDate = this.oCVMERDate;
			}
			var oOperator = "";
			if (mainType !== "CVMVALUES") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, type));
			}
			if (mainType === "CVMVALUES" && this.userType === "E") {
				aFilter.push(new sap.ui.model.Filter("RcCode", sap.ui.model.FilterOperator.EQ, this.oRegionTypeModel.getData().results[0].Key));
			}
			if (region) {
				if (this.userType === "I") {
					aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
				} else {
					aFilter.push(new sap.ui.model.Filter("RcCode", sap.ui.model.FilterOperator.EQ, region));
				}
			}
			if (ServiceNotificationNoMulInput) {
				var tokens = ServiceNotificationNoMulInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("ServiceNotificationNo", oOperator, iData));
				}
			}
			if (DispatchMultiInput) {
				var tokens = DispatchMultiInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("DispatchID", oOperator, iData));
				}
			}
			if (ModuleSerialNoMultiInput) {
				var tokens = ModuleSerialNoMultiInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("ModuleSerialNo", oOperator, iData));
				}
			}
			if (PurchaseOrderMultiInput) {
				var tokens = PurchaseOrderMultiInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("PurchaseOrder", oOperator, iData));
				}
			}
			if (PartToPartnerMulInput) {
				var tokens = PartToPartnerMulInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("ShipToPartner", oOperator, iData));
				}
			}
			if (ShipFromPartnerMulInput) {
				var tokens = ShipFromPartnerMulInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("ShipFromPartner", oOperator, iData));
				}
			}
			if (RMAMulInput) {
				var tokens = RMAMulInput.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("RMA", oOperator, iData));
				}
			}
			if (PartNo) {
				var tokens = PartNo.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("PartNumber", oOperator, iData));
				}
			}
			if (SourceCountry) {
				var tokens = SourceCountry.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("SourceCountry", oOperator, iData));
				}
			}
			if (DestinationCountry) {
				var tokens = DestinationCountry.getTokens();
				for (var i = 0; i < tokens.length; i++) {
					var iData = tokens[i].getText();
					if (iData.includes('=')) {
						oOperator = FilterOperator.EQ;
						iData = iData.substring(1);
					}
					if (iData.includes('*')) {
						oOperator = FilterOperator.Contains;
						iData = iData.substring(1).slice(0, -1);
					}
					if (iData.includes('>')) {
						oOperator = FilterOperator.GT;
						iData = iData.substring(1);
					}
					if (iData.includes('<')) {
						oOperator = FilterOperator.LT;
						iData = iData.substring(1);
					}
					if (iData.includes('<=')) {
						oOperator = FilterOperator.LE;
						iData = iData.substring(2);
					}
					if (iData.includes('>=')) {
						oOperator = FilterOperator.GE;
						iData = iData.substring(2);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.slice(-1) === "*") {
						oOperator = FilterOperator.StartsWith;
						iData = iData.slice(0, -1);
					}
					if (iData.substring(0, 1) === "*") {
						oOperator = FilterOperator.EndsWith;
						iData = iData.substring(1);
					}
					aFilter.push(new sap.ui.model.Filter("DestinationCountry", oOperator, iData));
				}
			}
			if (ConditionType) {
				aFilter.push(new sap.ui.model.Filter("ConditionType", sap.ui.model.FilterOperator.EQ, ConditionType));
			}
			if (FromDate) {
				aFilter.push(new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, FromDate));
			}
			if (ToDate) {
				aFilter.push(new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, ToDate));
			}
			if (BatchNo) {
				aFilter.push(new sap.ui.model.Filter("BatchNumber", sap.ui.model.FilterOperator.EQ, BatchNo));
			}
			if (changeDate) {
				aFilter.push(new sap.ui.model.Filter("ChangeDate", sap.ui.model.FilterOperator.EQ, changeDate));
			}
			if (maxRows) {
				aFilter.push(new sap.ui.model.Filter("MaxRows", sap.ui.model.FilterOperator.EQ, maxRows));
			}
			if (mainType !== "CVMVALUES") {
				if (ERDate.getValue()) {
					var fromDate = (ERDate.getFrom().getFullYear() + "" + ("0" + (ERDate.getFrom().getMonth() + 1)).slice(-2) + "" + ("0" + (ERDate.getFrom()
						.getDate())).slice(-2));
					var toDate = (ERDate.getTo().getFullYear() + "" + ("0" + (ERDate.getTo().getMonth() + 1)).slice(-2) + "" + ("0" + (ERDate.getTo()
						.getDate())).slice(-2));
					aFilter.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, fromDate, toDate));
				}
			}
			return aFilter;
		},
		onUploadCancelBtnPress: function () {
			if (this._itemStatus) {
				this._itemStatus.destroy();
				this._itemStatus = null;
			}
		},
		onSelectFileBtnPress: function (oEvent) {
			if (this._itemStatus) {
				this._itemStatus.destroy();
				this._itemStatus = null;
			}
			var oFileType = {
				"items": [{
					"key": "SerialNumber",
					"text": "Serial Number"
				}, {
					"key": "ServiceNotification",
					"text": "Service Notification"
				}, {
					"key": "DispatchID",
					"text": "Dispatch ID"
				}]
			};
			var oCVMFileType = {
				"items": [{
					"key": "LEG3-KGB",
					"text": "LEG3-KGB"
				}, {
					"key": "LEG4-KBB",
					"text": "LEG4-KBB"
				}]
			};
			var oDCFileTypeData = {
				"items": [{
					"key": "RMA_ITEMNO",
					"text": "RMA Number and Item number"
				}, {
					"key": "RMA_ITEMNO_PARTNO",
					"text": "RMA Number and Item Number and Part Number"
				}, {
					"key": "SerialNumber",
					"text": "Serial Number"
				}, {
					"key": "ServiceNotification",
					"text": "Service Notification"
				}, {
					"key": "DispatchID",
					"text": "Dispatch ID"
				}]
			};
			var oFileTypeModel = new JSONModel();
			var oView = this.getView();
			if (!this._itemStatus) {
				this._itemStatus = sap.ui.xmlfragment("popup", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.selectFile", this);
				oView.addDependent(this._itemStatus);
			}
			this._itemStatus.setModel(oFileTypeModel);
			var selectedKey = sap.ui.core.Fragment.byId("popup", "idDCShipCombox");
			var fileUploader = sap.ui.core.Fragment.byId("popup", "fileUploader");
			if (this.oMainSelectedKey === "DCSHIP") {
				oFileTypeModel.setData(oDCFileTypeData);
				selectedKey.setSelectedKey("RMA_ITEMNO");
			} else if (this.oMainSelectedKey === "CUSTSHIP" || this.oMainSelectedKey === "LEANREC") {
				oFileTypeModel.setData(oFileType);
				selectedKey.setSelectedKey("SerialNumber");
			} else if (this.oMainSelectedKey === "CVMVALUES") {
				oFileTypeModel.setData(oCVMFileType);
				selectedKey.setSelectedKey("LEG3-KGB");
			}
			var oFileUploader = sap.ui.core.Fragment.byId("popup", "fileUploader");
			var ofileupload = oFileUploader.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("popup--fileUploader-fu_input-inner").readOnly = true;
					document.getElementById("popup--fileUploader-fu_input-inner").setAttribute('aria-label', 'Uploaded file name'),
						document.getElementById("popup--fileUploader-fu").setAttribute('readonly', 'true')
						// document.getElementById("popup--fileUploader-fu_data").setAttribute("readonly",true);
				}
			}, oFileUploader);
			var oSelectFile = sap.ui.core.Fragment.byId("popup", "idUploadFileDialog");
			var oSelectFileUpload = oSelectFile.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("popup--idUploadFileDialog-header").setAttribute('role', 'presentation'),
						document.getElementById("popup--idUploadFileDialog-firstfe").removeAttribute('tabindex'),
						document.getElementById("popup--idUploadFileDialog-header").removeAttribute('aria-level'),
						document.getElementById("popup--idUploadFileDialog-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oSelectFile);
			/*AX Issues*/
			var oCriteria = sap.ui.core.Fragment.byId("popup", "idDCShipCombox");
			// var oCriteriaUpload = oCriteria.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		document.getElementById("popup--idDCShipCombox-hiddenSelect").removeAttribute('role'),
			// 			document.getElementById("popup--idDCShipCombox-hiddenSelect").removeAttribute('aria-readonly'),
			// 			document.getElementById("popup--idDCShipCombox-hiddenSelect").removeAttribute('aria-expanded'),
			// 			document.getElementById("popup--idDCShipCombox-hiddenSelect").removeAttribute('aria-haspopup')

			// 	}
			// }, oCriteria);
			this._itemStatus.open();
		},
		onUploadBtnPress: function (oEvent) {
			var oFileUploader = sap.ui.core.Fragment.byId("popup", "fileUploader");
			var selectedKey = sap.ui.core.Fragment.byId("popup", "idDCShipCombox");
			this.ShipmentFileType = selectedKey.getSelectedKey();
			var file = oFileUploader.getFocusDomRef().files[0];
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function (evt) {
					var data = evt.target.result;
					var workbook = XLSX.read(data, {
						type: 'binary'
					});
					workbook.SheetNames.forEach(function (sheetName) {
						//						excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
						excelData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
							header: ["A", "B", "C", "D", "E", "F", "G"],
							skipHeader: true
						});
						that.excelData = excelData;
						that.fileShip = true;
						if (that.oMainSelectedKey === "CUSTSHIP") {
							that.onCustShipSearch(that.getFileFilter("", that.excelData, that.ShipmentFileType, that._oCustRegionInput.getSelectedKey()));
						} else if (that.oMainSelectedKey === "DCSHIP") {
							that.onDCShipSearch(that.getFileFilter("", that.excelData, that.ShipmentFileType, that._oDCRegionInput.getSelectedKey()));
						} else if (that.oMainSelectedKey === "CVMVALUES") {
							that.onCVMSearch(that.getFileFilter("", that.excelData, that.ShipmentFileType));
						} else if (that.oMainSelectedKey === "LEANREC") {
							that.onLeanReceiptsSearch(that.getFileFilter("", that.excelData, that.ShipmentFileType, that._oLeanRegionInput.getSelectedKey()));
						}
					});
				};
			}
			reader.readAsBinaryString(file);
			if (this._itemStatus) {
				this._itemStatus.destroy();
				this._itemStatus = null;
			}
		},
		getFileFilter: function (sSelect, excelData, filetype, region) {
			var aFilter = [];
			if (this.userType === "I" && this.oMainSelectedKey !== "CVMVALUES") {
				aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, region));
			} else {
				if (this.oMainSelectedKey !== "CVMVALUES") {
					aFilter.push(new sap.ui.model.Filter("RcCode", sap.ui.model.FilterOperator.EQ, region));
				} else if (this.oMainSelectedKey === "CVMVALUES" && this.userType === "E") {
					aFilter.push(new sap.ui.model.Filter("RcCode", sap.ui.model.FilterOperator.EQ, this.oRegionTypeModel.getData().results[0].Key));
				}
			}
			// aFilter.push(new sap.ui.model.Filter("MaxRows", sap.ui.model.FilterOperator.EQ, "5000"));
			if (filetype === "ServiceNotification") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, sSelect + "," + "SERV_NOTIF"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("ServiceNotificationNo", sap.ui.model.FilterOperator.EQ, excelData[i]["A"].padStart(12, 0)));
				}
			}
			if (filetype === "DispatchID") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, sSelect + "," + "DISPATCHID"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("DispatchID", sap.ui.model.FilterOperator.EQ, excelData[i]["A"]));
				}
			}
			if (filetype === "SerialNumber") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, sSelect + "," + "SERIAL_NO"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("ModuleSerialNo", sap.ui.model.FilterOperator.EQ, excelData[i]["A"]));
				}
			}
			if (filetype === "LEG3-KGB") {
				aFilter.push(new sap.ui.model.Filter("ConditionType", sap.ui.model.FilterOperator.EQ, "ZCVM"));
				aFilter.push(new sap.ui.model.Filter("BatchNumber", sap.ui.model.FilterOperator.EQ, "KGB"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("PartNumber", sap.ui.model.FilterOperator.EQ, excelData[i]["A"]));
					aFilter.push(new sap.ui.model.Filter("SourceCountry", sap.ui.model.FilterOperator.EQ, excelData[i]["B"]));
					aFilter.push(new sap.ui.model.Filter("DestinationCountry", sap.ui.model.FilterOperator.EQ, excelData[i]["C"]));
				}
			}
			if (filetype === "LEG4-KBB") {
				aFilter.push(new sap.ui.model.Filter("ConditionType", sap.ui.model.FilterOperator.EQ, "ZCVM"));
				aFilter.push(new sap.ui.model.Filter("BatchNumber", sap.ui.model.FilterOperator.EQ, "KBB"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("PartNumber", sap.ui.model.FilterOperator.EQ, excelData[i]["A"]));
					aFilter.push(new sap.ui.model.Filter("SourceCountry", sap.ui.model.FilterOperator.EQ, excelData[i]["B"]));
					aFilter.push(new sap.ui.model.Filter("DestinationCountry", sap.ui.model.FilterOperator.EQ, excelData[i]["C"]));
				}
			}
			// 	/*RMA Item Number & Part Number*/
			if (filetype === "RMA_ITEMNO_PARTNO") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, sSelect + "," + "RMAPART"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("RMA", sap.ui.model.FilterOperator.EQ, excelData[i]["A"] + "," + excelData[i]["B"] + "," +
						excelData[i]["C"]));
					// aFilter.push(new sap.ui.model.Filter("RMA", sap.ui.model.FilterOperator.EQ, excelData[i]["RMANumber"]));
					// aFilter.push(new sap.ui.model.Filter("ReturnOrderItem", sap.ui.model.FilterOperator.EQ, excelData[i]["ItemNumber"]));
					// aFilter.push(new sap.ui.model.Filter("PartNo", sap.ui.model.FilterOperator.EQ, excelData[i]["PartNumber"]));
				}
			}
			/*RMA & Item Number */
			if (filetype === "RMA_ITEMNO") {
				aFilter.push(new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, sSelect + "," + "RMA"));
				for (var i = 1; i < excelData.length; i++) {
					aFilter.push(new sap.ui.model.Filter("RMA", sap.ui.model.FilterOperator.EQ, excelData[i]["A"] + "" + excelData[i]["B"].padStart(
						6,
						0)));
					// aFilter.push(new sap.ui.model.Filter("ReturnOrderItem", sap.ui.model.FilterOperator.EQ, excelData[i].ItemNumber));
				}
			}
			return aFilter;
		},
		/*Customer Shipment Functionality*/
		onCustReqCarrBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oCustNewTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gCustShipment.setDeferredGroups(["CustbatchFunctionImport"]);
			if (selectedRows.length > 0) {
				if (selectedRows.length > 150) {
					this._oBusyDialog.close();
					this._showMessageBoxError("The request can only process maximum limit of 150 items");
					// MessageBox.error("The request can only process maximum limit of 150 items");
					return;
				} else {
					var firstShiptoPartner = "";
					var firstShipper = "";
					var that = this;
					that._oBusyDialog.open();
					for (var i = 0; i < selectedRows.length; i++) {
						var temp = {};
						rowPath = that.getView().byId("oCustNewTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
						rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
						//Validating whether the selected rows have same Ship to Partner & Ship to From - Start
						if (selectedRows.length > 1) {
							firstShiptoPartner = that.getView().getModel("oViewModel").getProperty(that.getView().byId("oCustNewTable").getBinding("rows").getContexts()[
								selectedRows[0]].getPath()).ShipToPartner;
							if (firstShiptoPartner !== rowProperty.ShipToPartner) {
								that._oBusyDialog.close();
								that._showMessageBoxError("Please select same Ship-To Partners");
								//MessageBox.error("Please select same Ship-To Partners");
								return;
							}
							firstShipper = that.getView().getModel("oViewModel").getProperty(that.getView().byId("oCustNewTable").getBinding("rows").getContexts()[
								selectedRows[0]].getPath()).Shipper;
							if (firstShipper !== rowProperty.Shipper) {
								that._oBusyDialog.close();
								that._showMessageBoxError("Please select same Ship-From Partners");
								//MessageBox.error("Please select same Ship-From Partners");
								return;
							}
						}
						//Validating whether the selected rows have same Ship to Partner & Ship to From - END
						if (that.userType === "I") {
							temp.Region = that._oCustRegionInput.getSelectedKey();
							temp.RcCode = '';
						} else if (that.userType === "E") {
							temp.Region = that.oRegionTypeModel.getData().results[0].Region;
							temp.RcCode = that._oCustRegionInput.getSelectedKey();
						}
						temp.PartNo = rowProperty.PartNumber;
						temp.ServiceNotification = rowProperty.ServiceNotification;
						temp.Status = rowProperty.Status;
						data.push(temp);
						that.gCustShipment.callFunction("/RequestCarrier", {
							urlParameters: temp,
							method: "POST",
							batchGroupId: "CustbatchFunctionImport",
						});
						temp = null;
					}
					that._oBusyDialog.close();
					if (selectedRows.length > 10) {
						MessageBox.show("Processing of request will take a few seconds", {
							title: "Information Message",
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							initialFocus: MessageBox.Action.YES,
							onClose: function (sAction) {
								if (sAction === "YES") {
									that._oBusyDialog.open();
									that.gCustShipment.submitChanges({
										batchGroupId: "CustbatchFunctionImport",
										changeSetId: 1,
										success: function (oData, oResponse) {
											that._oBusyDialog.close();
											if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
												that._showMessageBoxSuccess("Carrier Request Submitted Successfuly");
												//MessageBox.success("Carrier Request Submitted Successfuly");
												that.getCustShip("NEW", "ToNew");
											} else {
												// that._oBusyDialog.close();
												that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
												//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
											}
											// } else if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
											// 	MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											// }
										}.bind(this),
										error: function (oError) {
											that._oBusyDialog.close();
											that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
											//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
										}
									});
								} else if (sAction === "NO") {
									that._oBusyDialog.close();
									// that._modalKeyFocusOut()
									return;
								}
							}
						});
						that._showMessageBoxShow();
					} else {
						that._oBusyDialog.open();
						that.gCustShipment.submitChanges({
							batchGroupId: "CustbatchFunctionImport",
							changeSetId: 1,
							success: function (oData, oResponse) {
								if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
									that._oBusyDialog.close();
									that._showMessageBoxSuccess("Carrier Request Submitted Successfuly");
									// MessageBox.success("Carrier Request Submitted Successfuly");
									that.getCustShip("NEW", "ToNew");
								} else {
									that._oBusyDialog.close();
									that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
									// MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
								}
								// } else if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
								// 	MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
								// }
							}.bind(this),
							error: function (oError) {
								that._oBusyDialog.close();
								that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
								// MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}
						});
					}
				}
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				// var that = this;
				// MessageBox.error("Please select atleast one record",{
				//   onClose: function(oAction) { that._modalKeyFocusOut(); }
				// });
				// that._modalKeyFocusIn();
			}
		},
		onCustCDRDownloadBtnPress: function (oEvent) {
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oCustCDRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gCustShipment.setDeferredGroups(["CustbatchDownload"]);
			if (selectedRows.length > 0) {
				for (var i = 0; i < selectedRows.length; i++) {
					var temp = {};
					rowPath = this.getView().byId("oCustCDRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					if (this.userType === "I") {
						temp.Region = this._oCustRegionInput.getSelectedKey();
						temp.RcCode = '';
					} else if (this.userType === "E") {
						temp.Region = this.oRegionTypeModel.getData().results[0].Region;
						temp.RcCode = this._oCustRegionInput.getSelectedKey();
					}
					// temp.Region = this._oCustRegionInput.getSelectedKey();
					temp.ServiceNotification = rowProperty.ServiceNotification;
					temp.DispatchID = rowProperty.DispatchId;
					temp.SerialNumber = rowProperty.SerialNumber;
					temp.ShipToPartner = rowProperty.ShipToPartner;
					data.push(temp);
					this.gCustShipment.callFunction("/FileDownloadTemplate", {
						urlParameters: temp,
						method: "POST",
						batchGroupId: "CustbatchDownload",
					});
					temp = null;
				}
				this.gCustShipment.submitChanges({
					batchGroupId: "CustbatchDownload",
					changeSetId: 1,
					success: function (oData, oResponse) {
						var FileGUID = oData.__batchResponses[0].__changeResponses[0].data.FileGUID
						var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV";
						sUrl = sUrl + "/DownloadTemplateSet(FileGUID='" + FileGUID + "')/$value";
						sap.m.URLHelper.redirect(sUrl);
						// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV");
						// oModel.read("/DownloadTemplateSet(FileGUID='" + FileGUID+ "')/$value", {
						// 		success: function (oData, response) {
						// 			sap.m.URLHelper.redirect(response.requestUri);
						// 			this._oBusyDialog.close();
						// 		},
						// 		error: function () {
						// 			this._oBusyDialog.close();
						// 		}
						// 	});
					},
					error: function (oError) {
						this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {

				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onCustNEWDownloadBtnPress: function (oEvent) {
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oCustNewTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gCustShipment.setDeferredGroups(["CustbatchDownload"]);
			if (selectedRows.length > 0) {
				for (var i = 0; i < selectedRows.length; i++) {
					var temp = {};
					rowPath = this.getView().byId("oCustNewTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					if (this.userType === "I") {
						temp.Region = this._oCustRegionInput.getSelectedKey();
						temp.RcCode = '';
					} else if (this.userType === "E") {
						temp.Region = this.oRegionTypeModel.getData().results[0].Region;
						temp.RcCode = this._oCustRegionInput.getSelectedKey();
					}
					// temp.Region = this._oCustRegionInput.getSelectedKey();
					temp.ServiceNotification = rowProperty.ServiceNotification;
					temp.DispatchID = rowProperty.DispatchId;
					temp.SerialNumber = rowProperty.SerialNumber;
					temp.ShipToPartner = rowProperty.ShipToPartner;
					data.push(temp);
					this.gCustShipment.callFunction("/FileDownloadTemplate", {
						urlParameters: temp,
						method: "POST",
						batchGroupId: "CustbatchDownload",
					});
					temp = null;
				}
				this.gCustShipment.submitChanges({
					batchGroupId: "CustbatchDownload",
					changeSetId: 1,
					success: function (oData, oResponse) {
						var FileGUID = oData.__batchResponses[0].__changeResponses[0].data.FileGUID
						var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV";
						sUrl = sUrl + "/DownloadTemplateSet(FileGUID='" + FileGUID + "')/$value";
						sap.m.URLHelper.redirect(sUrl);
						// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV");
						// oModel.read("/DownloadTemplateSet(FileGUID='" + FileGUID+ "')/$value", {
						// 		success: function (oData, response) {
						// 			sap.m.URLHelper.redirect(response.requestUri);
						// 			this._oBusyDialog.close();
						// 		},
						// 		error: function () {
						// 			this._oBusyDialog.close();
						// 		}
						// 	});
					},
					error: function (oError) {
						this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});

			} else {
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onCustUpdCarrBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var aFilter = [];
			var selectedRows = this.getView().byId("oCustNewTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			if (selectedRows.length > 0) {
				aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this._oCustRegionInput.getSelectedKey()));
				for (var i = 0; i < selectedRows.length; i++) {
					rowPath = this.getView().byId("oCustNewTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					aFilter.push(new sap.ui.model.Filter("DispatchId", sap.ui.model.FilterOperator.EQ, rowProperty.DispatchId));
					aFilter.push(new sap.ui.model.Filter("ServiceNotification", sap.ui.model.FilterOperator.EQ, rowProperty.ServiceNotification));
					aFilter.push(new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, rowProperty.SerialNumber));
					aFilter.push(new sap.ui.model.Filter("ShipTo", sap.ui.model.FilterOperator.EQ, rowProperty.ShipToPartner));
				}
				var that = this;
				that.gCustShipment.read('/UpdateCarrierSet', {
					filters: aFilter,
					urlParameters: {
						'$expand': 'ToCarrierItem'
					},
					success: function (oData) {
						that.oFreightOrderModel.setData(oData.results[0]);
						that.getView().byId("oCustShipSubMenuNew").setVisible(false);
						that.getView().byId("idCustShipNewPACUpdateCarrPanel").setVisible(true);
						that.oFreightOrderModel.refresh();
						that._oBusyDialog.close();

						/*AX rdar://76447424:Update Carrier section expand/Collapse */
						this._oCustPacCarrier = this.byId(sap.ui.core.Fragment.createId("idCustShipNewPACUpdateCarrFragment", "oFrightOrderItemTable"));
						this._oCustPacCarrier.addEventDelegate({
							onAfterRendering: function () {
								document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].setAttribute('role', 'presentation'),
									document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].childNodes[0].setAttribute('title',
										'Item Details Expand/Collapse'),
									document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].childNodes[0].setAttribute('aria-label',
										'Item Details Expand/Collapse')

								document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].setAttribute('role', 'presentation'),
									document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].childNodes[0].setAttribute('title',
										'Shipping Details Expand/Collapse'),
									document.getElementById("__xmlview0--idCustShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].childNodes[0].setAttribute('aria-label',
										'Shipping Details Expand/Collapse')
							}
						}, this._oCustPacCarrier)

					}.bind(that),
					error: function (oError) {
						that._oBusyDialog.close();
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onCUSTShipPACSaveFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			this.gCustShipment.setDeferredGroups(["FreightOrderPAC"]);
			var oFreightOrderDetails = {};
			//oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;

			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;

			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			var sPath = "/FreightPacHeaderSet('" + oFreightOrderDetails.ShipTo + "')";
			var sPathItem = "/FreightPacItemSet('" + oFreightOrderDetails.ShipTo + "')";
			this.gCustShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrderPAC"
				});
			for (var i = 0; i < oFreightOrderModel.ToCarrierItem.results.length; i++) {
				var oFreightOrderItemDetails = {};
				oFreightOrderItemDetails.DispatchId = oFreightOrderModel.ToCarrierItem.results[i].DispatchId;
				oFreightOrderItemDetails.ShipToPartner = oFreightOrderModel.ToCarrierItem.results[i].ShipToPartner;
				oFreightOrderItemDetails.ServiceNotifiation = oFreightOrderModel.ToCarrierItem.results[i].ServiceNotifiation;
				oFreightOrderItemDetails.PartNo = oFreightOrderModel.ToCarrierItem.results[i].PartNo;
				this.gCustShipment.update(
					sPathItem, oFreightOrderItemDetails, {
						groupId: "FreightOrderPAC"
					});
			}
			var that = this;
			that.gCustShipment.submitChanges({
				groupId: "FreightOrderPAC",
				changeSetId: "1",
				success: function (oData, oResponse) {
					if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
						that.onCustUpdCarrBtnPress();
						that._showMessageBoxSuccess("Data saved Successfully");
						//MessageBox.success("Data saved Successfully");
					} else {
						that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onCUSTShipPACReqFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			this.gCustShipment.setDeferredGroups(["FreightOrderPAC"]);
			var oFreightOrderDetails = {};
			// oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;

			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;

			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			var sPath = "/FreightPacHeaderSet('" + oFreightOrderDetails.ShipTo + "')";
			var sPathItem = "/FreightPacItemSet('" + oFreightOrderDetails.ShipTo + "')";
			this.gCustShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrderPAC"
				});
			for (var i = 0; i < oFreightOrderModel.ToCarrierItem.results.length; i++) {
				var oFreightOrderItemDetails = {};
				oFreightOrderItemDetails.DispatchId = oFreightOrderModel.ToCarrierItem.results[i].DispatchId;
				oFreightOrderItemDetails.ShipToPartner = oFreightOrderModel.ToCarrierItem.results[i].ShipToPartner;
				oFreightOrderItemDetails.ServiceNotifiation = oFreightOrderModel.ToCarrierItem.results[i].ServiceNotifiation;
				oFreightOrderItemDetails.PartNo = oFreightOrderModel.ToCarrierItem.results[i].PartNo;
				this.gCustShipment.update(
					sPathItem, oFreightOrderItemDetails, {
						groupId: "FreightOrderPAC"
					});
			}
			var temp = {}
			temp.ShipTo = oFreightOrderDetails.ShipTo;
			this.gCustShipment.callFunction("/PacRequestShipping", {
				urlParameters: temp,
				method: "POST",
				groupId: "FreightOrderPAC"
			});
			var that = this;
			that.gCustShipment.submitChanges({
				groupId: "FreightOrderPAC",
				changeSetId: "1",
				success: function (oData, oResponse) {
					var count = oResponse.data.__batchResponses[0].__changeResponses.length;
					if (oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgType === "S") {
						that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						that.onCustUpdCarrBtnPress();
					} else if (oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgType === "E") {
						that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
					}
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onCustNEWUploadBtnPress: function (oEvent) {
			var oView = this.getView();
			if (this._uploadFile) {
				this._uploadFile.destroy();
				this._uploadFile = null;
			}
			if (!this._uploadFile) {
				this._uploadFile = sap.ui.xmlfragment("UploadFile", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.uploadFile", this);
				oView.addDependent(this._uploadFile);
			}
			var oUploadFile = sap.ui.core.Fragment.byId("UploadFile", "idUploadFileDialog");
			var oUploadFileUpload = oUploadFile.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("UploadFile--idUploadFileDialog-header").setAttribute('role', 'presentation'),
						document.getElementById("UploadFile--idUploadFileDialog-firstfe").removeAttribute('tabindex'),
						document.getElementById("UploadFile--idUploadFileDialog-header").removeAttribute('aria-level'),
						document.getElementById("UploadFile--idUploadFileDialog-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oUploadFile);

			this._uploadFile.open();
		},
		onUploadTemplateCancelBtnPress: function (oEvent) {
			if (this._uploadFile) {
				this._uploadFile.destroy();
				this._uploadFile = null;
			}
		},
		onUploadTemplateBtnPress: function (oEvent) {
			var oFileUploader = sap.ui.core.Fragment.byId("UploadFile", "fileUploader");
			var file = oFileUploader.oFileUpload.files[0];
			if (oFileUploader.getValue() === "") {
				this._showMessageBoxError("Please Choose any File");
				//MessageBox.error("Please Choose any File");
			}
			var token = this.gCustShipment.getSecurityToken();
			if (this.userType === "I") {
				var region = this.userType + "," + this._oCustRegionInput.getSelectedKey();
			} else if (this.userType === "E") {
				var region = this.userType + "," + this._oCustRegionInput.getSelectedKey();
			}
			//			var region = this._oCustRegionInput.getSelectedKey();
			var oUploadURL = "/sap/opu/odata/sap/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV/FileUploadSet";
			jQuery.ajax({
				type: 'POST',
				url: oUploadURL,
				contentType: "application/json",
				cache: false,
				processData: false,
				data: file,
				beforeSend: function (xhr) {
					xhr.setRequestHeader("X-CSRF-Token", token);
					xhr.setRequestHeader("slug", region);
					xhr.setRequestHeader("mimeType", file.type);
				},
				success: function (data, response) {
					this.onUploadTemplateCancelBtnPress();
					this._showMessageBoxSuccess("Data Updated Successfully");
					//MessageBox.success("Data Updated Successfully");
					this.getCustShip("NEW", "ToNew");
					// sap.m.MessageToast.show("File upload Successful");
				}.bind(this),
				error: function (error) {
					this.onUploadTemplateCancelBtnPress();
					var parser, xmlDoc;
					parser = new DOMParser();
					xmlDoc = parser.parseFromString(error.responseText, "text/xml");
					this._showMessageBoxError(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
					//MessageBox.error(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}.bind(this)
			});
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "SLUG",
			// 	value: "PAC"
			// }));
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "mimeType",
			// 	value: file.type
			// }));
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "Content-Type",
			// 	value: file.type
			// }));
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "x-csrf-token",
			// 	value: oModel.getSecurityToken()
			// }));
			// oFileUploader.setSendXHR(true);
			// oFileUploader.upload();
		},
		handleCustUpdateCarrierBack: function (oEvent) {
			this.getView().byId("oCustShipSubMenuNew").setVisible(true);
			this.getView().byId("idCustShipNewPACUpdateCarrPanel").setVisible(false);
		},
		onCUSTRFSCancelBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var cancelBatchChanges = [];
			var cancelSelectedRows = this.getView().byId("oCustRFSTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gCustShipment.setDeferredGroups(["cancelBatchFunctionImport"]);
			if (cancelSelectedRows.length > 0) {
				var that = this;
				MessageBox.show("Selected shipping documents will be cancelled. Continue", {
					title: "Confirmation",
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					initialFocus: MessageBox.Action.YES,
					emphasizedAction: MessageBox.Action.YES,
					onClose: function (sAction) {
						data = [];
						if (sAction === "YES") {
							that._oBusyDialog.open();
							for (var i = 0; i < cancelSelectedRows.length; i++) {
								var temp = {};
								rowPath = that.getView().byId("oCustRFSTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
								rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
								if (that.userType === "I") {
									temp.Region = that._oCustRegionInput.getSelectedKey();
									temp.RcCode = '';
								} else if (that.userType === "E") {
									temp.Region = that.oRegionTypeModel.getData().results[0].Region;
									temp.RcCode = that._oCustRegionInput.getSelectedKey();
								}
								//								temp.Region = that._oCustRegionInput.getSelectedKey();
								temp.LoadRequest = rowProperty.LoadRequest;
								temp.ReferenceNumber = rowProperty.ReferenceNo;
								data.push(temp);
								that.gCustShipment.callFunction("/RFSCancelShipment", {
									urlParameters: temp,
									method: "POST",
									batchGroupId: "cancelBatchFunctionImport",
									// changeSetId: i,
								});
								temp = null;
							}
							that.gCustShipment.submitChanges({
								batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
								changeSetId: 1,
								success: function (oData, oResponse) {
									that._oBusyDialog.close();
									if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
										//if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
										that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										that.getCustShip("RFS", "ToReadyForShipment");
										// } else if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
									} else {
										that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
										//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
									}
								}.bind(this),
								error: function (oError) {
									that._oBusyDialog.close();
									that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
									//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
								}
							});
						} else if (sAction === "NO") {
							that._oBusyDialog.close();
							// that._modalKeyFocusOut();
							that.getCustShip("RFS", "ToReadyForShipment");
						}
					}
				});
				that._showMessageBoxShow();
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				// this._modalKeyFocusIn();
				// MessageBox.error("Please select atleast one record",{
				// actions: [MessageBox.Action.CLOSE],	
				// initialFocus: MessageBox.Action.CLOSE,
				//   onClose: function(oAction) {this._modalKeyFocusOut(); }
				// });
			}
		},
		onCUSTCDRCancelBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var cancelBatchChanges = [];
			var cancelSelectedRows = this.getView().byId("oCustCDRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gCustShipment.setDeferredGroups(["cancelBatchFunctionImport"]);
			if (cancelSelectedRows.length > 0) {
				if (cancelSelectedRows.length > 150) {
					this._oBusyDialog.close()
					this._showMessageBoxError("The request can only process maximum limit of 150 items");
					//MessageBox.error("The request can only process maximum limit of 150 items");
					return;
				} else {
					var that = this;
					MessageBox.show("Selected shipping documents will be cancelled. Continue", {
						title: "Confirmation",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						initialFocus: MessageBox.Action.YES,
						emphasizedAction: MessageBox.Action.YES,
						onClose: function (sAction) {
							data = [];
							if (sAction === "YES") {
								that._oBusyDialog.open();
								for (var i = 0; i < cancelSelectedRows.length; i++) {
									var temp = {};
									rowPath = that.getView().byId("oCustCDRTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
									rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
									if (that.userType === "I") {
										temp.Region = that._oCustRegionInput.getSelectedKey();
										temp.RcCode = '';
									} else if (that.userType === "E") {
										temp.Region = that.oRegionTypeModel.getData().results[0].Region;
										temp.RcCode = that._oCustRegionInput.getSelectedKey();
									}
									//								temp.Region = that._oCustRegionInput.getSelectedKey();
									temp.LoadRequest = "";
									temp.ReferenceNumber = rowProperty.ReferenceNo;
									data.push(temp);
									that.gCustShipment.callFunction("/CDRCancelShipment", {
										urlParameters: temp,
										method: "POST",
										batchGroupId: "cancelBatchFunctionImport",
										// changeSetId: i,
									});
									temp = null;
								}
								that.gCustShipment.submitChanges({
									batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
									changeSetId: 1,
									success: function (oData, oResponse) {
										that._oBusyDialog.close();
										if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType == "S") {
											that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											that.getCustShip("CDR", "ToCarrierDetermined");
											// } else if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
										} else {
											that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
											//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										}
									}.bind(this),
									error: function (oError) {
										that._oBusyDialog.close();
										that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
										//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
									}
								});
							} else if (sAction === "NO") {
								that._oBusyDialog.close();
								// that._modalKeyFocusOut();
								that.getCustShip("CDR", "ToCarrierDetermined");
							}
						}
					});
					that._showMessageBoxShow();
					// that._modalKeyFocusIn();
				}
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				// var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				// var that = this;
				// MessageBox.error("Please select atleast one record",{
				// actions: [MessageBox.Action.CLOSE],	
				// initialFocus: null,
				// styleClass: bCompact ? "sapUiSizeCompact" : "",
				//   onClose: function(oAction) { that._modalKeyFocusOut(); }
				// });
				// that._modalKeyFocusIn();
			}
		},
		handleCUSTFreightOrderLinkPress: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			if (rowProperty.Carrier) {
				this._oBusyDialog.open();
				var aFilter = [];
				aFilter.push(new sap.ui.model.Filter("ReferenceNumber", sap.ui.model.FilterOperator.EQ, rowProperty.ReferenceNo));
				var that = this;
				that.gCustShipment.read("/FreightHeaderSet('" + rowProperty.ReferenceNo + "')", {
					urlParameters: {
						'$expand': 'ToFreightItem,ToBoxHeader/ToBoxItem'
					},
					success: function (oData, resp) {
						if (that._oCustRegionInput.getSelectedKey() !== "PAC" && that.oRegionTypeModel.getData().results[0].Region !== "PAC") {
							if (that.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTCDR") {
								var boxPanelId = this.byId(sap.ui.core.Fragment.createId("idCustShipCDRFreightOrderFragment", "idBoxDetails"));
							} else {
								var boxPanelId = this.byId(sap.ui.core.Fragment.createId("idCustShipRFSFreightOrderFragment", "idBoxDetails"));
							}
							boxPanelId.destroyContent();
							var form = new sap.ui.layout.form.SimpleForm();
							// for (var i = 0; i < parseInt(oData.TotalPackages); i++) {
							for (var i = 0; i < oData.ToBoxHeader.results.length; i++) {
								var oHbox = new sap.m.HBox({});
								var oVbox = new sap.m.VBox({});
								var oImage = new sap.m.Image({
									src: "./images/Box.png"
								});
								var oHbox1 = new sap.m.HBox({});
								oHbox1.addItem(oImage);
								var oHbox2 = new sap.m.HBox({
									items: [
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].BoxName,
										}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginTop")
									]
								}).addStyleClass("sapUiTinyMarginBegin");
								var oHbox3 = new sap.m.HBox({
									items: [
										new sap.m.Label({
											text: "Weight:",
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].GrossWeight,
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: " Volume:",
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].GrossVolume,
										}).addStyleClass("sapUiTinyMarginBegin")
									]
								}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginTop");
								var oHbox4 = new sap.m.HBox();
								oHbox4.addItem(oHbox3);
								var oVbox5 = new sap.m.VBox({
									width: "100%"
								});
								oVbox5.addItem(oHbox2);
								oVbox5.addItem(oHbox4);
								oHbox1.addItem(oVbox5);
								oHbox.addItem(oHbox1);
								var oTable = new sap.m.Table({
									width: "30rem"
								}).addStyleClass("sapUiTinyMarginTop");
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Part Number"
									})
								}));
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Part Description"
									})
								}));
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Quantity"
									})
								}));
								var colItemList = new sap.m.ColumnListItem({
									cells: [
										new sap.m.Text({
											text: "{PartNumber}"
										}),
										new sap.m.Text({
											text: "{PartDescription}"
										}),
										new sap.m.Text({
											text: "{Quantity}"
										}),
									]
								});
								var oFreightOrderBoxModel = new JSONModel();
								oFreightOrderBoxModel.setData({
									items: oData.ToBoxHeader.results[i].ToBoxItem.results
								});
								oTable.bindAggregation("items", "/items", colItemList);
								oTable.setModel(oFreightOrderBoxModel);
								oVbox.addItem(oHbox);
								oVbox.addItem(oTable);
								var oTitle = new sap.ui.core.Title();
								form.addContent(oTitle);
								form.addContent(oVbox);
							}
							boxPanelId.addContent(form);
						}
						if (that.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTCDR") {
							that.getView().byId("oCustShipSubMenuCDR").setVisible(false);
							that.getView().byId("idCustShipCDRFreightOrderPanel").setVisible(true);
						} else if (that.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTRFS") {
							that.getView().byId("oCustShipSubMenuRFS").setVisible(false);
							that.getView().byId("idCustShipRFSFreightOrderPanel").setVisible(true);
						}
						oData.DateFormat = that.UserDateFormat;
						that.oFreightOrderModel.setData(oData);
						jQuery.extend(true, that.oFreightOrderModelRevert, that.oFreightOrderModel.getData());
						that._oBusyDialog.close();
					}.bind(that),
					error: function (oError) {
						that.getView().byId("oCustShipSubMenuCDR").setVisible(false);
						that.getView().byId("oCustShipSubMenuCDR").setVisible(true);
						that._oBusyDialog.close();
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);

					}
				});
			} else {
				this._showMessageBoxError("Please select only 'Carrier Updated' Records");
				//MessageBox.error("Please select only 'Carrier Updated' Records")
			}
		},
		handleCUSTFreightOrderBack: function (oEvent) {
			if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTCDR") {
				this.getView().byId("oCustShipSubMenuCDR").setVisible(true);
				this.getView().byId("idCustShipCDRFreightOrderPanel").setVisible(false);
			} else if (this.getView().byId("oCustShipSubMenu").getSelectedKey() === "CUSTRFS") {
				this.getView().byId("oCustShipSubMenuRFS").setVisible(true);
				this.getView().byId("idCustShipRFSFreightOrderPanel").setVisible(false);
			}
		},
		onCUSTShipSaveFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			if (this.userType === "I") {
				oFreightOrderDetails.Region = this._oCustRegionInput.getSelectedKey();
			} else {
				oFreightOrderDetails.RcCode = this._oCustRegionInput.getSelectedKey();
			}
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.ServiceLevel = oFreightOrderModel.ServiceLevel;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.ServiceLevelIndicator = oFreightOrderModel.ServiceLevelIndicator;
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;
			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.ParcelAccountNo = oFreightOrderModel.ParcelAccountNo;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.CountryOfClearence = oFreightOrderModel.CountryOfClearence;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = oFreightOrderModel.BatteryStatus;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	// oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			this.gCustShipment.setDeferredGroups(["FreightOrder"]);
			var sPath = "/FreightHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gCustShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrder"
				});
			this.gCustShipment.submitChanges({
				groupId: "FreightOrder",
				changeSetId: "FreightOrder",
				success: function (oData, oResponse) {
					if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
						this._showMessageBoxSuccess("Data saved Successfully");
						//MessageBox.success("Data saved Successfully");
					} else {
						this._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onCUSTShipReqShipmFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			if (this.userType === "I") {
				oFreightOrderDetails.Region = this._oCustRegionInput.getSelectedKey();
			} else {
				oFreightOrderDetails.RcCode = this._oCustRegionInput.getSelectedKey();
			}
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.ServiceLevel = oFreightOrderModel.ServiceLevel;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.ServiceLevelIndicator = oFreightOrderModel.ServiceLevelIndicator;
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;
			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.ParcelAccountNo = oFreightOrderModel.ParcelAccountNo;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.CountryOfClearence = oFreightOrderModel.CountryOfClearence;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = oFreightOrderModel.BatteryStatus;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			var temp = {};
			temp.ReferenceNumber = oFreightOrderDetails.ReferenceNumber;
			this.gCustShipment.setDeferredGroups(["FreightOrder"]);
			var sPath = "/FreightHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gCustShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrder"
				});
			this.gCustShipment.callFunction("/RequestShipping", {
				urlParameters: temp,
				method: "POST",
				groupId: "FreightOrder"
					//						changeSetId: i,
			});
			var that = this;
			that.gCustShipment.submitChanges({
				groupId: "FreightOrder",
				changeSetId: "FreightOrder",
				success: function (oData, oResponse) {
					if (oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "S") {
						that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgText);
						//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgText);
						that.getCustShip("CDR", "ToCarrierDetermined");
					} else if (oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "E") {
						that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgText);
						//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgText);
					}
					// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
					// 	MessageBox.success("Data saved Successfully");
					// 	that.getCustShip("CDR", "ToCarrierDetermined");
					// } else {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// }
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		handleCustPackingList: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV";
			sUrl = sUrl + "/FileDownloadSet(OutputType='ZAPL',Proforma='" + rowProperty.Proforma + "')/$value";
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		handleCustCommercialInvoice: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV";
			sUrl = sUrl + "/FileDownloadSet(OutputType='ZACI',Proforma='" + rowProperty.Proforma + "')/$value";
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		handleCustPurchaseContract: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_CUSTOMER_SHIPMENTS_SRV";
			sUrl = sUrl + "/FileDownloadSet(OutputType='ZCPC',Proforma='" + rowProperty.Proforma + "')/$value";
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		/*DC Shipment Functionality*/
		onDCReqCarrBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oDCPPRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gDCShipment.setDeferredGroups(["batchFunctionImport"]);
			//			this._oBusyDialog.open();
			if (selectedRows.length > 0) {
				if (selectedRows.length > 150) {
					this._oBusyDialog.close()
					this._showMessageBoxError("The request can only process maximum limit of 150 items");
					//MessageBox.error("The request can only process maximum limit of 150 items");
					return;
				} else {
					var firstShippingPoint = null;
					var that = this;
					for (var i = 0; i < selectedRows.length; i++) {
						var temp = {};
						rowPath = that.getView().byId("oDCPPRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
						rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
						//Validating whether the selected rows have same Shipping Point - Start
						if (selectedRows.length > 1) {
							firstShippingPoint = that.getView().getModel("oViewModel").getProperty(that.getView().byId("oDCPPRTable").getBinding("rows").getContexts()[
								selectedRows[0]].getPath()).ShippingPoint;
							if (firstShippingPoint !== rowProperty.ShippingPoint) {
								that._oBusyDialog.close();
								that._showMessageBoxError("Please select same Shipping Point");
								//MessageBox.error("Please select same Shipping Point");
								return;
							}
						}
						//Validating whether the selected rows have same Shipping Point - END
						if (that.userType === "I") {
							temp.Region = that._oDCRegionInput.getSelectedKey();
							temp.RcCode = '';
						} else if (that.userType === "E") {
							temp.Region = that.oRegionTypeModel.getData().results[0].Region;
							temp.RcCode = that._oDCRegionInput.getSelectedKey();
						}
						temp.PartNo = rowProperty.PartNo;
						temp.ReturnOrder = rowProperty.ReturnOrder;
						temp.ReturnOrderItem = rowProperty.ReturnOrderItem;
						temp.ServiceNotification = rowProperty.ServiceNotification;
						temp.Status = rowProperty.Status;
						data.push(temp);
						that.gDCShipment.callFunction("/RequestCarrier", {
							urlParameters: temp,
							method: "POST",
							batchGroupId: "batchFunctionImport",
							//changeSetId: 1,
						});
						temp = null;
					}
					that._oBusyDialog.close();
					if (selectedRows.length > 10) {
						MessageBox.show("Processing of request will take a few seconds", {
							title: "Information Message",
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							initialFocus: MessageBox.Action.YES,
							emphasizedAction: MessageBox.Action.YES,
							onClose: function (sAction) {
								if (sAction === "YES") {
									that._oBusyDialog.open();
									//Submitting the function import batch call
									that.gDCShipment.submitChanges({
										batchGroupId: "batchFunctionImport",
										changeSetId: 1,
										//Same as the batch group id used previously
										success: function (oData, oResponse) {
											that._oBusyDialog.close();
											if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
												// if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
												that._showMessageBoxSuccess("Carrier Request Submitted Successfuly");
												//MessageBox.success("Carrier Request Submitted Successfuly");
												that.getDCShip("PPR", "ToPartsPendingReturn");
											} else {
												// that._oBusyDialog.close();
												that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
												// MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MsgTxt);
												//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
											}
										}.bind(that),
										error: function (oError) {
											that._oBusyDialog.close();
											that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
											//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
										}
									});
									// this.gDCShipment.callFunction(
									// 	"/RequestCarrier", {
									// 		method: "POST",
									// 		// urlParameter: JSON.stringify(data),
									// 		urlParameters: {
									// 			PartNo: '12345',
									// 			ReturnOrder: '6789',
									// 			ReturnOrderItem: '22',
									// 			ServiceNotification: 'TST',
									// 			Status: 'X'
									// 		},
									// 		success: function (oData, response) {},
									// 		error: function (oError) {}
									// 	});

								} else if (sAction === "NO") {
									that._oBusyDialog.close();
									return;
								}
							}
						});
						that._showMessageBoxShow();
					} else {
						that._oBusyDialog.open();
						that.gDCShipment.submitChanges({
							batchGroupId: "batchFunctionImport",
							changeSetId: 1,
							//Same as the batch group id used previously
							success: function (oData, oResponse) {
								that._oBusyDialog.close();
								if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
									that._showMessageBoxSuccess("Carrier Request Submitted Successfuly");
									//MessageBox.success("Carrier Request Submitted Successfuly");
									that.getDCShip("PPR", "ToPartsPendingReturn");
								} else {
									that._oBusyDialog.close();
									that._showMessageBoxError(oData.__batchResponses[0].__changeResponses[0].data.MsgTxt);
									//MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MsgTxt);
								}
							}.bind(that),
							error: function (oError) {
								that._oBusyDialog.close();
								that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
								//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}
						});
					}
				}
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onDCUpdCarrBtnPress: function (oEvent) {
			var aFilter = [];
			var selectedRows = this.getView().byId("oDCPPRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			if (selectedRows.length > 0) {
				aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this._oDCRegionInput.getSelectedKey()));
				for (var i = 0; i < selectedRows.length; i++) {
					rowPath = this.getView().byId("oDCPPRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					aFilter.push(new sap.ui.model.Filter("DispatchId", sap.ui.model.FilterOperator.EQ, rowProperty.DispatchId));
					aFilter.push(new sap.ui.model.Filter("ServiceNotification", sap.ui.model.FilterOperator.EQ, rowProperty.ServiceNotification));
					aFilter.push(new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, rowProperty.SerialNumber));
					// aFilter.push(new sap.ui.model.Filter("ShipTo", sap.ui.model.FilterOperator.EQ, rowProperty.ShipToPartner));
				}
				var that = this;
				that.gDCShipment.read('/UpdateCarrierSet', {
					filters: aFilter,
					urlParameters: {
						'$expand': 'ToCarrierItem'
					},
					success: function (oData) {
						that.UpdBatteryStatus.setSelectedKey(oData.results[0].BatteryStatus);
						that.oFreightOrderModel.setData(oData.results[0]);
						that.getView().byId("oDCShipSubMenuPPRContainer").setVisible(false);
						that.getView().byId("idDCShipNewPACUpdateCarrPanel").setVisible(true);

						/*AX rdar://76447424:Update Carrier section expand/Collapse */
						this._oDCPacCarrier = this.byId(sap.ui.core.Fragment.createId("idDCShipNewPACUpdateCarrFragment", "oFrightOrderItemTable"));
						this._oDCPacCarrier.addEventDelegate({
							onAfterRendering: function () { 
								document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].setAttribute('role', 'presentation'),
									document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].childNodes[0].setAttribute('title',
										'Item Details Expand/Collapse'),
									document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										1].childNodes[0].childNodes[0].setAttribute('aria-label',
										'Item Details Expand/Collapse')

								document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].setAttribute('role', 'presentation'),
									document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].childNodes[0].setAttribute('title',
										'Shipping Details Expand/Collapse'),
									document.getElementById("__xmlview0--idDCShipNewPACUpdateCarrPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[
										2].childNodes[0].childNodes[0].setAttribute('aria-label',
										'Shipping Details Expand/Collapse')
										
								// document.getElementById("__panel19-CollapsedImg").parentNode.setAttribute('role', 'presentation'),
								// 	document.getElementById("__panel19-CollapsedImg").setAttribute('title',
								// 		'Item Details Expand/Collapse'),
								// 	document.getElementById("__panel19-CollapsedImg").setAttribute('aria-label',
								// 		'Item Details Expand/Collapse')

								// document.getElementById("__panel20-CollapsedImg").parentNode.setAttribute('role', 'presentation'),
								// 	document.getElementById("__panel20-CollapsedImg").setAttribute('title',
								// 		'Shipping Details Expand/Collapse'),
								// 	document.getElementById("__panel20-CollapsedImg").setAttribute('aria-label',
								// 		'Shipping Details Expand/Collapse')
							}
						}, this._oDCPacCarrier)
					}.bind(that),
					error: function (oError) {
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
				// for (var i = 0; i < selectedRows.length; i++) {
				// 	var temp = {};
				// 	rowPath = this.getView().byId("oDCPPRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
				// 	rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
				// 	temp.PartNo = rowProperty.PartNumber;
				// 	temp.ServiceNotification = rowProperty.ServiceNotification;
				// 	temp.Status = rowProperty.Status;
				// 	data.push(temp);
				// 	this.gDCShipment.callFunction("/RequestCarrier", {
				// 		urlParameters: temp,
				// 		method: "POST",
				// 		batchGroupId: "CustbatchFunctionImport",
				// 	});
				// 	temp = null;
				// }
				// this.gDCShipment.submitChanges({
				// 	batchGroupId: "CustbatchFunctionImport",
				// 	changeSetId: 1,
				// 	success: function (oData, oResponse) {
				// 		this.getCustShip("NEW", "ToNew");
				// 		if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
				// 			MessageBox.confirm("Carrier Request Submitted Successfuly");
				// 			this.getCustShip("NEW", "ToNew");
				// 		} else if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
				// 			MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MsgTxt);
				// 		}
				// 	}.bind(this),
				// 	error: function (oError) {
				// 		MessageToast.show("Error");
				// 	}
				// });
			} else {
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		handleDCUpdateCarrierBack: function (oEvent) {
			if (this._oDCRegionInput.getSelectedKey() === "PAC" && this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCCDR") {
				this.getView().byId("oDCShipSubMenuCDRContainer").setVisible(true);
				this.getView().byId("idDCShipCDRFreightOrderPanel").setVisible(false);
				this.getView().byId("idDCShipCDRPACFreightOrderPanel").setVisible(false);
			} else {
				this.getView().byId("oDCShipSubMenuPPRContainer").setVisible(true);
				this.getView().byId("idDCShipNewPACUpdateCarrPanel").setVisible(false);
			}
		},
		onDCShipPACSaveFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			this.gDCShipment.setDeferredGroups(["FreightOrderPAC"]);
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;

			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;

			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipNewPACUpdateCarrFragment",
					"idBatteryStatus"))
				.getSelectedKey();
			var sPath = "/FreightPacHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			var sPathItem = "/FreightPacItemSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gDCShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrderPAC"
				});
			for (var i = 0; i < oFreightOrderModel.ToCarrierItem.results.length; i++) {
				var oFreightOrderItemDetails = {};
				oFreightOrderItemDetails.DispatchId = oFreightOrderModel.ToCarrierItem.results[i].DispatchId;
				// oFreightOrderItemDetails.ShipToPartner = oFreightOrderModel.ToCarrierItem.results[i].ShipToPartner;
				oFreightOrderItemDetails.ServiceNotification = oFreightOrderModel.ToCarrierItem.results[i].ServiceNotification;
				oFreightOrderItemDetails.ReturnOrder = oFreightOrderModel.ToCarrierItem.results[i].ReturnOrder;
				this.gDCShipment.update(
					sPathItem, oFreightOrderItemDetails, {
						groupId: "FreightOrderPAC"
					});
			}
			var that = this;
			that.gDCShipment.submitChanges({
				groupId: "FreightOrderPAC",
				changeSetId: "1",
				success: function (oData, oResponse) {
					if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
						that._showMessageBoxSuccess("Data saved Successfully");
						//MessageBox.success("Data saved Successfully");
						that.onDCUpdCarrBtnPress();
					} else {
						that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onDCShipPACReqFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			this.gDCShipment.setDeferredGroups(["FreightOrderPAC"]);
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;
			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;

			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipNewPACUpdateCarrFragment",
					"idBatteryStatus"))
				.getSelectedKey();
			var sPath = "/FreightPacHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			var sPathItem = "/FreightPacItemSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gDCShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrderPAC"
				});
			for (var i = 0; i < oFreightOrderModel.ToCarrierItem.results.length; i++) {
				var oFreightOrderItemDetails = {};
				oFreightOrderItemDetails.DispatchId = oFreightOrderModel.ToCarrierItem.results[i].DispatchId;
				// oFreightOrderItemDetails.ShipToPartner = oFreightOrderModel.ToCarrierItem.results[i].ShipToPartner;
				oFreightOrderItemDetails.ServiceNotifiation = oFreightOrderModel.ToCarrierItem.results[i].ServiceNotifiation;
				oFreightOrderItemDetails.ReturnOrder = oFreightOrderModel.ToCarrierItem.results[i].ReturnOrder;
				this.gDCShipment.update(
					sPathItem, oFreightOrderItemDetails, {
						groupId: "FreightOrderPAC"
					});
			}
			var temp = {}
			temp.ShipTo = oFreightOrderDetails.ShipTo;
			this.gDCShipment.callFunction("/PacRequestShipping", {
				urlParameters: temp,
				method: "POST",
				groupId: "FreightOrderPAC"
			});
			var that = this;
			that.gDCShipment.submitChanges({
				groupId: "FreightOrderPAC",
				changeSetId: "1",
				success: function (oData, oResponse) {
					// if (oResponse.data.__batchResponses[0].response != "undefined") {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// } else {
					var count = oResponse.data.__batchResponses[0].__changeResponses.length;
					if (oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgType === "S") {
						that.onDCUpdCarrBtnPress();
						that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						this.getDCShip("PPR", "ToPartsPendingReturn");
					} else if (oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgType === "E") {
						that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
						//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[count - 1].data.MsgText);
					}
					// }
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onDCRFSCancelBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var cancelBatchChanges = [];
			var cancelSelectedRows = this.getView().byId("oDCRFSTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gDCShipment.setDeferredGroups(["cancelBatchFunctionImport"]);
			if (cancelSelectedRows.length > 0) {
				var that = this;
				MessageBox.show("Selected shipping documents will be cancelled. Continue", {
					title: "Confirmation",
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					initialFocus: MessageBox.Action.YES,
					emphasizedAction: MessageBox.Action.YES,
					onClose: function (sAction) {
						if (sAction === "YES") {
							that._oBusyDialog.open();
							for (var i = 0; i < cancelSelectedRows.length; i++) {
								var temp = {};
								rowPath = that.getView().byId("oDCRFSTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
								rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
								if (that.userType === "I") {
									temp.Region = that._oDCRegionInput.getSelectedKey();
									temp.RcCode = rowProperty.Shipper;
								} else if (that.userType === "E") {
									temp.Region = that.oRegionTypeModel.getData().results[0].Region;
									temp.RcCode = that._oDCRegionInput.getSelectedKey();
								}

								temp.Proforma = rowProperty.Proforma;
								temp.ReferenceNumber = rowProperty.ReferenceNo;
								data.push(temp);
								that.gDCShipment.callFunction("/RFSCancelShipment", {
									urlParameters: temp,
									method: "POST",
									batchGroupId: "cancelBatchFunctionImport",
									// changeSetId: i,
								});
								temp = null;
							}
							that.gDCShipment.submitChanges({
								batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
								changeSetId: 1,
								success: function (oData, oResponse) {
									that._oBusyDialog.close();
									if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
										that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										that.getDCShip("RFS", "ToReadyForShip");
									} else if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
										that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
										//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
									}
									// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
									// 	that._oBusyDialog.close();
									// 	MessageBox.success("Proforma Cancellation is Successful");
									// 	that.getDCShip("RFS", "ToReadyForShip");
									// } else {
									// 	that._oBusyDialog.close();
									// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
									// }
								}.bind(this),
								error: function (oError) {
									that._oBusyDialog.close();
									that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
									//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
								}
							});
						} else if (sAction === "NO") {
							that._oBusyDialog.close();
							that.getDCShip("RFS", "ToReadyForShip");
						}
					}
				});
				that._showMessageBoxShow();
				// for (var i = 0; i < cancelSelectedRows.length; i++) {
				// 	var temp = {};
				// 	rowPath = this.getView().byId("oDCRFSTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
				// 	rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
				// 	if (this.userType === "I") {
				// 		temp.Region = this._oDCRegionInput.getSelectedKey();
				// 		temp.RcCode = rowProperty.Shipper;
				// 	} else if (this.userType === "E") {
				// 		temp.Region = this.oRegionTypeModel.getData().results[0].Region;
				// 		temp.RcCode = this._oDCRegionInput.getSelectedKey();
				// 	}
				// 	temp.Proforma = rowProperty.Proforma;
				// 	temp.ReferenceNumber = rowProperty.ReferenceNo;
				// 	data.push(temp);
				// 	this.gDCShipment.callFunction("/RFSCancelShipmentValidate", {
				// 		urlParameters: temp,
				// 		method: "POST",
				// 		batchGroupId: "cancelBatchFunctionImport",
				// 		//	changeSetId: i,
				// 	});
				// 	temp = null;
				// }
				// this._oBusyDialog.close();
				// var that = this;
				// that._oBusyDialog.open();
				// //Submitting the function import batch call
				// that.gDCShipment.submitChanges({
				// 	batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
				// 	changeSetId: 1,
				// 	success: function (oData, oresponse) {
				// 		if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
				// 			that._oBusyDialog.close();
				// 			MessageBox.show(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText, {
				// 				title: "Confirmation",
				// 				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				// 				emphasizedAction: MessageBox.Action.YES,
				// 				onClose: function (sAction) {
				// 					data = [];
				// 					if (sAction === "YES") {
				// 						that._oBusyDialog.open();
				// 						for (var i = 0; i < cancelSelectedRows.length; i++) {
				// 							var temp = {};
				// 							rowPath = that.getView().byId("oDCRFSTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
				// 							rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
				// 							if (that.userType === "I") {
				// 								temp.Region = that._oDCRegionInput.getSelectedKey();
				// 								temp.RcCode = rowProperty.Shipper;
				// 							} else if (that.userType === "E") {
				// 								temp.Region = that.oRegionTypeModel.getData().results[0].Region;
				// 								temp.RcCode = that._oDCRegionInput.getSelectedKey();
				// 							}

				// 							temp.Proforma = rowProperty.Proforma;
				// 							temp.ReferenceNumber = rowProperty.ReferenceNo;
				// 							data.push(temp);
				// 							that.gDCShipment.callFunction("/RFSCancelShipment", {
				// 								urlParameters: temp,
				// 								method: "POST",
				// 								batchGroupId: "cancelBatchFunctionImport",
				// 								// changeSetId: i,
				// 							});
				// 							temp = null;
				// 						}
				// 						that.gDCShipment.submitChanges({
				// 							batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
				// 							changeSetId: 1,
				// 							success: function (oData, oResponse) {
				// 								if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
				// 									that._oBusyDialog.close();
				// 									MessageBox.success("Proforma Cancellation is Successful");
				// 									that.getDCShip("RFS", "ToReadyForShip");
				// 								} else {
				// 									that._oBusyDialog.close();
				// 									MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
				// 								}
				// 							}.bind(this),
				// 							error: function (oError) {
				// 								that._oBusyDialog.close();
				// 								MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				// 							}
				// 						});
				// 					} else if (sAction === "NO") {
				// 						that._oBusyDialog.close();
				// 						that.getDCShip("RFS", "ToReadyForShip");
				// 					}
				// 				}
				// 			});
				// 		} else {
				// 			that._oBusyDialog.close();
				// 			MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
				// 		}
				// 	}.bind(this),
				// 	error: function (oError) {
				// 		that._oBusyDialog.close();
				// 		MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				// 	}
				// });
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onDCCDRCancelBtnPress: function (oEvent) {
			this._oBusyDialog.open();
			var data = [];
			var cancelBatchChanges = [];
			var cancelSelectedRows = this.getView().byId("oDCCDRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gDCShipment.setDeferredGroups(["cancelBatchFunctionImport"]);
			if (cancelSelectedRows.length > 0) {
				if (cancelSelectedRows.length > 150) {
					this._oBusyDialog.close();
					this._showMessageBoxError("The request can only process maximum limit of 150 items");
					//MessageBox.error("The request can only process maximum limit of 150 items");
					return;
				} else {
					var that = this;
					var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.show("Selected shipping documents will be cancelled. Continue", {
						title: "Confirmation",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: MessageBox.Action.YES,
						// emphasizedAction: MessageBox.Action.YES,
						onClose: function (sAction) {
							if (sAction === "YES") {
								that._oBusyDialog.open();
								for (var i = 0; i < cancelSelectedRows.length; i++) {
									var temp = {};
									rowPath = that.getView().byId("oDCCDRTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
									rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
									// temp.Proforma = rowProperty.Proforma;
									if (that.userType === "I") {
										temp.Region = that._oDCRegionInput.getSelectedKey();
										temp.RcCode = '';
									} else if (that.userType === "E") {
										temp.Region = that.oRegionTypeModel.getData().results[0].Region;
										temp.RcCode = that._oDCRegionInput.getSelectedKey();
									}

									temp.ReferenceNumber = rowProperty.ReferenceNo;
									data.push(temp);
									that.gDCShipment.callFunction("/CDRCancelShipment", {
										urlParameters: temp,
										method: "POST",
										batchGroupId: "cancelBatchFunctionImport",
										// changeSetId: i,
									});
									temp = null;
								}
								that.gDCShipment.submitChanges({
									batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
									changeSetId: 1,
									success: function (oData, oResponse) {
										that._oBusyDialog.close();
										if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType == "S") {
											that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											that.getDCShip("CDR", "ToCarrierDetermined");
											//if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
										} else {
											that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
											//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
										}
										// }
									}.bind(this),
									error: function (oError) {
										that._oBusyDialog.close();
										that._showMessageBoxError(oError);
										//MessageBox.error(oError);
									}
								});
							} else if (sAction === "NO") {
								that._oBusyDialog.close();
								that._modalKeyFocusOut();
								that.getDCShip("CDR", "ToCarrierDetermined");
							}
						}
					});
					that._showMessageBoxShow();
				}
				// for (var i = 0; i < cancelSelectedRows.length; i++) {
				// 	var temp = {};
				// 	rowPath = this.getView().byId("oDCCDRTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
				// 	rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
				// 	if (this.userType === "I") {
				// 		temp.Region = this._oDCRegionInput.getSelectedKey();
				// 		temp.RcCode = '';
				// 	} else if (this.userType === "E") {
				// 		temp.Region = this.oRegionTypeModel.getData().results[0].Region;
				// 		temp.RcCode = this._oDCRegionInput.getSelectedKey();
				// 	}
				// 	temp.ReferenceNumber = rowProperty.ReferenceNo;
				// 	data.push(temp);
				// 	this.gDCShipment.callFunction("/CDRCancelShipmentValidate", {
				// 		urlParameters: temp,
				// 		method: "POST",
				// 		batchGroupId: "cancelBatchFunctionImport",
				// 	});
				// 	temp = null;
				// }
				// this._oBusyDialog.close();
				// var that = this;
				// that._oBusyDialog.open();
				// //Submitting the function import batch call
				// that.gDCShipment.submitChanges({
				// 	batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
				// 	changeSetId: 1,
				// 	success: function (oData, oresponse) {
				// 		if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
				// 			that._oBusyDialog.close();
				// 			MessageBox.show(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText, {
				// 				title: "Confirmation",
				// 				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				// 				emphasizedAction: MessageBox.Action.YES,
				// 				onClose: function (sAction) {
				// 					data = [];
				// 					if (sAction === "YES") {
				// 						that._oBusyDialog.open();
				// 						for (var i = 0; i < cancelSelectedRows.length; i++) {
				// 							var temp = {};
				// 							rowPath = that.getView().byId("oDCCDRTable").getBinding("rows").getContexts()[cancelSelectedRows[i]].getPath();
				// 							rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
				// 							// temp.Proforma = rowProperty.Proforma;
				// 							if (that.userType === "I") {
				// 								temp.Region = that._oDCRegionInput.getSelectedKey();
				// 								temp.RcCode = '';
				// 							} else if (that.userType === "E") {
				// 								temp.Region = that.oRegionTypeModel.getData().results[0].Region;
				// 								temp.RcCode = that._oDCRegionInput.getSelectedKey();
				// 							}

				// 							temp.ReferenceNumber = rowProperty.ReferenceNo;
				// 							data.push(temp);
				// 							that.gDCShipment.callFunction("/CDRCancelShipment", {
				// 								urlParameters: temp,
				// 								method: "POST",
				// 								batchGroupId: "cancelBatchFunctionImport",
				// 								// changeSetId: i,
				// 							});
				// 							temp = null;
				// 						}
				// 						that.gDCShipment.submitChanges({
				// 							batchGroupId: "cancelBatchFunctionImport", //Same as the batch group id used previously
				// 							changeSetId: 1,
				// 							success: function (oData, oResponse) {
				// 								that._oBusyDialog.close();
				// 								if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType == "S") {
				// 									MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
				// 									that.getDCShip("CDR", "ToCarrierDetermined");
				// 									//if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
				// 								} else {
				// 									MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
				// 									//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
				// 								}
				// 								// }
				// 							}.bind(this),
				// 							error: function (oError) {
				// 								that._oBusyDialog.close();
				// 								MessageBox.error(oError);
				// 							}
				// 						});
				// 					} else if (sAction === "NO") {
				// 						that._oBusyDialog.close();
				// 						that.getDCShip("CDR", "ToCarrierDetermined");
				// 					}
				// 				}
				// 			});
				// 		} else {
				// 			that._oBusyDialog.close();
				// 			MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
				// 		}
				// 	}.bind(this),
				// 	error: function (oError) {
				// 		that._oBusyDialog.close();
				// 		MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				// 	}
				// });
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onDCShipSaveFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			if (this.userType === "I") {
				oFreightOrderDetails.Region = this._oDCRegionInput.getSelectedKey();
			} else {
				oFreightOrderDetails.RcCode = this._oDCRegionInput.getSelectedKey();
			}
			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.ServiceLevel = oFreightOrderModel.ServiceLevel;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.ServiceLevelIndicator = oFreightOrderModel.ServiceLevelIndicator;
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;
			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.ParcelAccountNo = oFreightOrderModel.ParcelAccountNo;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.CountryOfClearence = oFreightOrderModel.CountryOfClearence;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipCDRFreightOrderFragment", "idBatteryStatus"))
				.getSelectedKey();
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			//			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			this.gDCShipment.setDeferredGroups(["FreightOrder"]);
			var sPath = "/FreightHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gDCShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrder"
				});
			this.gDCShipment.submitChanges({
				groupId: "FreightOrder",
				changeSetId: "FreightOrder",
				success: function (oData, oResponse) {
					if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
						this._showMessageBoxSuccess("Data saved successfully");
						//MessageBox.success("Data saved successfully");
					} else {
						this._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					}
				},
				error: function (oError) {
					this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onDCShipReqShipFreightPress: function (oEvent) {
			var oFreightOrderModel = this.getView().getModel("oFreightOrderModel").getData();
			if (!this._FreightOrdervalidation(oFreightOrderModel)) {
				return;
			}
			var oFreightOrderDetails = {};
			oFreightOrderDetails.ReferenceNumber = oFreightOrderModel.ReferenceNumber;
			oFreightOrderDetails.ShipTo = oFreightOrderModel.ShipTo;
			if (this.userType === "I") {
				oFreightOrderDetails.Region = this._oDCRegionInput.getSelectedKey();
			} else {
				oFreightOrderDetails.RcCode = this._oDCRegionInput.getSelectedKey();
			}
			oFreightOrderDetails.Carrier = (oFreightOrderModel.Carrier).toUpperCase();
			oFreightOrderDetails.FreightOrder = oFreightOrderModel.FreightOrder;
			oFreightOrderDetails.TotalGrossWeight = oFreightOrderModel.TotalGrossWeight;
			oFreightOrderDetails.TotalPackages = oFreightOrderModel.TotalPackages;
			oFreightOrderDetails.ServiceLevel = oFreightOrderModel.ServiceLevel;
			oFreightOrderDetails.WeightUnitOfMeasure = (oFreightOrderModel.WeightUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.ShipmentType = (oFreightOrderModel.ShipmentType).toUpperCase();
			oFreightOrderDetails.ServiceLevelIndicator = oFreightOrderModel.ServiceLevelIndicator;
			oFreightOrderDetails.TotalGrossVolume = oFreightOrderModel.TotalGrossVolume;
			oFreightOrderDetails.ModeOfTransport = oFreightOrderModel.ModeOfTransport;
			oFreightOrderDetails.ParcelAccountNo = oFreightOrderModel.ParcelAccountNo;
			oFreightOrderDetails.VolumeUnitOfMeasure = (oFreightOrderModel.VolumeUnitOfMeasure).toUpperCase();
			oFreightOrderDetails.PortOfEntry = oFreightOrderModel.PortOfEntry;
			oFreightOrderDetails.CountryOfClearence = oFreightOrderModel.CountryOfClearence;
			oFreightOrderDetails.ShippingCondition = oFreightOrderModel.ShippingCondition;
			oFreightOrderDetails.PortOfOrigin = oFreightOrderModel.PortOfOrigin;
			oFreightOrderDetails.BatteryStatus = this.byId(sap.ui.core.Fragment.createId("idDCShipCDRFreightOrderFragment", "idBatteryStatus"))
				.getSelectedKey();
			oFreightOrderDetails.CarrierTracking = (oFreightOrderModel.CarrierTracking).toUpperCase();
			// if ((oFreightOrderModel.CarrierHandoverDate).includes(".") === true) {
			// 	var sDate = oFreightOrderModel.CarrierHandoverDate;
			// 	oFreightOrderDetails.CarrierHandoverDate = sDate.substring(6) + sDate.substring(3, 5) + sDate.substring(0, 2);
			// } else {
			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			// }
			//			oFreightOrderDetails.CarrierHandoverDate = oFreightOrderModel.CarrierHandoverDate;
			var temp = {};
			temp.ReferenceNumber = oFreightOrderDetails.ReferenceNumber;
			this.gDCShipment.setDeferredGroups(["FreightOrder"]);
			var sPath = "/FreightHeaderSet('" + oFreightOrderDetails.ReferenceNumber + "')";
			this.gDCShipment.update(
				sPath, oFreightOrderDetails, {
					groupId: "FreightOrder"
				});
			this.gDCShipment.callFunction("/RequestShipping", {
				urlParameters: temp,
				method: "POST",
				groupId: "FreightOrder"
					//						changeSetId: i,
			});
			var that = this;
			that.gDCShipment.submitChanges({
				groupId: "FreightOrder",
				changeSetId: "FreightOrder",
				success: function (oData, oResponse) {
					if (oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "S") {
						that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
						//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
						that.getDCShip("CDR", "ToCarrierDetermined");
					} else if (oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "E") {
						that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
						//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
					}
					// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
					// 	MessageBox.success("Data saved successfully");
					// 	that.getDCShip("CDR", "ToCarrierDetermined");
					// } else {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// }
					// if (oresponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "S") {
					// 	MessageBox.confirm(oresponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
					// } else if (oresponse.data.__batchResponses[0].__changeResponses[1].data.MsgType === "E") {
					// 	MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[1].data.MsgTxt);
					// }
				},
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		_FreightOrdervalidation: function (model) {
			var errorOccured = true;
			if (this._oCustRegionInput.getSelectedKey() === "PAC" || this._oDCRegionInput.getSelectedKey() === "PAC" || this.oRegionTypeModel
				.getData().results[0].Region === "PAC") {
				if ((!model.CarrierTracking) || (!model.Carrier) || (!model.TotalGrossWeight) || (!model.TotalPackages) ||
					(!model.WeightUnitOfMeasure) || (!model.ShipmentType) || (!model.TotalGrossVolume) || (!model.VolumeUnitOfMeasure) || (!model.CarrierHandoverDate)
				) {
					this._showMessageBoxError("Please enter all mandatory fields in Freight screen");
					//MessageBox.error("Please enter all mandatory fields in Freight screen");
					return errorOccured = false;
				}
				if (model.CarrierHandoverDate.substring(6) === "0000") {
					this._showMessageBoxError("Please enter valid Carrier Handover Date");
					//MessageBox.error("Please enter valid Carrier Handover Date");
					return errorOccured = false;
				}

			} else {
				if ((!model.CarrierTracking) || (!model.Carrier) || (!model.TotalGrossWeight) || (!model.TotalPackages) || (!model.ServiceLevel) ||
					(!model.WeightUnitOfMeasure) || (!model.ShipmentType) || (!model.TotalGrossVolume) || (!model.VolumeUnitOfMeasure) || (!model.CarrierHandoverDate)
				) {
					this._showMessageBoxError("Please enter all mandatory fields in Freight screen");
					//MessageBox.error("Please enter all mandatory fields in Freight screen");
					return errorOccured = false;
				}
				if (model.CarrierHandoverDate.substring(6) === "0000") {
					this._showMessageBoxError("Please enter valid Carrier Handover Date");
					//MessageBox.error("Please enter valid Carrier Handover Date");
					return errorOccured = false;
				}
			}
			return errorOccured;
		},
		handleFreightOrderLinkPress: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			if (rowProperty.Carrier) {
				this._oBusyDialog.open();
				var aFilter = [];
				aFilter.push(new sap.ui.model.Filter("ReferenceNumber", sap.ui.model.FilterOperator.EQ, rowProperty.ReferenceNo));
				var that = this;
				that.gDCShipment.read("/FreightHeaderSet('" + rowProperty.ReferenceNo + "')", {
					urlParameters: {
						'$expand': 'ToFreightItem,ToBoxHeader/ToBoxItem'
					},
					success: function (oData, resp) {
						if (that._oDCRegionInput.getSelectedKey() !== "PAC" && that.oRegionTypeModel.getData().results[0].Region !== "PAC") {
							if (that.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCCDR") {
								var boxPanelId = that.byId(sap.ui.core.Fragment.createId("idDCShipCDRFreightOrderFragment", "idBoxDetails"));
								boxPanelId.destroyContent();
							} else {
								var boxPanelId = that.byId(sap.ui.core.Fragment.createId("idDCShipRFSFreightOrderFragment", "idBoxDetails"));
								boxPanelId.destroyContent();
							}
							var form = new sap.ui.layout.form.SimpleForm();
							form.destroyContent();
							for (var i = 0; i < oData.ToBoxHeader.results.length; i++) {
								var oHbox = new sap.m.HBox({});
								var oVbox = new sap.m.VBox({});
								var oImage = new sap.m.Image({
									src: "./images/Box.png"
								});
								var oHbox1 = new sap.m.HBox({});
								oHbox1.addItem(oImage);
								var oHbox2 = new sap.m.HBox({
									items: [
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].BoxName,
										}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginTop")
									]
								}).addStyleClass("sapUiTinyMarginBegin");
								var oHbox3 = new sap.m.HBox({
									items: [
										new sap.m.Label({
											text: "Weight:",
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].GrossWeight,
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: " Volume:",
										}).addStyleClass("sapUiTinyMarginBegin"),
										new sap.m.Label({
											text: oData.ToBoxHeader.results[i].GrossVolume,
										}).addStyleClass("sapUiTinyMarginBegin")
									]
								}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginTop");
								var oHbox4 = new sap.m.HBox();
								oHbox4.addItem(oHbox3);
								var oVbox5 = new sap.m.VBox({
									width: "100%"
								});
								oVbox5.addItem(oHbox2);
								oVbox5.addItem(oHbox4);
								oHbox1.addItem(oVbox5);
								oHbox.addItem(oHbox1);
								var oTable = new sap.m.Table({
									width: "30rem"
								}).addStyleClass("sapUiTinyMarginTop");
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Part Number"
									})
								}));
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Part Description"
									})
								}));
								oTable.addColumn(new sap.m.Column({
									header: new sap.m.Label({
										text: "Quantity"
									})
								}));
								var colItemList = new sap.m.ColumnListItem({
									cells: [
										new sap.m.Text({
											text: "{PartNumber}"
										}),
										new sap.m.Text({
											text: "{PartDescription}"
										}),
										new sap.m.Text({
											text: "{Quantity}"
										}),
									]
								});
								var oFreightOrderBoxModel = new JSONModel();
								oFreightOrderBoxModel.setData({
									items: oData.ToBoxHeader.results[i].ToBoxItem.results
								});
								oTable.bindAggregation("items", "/items", colItemList);
								oTable.setModel(oFreightOrderBoxModel);
								oVbox.addItem(oHbox);
								oVbox.addItem(oTable);
								var oTitle = new sap.ui.core.Title();
								form.addContent(oTitle);
								form.addContent(oVbox);
							}
							boxPanelId.addContent(form);
						}
						if (that.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCCDR") {
							that.getView().byId("oDCShipSubMenuCDRContainer").setVisible(false);
							that.getView().byId("idDCShipCDRFreightOrderPanel").setVisible(true);
						} else {
							that.getView().byId("oDCShipSubMenuRFSContainer").setVisible(false);
							that.getView().byId("idDCShipRFSFreightOrderPanel").setVisible(true);
						}
						that.CDRBatteryStatus.setSelectedKey(oData.BatteryStatus);
						that.RFSBatteryStatus.setSelectedKey(oData.BatteryStatus);
						oData.DateFormat = that.UserDateFormat;
						that.oFreightOrderModel.setData(oData);
						jQuery.extend(true, that.oFreightOrderModelRevert, that.oFreightOrderModel.getData());
						that._oBusyDialog.close();
					}.bind(that),
					error: function (oError) {
						that.getView().byId("oDCShipSubMenuCDRContainer").setVisible(false);
						that.getView().byId("idDCShipCDRFreightOrderPanel").setVisible(true);
						that._oBusyDialog.close();
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				this._showMessageBoxError("Please select only 'Carrier Updated' Records");
				//MessageBox.error("Please select only 'Carrier Updated' Records")
			}
		},
		handleFreightOrderBack: function (oEvent) {
			if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCCDR") {
				this.getView().byId("idDCShipCDRFreightOrderPanel").setVisible(false);
				this.getView().byId("oDCShipSubMenuCDRContainer").setVisible(true);
			} else if (this.getView().byId("oDCShipSubMenu").getSelectedKey() === "DCRFS") {
				this.getView().byId("oDCShipSubMenuRFSContainer").setVisible(true);
				this.getView().byId("idDCShipRFSFreightOrderPanel").setVisible(false);
			}
		},
		handlePackingList: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_DCSHIPMENTS_SRV";
			sUrl = sUrl + "/PackageFileSet('" + rowProperty.Proforma + "')/$value"
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		handleCommercialInvoice: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_DCSHIPMENTS_SRV";
			sUrl = sUrl + "/InvoiceFileSet('" + rowProperty.Proforma + "')/$value"
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		handlePurchaseContract: function (oEvent) {
			var rowPath = oEvent.getSource().getParent().getBindingContext("oViewModel").getPath()
			var rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			this._oBusyDialog.open();
			var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_DCSHIPMENTS_SRV";
			sUrl = sUrl + "/PurchaseContractFileSet('" + rowProperty.Proforma + "')/$value"
			sap.m.URLHelper.redirect(sUrl);
			this._oBusyDialog.close();
		},
		/*Lean Receipts Functionality*/
		onLeanDownloadBtnPress: function (oEvent) {
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oLeanReceiptsNewTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gLeanReceipts.setDeferredGroups(["LeanbatchDownload"]);
			if (selectedRows.length > 0) {
				this._oBusyDialog.open();
				for (var i = 0; i < selectedRows.length; i++) {
					var temp = {};
					rowPath = this.getView().byId("oLeanReceiptsNewTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					if (this.userType === "I") {
						temp.Region = this._oLeanRegionInput.getSelectedKey();
						temp.RcCode = '';
					} else if (this.userType === "E") {
						temp.Region = this.oRegionTypeModel.getData().results[0].Region;
						temp.RcCode = this._oLeanRegionInput.getSelectedKey();
					}
					// temp.Region = this._oLeanRegionInput.getSelectedKey();
					//temp.MaxRows = "1000";
					temp.ServiceNotificationNo = rowProperty.ServiceNotification;
					temp.DispatchID = rowProperty.DispatchID;
					temp.ModuleSerialNo = rowProperty.SerialNumber;
					temp.ShipToPartner = rowProperty.ShipToPartner;
					//temp.ChangeDate = "";
					data.push(temp);
					this.gLeanReceipts.callFunction("/FileDownloadTemplate", {
						urlParameters: temp,
						method: "POST",
						batchGroupId: "LeanbatchDownload",
					});
					temp = null;
				}
				var that = this;
				that.gLeanReceipts.submitChanges({
					batchGroupId: "LeanbatchDownload",
					changeSetId: 1,
					success: function (oData, oResponse) {
						that._oBusyDialog.close();
						var FileGUID = oData.__batchResponses[0].__changeResponses[0].data.FileGUID
						var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_LEAN_RECEIPTS_SRV";
						sUrl = sUrl + "/DownloadTemplateSet(FileGUID='" + FileGUID + "')/$value";
						sap.m.URLHelper.redirect(sUrl);
					},
					error: function (oError) {
						that._oBusyDialog.close();
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
				// }
				// if (selectedRows.length > 0) {
				// 	for (var i = 0; i < selectedRows.length; i++) {
				// 		var temp = {};
				// 		rowPath = this.getView().byId("oLeanReceiptsNewTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
				// 		rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
				// 		data.push(rowProperty);
				// 	}
				// 	var oModel, aCols;
				// 	oModel = data;
				// 	aCols = this.createColumnLeanConfig();
				// 	this.DownloadAction(aCols, oModel);
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onLeanGRUploadBtnPress: function (oEvent) {
			var oView = this.getView();
			if (this._GRFile) {
				this._GRFile.destroy();
				this._GRFile = null;
			}
			if (!this._GRFile) {
				this._GRFile = sap.ui.xmlfragment("GRFile", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.GRuploadFile", this);
				oView.addDependent(this._GRFile);
			}
			var oFileUploader = sap.ui.core.Fragment.byId("GRFile", "fileUploader");
			var ofileupload = oFileUploader.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("GRFile--fileUploader-fu_input-inner").setAttribute('readonly', 'true'),
						document.getElementById("GRFile--fileUploader-fu_input-inner").setAttribute('aria-label', 'Uploaded file name'),
						document.getElementById("GRFile--fileUploader-fu").setAttribute('readonly', 'true')
				}
			}, oFileUploader);
			var oGRFile = sap.ui.core.Fragment.byId("GRFile", "idGRFileDialog");
			var oGRFileUpload = oGRFile.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("GRFile--idGRFileDialog-header").setAttribute('role', 'presentation'),
						document.getElementById("GRFile--idGRFileDialog-firstfe").removeAttribute('tabindex'),
						document.getElementById("GRFile--idGRFileDialog-header").removeAttribute('aria-level'),
						document.getElementById("GRFile--idGRFileDialog-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oGRFile);
			this._GRFile.open();
		},
		onUploadGRCancelBtnPress: function (oEvent) {
			if (this._GRFile) {
				this._GRFile.destroy();
				this._GRFile = null;
			}
		},
		onUploadGRBtnPress: function (oEvent) {
			var oFileUploader = sap.ui.core.Fragment.byId("GRFile", "fileUploader");
			var file = oFileUploader.oFileUpload.files[0];
			if (oFileUploader.getValue() === "") {
				this._showMessageBoxError("Please Choose any File");
				//MessageBox.error("Please Choose any File");
			}
			var token = this.gLeanReceipts.getSecurityToken();
			if (this.userType === "I") {
				var region = this.userType + "," + this._oLeanRegionInput.getSelectedKey();
			} else if (this.userType === "E") {
				var region = this.userType + "," + this._oLeanRegionInput.getSelectedKey();
			}
			// var region = this._oLeanRegionInput.getSelectedKey();
			this._oBusyDialog.open();
			var oUploadURL = "/sap/opu/odata/sap/ZOD_LAZARUS_LEAN_RECEIPTS_SRV/FileUploadSet";
			jQuery.ajax({
				type: 'POST',
				url: oUploadURL,
				contentType: "application/json",
				cache: false,
				processData: false,
				data: file,
				beforeSend: function (xhr) {
					xhr.setRequestHeader("X-CSRF-Token", token);
					xhr.setRequestHeader("slug", region);
					xhr.setRequestHeader("mimeType", file.type);
				},
				success: function (data, response) {
					this._oBusyDialog.close();
					sap.m.MessageToast.show("File upload Successful");
					this.onUploadGRCancelBtnPress();
					this.getLean("NEW", "ToNew");
				}.bind(this),
				error: function (error) {
					this._oBusyDialog.close();
					this.onUploadGRCancelBtnPress();
					var parser, xmlDoc;
					parser = new DOMParser();
					xmlDoc = parser.parseFromString(error.responseText, "text/xml");
					this._showMessageBoxError(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
					//MessageBox.error(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}.bind(this)
			});
		},
		onLeanGRDownloadBtnPress: function (oEvent) {
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oLeanReceiptsGRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			this.gLeanReceipts.setDeferredGroups(["LeanbatchDownload"]);
			if (selectedRows.length > 0) {
				this._oBusyDialog.open();
				for (var i = 0; i < selectedRows.length; i++) {
					var temp = {};
					rowPath = this.getView().byId("oLeanReceiptsGRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					if (this.userType === "I") {
						temp.Region = this._oLeanRegionInput.getSelectedKey();
						temp.RcCode = '';
					} else if (this.userType === "E") {
						temp.Region = this.oRegionTypeModel.getData().results[0].Region;
						temp.RcCode = this._oLeanRegionInput.getSelectedKey();
					}
					// temp.Region = this._oLeanRegionInput.getSelectedKey();
					temp.MaxRows = "500";
					temp.ServiceNotificationNo = rowProperty.ServiceNotification;
					temp.DispatchID = rowProperty.DispatchID;
					temp.ModuleSerialNo = rowProperty.SerialNumber;
					temp.ShipToPartner = rowProperty.ShipToPartner;
					temp.ChangeDate = "";
					data.push(temp);
					this.gLeanReceipts.callFunction("/FileDownloadTemplate", {
						urlParameters: temp,
						method: "POST",
						batchGroupId: "LeanbatchDownload",
					});
					temp = null;
				}
				this.gLeanReceipts.submitChanges({
					batchGroupId: "LeanbatchDownload",
					changeSetId: 1,
					success: function (oData, oResponse) {
						this._oBusyDialog.close();
						var FileGUID = oData.__batchResponses[0].__changeResponses[0].data.FileGUID
						var sUrl = "/sap/opu/odata/SAP/ZOD_LAZARUS_LEAN_RECEIPTS_SRV";
						sUrl = sUrl + "/DownloadTemplateSet(FileGUID='" + FileGUID + "')/$value";
						sap.m.URLHelper.redirect(sUrl);
					},
					error: function (oError) {
						this._oBusyDialog.close();
						this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onLeanGRDeleteBtnPress: function (oEvent) {
			var data = [];
			var batchChanges = [];
			var selectedRows = this.getView().byId("oLeanReceiptsGRTable").getSelectedIndices();
			var rowPath = "";
			var rowProperty = "";
			var that = this;
			that.gLeanReceipts.setDeferredGroups(["LeanDeletebatchDownload"]);
			if (selectedRows.length > 0) {
				that._oBusyDialog.open();
				for (var i = 0; i < selectedRows.length; i++) {
					var temp = {};
					rowPath = that.getView().byId("oLeanReceiptsGRTable").getBinding("rows").getContexts()[selectedRows[i]].getPath();
					rowProperty = that.getView().getModel("oViewModel").getProperty(rowPath);
					temp.ServiceNotification = rowProperty.ServiceNotification;
					temp.DispatchID = rowProperty.DispatchID;
					temp.Status = rowProperty.Status;
					data.push(temp);
					that.gLeanReceipts.callFunction("/GRDelete", {
						urlParameters: temp,
						method: "POST",
						batchGroupId: "LeanDeletebatchDownload",
					});
					temp = null;
				}
				that._oBusyDialog.open();
				that.gLeanReceipts.submitChanges({
					batchGroupId: "LeanDeletebatchDownload",
					changeSetId: 1,
					success: function (oData, oResponse) {
						that._oBusyDialog.close();
						if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
							that._oBusyDialog.close();
							that._showMessageBoxSuccess("GR Details Deleted Successfully");
							//MessageBox.success("GR Details Deleted Successfully");
							that.getLean("GRC", "ToGRCompleted");
						} else {
							that._oBusyDialog.close();
							that._showMessageBoxError(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
							//MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
						}

						// if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
						// 	MessageBox.success(oData.__batchResponses[0].__changeResponses[0].data.MsgText);
						// 	that.getLean("GRC", "ToGRCompleted");
						// } else if (oData.__batchResponses[0].__changeResponses[0].data.MsgType === "E") {
						// 	MessageBox.error(oData.__batchResponses[0].__changeResponses[0].data.MsgText);
						// }
					},
					error: function (oError) {
						that._oBusyDialog.close();
						that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				that._oBusyDialog.close();
				that._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onLeanGREditBtnPress: function (oEvent) {
			var aFilter = [];
			var editSelectedRows;
			editSelectedRows = this.getView().byId("oLeanReceiptsGRTable").getSelectedIndices();
			if (editSelectedRows.length > 0) {
				var rowPath = "";
				var rowProperty = "";
				aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this._oLeanRegionInput.getSelectedKey()));
				for (var i = 0; i < editSelectedRows.length; i++) {
					rowPath = this.getView().byId("oLeanReceiptsGRTable").getBinding("rows").getContexts()[editSelectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					aFilter.push(new sap.ui.model.Filter("DispatchID", sap.ui.model.FilterOperator.EQ, rowProperty.DispatchID));
				}
				var EditGRModel = new JSONModel();
				this.getView().setModel(EditGRModel, "EditGRModel");
				this.gLeanReceipts.read('/GoodsReceiptSet', {
					filters: aFilter,
					success: function (oData, resp) {
						EditGRModel.setData(oData.results);
						var oView = this.getView();
						if (this._GREdit) {
							this._GREdit.destroy();
							this._GREdit = null;
						}
						if (!this._GREdit) {
							this._GREdit = sap.ui.xmlfragment("GRFile", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.LeanReceiptsGREdit", this);
							oView.addDependent(this._GREdit);
						}
						var oGRFile = sap.ui.core.Fragment.byId("GRFile", "idLeanReceiptsGREDIT");
						var oGRFileUpload = oGRFile.addEventDelegate({
							onAfterRendering: function () {
								document.getElementById("GRFile--idLeanReceiptsGREDIT-header").setAttribute('role', 'presentation'),
									document.getElementById("GRFile--idLeanReceiptsGREDIT-firstfe").removeAttribute('tabindex'),
									document.getElementById("GRFile--idLeanReceiptsGREDIT-header").removeAttribute('aria-level'),
									document.getElementById("GRFile--idLeanReceiptsGREDIT-footer").setAttribute('role', 'presentation')
							}
						}, oGRFile);
						this._GREdit.open();
						this._oBusyDialog.close();
					}.bind(this),
					error: function (oError) {
						this._oBusyDialog.close();
						this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onLeanNEWGRBtnPress: function (oEvent) {
			var aFilter = [];
			var editSelectedRows;
			editSelectedRows = this.getView().byId("oLeanReceiptsNewTable").getSelectedIndices();
			if (editSelectedRows.length > 0) {
				var rowPath = "";
				var rowProperty = "";
				aFilter.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, this._oLeanRegionInput.getSelectedKey()));
				for (var i = 0; i < editSelectedRows.length; i++) {
					rowPath = this.getView().byId("oLeanReceiptsNewTable").getBinding("rows").getContexts()[editSelectedRows[i]].getPath();
					rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
					aFilter.push(new sap.ui.model.Filter("DispatchID", sap.ui.model.FilterOperator.EQ, rowProperty.DispatchID));
				}
				var EditGRModel = new JSONModel();
				this.getView().setModel(EditGRModel, "EditGRModel");
				this.gLeanReceipts.read('/GoodsReceiptSet', {
					filters: aFilter,
					success: function (oData, resp) {
						EditGRModel.setData(oData.results);
						var oView = this.getView();
						if (this._GREdit) {
							this._GREdit.destroy();
							this._GREdit = null;
						}
						if (!this._GREdit) {
							this._GREdit = sap.ui.xmlfragment("GRFile", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.LeanReceiptsGREdit", this);
							oView.addDependent(this._GREdit);
						}
						this._GREdit.open();
						this._oBusyDialog.close();
					}.bind(this),
					error: function (oError) {
						this._oBusyDialog.close();
						this._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
						//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					}
				});
			} else {
				this._oBusyDialog.close();
				this._showMessageBoxError("Please select atleast one record");
				//MessageBox.error("Please select atleast one record");
			}
		},
		onLeanEditCancelBtnPress: function (oEvent) {
			if (this._GREdit) {
				this._GREdit.destroy();
				this._GREdit = null;
			}
		},
		onLeanEditSubmitBtnPress: function (oEvent) {
			var GREditDetailsModel = this.getView().getModel("EditGRModel").getData();
			var data = [];
			var TabType = this.getView().byId("oLeanReceiptsSubMenu").getSelectedKey();
			for (var i = 0; i < GREditDetailsModel.length; i++) {
				var temp = {};
				temp.DispatchID = GREditDetailsModel[i].DispatchID;
				temp.ServiceNotification = GREditDetailsModel[i].ServiceNotification;
				temp.GRCarrier = GREditDetailsModel[i].GRCarrier;
				temp.GRCarrierTrackingNo = GREditDetailsModel[i].GRCarrierTrackingNo;
				temp.GRDate = GREditDetailsModel[i].GRDate;
				temp.GRTime = (GREditDetailsModel[0].GRTime).substr(0, 2) + "" + (GREditDetailsModel[0].GRTime).substr(3, 2) + "" + (
					GREditDetailsModel[0].GRTime).substr(6, 2)
				temp.GRTimeZone = GREditDetailsModel[i].GRTimeZone;
				temp.GRStatus = GREditDetailsModel[i].GRStatus;
				temp.TabType = TabType;
				data.push(temp);
				this.gLeanReceipts.callFunction("/GREditSubmit", {
					urlParameters: temp,
					method: "POST",
					batchGroupId: "editBatchFunctionImport",
				});
				temp = null;
			}
			var that = this;
			that.gLeanReceipts.submitChanges({
				batchGroupId: "editBatchFunctionImport", //Same as the batch group id used previously
				changeSetId: 1,
				success: function (oData, oresponse) {
					if (oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
						that._showMessageBoxSuccess(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						//MessageBox.success(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						that.onLeanEditCancelBtnPress();
						if (that.getView().byId("oLeanReceiptsSubMenu").getSelectedKey() === "NEW") {
							that.getLean("NEW", "ToNew");
						} else if (that.getView().byId("oLeanReceiptsSubMenu").getSelectedKey() === "GRC") {
							that.getLean("GRC", "ToGRCompleted");
						}
					} else {
						that._showMessageBoxError(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						//MessageBox.error(oresponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
					}
				}.bind(this),
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onLeanEditValidateBtnPress: function (oEvent) {
			var GREditDetailsModel = this.getView().getModel("EditGRModel").getData();
			var data = [];
			var TabType = this.getView().byId("oLeanReceiptsSubMenu").getSelectedKey();
			for (var i = 0; i < GREditDetailsModel.length; i++) {
				var temp = {};
				temp.DispatchID = GREditDetailsModel[i].DispatchID;
				temp.ServiceNotification = GREditDetailsModel[i].ServiceNotification;
				temp.GRCarrier = GREditDetailsModel[i].GRCarrier;
				temp.GRCarrierTrackingNo = GREditDetailsModel[i].GRCarrierTrackingNo;
				temp.GRDate = GREditDetailsModel[i].GRDate;
				temp.GRTime = (GREditDetailsModel[0].GRTime).substr(0, 2) + "" + (GREditDetailsModel[0].GRTime).substr(3, 2) + "" + (
					GREditDetailsModel[0].GRTime).substr(6, 2)
				temp.GRTimeZone = GREditDetailsModel[i].GRTimeZone;
				temp.GRStatus = GREditDetailsModel[i].GRStatus;
				temp.TabType = TabType;
				data.push(temp);
				this.gLeanReceipts.callFunction("/GREditValidate", {
					urlParameters: temp,
					method: "POST",
					batchGroupId: "editBatchFunctionImport",
				});
				temp = null;
			}
			var that = this;
			that.gLeanReceipts.setDeferredGroups(["editBatchFunctionImport"]);
			//Submitting the function import batch call
			that.gLeanReceipts.submitChanges({
				batchGroupId: "editBatchFunctionImport", //Same as the batch group id used previously
				changeSetId: 1,
				success: function (oData, oResponse) {
					// if (typeof oResponse.data.__batchResponses[0].response === "undefined") {
					// 	MessageBox.success("Successfully validated");
					// 	sap.ui.getCore().byId("GRFile--idLeanReceiptsGREdit").setEnabled(true);
					// } else {
					// 	MessageBox.error(JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value);
					// }
					if (oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgType === "S") {
						that._showMessageBoxSuccess(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						//MessageBox.success(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						sap.ui.getCore().byId("GRFile--idLeanReceiptsGREdit").setEnabled(true);
					} else {
						that._showMessageBoxError(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
						//MessageBox.error(oResponse.data.__batchResponses[0].__changeResponses[0].data.MsgText);
					}
				}.bind(this),
				error: function (oError) {
					that._showMessageBoxError(JSON.parse(oError.responseText).error.message.value);
					//MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		createColumnLeanConfig: function () {
			return [{
				label: "Dispatch Id",
				property: "DispatchID",
				width: "25"
			}, {
				label: "Material Number",
				property: "PartNumber",
				width: "25"
			}, {
				label: "Serial Number",
				property: "SerialNumber",
				width: "25"
			}, {
				label: "Carrier",
				property: "GRCarrier",
				width: "25"
			}, {
				label: "GRCTN",
				property: "GRCarrierTrackingNo",
				width: "18"
			}, {
				label: "GR Time(HHMMSS)",
				property: "GRTime",
				width: "25"
			}, {
				label: "GR Date",
				property: "GRDate",
				width: "25"
			}, {
				label: "GR Timezone",
				property: "GRTimeZone",
				width: "25"
			}];
		},
		/*Clearing Table Filter, Selection*/
		clearCustTableColumnFilters: function () {
			var oCustNEWtable = this.getView().byId("oCustNewTable");
			var oCustCDRTable = this.getView().byId("oCustCDRTable");
			var oCustRFStable = this.getView().byId("oCustRFSTable");
			var oCustERRTable = this.getView().byId("oCustERRTable");
			oCustNEWtable.clearSelection();
			oCustCDRTable.clearSelection();
			oCustERRTable.clearSelection();
			oCustNEWtable.clearSelection();
			for (var t = 0; t < oCustNEWtable.getColumns().length; t++) {
				oCustNEWtable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oCustCDRTable.getColumns().length; t++) {
				oCustCDRTable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oCustRFStable.getColumns().length; t++) {
				oCustRFStable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oCustERRTable.getColumns().length; t++) {
				oCustERRTable.getColumns()[t].filter("");
			}
		},
		clearDCTableColumnFilters: function () {
			var oDCPPRTable = this.getView().byId("oDCPPRTable");
			var oDCCDRTable = this.getView().byId("oDCCDRTable");
			var oDCRFSTable = this.getView().byId("oDCRFSTable");
			var oDCERRTable = this.getView().byId("oDCERRTable");
			oDCPPRTable.clearSelection();
			oDCCDRTable.clearSelection();
			oDCRFSTable.clearSelection();
			oDCERRTable.clearSelection();
			for (var t = 0; t < oDCPPRTable.getColumns().length; t++) {
				oDCPPRTable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oDCCDRTable.getColumns().length; t++) {
				oDCCDRTable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oDCRFSTable.getColumns().length; t++) {
				oDCRFSTable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oDCERRTable.getColumns().length; t++) {
				oDCERRTable.getColumns()[t].filter("");
			}
		},
		clearLeanTableColumnFilters: function () {
			var oLeanNEWTable = this.getView().byId("oLeanReceiptsNewTable");
			var oLeanGRTable = this.getView().byId("oLeanReceiptsGRTable");
			oLeanNEWTable.clearSelection();
			oLeanGRTable.clearSelection();
			for (var t = 0; t < oLeanNEWTable.getColumns().length; t++) {
				oLeanNEWTable.getColumns()[t].filter("");
			}
			for (var t = 0; t < oLeanNEWTable.getColumns().length; t++) {
				oLeanNEWTable.getColumns()[t].filter("");
			}
		},
		/*Reset Filter*/
		resetCustShipFilterBy: function () {
			this.fileShip = false;
			this._oCustDispatchIdMultiInput.removeAllTokens();
			this._oCustSerNotNoMultiInput.removeAllTokens();
			this.byId(sap.ui.core.Fragment.createId("idCustFilterByFragment", "idDCChgDate")).setValue("");
			// this._oCustSerNotNoMultiInput.removeAllTokens();
			this._oCustPurchaseOrderMultiInput.removeAllTokens();
			this._oCustModSerNoMultiInput.removeAllTokens();
			this._oCustShiptoPartnerMultiInput.removeAllTokens();
			this._oCustMaxRows.setValue("500");
			this.oCustERDate.setValue("");
		},
		resetDCShipFilterBy: function () {
			this.fileShip = false;
			// this.getView().byId("idDCRegion").setValue("AMR");
			this._oDCDispatchIdMultiInput.removeAllTokens();
			this._oDCSerNotNoMultiInput.removeAllTokens();
			this._oDCModSerNoMultiInput.removeAllTokens();
			this._oDCPurchaseOrderMultiInput.removeAllTokens();
			this._oDCSerNotNoMultiInput.removeAllTokens();
			this._oDCShipfromPartnerMultiInput.removeAllTokens();
			this._oDCRMAMultiInput.removeAllTokens();
			this.byId(sap.ui.core.Fragment.createId("idDCFilterByFragment", "idDCChgDate")).setValue("");
			this._oDCMaxRows.setValue("500");
			this.oDCERDate.setValue("");
		},
		resetLeanFilterBy: function () {
			this.fileShip = false;
			this._oLeanDispatchIdMultiInput.removeAllTokens();
			this._oLeanSerNotNoMultiInput.removeAllTokens();
			this._oLeanModSerNoMultiInput.removeAllTokens();
			this._oLeanShiptoPartnerMultiInput.removeAllTokens();
			this.byId(sap.ui.core.Fragment.createId("idLeanReceiptsFilterByFragment", "idDCChgDate")).setValue("");
			this._oLeanMaxRows.setValue("500");
			this.oLeanERDate.setValue("");
		},
		resetCVMValuesFilterBy: function () {
			this.fileShip = false;
			(this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMConType"))).setValue("");
			(this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMFrom"))).setValue("");
			(this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMTo"))).setValue("");
			(this.byId(sap.ui.core.Fragment.createId("idCVMValuesFilterByFragment", "idCVMBatchNo"))).setValue("");
			this._oCVMPartNoMultiInput.removeAllTokens();
			this._oCVMSourCountryMultiInput.removeAllTokens();
			this._oCVMDestCountryMultiInput.removeAllTokens();
			this._oCVMMaxRows.setValue("500");
			// this.oCVMERDate.setValue("");
		},
		/*Value Help*/
		onValueHelpSerNotNo: function () {
			if (this._serviceNo) {
				this._serviceNo.destroy();
				this._serviceNo = null;
			}
			var oView = this.getView();
			if (!this._serviceNo) {
				this._serviceNo = sap.ui.xmlfragment("serviceNo", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.serviceNotification", this);
				oView.addDependent(this._serviceNo);
				this._serviceNo.setRangeKeyFields([{
					label: "Service Notification",
					key: "ServiceNo",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._serviceNo.setTokens(this._oCustSerNotNoMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._serviceNo.setTokens(this._oDCSerNotNoMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._serviceNo.setTokens(this._oLeanSerNotNoMultiInput.getTokens());
			}
			var oServiceNo = sap.ui.core.Fragment.byId("serviceNo", "idServiceNo");
			oServiceNo.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oServiceNo);
			//Radr#75359054 - Start
			oServiceNo.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[i]
							.id).getAttribute('value'));
					}
				}
			}, oServiceNo);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oServiceNo.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oServiceNo);
			//Radr#75473561 - End
			var oServiceNoDialog = oServiceNo.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("serviceNo--idServiceNo-header").setAttribute('role', 'presentation'),
						document.getElementById("serviceNo--idServiceNo-firstfe").removeAttribute('tabindex'),
						document.getElementById("serviceNo--idServiceNo-header").removeAttribute('aria-level'),
						document.getElementById("serviceNo--idServiceNo-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oServiceNo);
			this._serviceNo.open();
		},
		onValueHelpSerNotNoOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._oCustSerNotNoMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._oDCSerNotNoMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._oLeanSerNotNoMultiInput.setTokens(aTokens);
			}
			this._serviceNo.close();
		},
		onValueHelpSerNotNoCancelPress: function () {
			this._serviceNo.close();
		},
		onValueHelpDispatchID: function () {
			if (this._dispatchId) {
				this._dispatchId.destroy();
				this._dispatchId = null;
			}
			var oView = this.getView();
			if (!this._dispatchId) {
				this._dispatchId = sap.ui.xmlfragment("dispatchId", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.dispatchId", this);
				oView.addDependent(this._dispatchId);
				this._dispatchId.setRangeKeyFields([{
					label: "Dispatch ID",
					key: "dispatchId",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._dispatchId.setTokens(this._oCustDispatchIdMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._dispatchId.setTokens(this._oDCDispatchIdMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._dispatchId.setTokens(this._oLeanDispatchIdMultiInput.getTokens());
			}
			var oDispatchID = sap.ui.core.Fragment.byId("dispatchId", "idDispatchID");
			oDispatchID.addEventDelegate({
					onAfterRendering: function () {
						var oPanel = this.$().find('.sapMDialogResizeHandler');
						document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
					}
				},
				oDispatchID);
			//Radr#75359054 - Start
			oDispatchID.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oDispatchID);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oDispatchID.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oDispatchID);
			//Radr#75473561 - End
			var oDispatchIdDialog = oDispatchID.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("dispatchId--idDispatchID-header").setAttribute('role', 'presentation'),
						document.getElementById("dispatchId--idDispatchID-firstfe").removeAttribute('tabindex'),
						document.getElementById("dispatchId--idDispatchID-header").removeAttribute('aria-level'),
						document.getElementById("dispatchId--idDispatchID-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oDispatchID);
			this._dispatchId.open();
		},
		onValueHelpDispatchIDOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._oCustDispatchIdMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._oDCDispatchIdMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._oLeanDispatchIdMultiInput.setTokens(aTokens);
			}
			this._dispatchId.close();
		},
		onValueHelpDispatchIDCancelPress: function () {
			this._dispatchId.close();
		},
		onValueHelpModSerNo: function () {
			if (this._ModSerNo) {
				this._ModSerNo.destroy();
				this._ModSerNo = null;
			}
			var oView = this.getView();
			if (!this._ModSerNo) {
				this._ModSerNo = sap.ui.xmlfragment("ModSerNo", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.moduleSerialNo", this);
				oView.addDependent(this._ModSerNo);
				this._ModSerNo.setRangeKeyFields([{
					label: "Module Serial No.",
					key: "ModSerNo",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._ModSerNo.setTokens(this._oCustModSerNoMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._ModSerNo.setTokens(this._oDCModSerNoMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._ModSerNo.setTokens(this._oLeanModSerNoMultiInput.getTokens());
			}
			var oModSerNo = sap.ui.core.Fragment.byId("ModSerNo", "idModSerNo");
			oModSerNo.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oModSerNo);
			//Radr#75359054 - Start
			oModSerNo.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oModSerNo);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oModSerNo.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oModSerNo);
			//Radr#75473561 - End
			var oModSerNoDialog = oModSerNo.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("ModSerNo--idModSerNo-header").setAttribute('role', 'presentation'),
						document.getElementById("ModSerNo--idModSerNo-firstfe").removeAttribute('tabindex'),
						document.getElementById("ModSerNo--idModSerNo-header").removeAttribute('aria-level'),
						document.getElementById("ModSerNo--idModSerNo-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oModSerNo);
			this._ModSerNo.open();
		},
		onValueHelpModSerNoOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._oCustModSerNoMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "DCSHIP") {
				this._oDCModSerNoMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._oLeanModSerNoMultiInput.setTokens(aTokens);
			}
			this._ModSerNo.close();
		},
		onValueHelpModSerNoCancelPress: function () {
			this._ModSerNo.close();
		},
		onValueHelpPurchaseOrder: function () {
			if (this._PurchaseOrder) {
				this._PurchaseOrder.destroy();
				this._PurchaseOrder = null;
			}
			var oView = this.getView();
			if (!this._PurchaseOrder) {
				this._PurchaseOrder = sap.ui.xmlfragment("PurchaseOrder", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.purchaseOrder", this);
				oView.addDependent(this._PurchaseOrder);
				this._PurchaseOrder.setRangeKeyFields([{
					label: "Purchase Order",
					key: "ModSePurchaseOrderger",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._PurchaseOrder.setTokens(this._oCustPurchaseOrderMultiInput.getTokens());
			} else {
				this._PurchaseOrder.setTokens(this._oDCPurchaseOrderMultiInput.getTokens());
			}
			var oPurchaseOrder = sap.ui.core.Fragment.byId("PurchaseOrder", "idPurchaseOrder");
			oPurchaseOrder.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oPurchaseOrder);
			//Radr#75359054 - Start
			oPurchaseOrder.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oPurchaseOrder);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oPurchaseOrder.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oPurchaseOrder);
			//Radr#75473561 - End
			var oPurchaseOrderDialog = oPurchaseOrder.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("PurchaseOrder--idPurchaseOrder-header").setAttribute('role', 'presentation'),
						document.getElementById("PurchaseOrder--idPurchaseOrder-firstfe").removeAttribute('tabindex'),
						document.getElementById("PurchaseOrder--idPurchaseOrder-header").removeAttribute('aria-level'),
						document.getElementById("PurchaseOrder--idPurchaseOrder-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oPurchaseOrder);
			this._PurchaseOrder.open();
		},
		onValueHelpPurchaseOrderOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._oCustPurchaseOrderMultiInput.setTokens(aTokens);
			} else {
				this._oDCPurchaseOrderMultiInput.setTokens(aTokens);
			}
			this._PurchaseOrder.close();
		},
		onValueHelpPurchaseOrderCancelPress: function () {
			this._PurchaseOrder.close();
		},
		onValueHelpShipTo: function () {
			if (this._ShipToPartner) {
				this._ShipToPartner.destroy();
				this._ShipToPartner = null;
			}
			var oView = this.getView();
			if (!this._ShipToPartner) {
				this._ShipToPartner = sap.ui.xmlfragment("ShipToPartner", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.shipToPartner", this);
				oView.addDependent(this._ShipToPartner);
				this._ShipToPartner.setRangeKeyFields([{
					label: "Ship-To Partner",
					key: "ShipToPartner",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._ShipToPartner.setTokens(this._oCustShiptoPartnerMultiInput.getTokens());
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._ShipToPartner.setTokens(this._oLeanShiptoPartnerMultiInput.getTokens());
			}
			var oShipToPartner = sap.ui.core.Fragment.byId("ShipToPartner", "idShipToPartner");
			oShipToPartner.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oShipToPartner);
			//Radr#75359054 - Start
			oShipToPartner.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oShipToPartner);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oShipToPartner.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oShipToPartner);
			//Radr#75473561 - End
			var oShipToPartnerDialog = oShipToPartner.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("ShipToPartner--idShipToPartner-header").setAttribute('role', 'presentation'),
						document.getElementById("ShipToPartner--idShipToPartner-firstfe").removeAttribute('tabindex'),
						document.getElementById("ShipToPartner--idShipToPartner-header").removeAttribute('aria-level'),
						document.getElementById("ShipToPartner--idShipToPartner-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');
				}
			}, oShipToPartner);
			this._ShipToPartner.open();
		},
		onValueHelpShipFromOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			// if (this.oMainSelectedKey === "CUSTSHIP") {
			this._oDCShipfromPartnerMultiInput.setTokens(aTokens);
			// } else if (this.oMainSelectedKey === "LEANREC") {
			// 	this._oLeanShiptoPartnerMultiInput.setTokens(aTokens);
			// }
			this._ShipFromPartner.close();
		},
		onValueHelpShipToOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (this.oMainSelectedKey === "CUSTSHIP") {
				this._oCustShiptoPartnerMultiInput.setTokens(aTokens);
			} else if (this.oMainSelectedKey === "LEANREC") {
				this._oLeanShiptoPartnerMultiInput.setTokens(aTokens);
			}
			this._ShipToPartner.close();
		},
		onValueHelpShipFrom: function () {
			if (this._ShipFromPartner) {
				this._ShipFromPartner.destroy();
				this._ShipFromPartner = null;
			}
			var oView = this.getView();
			if (!this._ShipFromPartner) {
				this._ShipFromPartner = sap.ui.xmlfragment("ShipFromPartner", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.shipFromPartner", this);
				oView.addDependent(this._ShipFromPartner);
				this._ShipFromPartner.setRangeKeyFields([{
					label: "Ship-From Partner",
					key: "ShipFromPartner",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			this._ShipFromPartner.setTokens(this._oDCShipfromPartnerMultiInput.getTokens());
			var oShipFromPartner = sap.ui.core.Fragment.byId("ShipFromPartner", "idShipFromPartner");
			oShipFromPartner.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oShipFromPartner);
			//Radr#75359054 - Start
			oShipFromPartner.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oShipFromPartner);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oShipFromPartner.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oShipFromPartner);
			//Radr#75473561 - End
			var oShipFromPartnerDialog = oShipFromPartner.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("ShipFromPartner--idShipFromPartner-header").setAttribute('role', 'presentation'),
						document.getElementById("ShipFromPartner--idShipFromPartner-firstfe").removeAttribute('tabindex'),
						document.getElementById("ShipFromPartner--idShipFromPartner-header").removeAttribute('aria-level'),
						document.getElementById("ShipFromPartner--idShipFromPartner-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oShipFromPartner);
			this._ShipFromPartner.open();
		},
		onValueHelpShipFromCancelPress: function () {
			this._ShipFromPartner.close();
		},
		onValueHelpShipToCancelPress: function () {
			this._ShipToPartner.close();
		},
		onValueHelpRMA: function () {
			if (this._RMA) {
				this._RMA.destroy();
				this._RMA = null;
			}
			var oView = this.getView();
			if (!this._RMA) {
				this._RMA = sap.ui.xmlfragment("RMA", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.RMA", this);
				oView.addDependent(this._RMA);
				this._RMA.setRangeKeyFields([{
					label: "RMA",
					key: "RMA",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			this._RMA.setTokens(this._oDCRMAMultiInput.getTokens());
			var oRMA = sap.ui.core.Fragment.byId("RMA", "idRMA");
			oRMA.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oRMA);
			//Radr#75359054 - Start			
			oRMA.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oRMA);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oRMA.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oRMA);
			//Radr#75473561 - End
			var oRMADialog = oRMA.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("RMA--idRMA-header").setAttribute('role', 'presentation'),
						document.getElementById("RMA--idRMA-firstfe").removeAttribute('tabindex'),
						document.getElementById("RMA--idRMA-header").removeAttribute('aria-level'),
						document.getElementById("RMA--idRMA-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oRMA);
			this._RMA.open();
		},
		onValueHelpRMAOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oDCRMAMultiInput.setTokens(aTokens);
			this._RMA.close();
		},
		onValueHelpRMACancelPress: function () {
			this._RMA.close();
		},
		onValueHelpPartNo: function () {
			if (this._PartNo) {
				this._PartNo.destroy();
				this._PartNo = null;
			}
			var oView = this.getView();
			if (!this._PartNo) {
				this._PartNo = sap.ui.xmlfragment("PartNumber", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.partNumber", this);
				oView.addDependent(this._PartNo);
				this._PartNo.setRangeKeyFields([{
					label: "Part Number",
					key: "PartNumber",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			this._PartNo.setTokens(this._oCVMPartNoMultiInput.getTokens());
			var oPartNumber = sap.ui.core.Fragment.byId("PartNumber", "idPartNumber");
			oPartNumber.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oPartNumber);
			//Radr#75359054 - Start
			oPartNumber.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oPartNumber);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oPartNumber.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oPartNumber);
			//Radr#75473561 - End
			var oPartNumberDialog = oPartNumber.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("PartNumber--idPartNumber-header").setAttribute('role', 'presentation'),
						document.getElementById("PartNumber--idPartNumber-firstfe").removeAttribute('tabindex'),
						document.getElementById("PartNumber--idPartNumber-header").removeAttribute('aria-level'),
						document.getElementById("PartNumber--idPartNumber-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oPartNumber);
			this._PartNo.open();
		},
		onValueHelpPartNoOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oCVMPartNoMultiInput.setTokens(aTokens);
			this._PartNo.close();
		},
		onValueHelpPartNoCancelPress: function () {
			this._PartNo.close();
		},
		onValueHelpSourCountry: function () {
			if (this._SourCountry) {
				this._SourCountry.destroy();
				this._SourCountry = null;
			}
			var oView = this.getView();
			if (!this._SourCountry) {
				this._SourCountry = sap.ui.xmlfragment("SourceCountry", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.sourceCountry", this);
				oView.addDependent(this._PartNo);
				this._SourCountry.setRangeKeyFields([{
					label: "Source Country",
					key: "SourceCountry",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			this._SourCountry.setTokens(this._oCVMSourCountryMultiInput.getTokens());
			var oSourceCountry = sap.ui.core.Fragment.byId("SourceCountry", "idSourceCountry");
			oSourceCountry.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oSourceCountry);
			//Radr#75359054 - Start
			oSourceCountry.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oSourceCountry);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oSourceCountry.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oSourceCountry);
			//Radr#75473561 - End
			var oSourceCountryDialog = oSourceCountry.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("SourceCountry--idSourceCountry-header").setAttribute('role', 'presentation'),
						document.getElementById("SourceCountry--idSourceCountry-firstfe").removeAttribute('tabindex'),
						document.getElementById("SourceCountry--idSourceCountry-header").removeAttribute('aria-level'),
						document.getElementById("SourceCountry--idSourceCountry-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oSourceCountry);
			this._SourCountry.open();
		},
		onValueHelpSourceCountryOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oCVMSourCountryMultiInput.setTokens(aTokens);
			this._SourCountry.close();
		},
		onValueHelpSourceCountryCancelPress: function () {
			this._SourCountry.close();
		},
		onValueHelpDestCountry: function () {
			if (this._DestCountry) {
				this._DestCountry.destroy();
				this._DestCountry = null;
			}
			var oView = this.getView();
			if (!this._DestCountry) {
				this._DestCountry = sap.ui.xmlfragment("DestinationCountry", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.destinationCountry", this);
				oView.addDependent(this._PartNo);
				this._DestCountry.setRangeKeyFields([{
					label: "Destination Country",
					key: "DestinationCountry",
					type: "Integer",
					typeInstance: new typeString({}, {
						maxLength: 25
					})
				}]);
			}
			this._DestCountry.setTokens(this._oCVMDestCountryMultiInput.getTokens());
			var oDestinationCountry = sap.ui.core.Fragment.byId("DestinationCountry", "idDestinationCountry");
			oDestinationCountry.addEventDelegate({
				onAfterRendering: function () {
					var oPanel = this.$().find('.sapMDialogResizeHandler');
					document.getElementById(oPanel[0].id).setAttribute('aria-hidden', 'true');
				}
			}, oDestinationCountry);
			//Radr#75359054 - Start
			oDestinationCountry.addEventDelegate({
				onAfterRendering: function () {
					var oConditionValueInput = this.$().find('.sapMInputBaseInner');
					for (var i = 0; i < oConditionValueInput.length; i++) {
						document.getElementById(oConditionValueInput[i].id).setAttribute('aria-label', document.getElementById(oConditionValueInput[
								i]
							.id).getAttribute('value'));
					}
				}
			}, oDestinationCountry);
			//Radr#75359054 - End
			//Radr#75473561 - Start
			oDestinationCountry.addEventDelegate({
				onAfterRendering: function () {
					var oConditionFilter = this.$().find('.sapMInputBaseReadonlyWrapper');
					for (var i = 0; i < oConditionFilter.length; i++) {
						document.getElementById(oConditionFilter[i].id).removeAttribute('role')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-autocomplete')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-haspopup')
						document.getElementById(oConditionFilter[i].id).removeAttribute('aria-expanded')
					}
				}
			}, oDestinationCountry);
			//Radr#75473561 - End
			var oDestinationCountryDialog = oDestinationCountry.addEventDelegate({
				onAfterRendering: function () {
					document.getElementById("DestinationCountry--idDestinationCountry-header").setAttribute('role', 'presentation'),
						document.getElementById("DestinationCountry--idDestinationCountry-firstfe").removeAttribute('tabindex'),
						document.getElementById("DestinationCountry--idDestinationCountry-header").removeAttribute('aria-level'),
						document.getElementById("DestinationCountry--idDestinationCountry-footer").setAttribute('role', 'presentation')
					var oFileUploadHeader = this.$().find('.sapMDialogTitle');
					oFileUploadHeader[0].setAttribute('role', 'presentation');
					var oFileUploadFooter = this.$().find('.sapMDialogFooter');
					oFileUploadFooter[0].setAttribute('role', 'presentation');

				}
			}, oDestinationCountry);
			this._DestCountry.open();
		},
		onValueHelpDestCountryOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oCVMDestCountryMultiInput.setTokens(aTokens);
			this._DestCountry.close();
		},
		onValueHelpDestCountryCancelPress: function () {
			this._DestCountry.close();
		},
		/*Customer Shipment Refresh*/
		onCustNEWRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetCustShipFilterBy();
			this.getCustShip("NEW", "ToNew");
			this.oCustShipNEWSmartTable.applyVariant({});
		},
		onCustCDRRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetCustShipFilterBy();
			this.getCustShip("CDR", "ToCarrierDetermined");
			this.oCustShipCDRSmartTable.applyVariant({});
		},
		onCustRFSRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetCustShipFilterBy();
			this.getCustShip("RFS", "ToReadyForShipment");
			this.oCustShipRFSSmartTable.applyVariant({});
		},
		onCustERRRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetCustShipFilterBy();
			this.getCustShip("ERR", "ToError");
			this.oCustShipERRSmartTable.applyVariant({});
		},
		/*DC Shipment Refresh*/
		onDCPPRRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetDCShipFilterBy();
			this.getDCShip("PPR", "ToPartsPendingReturn");
			this.oDCShipPPRSmartTable.applyVariant({});
		},
		onDCCDRRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetDCShipFilterBy();
			this.getDCShip("CDR", "ToCarrierDetermined");
			this.oDCShipCDRSmartTable.applyVariant({});
		},
		onDCRFSRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetDCShipFilterBy();
			this.getDCShip("RFS", "ToReadyForShip");
			this.oDCShipRFSSmartTable.applyVariant({});
		},
		onDCERRRefreshlstBtnPress: function (oEvent) {
			// this.fileShip = false;
			// this.resetDCShipFilterBy();
			this.getDCShip("ERR", "ToError");
			this.oDCShipERRSmartTable.applyVariant({});
		},
		/*Lean Receipts refresh*/
		onLeanNEWRefreshlstBtnPress: function (oEvent) {
			this.getLean("NEW", "ToNew");
			this.oLeanNEWSmartTable.applyVariant({});
		},
		onLeanGRRefreshlstBtnPress: function (oEvent) {
			this.getLean("GRC", "ToGRCompleted");
			this.oLeanGRSmartTable.applyVariant({});
		},
		/*CVM Values refresh*/
		onCVMRefreshlstBtnPress: function (oEvent) {
			this.oCVMValuesSmartTable.applyVariant({});
		},
		/* Start Export */
		onCustNewExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oCustNewTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oCustNewTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onCustCDRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oCustCDRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oCustCDRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onCustRFSExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oCustRFSTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oCustRFSTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onCustERRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oCustERRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oCustERRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onDCPPRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oDCPPRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oDCPPRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onDCCDRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oDCCDRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oDCCDRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onDCRFSExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oDCRFSTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oDCRFSTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onDCERRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oDCERRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oDCERRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onLeanNewExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oLeanReceiptsNewTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oLeanReceiptsNewTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onLeanGRExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oLeanReceiptsGRTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oLeanReceiptsGRTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		onCVMExcelDataExport: function (oEvent) {
			var oModel, aCols, tableColumn, tableContext
			aCols = this.createColumnConfig(this.getView().byId("oCVMValuesTable").getColumns());
			oModel = this.filteredTablemodel(this.getView().byId("oCVMValuesTable").getBinding("rows").getContexts());
			this.DownloadAction(aCols, oModel);
		},
		filteredTablemodel: function (tableContext) {
			var filteredTableModel = [];
			//			var tableContext = this.getView().byId("oDCPPRTable").getBinding("rows").getContexts();
			for (var r of tableContext) {
				filteredTableModel.push(r.getObject());
			}
			return filteredTableModel;
		},
		DownloadAction: sap.ui.export.Spreadsheet.prototype.exportData || function (aColumns, oModel) {
			var aCols, dataSource, oSettings, oSheet, acontext, fileName;
			aCols = aColumns;
			dataSource = oModel;
			fileName = "AC Shipping";
			var that = this;
			if (dataSource.length > 0) {
				acontext = {
					sheetName: "AC Shipping",
					title: "AC Shipping"
				};
				oSettings = {
					workbook: {
						columns: aCols,
						context: acontext
					},
					dataSource: dataSource,
					fileName: fileName,
					showProgress: false,
				};
				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function () {
						MessageToast.show("Spreadsheet export has finished");
					})
					.finally(function () {
						oSheet.destroy();
					});
			} else {
				that._showMessageBoxError("No data to export");
			}
		},
		createColumnConfig: function (tableColumns) {
				var columnConfig = [];
				for (var n = 0; n < tableColumns.length; n++) {
					if (tableColumns[n].getVisible()) {
						var temp = {};
						if (tableColumns[n].getTemplate().mBindingInfos.visible) {
							temp.label = tableColumns[n].getLabel().getText();
							temp.property = tableColumns[n].getTemplate().mBindingInfos.visible.parts[0].path;
							temp.width = tableColumns[n].getWidth();
						} else {
							temp.label = tableColumns[n].getLabel().getText();
							temp.property = tableColumns[n].getTemplate().mBindingInfos.text.parts[0].path;
							temp.width = tableColumns[n].getWidth();
						}
						columnConfig.push(temp);
						temp = null;
					}
				}
				return columnConfig;
			}
			/* End Export */
			// setViewJSONModel: function () {
			// 	var sRootPath = jQuery.sap.getModulePath("com.apple.ui5.ZUI5_AC_SHIPMENT");
			// 	this.byId("oMainCustShip").setIcon(sRootPath + "/images/Cshipments.png");
			// 	this._oViewJSONModel = new JSONModel({
			// 		courierImgSrc: "../images/Cshipments.png",
			// 		shippedImgSrc: "../images/DCshipments.png",
			// 		reductionImgSrc: "../images/Lean.png",
			// 		billImgSrc: "../images/CVM.png"
			// 	});
			// 	this.getView().setModel(this._oViewJSONModel, "viewJSONModel");
			// },
			// onLeanGREditBtnPress: function (oEvent) {
			// 	var data = [];
			// 	var EditGRBatchChanges = [];
			// 	var editSelectedRows = this.getView().byId("oLeanReceiptsGRTable").getSelectedIndices();
			// 	var rowPath = "";
			// 	var rowProperty = "";
			// 	for (var i = 0; i < editSelectedRows.length; i++) {
			// 		rowPath = this.getView().byId("oLeanReceiptsGRTable").getBinding("rows").getContexts()[editSelectedRows[i]].getPath();
			// 		rowProperty = this.getView().getModel("oViewModel").getProperty(rowPath);
			// 		data.push(rowProperty);
			// 	}
			// 	var EditGRModel = new JSONModel();
			// 	EditGRModel.setData(data)
			// 	this.getView().setModel(EditGRModel, "EditGRModel");
			// 	this.gLeanReceipts.setDeferredGroups(["editBatchFunctionImport"]);
			// 	if (editSelectedRows.length > 0) {
			// 		var oView = this.getView();
			// 		if (this._GREdit) {
			// 			this._GREdit.destroy();
			// 			this._GREdit = null;
			// 		}
			// 		if (!this._GREdit) {
			// 			this._GREdit = sap.ui.xmlfragment("GRFile", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.LeanReceiptsGREdit", this);
			// 			oView.addDependent(this._GREdit);
			// 		}
			// 		this._GREdit.open();
			// 	} else {
			// 		MessageBox.error("Please select atleast one record");
			// 	}
			// },
			// onValueHelpRegion: function () {
			// 	var aCols = this.oColModel.getData().cols;
			// 	this._oRegionValueHelpDialog = sap.ui.xmlfragment("region", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.Region", this);
			// 	this.getView().addDependent(this._oRegionValueHelpDialog);
			// 	this._oRegionValueHelpDialog.getTableAsync().then(function (oTable) {
			// 		oTable.setModel(this.oRegionsModel);
			// 		oTable.setModel(this.oColModel, "columns");
			// 		if (oTable.bindRows) {
			// 			oTable.bindAggregation("rows", "/RegionCollection");
			// 			//oTable.bindAggregation("rows", "oRegionsModel>/");
			// 		}
			// 		if (oTable.bindItems) {
			// 			oTable.bindAggregation("items", "/RegionCollection", function () {
			// 			//oTable.bindAggregation("items", "oRegionsModel>/", function () {
			// 				return new ColumnListItem({
			// 					cells: aCols.map(function (column) {
			// 						return new Label({
			// 							text: "{" + column.template + "}"
			// 						});
			// 					})
			// 				});
			// 			});
			// 		}
			// 		this._oRegionValueHelpDialog.update();
			// 	}.bind(this));
			// 	var oToken = new Token();
			// 	if (this.oMainSelectedKey === "CUSTSHIP") {
			// 		oToken.setKey(this._oCustRegionInput.getSelectedKey());
			// 		oToken.setText(this._oCustRegionInput.getValue());
			// 	} else if (this.oMainSelectedKey === "DCSHIP") {
			// 		oToken.setKey(this._oDCRegionInput.getSelectedKey());
			// 		oToken.setText(this._oDCRegionInput.getValue());
			// 	} else if (this.oMainSelectedKey === "LEANREC") {
			// 		oToken.setKey(this._oLeanRegionInput.getSelectedKey());
			// 		oToken.setText(this._oLeanRegionInput.getValue());
			// 	}
			// 	this._oRegionValueHelpDialog.setTokens([oToken]);
			// 	this._oRegionValueHelpDialog.open();
			// },
			// },
			// onValueHelpRegionOkPress: function (oEvent) {
			// 	var aTokens = oEvent.getParameter("tokens");
			// 	if (this.oMainSelectedKey === "CUSTSHIP") {
			// 		this._oCustRegionInput.setSelectedKey(aTokens[0].getKey());
			// 		this._oCustRegionInput.setValue(aTokens[0].getKey());
			// 	} else if (this.oMainSelectedKey === "DCSHIP") {
			// 		this._oDCRegionInput.setSelectedKey(aTokens[0].getKey());
			// 		this._oDCRegionInput.setValue(aTokens[0].getKey());
			// 	} else if (this.oMainSelectedKey === "LEANREC") {
			// 		this._oLeanRegionInput.setSelectedKey(aTokens[0].getKey());
			// 		this._oLeanRegionInput.setValue(aTokens[0].getKey());
			// 	}
			// 	this._oRegionValueHelpDialog.close();
			// },
			// onValueHelpRegionCancelPress: function () {
			// 	this._oRegionValueHelpDialog.close();
			// },
			// onValueHelpRegionAfterClose: function () {
			// 	this._oRegionValueHelpDialog.destroy();
			// },
			//AX rdar://75518157
			// onValueHelpAfterClose: function (oEvent) {
			// 		if (this.oMainSelectedKey === "CUSTSHIP") {
			// 	//Customer Shipment
			// 	if (document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-content").childNodes[0]) {
			// 		var custDispatch = document.getElementById("__xmlview0--idCustFilterByFragment--idDCDispatchiD-content").childNodes[0];
			// 		custDispatch.setAttribute('role', 'group');
			// 		custDispatch.setAttribute('aria-label', 'Dispatch ID condition tokens');
			// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
			// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
			// 				var d = custDispatch.childNodes[i].getAttribute("id");
			// 				if (d.endsWith("-scrollContainer") == true) {
			// 					var dTokenizer = custDispatch.childNodes[i];
			// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
			// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
			// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
			// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
			// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
			// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
			// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}
			// 	if (document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-content").childNodes[0]) {
			// 		var custDispatch = document.getElementById("__xmlview0--idCustFilterByFragment--idDCSerNotNo-content").childNodes[0];
			// 		custDispatch.setAttribute('role', 'group');
			// 		custDispatch.setAttribute('aria-label', 'Service Notification no. condition tokens');
			// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
			// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
			// 				var d = custDispatch.childNodes[i].getAttribute("id");
			// 				if (d.endsWith("-scrollContainer") == true) {
			// 					var dTokenizer = custDispatch.childNodes[i];
			// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
			// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
			// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
			// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
			// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
			// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
			// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}
			// 	if (document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-content").childNodes[0]) {
			// 		var custDispatch = document.getElementById("__xmlview0--idCustFilterByFragment--idDCModSerNo-content").childNodes[0];
			// 		custDispatch.setAttribute('role', 'group');
			// 		custDispatch.setAttribute('aria-label', 'Module Serial no. condition tokens');
			// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
			// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
			// 				var d = custDispatch.childNodes[i].getAttribute("id");
			// 				if (d.endsWith("-scrollContainer") == true) {
			// 					var dTokenizer = custDispatch.childNodes[i];
			// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
			// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
			// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
			// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
			// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
			// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
			// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}
			// 	if (document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-content").childNodes[0]) {
			// 		var custDispatch = document.getElementById("__xmlview0--idCustFilterByFragment--idDCPO-content").childNodes[0];
			// 		custDispatch.setAttribute('role', 'group');
			// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
			// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
			// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
			// 				var d = custDispatch.childNodes[i].getAttribute("id");
			// 				if (d.endsWith("-scrollContainer") == true) {
			// 					var dTokenizer = custDispatch.childNodes[i];
			// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
			// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
			// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
			// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
			// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
			// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
			// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}
			// 	if (document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-content").childNodes[0]) {
			// 		var custDispatch = document.getElementById("__xmlview0--idCustFilterByFragment--idDCShipTo-content").childNodes[0];
			// 		custDispatch.setAttribute('role', 'group');
			// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
			// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
			// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
			// 				var d = custDispatch.childNodes[i].getAttribute("id");
			// 				if (d.endsWith("-scrollContainer") == true) {
			// 					var dTokenizer = custDispatch.childNodes[i];
			// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
			// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
			// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
			// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
			// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
			// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
			// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}

		// 	} else if (this.oMainSelectedKey === "DCSHIP") {
		// 					//DC Shipment
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCDispatchiD-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Dispatch ID condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCSerNotNo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Service Notification no. condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCModSerNo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Module Serial no. condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCPO-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCShipFrom-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idDCFilterByFragment--idDCMRMA-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}

		// 	} else if (this.oMainSelectedKey === "LEANREC") {
		// 					//Lean Receipt
		// 	if (document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCDispatchiD-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Dispatch ID condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCSerNotNo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Service Notification no. condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCModSerNo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Module Serial no. condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idLeanReceiptsFilterByFragment--idDCShipTo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}

		// 	} else if (this.oMainSelectedKey === "CVMVALUES") {
		// 				//CVM
		// 	if (document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMPartNo-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Part No condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMSourCountry-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// 	if (document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-content").childNodes[0]) {
		// 		var custDispatch = document.getElementById("__xmlview0--idCVMValuesFilterByFragment--idCVMDestCountry-content").childNodes[0];
		// 		custDispatch.setAttribute('role', 'group');
		// 		custDispatch.setAttribute('aria-label', 'Purchase Order condition tokens');
		// 		for (var i = 0; i < custDispatch.childElementCount; i++) {
		// 			if (custDispatch.childNodes[i].hasAttribute("id") == true) {
		// 				var d = custDispatch.childNodes[i].getAttribute("id");
		// 				if (d.endsWith("-scrollContainer") == true) {
		// 					var dTokenizer = custDispatch.childNodes[i];
		// 					for (var k = 0; k < dTokenizer.childElementCount; k++) {
		// 						dTokenizer.childNodes[k].setAttribute('role', 'button'),
		// 							dTokenizer.childNodes[k].setAttribute('tabindex', '0');
		// 						var tTitle = dTokenizer.childNodes[k].getAttribute('title');
		// 						dTokenizer.childNodes[k].setAttribute('aria-label', tTitle);
		// 						dTokenizer.childNodes[k].removeAttribute('aria-posinset');
		// 						dTokenizer.childNodes[k].removeAttribute('aria-setsize');
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}

		// 	}
		// },
		// onValueHelpAfterOpen: function (oEvent) {
		// 	//AX
		// 	// Var idCondition = document.getElementById("ModSerNo--idModSerNo-filterPanel").childNodes[0].childNodes[0].childNodes[0].
		// 	// childNodes[0].childNodes[0].childNodes[2].childNodes[1].childNodes[0].childNodes[7].childNodes[0].childNodes[1].childNodes[0].getAttribute("id”);
		// 	debugger;
		// 	var c = document.getElementById("dispatchId--idDispatchID-filterPanel").childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[2];
		// 	var d = c.childElementCount;
		// 	var idAdd = c.childNodes[d - 1].childNodes[0].childNodes[7].childNodes[0].childNodes[1].childNodes[0].getAttribute("id");

		// 			// var oAdd = sap.ui.core.Fragment.byId("dispatchId", idAdd); 
		// 			// var cAdd = oAdd.addEventDelegate({
		// 			// 	onAfterRendering: function () {
		// 			// 		for (var i = 0; i < d; i++) {
		// 					var	k = c.childNodes[0].childNodes[0].childNodes[4].childNodes[0].childNodes[0];
		// 						k.removeAttribute('role'),
		// 							k.removeAttribute('aria-readonly'),
		// 							k.removeAttribute('aria-expanded'),
		// 							k.removeAttribute('aria-haspopup')
		// 			// 		}
		// 			// 	}
		// 			// }, oAdd);
		// 			// 	// }
		// 		},

	});
});