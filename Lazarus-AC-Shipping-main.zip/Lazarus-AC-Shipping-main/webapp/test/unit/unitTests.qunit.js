/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/apple/ui5/ZUI5_AC_SHIPMENT/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});