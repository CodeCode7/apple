sap.ui.define([
	"com/apple/ui5/ZUI5_AC_SHIPMENT/test/unit/controller/Main.controller"
], function () {
	"use strict";
});