sap.ui.define([
    "com/app/scp/ui/olympuslogon/test/unit/controller/Main.controller",
    "com/app/scp/ui/olympuslogon/test/unit/model/models"
], function () {
    "use strict";
});
