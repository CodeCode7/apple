sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log"
], function (MockServer, Log) {
    "use strict";

    var _sAppPathPalletCarrier = "com/apple/scp/palletgs1carrierlabel/",
        _sJsonFilesPathPalletCarrier = _sAppPathPalletCarrier + "localService/mockdata",
        _aEntitySetsPalletCarrier = ["DistinctPo", "CarrierPalletData", "GenerateLabelData"];

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function () {
            var sJsonFilesUrlPalletCarrier = sap.ui.require.toUrl(_sJsonFilesPathPalletCarrier),
                sManifestUrlPalletCarrier = sap.ui.require.toUrl(_sAppPathPalletCarrier + "manifest.json"),
                oManifestPalletCarrier = jQuery.sap.syncGetJSON(sManifestUrlPalletCarrier).data,
                oMainDataSource = oManifestPalletCarrier["sap.app"].dataSources.mainService,
                sMetadataUrlPalletCarrier = sap.ui.require.toUrl(_sAppPathPalletCarrier + oMainDataSource.settings.localUri);

            this.sMockServerUrl = oMainDataSource.uri;

            // init root URI
            this.oMockServer = new MockServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MockServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockServer.simulate(sMetadataUrlPalletCarrier, {
                sMockdataBaseUrl: sJsonFilesUrlPalletCarrier,
                aEntitySetsNames: _aEntitySetsPalletCarrier,
                bGenerateMissingMockData: false
            });

            this.oMockServer.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrlPalletCarrier + "\n" +
                "   mockdata dir: " + sJsonFilesUrlPalletCarrier);

            return this;
        }
    };

});
