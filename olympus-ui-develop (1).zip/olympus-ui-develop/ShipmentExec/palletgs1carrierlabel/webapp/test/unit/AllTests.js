sap.ui.define([
    "./formatter/formatter",
    "./controller/App.controller",
    "./controller/BaseController",
    "./controller/PalletGS1CarrierLabel.controller",
    "./model/models"
], function () {
    "use strict";
});
