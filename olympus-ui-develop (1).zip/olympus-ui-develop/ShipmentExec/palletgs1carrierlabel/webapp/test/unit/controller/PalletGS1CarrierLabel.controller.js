sap.ui.define([
    "sap/ui/core/mvc/View",
    "com/apple/scp/palletgs1carrierlabel/controller/PalletGS1CarrierLabel.controller",
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/UIComponent",
    "sap/m/InstanceManager",
    "sap/ui/base/Event",
    "sap/ui/model/resource/ResourceModel"
], function (ManagedObject, Controller, aController, sFB, sTable, View, JSONModel, UIComponent, InstanceManager, Event, ResourceModel) {
    "use strict";
    QUnit.module("PalletGS1CarrierLabel Controller", {
        beforeEach: function () {
            this.oPalletGS1CarrierLabelController = new Controller();
        },
        afterEach: function () {
            this.oPalletGS1CarrierLabelController.destroy();
        }
    });
    function jsonOk(body) {
        //the fetch API returns a resolved window Response object
        var mockResponsePalletCarrier = new window.Response(JSON.stringify(body), {
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });
        return Promise.resolve(mockResponsePalletCarrier);
    }
    QUnit.test("PalletGS1CarrierLabel controller Load", function (assert) {
        assert.ok(this.oPalletGS1CarrierLabelController);
    });

    QUnit.test("onDownload function test", function (assert) {
        var oViewStubPalletCarrier = new View({});
        var oGetViewStubPalletCarrier = sinon.stub(this.oPalletGS1CarrierLabelController, "getView").returns(oViewStubPalletCarrier);

        var oBtn = new sap.m.Button();
        var oBtnStub = sinon.stub(View.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oPalletGS1CarrierLabelController.onDownload();

        assert.strictEqual(oBtnSpy.callCount, 1, "Download function to be triggered");

        oViewStubPalletCarrier.destroy();
        oGetViewStubPalletCarrier.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });
    QUnit.test("Smart Table search test", function (assert) {
        //Arrange
        var oSTablePalletCarrier = new sTable("sTable");
        var oViewStubPalletCarrier = new ManagedObject({});
        var oSTableSpyPalletCarrier = this.stub(sap.ui.comp.smarttable.SmartTable.prototype, "rebindTable");
        var oGetViewStubPalletCarrier = sinon.stub(aController.prototype, "getView").returns(oViewStubPalletCarrier);
        var oSTableStubPalletCarrier = sinon.stub(ManagedObject.prototype, "byId").returns(oSTablePalletCarrier);
        this.oPalletGS1CarrierLabelController.oDefaultSSCC18 = new sap.m.Input();

        //Act
        this.oPalletGS1CarrierLabelController.onSearchPalletCarrier();

        //Assert
        assert.strictEqual(oSTableSpyPalletCarrier.callCount, 1, "Smart Table rebindTable event to be triggered");

        //CleanUp
        oSTableSpyPalletCarrier.restore();
        oSTableStubPalletCarrier.restore();
        oGetViewStubPalletCarrier.restore();
        oSTablePalletCarrier.destroy();
        oViewStubPalletCarrier.destroy();
    });
    QUnit.test("Smart Filter Bar clear test", function (assert) {
        //Arrange
        var oSFBPalletCarrier = new sFB("SFB");
        var oViewStubPalletCarrier = new ManagedObject({});
        var oSFBSpyPalletCarrier = this.stub(sap.ui.comp.smartfilterbar.SmartFilterBar.prototype, "clear");
        var oGetViewStubPalletCarrier = sinon.stub(aController.prototype, "getView").returns(oViewStubPalletCarrier);
        var oSFBStubPalletCarrier = sinon.stub(ManagedObject.prototype, "byId").returns(oSFBPalletCarrier);

        //Act
        this.oPalletGS1CarrierLabelController.onClearPalletCarrier();

        //Assert
        assert.strictEqual(oSFBSpyPalletCarrier.callCount, 1, "Smart Filter Bar clear to be triggered");

        //CleanUp
        oSFBSpyPalletCarrier.restore();
        oSFBStubPalletCarrier.restore();
        oGetViewStubPalletCarrier.restore();
        oSFBPalletCarrier.destroy();
        oViewStubPalletCarrier.destroy();
    });
    QUnit.test("checkAuthoPalletCarrier function test", function (assert) {
        //Arrange
        var fnDone = assert.async();
        var oViewStubPalletCarrier = new View({});
        oViewStubPalletCarrier.setModel(new JSONModel(), "AuthModelPalletCarrier");

        var oGetViewStubPalletCarrier = sinon.stub(this.oPalletGS1CarrierLabelController, "getView").returns(oViewStubPalletCarrier);
        var oComp = new UIComponent;
        oComp.isMock = false;
        var oControllerStub = sinon.stub(this.oPalletGS1CarrierLabelController, "getOwnerComponent").returns(oComp);

        var localJWT = {
            "decodedJWTToken":
            {
                "scope": [
                    "configandsetting!t9525.CARRIERLABEL_CREATE", "configandsetting!t9525.PALLETGS1_CREATE",
                    "configandsetting!t9525.CARRIERLABEL_UPDATE", "configandsetting!t9525.PALLETGS1_UPDATE",
                    "configandsetting!t9525.CARRIERLABEL_DISPLAY", "configandsetting!t9525.PALLETGS1_DISPLAY"
                ]
            }
        };
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk(localJWT));

        var lModel = oViewStubPalletCarrier.getModel("AuthModelPalletCarrier");
        this.oPalletGS1CarrierLabelController.checkAuthoPalletCarrier().then(function () {
            //Assert
            assert.strictEqual(lModel.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(lModel.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(lModel.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDone();

            //Cleanup
            oGetViewStubPalletCarrier.restore();
            oViewStubPalletCarrier.destroy();
            oComp.destroy();
            oControllerStub.restore();
        });
    });
    QUnit.test("formatDateAsStringPalletCarrier function test", function (assert) {
        const date1PalletCarrier = new Date(2021, 10, 24, 5, 30, 0, 0);
        const date2PalletCarrier = new Date(2021, 10, 5, 5, 30, 0, 0);
        const date3PalletCarrier = new Date(2021, 8, 24, 5, 30, 0, 0);

        var actDatePalletCarrier = this.oPalletGS1CarrierLabelController.formatDateAsStringPalletCarrier(date1PalletCarrier);
        assert.strictEqual(actDatePalletCarrier, "20211124", "Standalone JS Date conversion to YYYYMMDD");
        actDatePalletCarrier = this.oPalletGS1CarrierLabelController.formatDateAsStringPalletCarrier(date2PalletCarrier);
        assert.strictEqual(actDatePalletCarrier, "20211105", "Standalone JS Date with single digit date, conversion to YYYYMMDD");
        actDatePalletCarrier = this.oPalletGS1CarrierLabelController.formatDateAsStringPalletCarrier(date3PalletCarrier);
        assert.strictEqual(actDatePalletCarrier, "20210924", "Standalone JS Date with single digit month, conversion to YYYYMMDD");
    });
    QUnit.test("onInitialise function test", function (assert) {
        var oViewStubPalletCarrier = new View({});
        var oGetViewStubPalletCarrier = sinon.stub(this.oPalletGS1CarrierLabelController, "getView").returns(oViewStubPalletCarrier);

        var oBtn = new sap.m.Button();
        var oBtnStub = sinon.stub(View.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oPalletGS1CarrierLabelController.onInitialise();

        assert.strictEqual(oBtnSpy.callCount, 0, "onInitialise function to be triggered");

        oViewStubPalletCarrier.destroy();
        oGetViewStubPalletCarrier.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });
    QUnit.test("validateEnteredQty function test", function (assert) {
        this.oPalletGS1CarrierLabelController.value = 3;
        var aRes = this.oPalletGS1CarrierLabelController.validateEnteredQty();
        assert.strictEqual(aRes, false, "Negative Quantity Validation");
    });
    QUnit.test("getInputDataPalletGS1 function test", function (assert) {
        var dEvent = new Event('oEvent', {}, { 'value': 1 });
        this.oPalletGS1CarrierLabelController.getInputDataPalletGS1(dEvent);
        assert.strictEqual(this.oPalletGS1CarrierLabelController.value, 1, "Quantity changed to be saved in controller reference");
    });
    QUnit.test("typeNumPalletOnly function test", function (assert) {
        var oEvent = new Event('oEvent', {}, { 'value': "1" });
        let aResult = this.oPalletGS1CarrierLabelController.typeNumPalletOnly(oEvent);
        assert.strictEqual(aResult, false, "Is a Number Test");

        oEvent = new Event('oEvent', {}, { 'value': "0" });
        aResult = this.oPalletGS1CarrierLabelController.typeNumPalletOnly(oEvent);
        assert.strictEqual(aResult, false, "Quantity 0 negative test")
        InstanceManager.closeAllDialogs();
    });
    QUnit.test("validateSSCC18Number function test", function (assert) {
        //Arrange
        const i18nPath = "com/apple/scp/palletgs1carrierlabel/i18n/i18n.properties";
        var lComp = new UIComponent();

        var oControllerStub = sinon.stub(this.oPalletGS1CarrierLabelController, "getOwnerComponent").returns(lComp);
        var oResourceModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl(i18nPath) });
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResourceModel);

        var oEvent = new Event('oEvent', {}, { 'value': "123456789" });
        assert.strictEqual(this.oPalletGS1CarrierLabelController.validateSSCC18Number(oEvent), false, 'Negative SCC18N check(<18)');
        InstanceManager.closeAllDialogs();

        oEvent = new Event('oEvent', {}, { 'value': "011111111111111111" });
        assert.strictEqual(this.oPalletGS1CarrierLabelController.validateSSCC18Number(oEvent), false, 'Negative SCC18N check(1st Char not 1)');
        InstanceManager.closeAllDialogs();

        oControllerStub.restore();
        oCompStub.restore();
        lComp.destroy();
    });
    QUnit.test("validateEntries function test", function(assert){
        const i18nPath = "com/apple/scp/palletgs1carrierlabel/i18n/i18n.properties";
        var localComp = new UIComponent();

        var oConStub = sinon.stub(this.oPalletGS1CarrierLabelController, "getOwnerComponent").returns(localComp);
        var oResModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl(i18nPath) });
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResModel);

        //No Selection error popup
        var aResp = this.oPalletGS1CarrierLabelController.validateEntries();
        assert.strictEqual(aResp, false, "Validation failure check - No Selection");

        //Quantity zero check
        this.oPalletGS1CarrierLabelController.oSelItemPalletCarr = {};
        this.oPalletGS1CarrierLabelController.value = 0;
        aResp = this.oPalletGS1CarrierLabelController.validateEntries();
        assert.strictEqual(aResp, false, "Validation failure check - Zero Quantity");

        //Input Qty > Open Qty
        this.oPalletGS1CarrierLabelController.value = 2;
        this.oPalletGS1CarrierLabelController.selectedOpenQty=1;
        aResp = this.oPalletGS1CarrierLabelController.validateEntries();
        assert.strictEqual(aResp, false, "Validation failure check - Input Qty > open Qty");
        InstanceManager.closeAllDialogs();

        localComp.destroy();
        oConStub.restore();
        oCompStub.restore();
    });
    QUnit.test("validateEnteredQty function test", function (assert) {
        this.oPalletGS1CarrierLabelController.selectedOpenQty = 2;
        var aResCar = this.oPalletGS1CarrierLabelController.validateEnteredQty();
        assert.strictEqual(aResCar, true, "Positive Quantity Validation");

        this.oPalletGS1CarrierLabelController.value = 3;
        aResCar = this.oPalletGS1CarrierLabelController.validateEnteredQty();
        assert.strictEqual(aResCar, false, "Negative Quantity Validation");
    });
    QUnit.test("showErrorMessage function test", function (assert) {
        var oError = {
            "responseText": "Sample Error"
        };
        var msg = this.oPalletGS1CarrierLabelController.showErrorMessage(oError);
        assert.strictEqual(msg, "Sample Error", "Error Message for 401 to be parsed correctly");

        oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Error" } } }'
        };

        msg = this.oPalletGS1CarrierLabelController.showErrorMessage(oError);
        assert.strictEqual(msg, "Error", "Error for non 401 to be parsed correctly");
    });
});
