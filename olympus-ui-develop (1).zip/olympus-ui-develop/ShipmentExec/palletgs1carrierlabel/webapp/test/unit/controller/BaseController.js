
sap.ui.define([
    "com/apple/scp/palletgs1carrierlabel/controller/BaseController",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/UIComponent",
    "sap/ui/thirdparty/sinon",
    "sap/ui/thirdparty/sinon-qunit"
], function (Controller, ResourceModel, UIComponent) {
    "use strict";
    QUnit.module("Base Controller", {
        beforeEach: function () {
            this.oBaseControllerPallCarr = new Controller();
        },
        afterEach: function () {
            this.oBaseControllerPallCarr.destroy();
        }
    }
    );
    QUnit.test("Base controller Load", function (assert) {
        assert.ok(this.oBaseControllerPallCarr);
    });

    QUnit.test("Should return the translated texts", function (assert) {
        // Arrange
        this._oResourceModelPalletCarrier = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl("com/apple/scp/palletgs1carrierlabel/i18n/i18n.properties")
        });
        var oCompStubPalletCarrier = {
            getModel: this.stub().withArgs("i18n").returns(this._oResourceModelPalletCarrier)
        };
        var oControllerStubPalletCarrier = {
            getOwnerComponent: this.stub().returns(oCompStubPalletCarrier)
        };

        // System under test
        var fnIsolatedFormatterPalletCarrier = this.oBaseControllerPallCarr.getResourceBundle.bind(oControllerStubPalletCarrier);

        // Assert
        assert.strictEqual(fnIsolatedFormatterPalletCarrier("appTitle"), "Pallet GS1 & Carrier Label", "The long text for Application title is correct");

        //CleanUp
        this._oResourceModelPalletCarrier.destroy();
    });

    QUnit.test("Should return the router", function(assert){
        // Arrange
        var olocalRouterPalletCarr = new sap.m.routing.Router([
            {
                "name": "PalletGS1CarrierLabel",
                "pattern": "",
                "target": [
                    "PalletGS1CarrierLabel"
                ]
            }
        ]);

        var oCompStubPalletCarr = sinon.stub(UIComponent, "getRouterFor").returns(olocalRouterPalletCarr);
        var aRouterPalletCarrier = this.oBaseControllerPallCarr.getRouter();
        assert.strictEqual(aRouterPalletCarrier, olocalRouterPalletCarr, "Router bound to be returned" );
        oCompStubPalletCarr.restore();

    });
});
