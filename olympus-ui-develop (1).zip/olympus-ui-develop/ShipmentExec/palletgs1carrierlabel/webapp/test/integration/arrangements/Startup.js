sap.ui.define([
	"sap/ui/test/Opa5"
], function (Opa5) {
	"use strict";

	return Opa5.extend("com.apple.scp.palletgs1carrierlabel.test.integration.arrangements.Startup", {

		iStartMyApp: function (oOptionsParameter) {
			var oOptionsPalletCarrier = oOptionsParameter || {};

			// start the app with a minimal delay to make tests fast but still async to discover basic timing issues
			oOptionsPalletCarrier.delay = oOptionsPalletCarrier.delay || 50;

			// start the app UI component
			this.iStartMyUIComponent({
				componentConfig: {
					name: "com.apple.scp.palletgs1carrierlabel",
					async: true
				},
				hash: oOptionsPalletCarrier.hash,
				autoWait: oOptionsPalletCarrier.autoWait
			});
		},
        iTeardownTheApp: function () {
            this.iTeardownMyUIComponent();
        }
	});
});
