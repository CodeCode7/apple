/*global QUnit*/

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "./pages/App",
    "./pages/PalletGS1CarrierLabel"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Label Generate Journey");

    opaTest("Generate Label Positive Test case", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePalletCarrierPage.iTriggerBtnPress("idSearch"); //Click Search PalletGs1Carrier
        When.onThePalletCarrierPage.iSelectTableRow("Plant", "6401"); //Select table row with plant 6401
        When.onThePalletCarrierPage.iEnterInputQuantity(); //Enter Input Quantity
        When.onThePalletCarrierPage.iTriggerBtnPress("idGenLabel"); //Click Generate label
        
        Then.onThePalletCarrierPage.iShouldSeeFragment("PalletGS1CarrierLabelGeneration","labelCreationFragId"); //Fragment check
        When.onThePalletCarrierPage.iTriggerBtnPress("idPalletCarrierCancel"); //Click Cancel
        Then.onThePalletCarrierPage.iShouldNotSeeControl("labelCreationFragId"); //Fragment check

        When.onThePalletCarrierPage.iTriggerBtnPress("idGenLabel"); //Click Generate label again
        
        Then.onThePalletCarrierPage.iShouldSeeBtn("idPalletCarrierSaveToPDF"); //Save to PDF button check
        When.onThePalletCarrierPage.iTriggerBtnPress("idPalletCarrierSaveToPDF"); //Click Save
        Then.onThePalletCarrierPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onThePalletCarrierPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button
        Then.onThePalletCarrierPage.iShouldNotSeeControl("labelCreationFragId"); //Success Pop up not to be seen
        Then.iTeardownMyApp();
    });
});
