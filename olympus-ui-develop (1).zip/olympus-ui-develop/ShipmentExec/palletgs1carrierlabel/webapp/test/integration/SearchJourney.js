sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/palletgs1carrierlabel/test/integration/pages/PalletGS1CarrierLabel",
    "com/apple/scp/palletgs1carrierlabel/test/integration/arrangements/Startup"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Filter and Search");

    opaTest("Should show correct item count after PO search", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });
        //Actions
        When.onThePalletCarrierPage.iEnterPOForSearchAndPressEnterPalletCarrier("4300308293");

        // Assertions
        Then.onThePalletCarrierPage.iShouldSeeItemCountPalletCarrier(1).and.iTeardownMyAppFrame();
    });

    opaTest("Should show correct item count after PO search (0)", function (Given, When, Then) {

        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });
        //Actions
        When.onThePalletCarrierPage.iEnterPOForSearchAndPressEnterPalletCarrier("0601068999");
        // Assertions
        Then.onThePalletCarrierPage.iShouldSeeItemCountPalletCarrier(0).and.iTeardownMyAppFrame();
    });
});
