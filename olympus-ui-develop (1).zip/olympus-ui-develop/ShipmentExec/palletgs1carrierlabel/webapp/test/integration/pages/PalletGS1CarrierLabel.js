sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (opa5, EnterText, AggregationLengthEquals, Press, Properties) {
    "use strict";
    var sViewName = "PalletGS1CarrierLabel";
    var sPOInputIdPalletCarrier = "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--smartFilterBar-filterItemControl_BASIC-PO_Number";
    var sDateInputIdPalletCarrier = "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--smartFilterBar-filterItemControlA_-Creation_Date";
    var sTableIdPalletCarrier = "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--customTable";
    var names = {
        "idSearch": "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--idSearch",
        "idGenLabel": "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--idGenerateLabelBtn",
        "labelCreationFragId": "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--labelCreationFragId",
        "idPalletCarrierCancel": "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--idPalletCarrierCancel",
        "idPalletCarrierSaveToPDF": "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--idPalletCarrierSaveToPDF"
    };

    opa5.createPageObjects({
        onThePalletCarrierPage: {
            actions: {
                iTriggerBtnPress: function (bRef) {
                    var bId = names[bRef];
                    this.waitFor({
                        viewName: sViewName,
                        id: bId,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + bRef
                    });
                },

                iSelectTableRow: function () {
                    this.waitFor({
                        viewName: sViewName,
                        controlType: "sap.m.ColumnListItem",
                        id: "customTable",

                        actions: function (oTable) {
                            var item = oTable.getItems()[0];
                            oTable.setSelectedItem(item, true, true);
                        },
                        errorMessage: "Could not select item"
                    });
                },

                iEnterPOForSearchAndPressEnterPalletCarrier: function (poNum) {
                    return this.waitFor({
                        id: sPOInputIdPalletCarrier,
                        viewName: sViewName,
                        actions: [new EnterText({ text: poNum, pressEnterKey: true })],
                        errorMessage: "The PO Number cannot be entered"
                    });
                },

                iEnterDateForSearchAndPressEnter: function (dRange) {
                    return this.waitFor({
                        id: sDateInputIdPalletCarrier,
                        viewName: sViewName,
                        actions: [new EnterText({ text: dRange, pressEnterKey: true })],
                        errorMessage: "The Date range cannot be entered"
                    });
                },

                iClickOnTableItemByFieldValue: function (fName, fValue) {
                    return this.waitFor({
                        controlType: "sap.m.ColumnListItem",
                        // Retrieve all list items in the table
                        matchers: [function (oCandidateListItem) {
                            var oTableLine = {};
                            oTableLine = oCandidateListItem.getBindingContext().getObject();
                            var sFound = false;

                            // Iterate through the list items until the specified cell is found
                            for (var sName in oTableLine) {
                                if ((sName === fName) && (oTableLine[sName].toString() === fValue)) {
                                    QUnit.ok(true, "Cell has been found");
                                    sFound = true;
                                    break;
                                }
                            }
                            return sFound;
                        }],

                        // Click on the specified item
                        actions: new Press(),
                        errorMessage: "Cell could not be found in the table"
                    });
                },
                iSearchDialogWithButtonTextAndClick: function (text) {
                    this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Button",
                        matchers: new Properties({
                            text: text
                        }),
                        actions: new Press(),
                        errorMessage: text + " Button Not found"
                    });
                },

                iEnterInputQuantity: function () {
                    return this.waitFor({
                        viewName: sViewName,
                        controlType: "sap.m.ColumnListItem",
                        id: "customTable",
                        actions: function (oTable) {
                            var inputQuantity = oTable.getSelectedItem().getCells()[9];
                            inputQuantity.setValue("1.000");
                            inputQuantity.fireChange({value: "1.000"});
                        },
                        errorMessage: "Input Quantity cannot be entered"
                    });
                }
            },

            assertions: {
                iShouldSeeBtn: function (buttonReference) {
                    var bId = names[buttonReference];
                    return this.waitFor({
                        id: bId,
                        success: function () {
                            opa5.assert.ok(true, "Button Found: " + buttonReference);
                        },
                        errorMessage: "Button not found: " + buttonReference
                    });
                },
                iShouldSeePurchaseOrder: function () {
                    return this.waitFor({
                        viewName: sViewName,
                        success: function () {
                            opa5.assert.ok(true, "The " + sViewName + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewName + " view"
                    });
                },

                iShouldSeeItemCountPalletCarrier: function (iItemCount) {
                    return this.waitFor({
                        id: sTableIdPalletCarrier,
                        viewName: sViewName,
                        matchers: [new AggregationLengthEquals({
                            name: "items",
                            length: iItemCount
                        })],
                        success: function () {
                            opa5.assert.ok(true, "The table has " + iItemCount + " item(s)");
                        },
                        errorMessage: "Table does not have expected number of items '" + iItemCount + "'."
                    });
                },

                iShouldSeeFragment: function (fName, dName) {
                    return this.waitFor({
                        fragmentId: fName,
                        id: names[dName],
                        success: function () {
                            opa5.assert.ok(true, "Dialog opened");
                        },
                        errorMessage: "Dialog could not be opened"
                    });
                },

                iShouldNotSeeControl: function (sControlId) {
                    return this.waitFor({
                        success: function () {
                            var bExists = (opa5.getJQuery()("#" + sControlId).length > 0);
                            opa5.assert.ok(!bExists, "Control does not exists");
                        }
                    });
                },
                iShouldSeePopUp: function (title) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: title
                        }),
                        success: function () {
                            opa5.assert.ok(true, title + " Popup seen");
                        },
                        errorMessage: title + " PopUp not seen"
                    });
                },
            }
        }
    });
});
