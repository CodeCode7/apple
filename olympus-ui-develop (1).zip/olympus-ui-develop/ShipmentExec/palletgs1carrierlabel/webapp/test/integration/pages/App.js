sap.ui.define([
	"sap/ui/test/Opa5"
], function (Opa5PalletCarrier) {
	"use strict";
	var sViewNamePalletCarrier = "App";
	Opa5PalletCarrier.createPageObjects({
		onTheAppPage: {

			actions: {},

			assertions: {

				iShouldSeeTheApp: function () {
					return this.waitFor({
						id: "app",
						viewName: sViewNamePalletCarrier,
						success: function () {
							Opa5PalletCarrier.assert.ok(true, "The " + sViewNamePalletCarrier + " view is displayed");
						},
						errorMessage: "Did not find the " + sViewNamePalletCarrier + " view"
					});
				}
			}
		}
	});

});
