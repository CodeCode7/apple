sap.ui.define([
    "sap/ui/core/format/NumberFormat"
], function () {
    "use strict";

    var util = {};
    util.formatDatePallet = function (palleDateValue) {
        try {
            var date = palleDateValue.substring(0, 4) + "-" + palleDateValue.substring(4, 6) + "-" + palleDateValue.substring(6, 8);
            var oDatePallet = new Date(date);
            if (oDatePallet == "Invalid Date") {
                return palleDateValue;
            } else {
                return sap.ui.core.format.DateFormat.getDateInstance({
                    pattern: "MMM d, yyyy"
                }).format(oDatePallet);
            }
        } catch (oError) {
            return palleDateValue;
        }
    };
    return util;
});
