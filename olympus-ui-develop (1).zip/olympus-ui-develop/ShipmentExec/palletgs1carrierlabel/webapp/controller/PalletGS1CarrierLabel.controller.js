sap.ui.define([
    "./BaseController",
    "com/apple/scp/palletgs1carrierlabel/formatter/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox"
],
    function (BaseController, formatter, JSONModel, Fragment, MessageBox) {
        "use strict";
        return BaseController.extend("com.apple.scp.palletgs1carrierlabel.controller.PalletGS1CarrierLabel", {
            formatter: formatter,

            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("PalletGS1CarrierLabel").attachMatched(this.onRouteMatched, this);
            },
            onRouteMatched: function () {
                this.oBusyDialog = new sap.m.BusyDialog();
                this.oDefaultSSCC18 = this.byId("scc18").setValue("");
                this.checkAuthoPalletCarrier();
                this.value = 0;
                this.auto = true;
            },
            checkAuthoPalletCarrier: function () {
                var oModel = new JSONModel();
                this.getView().setModel(oModel, "AuthModel");
                var oAuthModel = this.getView().getModel("AuthModelPalletCarrier");
                return fetch("/getUserInfo")
                    .then(res => res.json())
                    .then(oToken => {
                        var scopeArr = oToken.decodedJWTToken.scope;
                        if (scopeArr.some(a => a.includes("CARRIERLABEL_CREATE")) && scopeArr.some(a => a.includes("PALLETGS1_CREATE"))) {
                            oAuthModel.setProperty('/createAccess', true);
                        }
                        if (scopeArr.some(a => a.includes("CARRIERLABEL_UPDATE")) && scopeArr.some(a => a.includes("PALLETGS1_UPDATE"))) {
                            oAuthModel.setProperty('/editAccess', true);
                        }
                        if (scopeArr.some(a => a.includes("CARRIERLABEL_DISPLAY")) && scopeArr.some(a => a.includes("PALLETGS1_DISPLAY"))) {
                            oAuthModel.setProperty('/displayAccess', true);
                        }
                    })
                    .catch();
            },
            filterIntialisePalletGs1Carrier: function () {
                this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").setDisplayFormat("MMM d, yyyy");
            },

            onInitialise: function () {
                let tabID = "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--gs1SmartTable";
                this.hideControl(['-btnExcelExport'], tabID); //Standard Toolbar buttons
            },

            hideControl: function (idArr, tabID) {
                for (var id in idArr) {
                    if (!idArr.hasOwnProperty(id)) {
                        continue;
                    }
                    var bID = tabID + idArr[id];
                    var refID = this.getView().byId(bID);
                    if (refID) {
                        refID.setVisible(false);
                    }
                }
            },

            beforeTableRebindPalletGs1Carrier: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                var that = this;
                var filterArray = oBindingParams.filters;
                var filterOutLength = filterArray.length;
                if (filterOutLength > 0) {
                    var filterArrayPath = oBindingParams.filters[0];
                    var filterValFirstParam = filterArrayPath.oValue1;
                    var filterValSecParam = this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo();
                    if (filterOutLength === 1 && filterArrayPath.sPath === "Creation_Date") {
                        filterArrayPath.oValue1 = that.formatDateAsStringPalletCarrier(filterValFirstParam);
                        filterArrayPath.oValue2 = that.formatDateAsStringPalletCarrier(filterValSecParam);
                    } else {
                        that.filterDateFormatPalletCarrier(filterArrayPath);
                    }
                }
            },
            filterDateFormatPalletCarrier: function (filterArrayPath) {
                var that = this;
                var filterManyArray = filterArrayPath.aFilters;
                var filterManyLength = filterManyArray.length;
                for (var i = 0; i < filterManyLength; i++) {
                    if (filterManyArray[i].sPath === "Creation_Date") {
                        filterManyArray[i].oValue1 = that.formatDateAsStringPalletCarrier(filterManyArray[i].oValue1);
                        filterManyArray[i].oValue2 = that.formatDateAsStringPalletCarrier(that.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo());
                        break;
                    }
                }
            },
            formatDateAsStringPalletCarrier: function (dateObject) {
                var year = dateObject.getFullYear();
                var month = dateObject.getMonth() + 1;
                var date = dateObject.getDate();
                if (month < 10) {
                    month = "0" + month;
                } else {
                    month = month + "";
                }
                if (date < 10) {
                    date = "0" + date;
                } else {
                    date = date + "";
                }
                return year + month + date;
            },
            onSearchPalletCarrier: function () {
                this.getView().byId("gs1SmartTable").rebindTable(true);
                this.oDefaultSSCC18.setValue("");
            },
            onClearPalletCarrier: function () {
                this.getView().byId('smartFilterBar').clear();
            },
            selectionChangePalletCarrier: function (oEvent) {
                this.oSelItemPalletCarr = oEvent.getSource().getSelectedItems();
                this.selRow = this.oSelItemPalletCarr[0].getBindingContext().getObject();
                this.selectedOpenQty = this.selRow.Open_Quantity;
            },
            getInputDataPalletGS1: function (oEvent) {
                let val = oEvent.getParameter("value");
                this.value = parseFloat(val);
            },

            validateSSCC18Number: function (oEvent) {
                var isValid = true;

                if (oEvent) {
                    this.sscc18 = oEvent.getParameter("value");
                } else {
                    this.sscc18 = this.getView().byId("gs1SmartTable").getTable().getSelectedItem().getCells()[10].getValue();
                }

                if (!this.auto) {
                    //Auto not checked
                    var sscc18_NUMBERStartIndex = this.sscc18.substring(0, 1);
                    this.errorMessage = "";

                    if ((this.sscc18.length !== 18 && this.sscc18.length !== 0) || sscc18_NUMBERStartIndex !== '1') {
                        this.errorMessage = this.sscc18.length !== 18 ? this.getResourceBundle('sscc18LenErr') : this.getResourceBundle('sscc18N1Err');
                        MessageBox.error(this.errorMessage);
                        isValid = false;
                    }
                }

                return isValid;
            },

            validateEntries: function () {
                //Selection check
                if (!this.oSelItemPalletCarr) {
                    MessageBox.error(this.getResourceBundle("selError"));
                    return false;
                }

                //Zero Qty Check
                if (this.value === 0) {
                    MessageBox.error(this.getResourceBundle("openQtyError"));
                    return false;
                }

                //Input Qty check aganist Open Qty available
                if (!this.validateEnteredQty()) {
                    MessageBox.error(this.getResourceBundle("openQtyErrorGreater"));
                    return false;
                }

                //Manual SSCC18N Validation
                var isValid = this.validateSSCC18Number();
                return isValid;
            },

            prepareFilters: function () {
                var selFilter = [];

                this.selRow.Quantity_Input = this.value;
                this.selRow.SSCC18_M = this.sscc18;

                var PO_NUMBER = new sap.ui.model.Filter({
                    path: "PO_NUMBER",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.PO_Number
                });
                var PO_ITEM_NUMBER = new sap.ui.model.Filter({
                    path: "PO_ITEM_NUMBER",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.Item_Number
                });
                var SUPPLIER = new sap.ui.model.Filter({
                    path: "SUPPLIER",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.Vendor
                });
                var MATERIAL = new sap.ui.model.Filter({
                    path: "MATERIAL",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.Material
                });
                var PLANT = new sap.ui.model.Filter({
                    path: "PLANT",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.Plant
                });
                var COUNT_OF_CARTONS = new sap.ui.model.Filter({
                    path: "COUNT_OF_CARTONS",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.Quantity_Input.toString()
                });
                var SSCC18_NUMBER = new sap.ui.model.Filter({
                    path: "SSCC18_NUMBER",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selRow.SSCC18_M
                });

                if (this.selRow.SSCC18_M === "") {
                    selFilter = [PO_NUMBER, PO_ITEM_NUMBER, SUPPLIER, MATERIAL, PLANT, COUNT_OF_CARTONS];
                } else {
                    selFilter = [PO_NUMBER, PO_ITEM_NUMBER, SUPPLIER, MATERIAL, PLANT, COUNT_OF_CARTONS, SSCC18_NUMBER];
                }

                return selFilter;
            },

            labelService: function () {
                if (!this.validateEntries()) {
                    return;
                }

                var that = this;
                this.oBusyDialog.open();

                var sPath = "/GenerateLabelData";
                var oGenModel = new JSONModel();
                that.getView().setModel(oGenModel, "GenModel");

                var selFilter = this.prepareFilters();

                var oPromiseGenData = new Promise(function (resolve, reject) {
                    that.getOwnerComponent().getModel().read(sPath, {
                        filters: selFilter,
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });

                oPromiseGenData.then(function (oData) {
                    //Success
                    that.openLabelGenPalletCarrierFrag();
                    var oGen = new JSONModel(oData);
                    that.getView().setModel(oGen, "GenModel");
                    if (oData.results[0]) {
                        if (oData.results[0].PALLET_PDF) {
                            that.convertBase64ToPDF(oData.results[0].PALLET_PDF);
                        }
                        if (oData.results[0].CARRIER_PDF) {
                            that.convertBase64ToPDFCarrierLabel(oData.results[0].CARRIER_PDF);
                        }
                    } else {
                        MessageBox.information(that.getResourceBundle("noPDFError"), {
                            onClose: function (oAction) {
                                if (oAction === "OK") {
                                    that.oBusyDialog.close();
                                    return;
                                }
                            }
                        });
                    }
                    that.oBusyDialog.close();
                }, function (oErr) {
                    //Error
                    that.oBusyDialog.close();
                    MessageBox.error(that.showErrorMessage(oErr));
                });
            },

            showErrorMessage: function (oErr) {
                try {
                    var responseText = JSON.parse(oErr.responseText);
                    var msg = responseText.error.message.value;
                } catch (exception) {
                    msg = oErr.responseText;
                }
                return msg;
            },

            validateEnteredQty: function () {
                if (!this.value) {
                    this.value = 0;
                }
                return parseFloat(this.value) <= parseFloat(this.selectedOpenQty);
            },

            openLabelGenPalletCarrierFrag: function (oEvent) {
                var oView = this.getView();
                if (!this.byId("labelCreationFragId")) {
                    Fragment.load({
                        id: oView.getId(),
                        name: "com.apple.scp.palletgs1carrierlabel.fragment.PalletGS1CarrierLabelGeneration",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        oDialog.open();
                    });
                } else {
                    this.byId("labelCreationFragId").open();
                    var oPDFModelPallet = new JSONModel({
                        data: ""
                    });
                    this.getView().setModel(oPDFModelPallet, "pdfModel");
                    var oPDFModelCarrier = new JSONModel({
                        data: ""
                    });
                    this.getView().setModel(oPDFModelCarrier, "pdfModelCarrier");
                }

            },

            closeFragmentLabelGen: function () {
                this.byId("labelCreationFragId").close();
                var oPDFModelPallet = new JSONModel({ data: "" });
                this.getView().setModel(oPDFModelPallet, "pdfModel");
                var oPDFModelCarrier = new JSONModel({ data: "" });
                this.getView().setModel(oPDFModelCarrier, "pdfModelCarrier");

            },

            convertBase64ToPDF: function (base64EncodedPDFPallet) {
                var decodedPdfContentPallet = atob(base64EncodedPDFPallet);
                var byteArrayPallet = new Uint8Array(decodedPdfContentPallet.length);
                for (var i = 0; i < decodedPdfContentPallet.length; i++) {
                    byteArrayPallet[i] = decodedPdfContentPallet.charCodeAt(i);
                }
                var blob = new Blob([byteArrayPallet.buffer], { type: 'application/pdf' });
                var pdfurlPallet = URL.createObjectURL(blob);
                var oPDFModelPallet = new JSONModel({
                    data: pdfurlPallet,
                    Title: "Pallet GS1 Label"
                });
                jQuery.sap.addUrlWhitelist("blob");
                this.getView().setModel(oPDFModelPallet, "pdfModel");
            },

            convertBase64ToPDFCarrierLabel: function (base64EncodedPDF) {
                var decodedPdfContent = atob(base64EncodedPDF);
                var byteArray = new Uint8Array(decodedPdfContent.length);
                for (var i = 0; i < decodedPdfContent.length; i++) {
                    byteArray[i] = decodedPdfContent.charCodeAt(i);
                }
                var blob = new Blob([byteArray.buffer], { type: 'application/pdf' });
                var _pdfurl = URL.createObjectURL(blob);
                var oPDFModelCarrier = new JSONModel({
                    data: _pdfurl,
                    Title1: "Carrier Label"
                });
                jQuery.sap.addUrlWhitelist("blob");
                this.getView().setModel(oPDFModelCarrier, "pdfModelCarrier");
            },

            savePalletPDFData: function () {
                var oPalletData = this.getView().getModel("GenModel").getData().results[0];
                var that = this;
                this.oBusyDialog.open();
                var palletLabelData = {
                    LABEL_ID: oPalletData.LABEL_ID,
                    PO_ITEM_NUMBER: this.selRow.Item_Number,
                    PALLET_TYPE: "Single",
                    PO_NUMBER: this.selRow.PO_Number,
                    PART_NUMBER: "13123",
                    COUNTRY_OF_ASSEMBLY: oPalletData.COUNTRY_OF_ASSEMBLY,
                    MODEL_NUMBER: oPalletData.Model_Number,
                    COUNTRY_OF_ORIGIN: oPalletData.COUNTRY_OF_ORIGIN,
                    GLOBAL_TRADE_IDENTIFICATION_NUMBER: oPalletData.GTIN,
                    COUNT_OF_CARTONS: this.value.toString(),
                    SSCC18_NUMBER: oPalletData.SSCC18_NUMBER,
                    Country: oPalletData.Country,
                    CARRIER_SCAC: oPalletData.CARRIER_SCAC,
                    ORIGIN_DEPARTURE_AIRPORT_CODE: oPalletData.ORIGIN_DEPARTURE_AIRPORT_CODE,
                    DESTINATION_AIRPORT_CODE: oPalletData.DESTINATION_AIRPORT_CODE,
                    SHIP_DATE: oPalletData.SHIP_DATE,
                    HAWB_NUMBER: oPalletData.HAWB_NUMBER,
                    SHIP_ID: oPalletData.SHIP_ID,
                    CARTON_COUNT_ON_PO: oPalletData.CARTON_COUNT_ON_PO,
                    SHIP_TO_ADDRESS1: oPalletData.SHIP_TO_ADDRESS1,
                    SHIP_TO_ADDRESS2: oPalletData.SHIP_TO_ADDRESS2,
                    SHIP_TO_ADDRESS3: oPalletData.SHIP_TO_ADDRESS3,
                    SHIP_TO_RETURN_ADDRESS1: oPalletData.SHIP_TO_RETURN_ADDRESS1,
                    SHIP_TO_RETURN_ADDRESS2: oPalletData.SHIP_TO_RETURN_ADDRESS2,
                    SHIP_TO_RETURN_ADDRESS3: oPalletData.SHIP_TO_RETURN_ADDRESS3
                };
                var oPromise = new Promise(function (resolve, reject) {
                    that.getOwnerComponent().getModel().create("/SaveToPDF", palletLabelData, {
                        success: function () {
                            resolve();
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
                oPromise.then(function () {
                    MessageBox.success(that.getResourceBundle("sucessMSG"));
                    that.closeFragmentLabelGen();
                    that.onSearchPalletCarrier();
                    that.getView().byId("gs1SmartTable").getModel().resetChanges();
                    that.onClearPalletCarrier();
                    that.oBusyDialog.close();
                }, function (oError) {
                    MessageBox.error(oError.responseText);
                    that.oBusyDialog.close();

                });

            },

            onSelectSSCC18Auto: function (oEvent) {
                this.auto = oEvent.getParameter('selected');

                if (this.auto === true) {
                    oEvent.getSource().getParent().getCells()[10].setEditable(false);
                } else {
                    oEvent.getSource().getParent().getCells()[10].setEditable(true);
                }

                oEvent.getSource().getParent().getCells()[10].setValue("");
            },
            typeNumPalletOnly: function (oEvent) {
                var value = oEvent.getParameter("value");
                var QuantityInputStartIndex = value.substring(0, 1);
                if (QuantityInputStartIndex === "0") {
                    MessageBox.information("Quantity Input cannot be 0");
                }

                var bNotnumber = isNaN(value);
                if (bNotnumber === true) {
                    oEvent.getSource().setValue(value.substring(0, value.length - 6));
                }
                return bNotnumber;
            },

            downloadPDF: function(){
                this.downloadFiles("pdfModel", this.getResourceBundle('PalletGS1Label'));
                var that = this;
                setTimeout(function () {
                    that.downloadFiles("pdfModelCarrier", that.getResourceBundle('CarrierLabel'));
                }, 2000);

            },
            downloadFiles: function(modelName, fileName){
                var oPDFData = this.getView().getModel(modelName).getData().data;
                var link = document.createElement('a');
                link.href = oPDFData;
                link.download = fileName;
                document.body.append(link);
                link.click();
                link.remove();
            },

            onDownload: function () {
                let tabID = "container-com.apple.scp.palletgs1carrierlabel---PalletGS1CarrierLabel--gs1SmartTable";
                var bID = tabID + '-btnExcelExport-internalSplitBtn';
                var btnRef = this.getView().byId(bID);
                if (btnRef) {
                    this.getView().byId(bID).firePress(); //Standard Export Data Fire
                }
            }
        });
    });
