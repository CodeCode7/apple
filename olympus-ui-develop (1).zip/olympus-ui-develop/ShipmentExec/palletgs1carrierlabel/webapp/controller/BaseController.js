
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/m/library"
], function (Controller, UIComponent, mobileLibrary) {
    "use strict";

    return Controller.extend("com.apple.scp.palletgs1carrierlabel.controller.BaseController", {
        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },
        getResourceBundle: function (text) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(text);
        }
    });
});
