sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/palletgs1carrierlabel/model/models",
    "sap/base/util/UriParameters",
    "com/apple/scp/palletgs1carrierlabel/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel"
], function (UIComponent, Device, models, UriParameters, MockServer, ODataModel) {
    "use strict";

    return UIComponent.extend("com.apple.scp.palletgs1carrierlabel.Component", {

        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            UIComponent.prototype.init.apply(this, arguments); // call the base component's init function
            this.getRouter().initialize(); // enable routing
            this.setModel(models.createDeviceModel(), "device"); // set the device model

            this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
            if (this.isMock) {
                //Start Mock Server
                this.oMockserver = MockServer.init();

                //Set Mockmodel to Component
                var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                    json: true
                });

                this.setModel(oModel);
            } else {
                this.fetchAppIdPalletCarrier();
            }
        },

        fetchAppIdPalletCarrier: function () {
            var that = this;
            fetch("/getAppVariables").then(
                resp => resp.json()).then(
                    appId => {
                        that.loadMetadataWithAppIDPalletCarrier(appId);
                    });
        },

        loadMetadataWithAppIDPalletCarrier: function (appId) {
            var oParameters = {
                defaultBindingMode: "TwoWay",
                disableHeadRequestForToken: true,
                headers: {
                    appID: appId
                }
            };

            var sUriPalletCarrier = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
            var oModelPalletCarrier = new sap.ui.model.odata.v2.ODataModel(sUriPalletCarrier, oParameters);
            this.setModel(oModelPalletCarrier);
        }
    });
}
);
