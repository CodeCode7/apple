sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (opa5Carrier, EnterText, AggregationLengthEquals, Press, Properties) {
    "use strict";
    var sViewNameCarrier = "CarrierLabel";
    var sPOInputIdCarrier = "container-carrierlabel---CarrierLabel--smartFilterBar-filterItemControl_BASIC-PO_Number";
    var sDateInputIdCarrier = "container-carrierlabel---CarrierLabel--smartFilterBar-filterItemControlA_-Creation_Date";
    var sTableIdCarrier = "container-carrierlabel---CarrierLabel--customTable";
    var namesCarrier = {
        "idSearch": "container-carrierlabel---CarrierLabel--idSearch",
        "idGenLabel": "container-carrierlabel---CarrierLabel--idGenerateLabelBtn",
        "labelCreationFragId" :"container-carrierlabel---CarrierLabel--labelCreationFragId",
        "glCancel": "container-carrierlabel---CarrierLabel--glCancel",
        "glNext": "container-carrierlabel---CarrierLabel--glNext",
        "glBack": "container-carrierlabel---CarrierLabel--glBack",
        "glSaveToPDF": "container-carrierlabel---CarrierLabel--glSaveToPDF"
    };
    opa5Carrier.createPageObjects({
        onTheCLPage: {
            actions: {
                iTriggerBtnPress: function (bRefCarrier) {
                    var bIdCarrier = namesCarrier[bRefCarrier];
                    this.waitFor({
                        viewName: sViewNameCarrier,
                        id: bIdCarrier,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + bRefCarrier
                    });
                },

                iSelectTableRow: function () {
                    this.waitFor({
                        viewName: sViewNameCarrier,
                        controlType: "sap.m.ColumnListItem",
                        id :"customTable",

                        actions: function (oTable) {
                           var item = oTable.getItems()[0];
                           oTable.setSelectedItem(item, true, true);
                        },
                        errorMessage: "Could not select item"
                    });
                },

                iEnterPOForSearchAndPressEnter: function (poNum) {
                    return this.waitFor({
                        id: sPOInputIdCarrier,
                        viewName: sViewNameCarrier,
                        actions: [new EnterText({ text: poNum, pressEnterKey: true })],
                        errorMessage: "The PO Number cannot be entered"
                    });
                },

                iEnterDateForSearchAndPressEnter: function (dRangeCarrier) {
                    return this.waitFor({
                        id: sDateInputIdCarrier,
                        viewName: sViewNameCarrier,
                        actions: [new EnterText({ text: dRangeCarrier, pressEnterKey: true })],
                        errorMessage: "The Date range cannot be entered"
                    });
                },

                iClickOnTableItemByFieldValue: function (fNameCarrier, fValue) {
                    return this.waitFor({
                        controlType: "sap.m.ColumnListItem",

                        // Retrieve all list items in the table
                        matchers: [function (oCandidateListItem) {
                            var oTableLine = {};
                            oTableLine = oCandidateListItem.getBindingContext().getObject();
                            var sFound = false;

                            // Iterate through the list items until the specified cell is found
                            for (var sName in oTableLine) {
                                if ((sName === fNameCarrier) && (oTableLine[sName].toString() === fValue)) {
                                    QUnit.ok(true, "Cell has been found");
                                    sFound = true;
                                    break;
                                }
                            }
                            return sFound;
                        }],

                        // Click on the specified item
                        actions: new Press(),
                        errorMessage: "Cell could not be found in the table"
                    });
                },
                iSearchDialogWithButtonTextAndClick: function (text) {
                    this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Button",
                        matchers: new Properties({
                            text: text
                        }),
                        actions: new Press(),
                        errorMessage: text + " Button Not found"
                    });
                },
            },

            assertions: {
                iShouldSeeBtn: function (buttonReference) {
                    var bIdCarrierLabel = namesCarrier[buttonReference];
                    return this.waitFor({
                        id: bIdCarrierLabel,
                        success: function () {
                            opa5Carrier.assert.ok(true, "Button Found: " + buttonReference);
                        },
                        errorMessage: "Button not found: " + buttonReference
                    });
                },
                iShouldSeePurchaseOrder: function () {
                    return this.waitFor({
                        viewName: sViewNameCarrier,
                        success: function () {
                            opa5Carrier.assert.ok(true, "The " + sViewNameCarrier + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewNameCarrier + " view"
                    });
                },

                iShouldSeeItemCount: function (iItemCountCarrier) {
                    return this.waitFor({
                        id: sTableIdCarrier,
                        viewName: sViewNameCarrier,
                        matchers: [new AggregationLengthEquals({
                            name: "items",
                            length: iItemCountCarrier
                        })],
                        success: function () {
                            opa5Carrier.assert.ok(true, "The table has " + iItemCountCarrier + " item(s)");
                        },
                        errorMessage: "Table does not have expected number of items '" + iItemCountCarrier + "'."
                    });
                },

                iShouldSeeFragment: function(fNameCarrierLabel, dNameCarrierLabel){
                    return this.waitFor({
                        fragmentId: fNameCarrierLabel,
                        id: namesCarrier[dNameCarrierLabel],
                        success: function(){
                            opa5Carrier.assert.ok(true, "Dialog opened");
                        },
                        errorMessage: "Dialog could not be opened"
                    });
                },

                iShouldNotSeeControl: function (sControlIdCarrier) {
                    return this.waitFor({
                        success: function () {
                            var bExistsCarrier = (opa5Carrier.getJQuery()("#" + sControlIdCarrier).length > 0);
                            opa5Carrier.assert.ok(!bExistsCarrier, "Control does not exists");
                        }
                    });
                },
                iShouldSeePopUp: function (titleCarrier) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: titleCarrier
                        }),
                        success: function () {
                            opa5Carrier.assert.ok(true, titleCarrier + " Popup seen");
                        },
                        errorMessage: titleCarrier + " PopUp not seen"
                    });
                },
            }
        }
    });

});
