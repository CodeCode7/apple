sap.ui.define([
    "sap/ui/test/Opa5"
], function (Opa5Carrier) {
    "use strict";
    var sViewNameCarrier = "App";
    Opa5Carrier.createPageObjects({
        onTheAppPage: {

            actions: {},

            assertions: {

                iShouldSeeTheApp: function () {
                    return this.waitFor({
                        id: "app",
                        viewName: sViewNameCarrier,
                        success: function () {
                            Opa5Carrier.assert.ok(true, "The " + sViewNameCarrier + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewNameCarrier + " view"
                    });
                }
            }
        }
    });

});
