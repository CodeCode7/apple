sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/carrierlabel/test/integration/pages/CarrierLabel",
    "com/apple/scp/carrierlabel/test/integration/arrangements/Startup"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Filter and Search");

    opaTest("Should show correct item count after PO search", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });
        //Actions
        When.onTheCLPage.iEnterPOForSearchAndPressEnter("0470000000");

        // Assertions
        Then.onTheCLPage.iShouldSeeItemCount(3).and.iTeardownMyAppFrame();
    });

    opaTest("Should show correct item count after PO search (0)", function (Given, When, Then) {

        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });
        //Actions
        When.onTheCLPage.iEnterPOForSearchAndPressEnter("0480000000");
        // Assertions
        Then.onTheCLPage.iShouldSeeItemCount(0).and.iTeardownMyAppFrame();
    });

});
