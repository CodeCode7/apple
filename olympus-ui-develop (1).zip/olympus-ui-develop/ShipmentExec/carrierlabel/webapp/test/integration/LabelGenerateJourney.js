/*global QUnit*/

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "./pages/App",
    "./pages/CarrierLabel"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Label Generate Journey");

    opaTest("Should open the Generate Label Popup and close it", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onTheCLPage.iTriggerBtnPress("idSearch"); //Click Search
        When.onTheCLPage.iSelectTableRow("Plant", "6401"); //Select table row with plant 6401
        When.onTheCLPage.iTriggerBtnPress("idGenLabel"); //Click Generate label
        
        Then.onTheCLPage.iShouldSeeFragment("CarrierLabelGeneration","labelCreationFragId"); //Fragment check
        When.onTheCLPage.iTriggerBtnPress("glCancel"); //Click Cancel
        Then.onTheCLPage.iShouldNotSeeControl("labelCreationFragId"); //Fragment check

        When.onTheCLPage.iTriggerBtnPress("idGenLabel"); //Click Generate label again
        When.onTheCLPage.iTriggerBtnPress("glNext"); //Click Next
        Then.onTheCLPage.iShouldSeeBtn("glBack"); //Back Button check
        
        When.onTheCLPage.iTriggerBtnPress("glBack"); //Click Back

        When.onTheCLPage.iTriggerBtnPress("glNext"); //Click Next 
        Then.onTheCLPage.iShouldSeeBtn("glSaveToPDF"); //Save to PDF button check
        When.onTheCLPage.iTriggerBtnPress("glSaveToPDF"); //Click Save
        Then.onTheCLPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onTheCLPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button
        Then.onTheCLPage.iShouldNotSeeControl("labelCreationFragId"); //Success Pop up not to be seen
        Then.iTeardownMyApp();
    });
});
