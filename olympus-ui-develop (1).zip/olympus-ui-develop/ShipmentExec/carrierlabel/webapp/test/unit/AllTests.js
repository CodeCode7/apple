sap.ui.define([
    "./formatter/formatter",
    "./controller/App.controller",
    "./controller/BaseController",
    "./controller/CarrierLabel.controller",
    "./model/models"
], function () {
    "use strict";
});
