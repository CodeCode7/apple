
sap.ui.define([
    "com/apple/scp/carrierlabel/controller/BaseController",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel",
    "sap/m/InstanceManager",
    "sap/ui/base/Event"
], function (Controller, ResourceModel, UIComponent, View, JSONModel, InstanceManager, Event) {
    "use strict";
    QUnit.module("Base Controller", {
        beforeEach: function () {
            this.oBaseControllerCarrier = new Controller();
        },
        afterEach: function () {
            this.oBaseControllerCarrier.destroy();
        }
    });

    function jsonOk(body) {
        //the fetch API returns a resolved window Response object
        var mockResponseCarrier = new window.Response(JSON.stringify(body), {
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });
        return Promise.resolve(mockResponseCarrier);
    }

    QUnit.test("Base controller Load", function (assert) {
        assert.ok(this.oBaseControllerCarrier);
    });

    QUnit.test("Should return the translated texts", function (assert) {
        // Arrange
        this._oResourceModelCarrier = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl("com/apple/scp/carrierlabel/i18n/i18n.properties")
        });
        var oCompStubCarrier = {
            getModel: this.stub().withArgs("i18n").returns(this._oResourceModelCarrier)
        };
        var oControllerStubCarrier = {
            getOwnerComponent: this.stub().returns(oCompStubCarrier)
        };

        // System under test
        var fnIsolatedFormatterCarrier = this.oBaseControllerCarrier.getResourceBundle.bind(oControllerStubCarrier);

        // Assert
        assert.strictEqual(fnIsolatedFormatterCarrier("appTitle"), "Carrier Label", "The long text for Application title is correct");

        //CleanUp
        this._oResourceModelCarrier.destroy();
    });

    QUnit.test("Should return the router", function (assert) {
        // Arrange
        var olocalRouterCarrier = new sap.m.routing.Router([
            { "name": "CarrierLabel", "pattern": "", "target": ["CarrierLabel"] }
        ]);

        var oCompStubCarr = sinon.stub(UIComponent, "getRouterFor").returns(olocalRouterCarrier);
        var aRouterCarrier = this.oBaseControllerCarrier.getRouter();
        assert.strictEqual(aRouterCarrier, olocalRouterCarrier, "Router bound to be returned");
        oCompStubCarr.restore();
    });

    QUnit.test("checkAuthoCarrier function test", function (assert) {
        //Arrange
        var fnDoneCarrier = assert.async();
        var oViewStubCarrier = new View({});
        oViewStubCarrier.setModel(new JSONModel(), "CarrierAuthModel");

        var oGetViewStubCarrier = sinon.stub(this.oBaseControllerCarrier, "getView").returns(oViewStubCarrier);
        var oCompCarrier = new UIComponent;
        oCompCarrier.isMock = false;
        var oControllerStubCarrier = sinon.stub(this.oBaseControllerCarrier, "getOwnerComponent").returns(oCompCarrier);

        var localJWTCarrier = {
            "decodedJWTToken":
            {
                "scope": [
                    "configandsetting!t9525.CARRIERLABEL_CREATE",
                    "configandsetting!t9525.CARRIERLABEL_UPDATE",
                    "configandsetting!t9525.CARRIERLABEL_DISPLAY"
                ]
            }
        };
        let stubCarrier = sinon.stub(window, 'fetch'); //add stub
        stubCarrier.onCall(0).returns(jsonOk(localJWTCarrier));

        var lModelCarrier = oViewStubCarrier.getModel("CarrierAuthModel");
        this.oBaseControllerCarrier.checkAuthoCarrier().then(function () {
            //Assert
            assert.strictEqual(lModelCarrier.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(lModelCarrier.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(lModelCarrier.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDoneCarrier();

            //Cleanup
            oGetViewStubCarrier.restore();
            oViewStubCarrier.destroy();
            oCompCarrier.destroy();
            oControllerStubCarrier.restore();
        });
    });

    QUnit.test("onDownloadCarrier function test", function (assert) {
        var oViewStubCarr = new View({});
        var oGetViewStubCarr = sinon.stub(this.oBaseControllerCarrier, "getView").returns(oViewStubCarr);

        var oBtnCarr = new sap.m.Button();
        var oBtnStub = sinon.stub(View.prototype, "byId").returns(oBtnCarr);
        var oBtnSpyCarr = this.stub(sap.m.Button.prototype, "firePress");

        this.oBaseControllerCarrier.onDownloadCarrier();

        assert.strictEqual(oBtnSpyCarr.callCount, 1, "Download function to be triggered");

        oViewStubCarr.destroy();
        oGetViewStubCarr.restore();
        oBtnStub.restore();
        oBtnCarr.destroy();
    });

    QUnit.test("getDepArrCode function test", function (assert) {
        var oViewStubCar = new View({});
        var oGetViewStubCar = sinon.stub(this.oBaseControllerCarrier, "getView").returns(oViewStubCar);
        this.oBaseControllerCarrier.getDepArrCode();
        assert.strictEqual(oViewStubCar.getModel("DepArrCode").getData()[0].code, 'HKG', "Depature Arrival Dropdown data to be set");
        oViewStubCar.destroy();
        oGetViewStubCar.restore();
    });

    QUnit.test("validateEnteredQuantity function test", function (assert) {
        this.oBaseControllerCarrier.selOpenQty = 2;
        var aResCar = this.oBaseControllerCarrier.validateEnteredQuantity();
        assert.strictEqual(aResCar, true, "Positive Quantity Validation");

        this.oBaseControllerCarrier.value = 3;
        aResCar = this.oBaseControllerCarrier.validateEnteredQuantity();
        assert.strictEqual(aResCar, false, "Negative Quantity Validation");
    });

    QUnit.test("handleButtonsVisibility function test", function (assert) {
        var oViewStubCa = new View({});
        var oGetViewStubCa = sinon.stub(this.oBaseControllerCarrier, "getView").returns(oViewStubCa);
        var oWizardVisiblityCa = new JSONModel();
        oViewStubCa.setModel(oWizardVisiblityCa, "wizardVisibilityModel");
        this.oBaseControllerCarrier.oWizard = new sap.m.Wizard();

        this.oBaseControllerCarrier.handleButtonsVisibility();
        assert.strictEqual(oViewStubCa.getModel("wizardVisibilityModel").getProperty("/stepVisibility"), true, "Postive");

        var wStubCa = sinon.stub(this.oBaseControllerCarrier.oWizard, "getProgress").returns(2);
        this.oBaseControllerCarrier.handleButtonsVisibility();
        assert.strictEqual(oViewStubCa.getModel("wizardVisibilityModel").getProperty("/stepVisibility"), false, "Negative");

        oViewStubCa.destroy();
        oGetViewStubCa.restore();
        wStubCa.restore();
    });

    QUnit.test("dateTimeFormatting function test", function (assert) {
        var aDateCarr = this.oBaseControllerCarrier.dateTimeFormatting('03-28-2022');
        assert.equal(typeof (aDateCarr), 'object', 'Date formatting');
    });

    QUnit.test("validateCarSSCC18Quantity function test", function (assert) {
        this.oBaseControllerCarrier.oGenCarrierData = { "SSCC128": '123456789' };
        assert.strictEqual(this.oBaseControllerCarrier.validateCarSSCC18Quantity(), false, 'Negative SCC18N check(<18)');
        InstanceManager.closeAllDialogs();

        this.oBaseControllerCarrier.oGenCarrierData = { "SSCC128": '011111111111111111' };
        assert.strictEqual(this.oBaseControllerCarrier.validateCarSSCC18Quantity(), false, 'Negative SCC18N check(1st Char not 1)');
        InstanceManager.closeAllDialogs();
    });
    QUnit.test("getInputData function test", function (assert){
        var dEvent = new Event('oEvent', {}, { 'value': 1 });
        this.oBaseControllerCarrier.getInputData(dEvent);
        assert.strictEqual(this.oBaseControllerCarrier.value,1,"Quantity changed to be saved in controller reference");
    });
    QUnit.test("typeNumOnly function test", function(assert){
        var oEvent = new Event('oEvent', {}, { 'value': "1" });

        let aResult = this.oBaseControllerCarrier.typeNumOnly(oEvent);
        assert.strictEqual(aResult, false, "Is a Number Test");
    });
});
