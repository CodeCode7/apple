/*global QUnit*/

sap.ui.require([
    "com/apple/scp/carrierlabel/formatter/formatter"
],
    function (formatter) {
        "use strict";

        QUnit.module("Formatting functions");

        function dateFormatTestCase(assert, sValue, fExpectedDate) {
            var msg = "The date format expected was " + fExpectedDate;
            var fDate = formatter.formatDate(sValue);
            assert.strictEqual(fDate, fExpectedDate, msg);
        }

        QUnit.test("Should return correct formatted Date", function (assert) {
            dateFormatTestCase.call(this, assert, "20000101", "Jan 01 , 2000");
            dateFormatTestCase.call(this, assert, "19901231", "Dec 31 , 1990");
        });

        QUnit.test("Invalid Date test", function (assert) {
            dateFormatTestCase.call(this, assert, "20000199", "20000199");
            dateFormatTestCase.call(this, assert, "200", "200");
        });

        QUnit.test("formatDateAsString function test", function (assert) {
            const date1 = new Date(2021, 10, 24, 5, 30, 0, 0);
            const date2 = new Date(2021, 10, 5, 5, 30, 0, 0);
            const date3 = new Date(2021, 8, 24, 5, 30, 0, 0);

            var actDate = formatter.formatDateAsString(date1);
            assert.strictEqual(actDate, "20211124", "Standalone JS Date conversion to YYYYMMDD");
            actDate = formatter.formatDateAsString(date2);
            assert.strictEqual(actDate, "20211105", "Standalone JS Date with single digit date, conversion to YYYYMMDD");
            actDate = formatter.formatDateAsString(date3);
            assert.strictEqual(actDate, "20210924", "Standalone JS Date with single digit month, conversion to YYYYMMDD");
        });
    }
);
