sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/carrierlabel/model/models",
    "sap/base/util/UriParameters",
    "com/apple/scp/carrierlabel/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel"],
    function (UIComponent, Device, models, UriParams, MockServerCarrier, ODataModel) {
        "use strict";
        return UIComponent.extend("com.apple.scp.carrierlabel.Component", {
            metadata: {
                manifest: "json"
            },
            init: function () {
                UIComponent.prototype.init.apply(this, arguments);
                this.getRouter().initialize();
                this.setModel(models.createDeviceModel(), "device");
                this.isMockCarrier = UriParams.fromURL(window.location.href).get("responderOn");
                if (this.isMockCarrier) {
                    this.oMockserver = MockServerCarrier.init("mainService");
                    var odataModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                        json: true
                    });
                    this.setModel(odataModel);

                    this.oMockserver = MockServerCarrier.init("onPremDestination");
                    var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                        json: true
                    });
                    this.setModel(oModel, "onPremDestination")
                } else {
                    this.fetchAppIdCarrier();
                }
            },
            fetchAppIdCarrier: function () {
                var that = this;
                fetch("/getAppVariables").then(resp => resp.json()).then(appId => {
                    that.loadMetadataWithAppIDCarrier(appId);
                });
            },
            loadMetadataWithAppIDCarrier: function (appIdCarrier) {
                var oParameters = {
                    defaultBindingMode: "TwoWay",
                    disableHeadRequestForToken: true,
                    headers: {
                        appID: appIdCarrier
                    }
                };
                var sUriCarrier = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
                var oModelCarrier = new sap.ui.model.odata.v2.ODataModel(sUriCarrier, oParameters);
                this.setModel(oModelCarrier);
                var onPremiseUriCarrier = this.getManifestEntry("/sap.app/dataSources/onPremDestination").uri;
                var onPremModelCarrier = new sap.ui.model.odata.v2.ODataModel(onPremiseUriCarrier, oParameters);
                this.setModel(onPremModelCarrier, "onPremDestination");
            }
        });
    });
