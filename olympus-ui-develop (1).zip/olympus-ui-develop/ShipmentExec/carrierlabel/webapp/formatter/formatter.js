sap.ui.define([
    "sap/ui/core/format/NumberFormat"
], function () {
    "use strict";

    var util = {};
    util.formatDate = function (dateValue) {
        try {
            var date = dateValue.substring(0, 4) + "-" + dateValue.substring(4, 6) + "-" + dateValue.substring(6, 8);
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var oDate = new Date(date);
            if (oDate == "Invalid Date") {
                return dateValue;
            } else {
                return months[dateValue.substring(4, 6) - 1] + " " + dateValue.substring(6, 8) + ' , ' + dateValue.substring(0, 4);
            }
        } catch (oError) {
            return dateValue;
        }
    };
    util.formatDateAsString = function (dateObject) {
        var year = dateObject.getFullYear();
        var month = dateObject.getMonth() + 1;
        var date = dateObject.getDate();
        if (month < 10) {
            month = "0" + month;
        } else {
            month = month + "";
        }
        if (date < 10) {
            date = "0" + date;
        } else {
            date = date + "";
        }
        return year + month + date;
    };
    return util;
});
