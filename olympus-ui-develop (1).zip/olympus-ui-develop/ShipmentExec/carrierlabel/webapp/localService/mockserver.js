sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log",
    "sap/ui/model/json/JSONModel"
], function (MockServer, Log, JSONModel) {
    "use strict";

    var _sAppPath = "com/apple/scp/carrierlabel/",
        _sJsonFilesPath = _sAppPath + "localService/mockdata",
        _aEntitySets = {
            "mainService" : ["CarrierLabelData","CarrierDistinctPo","Address"],
            "onPremDestination" : ["GENERATE_CARRIER_LABELSet"]
        };

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function (serviceName) {
            var sJsonFilesUrl = sap.ui.require.toUrl(_sJsonFilesPath),
                sManifestUrl = sap.ui.require.toUrl(_sAppPath + "manifest.json"),
                oManifest = jQuery.sap.syncGetJSON(sManifestUrl).data,
                oMainDataSource = oManifest["sap.app"].dataSources[serviceName],
                sMetadataUrl = sap.ui.require.toUrl(_sAppPath + oMainDataSource.settings.localUri);

            this.sMockServerUrl = oMainDataSource.uri;

            // init root URI
            this.oMockServer = new MockServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MockServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockServer.simulate(sMetadataUrl, {
                sMockdataBaseUrl: sJsonFilesUrl,
                aEntitySetsNames: _aEntitySets[serviceName],
                bGenerateMissingMockData: false
            });


            var mockPDFValue = function(oEvent) {
                var lModel = new JSONModel();
                var sPath = sap.ui.require.toUrl(_sJsonFilesPath + "/GENERATE_CARRIER_LABELSet.json")
                lModel.loadData(sPath, "", false);

                oEvent.getParameter("oEntity").VALUE = lModel.getProperty("/VALUE");
            };
            this.oMockServer.attachAfter("POST", mockPDFValue, "GENERATE_CARRIER_LABELSet");

            this.oMockServer.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrl + "\n" +
                "   mockdata dir: " + sJsonFilesUrl);

            return this;
        }
    };

});
