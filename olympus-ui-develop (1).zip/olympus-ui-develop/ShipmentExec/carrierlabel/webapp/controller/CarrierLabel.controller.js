sap.ui.define([
    "./BaseController",
    "com/apple/scp/carrierlabel/formatter/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox",
],
    function (BaseController, formatter, JSONModel, Fragment, MessageBox) {
        "use strict";
        return BaseController.extend("com.apple.scp.carrierlabel.controller.CarrierLabel", {
            formatter: formatter,
            onInit: function () {
                this.getDepArrCode();
                this.getView().setModel(new JSONModel(), "CarrierAuthModel");
                this.checkAuthoCarrier(this);
            },
            filterIntialise: function () {
                this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").setDisplayFormat("MMM d, yyyy");
                this.hideExportButtonCarrier();
            },
            hideExportButtonCarrier: function () {
                var exportButtonID = this.getView().getId() + '--gs1SmartTable-btnExcelExport';
                this.getView().byId(exportButtonID).setVisible(false);
            },
            beforeTableRebind: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                var that = this;
                var filterArray = oBindingParams.filters;
                var filterOutLength = filterArray.length;
                if (filterOutLength > 0) {
                    var filterArrayPath = oBindingParams.filters[0];
                    var filterVal1 = this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getFrom();
                    var filterVal2 = this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo();
                    if (filterOutLength === 1 && filterArrayPath.sPath === "Creation_Date") {
                        filterArrayPath.oValue1 = formatter.formatDateAsString(filterVal1);
                        filterArrayPath.oValue2 = formatter.formatDateAsString(filterVal2);
                    } else {
                        that.filterFormattingCarrierDate(filterArrayPath, this);
                    }

                }
            },
            selectionChange: function (oEvent) {
                this.oSelectedItem = oEvent.getSource().getSelectedItems();
                if (oEvent.getSource().getSelectedItems().length) {
                    var sPath = this.oSelectedItem[0].getBindingContext().sPath;
                    var tModel = this.getView().byId("gs1SmartTable").getModel();
                    this.selOpenQty = tModel.getProperty(sPath).Open_Quantity;
                }
            },
            labelServiceCarrierLabel: function () {
                var that = this;
                this.selectedItemsBindingData = this.getView().byId("customTable").getSelectedItem().getBindingContext().getObject();
                this.selectedItemsBindingData.Quantity_Input = this.value;
                var oGenerateLabelModel = new JSONModel(this.selectedItemsBindingData);
                this.getView().setModel(oGenerateLabelModel, "GenerateLabelModel");
                var oRef = this.headerData(this.selectedItemsBindingData.Plant);
                oRef.then(function (resdata) {
                    var oModel = new JSONModel(resdata);
                    that.getView().setModel(oModel, "shipAddModel");
                }, function (error) {
                    console.log(error);
                });
                var oRefPlant = this.headerData(this.selectedItemsBindingData.Vendor);
                oRefPlant.then(function (dataRef) {
                    var oModel = new JSONModel(dataRef);
                    that.getView().setModel(oModel, "returnAddModel");
                }, function (error) {
                    console.log(error);
                });
                var data = {
                    "CARRIER_SCAC": "",
                    "DEP_AP_CODE": "",
                    "DEST_AP_CODE": "",
                    "SHIP_DATE": "",
                    "HAWB_NUMBER": "",
                    "SHIP_ID": "",
                    "PO_NUMBER": this.selectedItemsBindingData.PO_Number,
                    "SSCC128": '122334567891234567',
                    "PO_ITEM_NUMBER": this.selectedItemsBindingData.Item_Number,
                    "CARTON_COUNT": "",
                    "SHIP_TO_ADDR1": "",
                    "SHIP_TO_ADDR2": "",
                    "SHIP_TO_ADDR3": "",
                    "RETURN_ADDR1": "",
                    "RETURN_ADDR2": "",
                    "RETURN_ADDR3": ""
                };
                var cModel = new JSONModel(data);
                this.getView().setModel(cModel, "CarrierModel");
            },
            openLabelGenFrag: function () {
                if (!this.oSelectedItem) {
                    MessageBox.information(this.getResourceBundle("noRecSelected"));
                    return;
                } else if (!this.validateEnteredQuantity()) {
                    MessageBox.information(this.getResourceBundle("openQtyError"));
                    return;
                }
                this.labelServiceCarrierLabel();
                var oView = this.getView();
                var that = this;
                if (!this.byId("labelCreationFragId")) {
                    Fragment.load({
                        id: oView.getId(),
                        name: "com.apple.scp.carrierlabel.fragment.CarrierLabelGeneration",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        oDialog.open();
                        that.onDialogAfterOpen();
                    });
                } else {
                    this.byId("labelCreationFragId").open();
                    that.onDialogAfterOpen();
                }
            },
            onDialogAfterOpen: function () {
                var oWizardVisiblity = new JSONModel({ 'stepVisibility': true });
                this.getView().setModel(oWizardVisiblity, "wizardVisibilityModel");
                this.oWizard = this.byId("labelWizard");
                var oDataInputStep = this.getView().byId("labelDataInputStep");
                this.oWizard.setCurrentStep(oDataInputStep);
                this.handleButtonsVisibility(this);
            },
            closeFragmentLabelGen: function () {
                var oCarr = new JSONModel();
                this.getView().setModel(oCarr, "CarrierModel");
                this.byId("labelCreationFragId").close();
            },
            onDialogNextButton: function () {
                this.oGenCarrierData = this.getView().getModel("CarrierModel").getData();
                if (this.validateCarSSCC18Quantity()) {
                    if (this.oWizard.getProgressStep().getValidated()) {
                        this.oWizard.nextStep();
                    }
                    this.handleButtonsVisibility(this);
                    this.getPDF();
                }
            },
            getPDF: function () {
                var that = this;
                this.shipAdd = this.getView().getModel("shipAddModel").getData().results[0];
                this.retAdd = this.getView().getModel("returnAddModel").getData().results[0];
                var carrierLabelData = {
                    "Uuid": "23232",
                    "PoNbr": this.oGenCarrierData.PO_NUMBER,
                    "CarrierScac": this.oGenCarrierData.CARRIER_SCAC,
                    "DepApCode": this.oGenCarrierData.DEP_AP_CODE,
                    "DestApCode": this.oGenCarrierData.DEST_AP_CODE,
                    "HawbNbr": this.oGenCarrierData.HAWB_NUMBER,
                    "ShipDate": this.oGenCarrierData.SHIP_DATE ? this.dateTimeFormatting(this.oGenCarrierData.SHIP_DATE) : null,
                    "ShipId": this.oGenCarrierData.SHIP_ID,
                    "Sscc128": this.oGenCarrierData.SSCC128,
                    "Carton1ToX": this.oGenCarrierData.CARTON_COUNT,
                    "CartonTotalPo": this.oGenCarrierData.CARTON_COUNT,
                    "ShipToName1": this.shipAdd.Name1 ? this.shipAdd.Name1 : "",
                    "ShipToName2": this.shipAdd.Name2 ? this.shipAdd.Name2 : "",
                    "ShipToAddr1": "",
                    "ShipToAddr2": "",
                    "ShipToAddr3": this.shipAdd.Street_House_NO ? this.shipAdd.Street_House_NO : "",
                    "ShipToCity": this.shipAdd.City ? this.shipAdd.City : "",
                    "ShipToState": this.shipAdd.Region ? this.shipAdd.Region : "",
                    "ShipToZip": this.shipAdd.Postal_Code ? this.shipAdd.Postal_Code : "",
                    "ShipToCtry": this.shipAdd.Country ? this.shipAdd.Country : "",
                    "ShipToTel": this.shipAdd.Telephone ? this.shipAdd.Telephone : "",
                    "ReturnName1": this.retAdd.Name1 ? this.retAdd.Name1 : "",
                    "ReturnName2": this.retAdd.Name2 ? this.retAdd.Name2 : "",
                    "ReturnAddr3": this.retAdd.Street_House_NO ? this.retAdd.Street_House_NO : "",
                    "ReturnCity": this.retAdd.City ? this.retAdd.City : "",
                    "ReturnState": this.retAdd.Region ? this.retAdd.Region : "",
                    "ReturnZip": this.retAdd.Postal_Code ? this.retAdd.Postal_Code : "",
                    "ReturnCtry": this.retAdd.Country ? this.retAdd.Country : "",
                    "ReturnTel": this.retAdd.Telephone ? this.retAdd.Telephone : "",
                    "DateTimestamp": "",
                    "CreationUser": "",
                    "CARRIER_PO_ITEMSSet": [{ "LineItem": this.selectedItemsBindingData.Item_Number, "Material": this.selectedItemsBindingData.Material, "Quantity": this.value }]
                };
                var oModel = that.getOwnerComponent().getModel("onPremDestination");
                oModel.create('/GENERATE_CARRIER_LABELSet', carrierLabelData, {
                    success: function (data) {
                        that.convertBase64ToPDFCarrierLabel(data.VALUE);
                    }, error: function (error) {
                        console.log(error);
                    }
                });
            },
            onDialogBackButton: function () {
                this.oWizard.previousStep();
                this.handleButtonsVisibility();
            },
        });
    });
