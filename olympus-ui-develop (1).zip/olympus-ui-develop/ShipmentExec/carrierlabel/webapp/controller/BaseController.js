
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "com/apple/scp/carrierlabel/formatter/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (Controller, UIComponent,formatter,JSONModel,MessageBox) {
    "use strict";

    return Controller.extend("com.apple.scp.carrierlabel.controller.BaseController", {
        formatter: formatter,
        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },
        getResourceBundle: function (text) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(text);
        },
        checkAuthoCarrier:function(){
            var oAuthModel = this.getView().getModel("CarrierAuthModel");
            return fetch("/getUserInfo").then(res => res.json()).then(oToken => {
                var scopeArr = oToken.decodedJWTToken.scope;
                if (scopeArr.some(a => a.includes("CARRIERLABEL_CREATE"))) {
                    oAuthModel.setProperty('/createAccess', true);
                }
                if (scopeArr.some(a => a.includes("CARRIERLABEL_UPDATE"))) {
                    oAuthModel.setProperty('/editAccess', true);
                }
                if (scopeArr.some(a => a.includes("CARRIERLABEL_DISPLAY"))) {
                    oAuthModel.setProperty('/displayAccess', true);
                }
            })
                .catch();
        },
        filterFormattingCarrierDate: function (filterArrayPath) {
            var that = this;
            var filterManyArray = filterArrayPath.aFilters;
            var filterManyLength = filterManyArray.length;
            for (var i = 0; i < filterManyLength; i++) {
                if (filterManyArray[i].sPath === "Creation_Date") {
                    filterManyArray[i].oValue1 = formatter.formatDateAsString(that.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getFrom());
                    filterManyArray[i].oValue2 = formatter.formatDateAsString(that.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo());
                    break;
                }
            }
        },
        onSearch: function () {
            this.getView().byId("gs1SmartTable").rebindTable(true);
        },
        onClear: function () {
            this.getView().byId('smartFilterBar').clear();
        },
        onDownloadCarrier:function(){
            var exportButtonID = this.getView().getId()+ '--gs1SmartTable-btnExcelExport-internalSplitBtn';
            var buttonRef = this.getView().byId(exportButtonID);
            if (buttonRef) {
                buttonRef.firePress();
            }
        },
        typeNumIntegerOnly: function (oEvent) {
            var value = oEvent.getSource().getValue();
            if (value !== "") {
                var bNotnumber = isNaN(value);
                if (bNotnumber === true) {
                    oEvent.getSource().setValue(value.substring(0, value.length - 1));
                } else {
                    value = Number.parseInt(value) + '';
                    oEvent.getSource().setValue(value);
                }
            }
        },
        typeNumOnly: function (oEvent) {
            var value = oEvent.getParameter("value");
            var bNotnumber = isNaN(value);
            if (bNotnumber === true) {
                oEvent.getSource().setValue(value.substring(0, value.length - 1));
            }
            return bNotnumber;
        },
        getInputData: function (oEvent) {
            this.value = oEvent.getParameter("value");
        },
        getDepArrCode: function () {
            var codes = [{"code": "HKG"},{"code": "JFK"},{"code": "SNG"},{"code": "DUB"},{"code": "SHG"}];
            var oModel = new JSONModel(codes);
            this.getView().setModel(oModel, "DepArrCode");
        },
        dateTimeFormatting:function(dateValue){
            if(dateValue){
                var dateDataValue = new Date(dateValue);
                dateDataValue.setDate(dateDataValue.getDate()+1);
                dateDataValue.setHours(0,0,0,0);
                return dateDataValue;
            }
            return dateValue;
        },

        convertBase64ToPDFCarrierLabel: function (base64EncodedPDF) {
            var decodedPdfContent = atob(base64EncodedPDF);
            var byteArray = new Uint8Array(decodedPdfContent.length);
            for (var i = 0; i < decodedPdfContent.length; i++) {
                byteArray[i] = decodedPdfContent.charCodeAt(i);
            }
            var blob = new Blob([byteArray.buffer], { type: 'application/pdf' });
            var _pdfurl = URL.createObjectURL(blob);
            var oPDFModel = new JSONModel({data: _pdfurl});
            jQuery.sap.addUrlWhitelist("blob");
            this.getView().setModel(oPDFModel, "pdfModel");
        },
        savePDFData: function () {
            var that = this;
            var cData = {
                "CARRIER_SCAC": this.oGenCarrierData.CARRIER_SCAC,
                "ORIGIN_DEPARTURE_AIRPORT_CODE": this.oGenCarrierData.DEP_AP_CODE,
                "DESTINATION_AIRPORT_CODE": this.oGenCarrierData.DEST_AP_CODE,
                "SHIP_DATE": this.dateTimeFormatting(this.oGenCarrierData.SHIP_DATE),
                "HAWB_NUMBER": this.oGenCarrierData.HAWB_NUMBER,
                "SHIP_ID": this.oGenCarrierData.SHIP_ID,
                "PO_NUMBER": this.oGenCarrierData.PO_NUMBER,
                "SSCC128_NUMBER": this.oGenCarrierData.SSCC128,
                "PO_ITEM_NUMBER":this.oGenCarrierData.PO_ITEM_NUMBER,
                "CARTON_COUNT_ON_PO": this.oGenCarrierData.CARTON_COUNT,
                "SHIP_TO_ADDRESS1": this.shipAdd.Name1,
                "SHIP_TO_ADDRESS2": this.shipAdd.Name2,
                "SHIP_TO_ADDRESS3": this.shipAdd.City,
                "SHIP_TO_RETURN_ADDRESS1": this.retAdd.Name1,
                "SHIP_TO_RETURN_ADDRESS2": this.retAdd.Name2,
                "SHIP_TO_RETURN_ADDRESS3": this.retAdd.Street_House_NO
            };
            this.getOwnerComponent().getModel().create("/CarrierLabel", cData, {
                success: function () {
                    MessageBox.success("Data saved sucessfully");
                    that.closeFragmentLabelGen();
                    that.onSearch();
                    that.onSearch();
                    that.getView().byId("gs1SmartTable").getModel().resetChanges();
                    that.onClear();
                },
                error: function (oError) {
                    MessageBox.error(oError.responseText);
                }
            });
        },
        validateCarSSCC18Quantity: function (oEvent) {
            if (oEvent) {
                this.SSCC18_NUMBER = oEvent.getSource().getValue();
            } else {
                this.SSCC18_NUMBER = this.oGenCarrierData.SSCC128;
            }
            var isValidNum = true;
            var sscc18_NumberStartIndex = this.SSCC18_NUMBER.substring(0, 1);
            this.errorMessage = "";
            if (this.SSCC18_NUMBER.length !== 18 || sscc18_NumberStartIndex !== '1') {
                this.errorMessage = this.SSCC18_NUMBER.length !== 18 ? 'Please enter a 18 digit SSCC18 number  ' : 'SSCC18 number should start with 1';
                MessageBox.information(this.errorMessage);
                return false;
            }
            if (!oEvent) {
                return isValidNum;
            }
            return;
        },
        headerData: function (supplier) {
            var that = this;
            var supplierFilter = new sap.ui.model.Filter({path: "Vendor",operator: sap.ui.model.FilterOperator.EQ,value1: supplier});
            return new Promise(function (resolve, reject) {
                that.getOwnerComponent().getModel().read("/Address", {
                    filters: [supplierFilter],
                    success: function (oData) {
                        resolve(oData);
                    },
                    error: function (oError) {
                        reject(oError);
                    }
                });
            });
        },
        handleButtonsVisibility: function () {
            var oModel = this.getView().getModel("wizardVisibilityModel");
            switch (this.oWizard.getProgress()) {
                case 1:
                    oModel.setProperty("/stepVisibility", true);
                    break;
                case 2:
                    oModel.setProperty("/stepVisibility", false);
                    break;
                default: break;
            }

        },
        validateEnteredQuantity: function () {
            if (!this.value) {
                this.value = 0;
            }
            return parseFloat(this.value) <= parseFloat(this.selOpenQty);
        },
    });
});
