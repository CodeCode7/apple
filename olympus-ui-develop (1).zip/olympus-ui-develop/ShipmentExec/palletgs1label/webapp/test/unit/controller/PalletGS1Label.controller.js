sap.ui.define([
    "sap/ui/core/mvc/View",
    "com/apple/scp/palletgs1label/controller/PalletGS1Label.controller",
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/UIComponent",
    "sap/m/InstanceManager",
    "sap/ui/base/Event"
], function (ManagedObject, Controller, aController, sFB, sTable, View, JSONModel, UIComponent, InstanceManager, Event) {
    "use strict";
    QUnit.module("PalletGS1Label Controller", {
        beforeEach: function () {
            this.oPalletGS1LabelController = new Controller();
        },
        afterEach: function () {
            this.oPalletGS1LabelController.destroy();
        }
    });

    function jsonOk(body) {
        //the fetch API returns a resolved window Response object
        var mockResponsePallet = new window.Response(JSON.stringify(body), {
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });
        return Promise.resolve(mockResponsePallet);
    }

    QUnit.test("PalletGS1Label controller Load", function (assert) {
        assert.ok(this.oPalletGS1LabelController);
    });
    QUnit.test("Smart Table search test", function (assert) {
        //Arrange
        var oSTablePallet = new sTable("sTable");
        var oViewStubPallet = new ManagedObject({});
        var oSTableSpyPallet = this.stub(sap.ui.comp.smarttable.SmartTable.prototype, "rebindTable");
        var oGetViewStubPallet = sinon.stub(aController.prototype, "getView").returns(oViewStubPallet);
        var oSTableStubPallet = sinon.stub(ManagedObject.prototype, "byId").returns(oSTablePallet);
        //Act
        this.oPalletGS1LabelController.onSearchPallet();
        //Assert
        assert.strictEqual(oSTableSpyPallet.callCount, 1, "Smart Table rebindTable event to be triggered");
        //CleanUp
        oSTableSpyPallet.restore();
        oSTableStubPallet.restore();
        oGetViewStubPallet.restore();
        oSTablePallet.destroy();
        oViewStubPallet.destroy();
    });
    QUnit.test("Smart Filter Bar clear test", function (assert) {
        //Arrange
        var oSFBPall = new sFB("SFB");
        var oViewStubPall = new ManagedObject({});
        var oSFBSpyPall = this.stub(sap.ui.comp.smartfilterbar.SmartFilterBar.prototype, "clear");
        var oGetViewStubPall = sinon.stub(aController.prototype, "getView").returns(oViewStubPall);
        var oSFBStubPall = sinon.stub(ManagedObject.prototype, "byId").returns(oSFBPall);

        //Act
        this.oPalletGS1LabelController.onClearPallet();

        //Assert
        assert.strictEqual(oSFBSpyPall.callCount, 1, "Smart Filter Bar clear to be triggered");

        //CleanUp
        oSFBSpyPall.restore();
        oSFBStubPall.restore();
        oGetViewStubPall.restore();
        oSFBPall.destroy();
        oViewStubPall.destroy();
    });

    QUnit.test("checkAutho function test", function (assert) {
        //Arrange
        var fnDone = assert.async();
        var oViewStub = new View({});
        oViewStub.setModel(new JSONModel(), "AuthModelPalletGS");

        var oGetViewStub = sinon.stub(this.oPalletGS1LabelController, "getView").returns(oViewStub);
        var oComp = new UIComponent;
        oComp.isMock = false;
        var oControllerStub = sinon.stub(this.oPalletGS1LabelController, "getOwnerComponent").returns(oComp);

        var localJWT = {
            "decodedJWTToken":
            {
                "scope": [
                    "configandsetting!t9525.PALLETGS1_CREATE",
                    "configandsetting!t9525.PALLETGS1_UPDATE",
                    "configandsetting!t9525.PALLETGS1_DISPLAY"
                ]
            }
        };
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk(localJWT));

        var lModel = oViewStub.getModel("AuthModelPalletGS");
        this.oPalletGS1LabelController.checkAutho().then(function () {
            //Assert
            assert.strictEqual(lModel.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(lModel.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(lModel.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDone();

            //Cleanup
            oGetViewStub.restore();
            oViewStub.destroy();
            oComp.destroy();
            oControllerStub.restore();
        });
    });

    QUnit.test("onDownload function test", function (assert) {
        var oViewStub = new View({});
        var oGetViewStub = sinon.stub(this.oPalletGS1LabelController, "getView").returns(oViewStub);

        var oBtn = new sap.m.Button();
        var oBtnStub = sinon.stub(View.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oPalletGS1LabelController.onDownload();

        assert.strictEqual(oBtnSpy.callCount, 1, "Download function to be triggered");

        oViewStub.destroy();
        oGetViewStub.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });
    QUnit.test("validateEnteredQty function test", function (assert) {
        this.oPalletGS1LabelController.selectedOpenQty = 2;
        var aRes = this.oPalletGS1LabelController.validateEnteredQty();
        assert.strictEqual(aRes, true, "Positive Quantity Validation");

        this.oPalletGS1LabelController.value = 3;
        aRes = this.oPalletGS1LabelController.validateEnteredQty();
        assert.strictEqual(aRes, false, "Negative Quantity Validation");
    });
    QUnit.test("handlePalletButtonsVisibility function test", function (assert) {
        var oViewStub = new View({});
        var oGetViewStub = sinon.stub(this.oPalletGS1LabelController, "getView").returns(oViewStub);
        var oWizardVisiblity = new JSONModel();
        oViewStub.setModel(oWizardVisiblity, "wizardVisibilityModel");
        this.oPalletGS1LabelController.oWizard = new sap.m.Wizard();

        this.oPalletGS1LabelController.handlePalletButtonsVisibility();
        assert.strictEqual(oViewStub.getModel("wizardVisibilityModel").getProperty("/stepVisibility"), true, "Postive");

        var wStub = sinon.stub(this.oPalletGS1LabelController.oWizard, "getProgress").returns(2);
        this.oPalletGS1LabelController.handlePalletButtonsVisibility();
        assert.strictEqual(oViewStub.getModel("wizardVisibilityModel").getProperty("/stepVisibility"), false, "Negative");

        oViewStub.destroy();
        oGetViewStub.restore();
        wStub.restore();
    });
    QUnit.test("formatDateAsStringPallet function test", function (assert) {
        const date1 = new Date(2021, 10, 24, 5, 30, 0, 0),
            date2 = new Date(2021, 10, 5, 5, 30, 0, 0),
            date3 = new Date(2021, 8, 24, 5, 30, 0, 0);

        var actualDate = this.oPalletGS1LabelController.formatDateAsStringPallet(date1);
        assert.strictEqual(actualDate, "20211124", "Standalone JS Date conversion to YYYYMMDD");
        actualDate = this.oPalletGS1LabelController.formatDateAsStringPallet(date2);
        assert.strictEqual(actualDate, "20211105", "Standalone JS Date with single digit date, conversion to YYYYMMDD");
        actualDate = this.oPalletGS1LabelController.formatDateAsStringPallet(date3);
        assert.strictEqual(actualDate, "20210924", "Standalone JS Date with single digit month, conversion to YYYYMMDD");
    });
    QUnit.test("sscc18NumberValidation function test", function (assert) {
        this.oPalletGS1LabelController.oBusyDialog = new sap.m.BusyDialog();
        this.oPalletGS1LabelController.SSCC18_NUMBER = '123456789';
        assert.strictEqual(this.oPalletGS1LabelController.sscc18NumberValidation(), false, 'Negative SCC18N check(<18)');
        InstanceManager.closeAllDialogs();

        this.oPalletGS1LabelController.SSCC18_NUMBER = '011111111111111111';
        assert.strictEqual(this.oPalletGS1LabelController.sscc18NumberValidation(), false, 'Negative SCC18N check(1st Char not 1)');
        InstanceManager.closeAllDialogs();
    });
    QUnit.test("typeNumPalletOnly function test", function(assert){
        var dEvent = new Event('oEvent', {}, { 'value': "1" });

        let aResult = this.oPalletGS1LabelController.typeNumPalletOnly(dEvent);
        assert.strictEqual(aResult, false, "Is a Number Test");
    });
});
