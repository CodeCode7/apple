/*global QUnit*/

sap.ui.require([
    "com/apple/scp/palletgs1label/formatter/formatter"
],
    function (formatterPallet) {
        "use strict";

        QUnit.module("Formatting functions");

        function dateFormatTestCase(assertPallet, sValuePallet, fExpectedDatePallet) {
            var msgPallet = "The date format expected was " + fExpectedDatePallet;
            var fDatePallet = formatterPallet.formatDatePallet(sValuePallet);
            assertPallet.strictEqual(fDatePallet, fExpectedDatePallet, msgPallet);
        }

        QUnit.test("Should return correct formatted Date", function (assertPallet) {
            dateFormatTestCase.call(this, assertPallet, "20000101", "Jan 01 , 2000");
            dateFormatTestCase.call(this, assertPallet, "19901231", "Dec 31 , 1990");
        });

        QUnit.test("Invalid Date test", function (assertPall) {
            dateFormatTestCase.call(this, assertPall, "20000199", "20000199");
            dateFormatTestCase.call(this, assertPall, "200", "200");
        });

    }
);
