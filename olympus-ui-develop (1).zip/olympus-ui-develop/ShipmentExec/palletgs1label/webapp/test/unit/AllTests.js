sap.ui.define([
    "./formatter/formatter",
    "./controller/App.controller",
    "./controller/BaseController",
    "./controller/PalletGS1Label.controller",
    "./model/models"
], function () {
    "use strict";
});
