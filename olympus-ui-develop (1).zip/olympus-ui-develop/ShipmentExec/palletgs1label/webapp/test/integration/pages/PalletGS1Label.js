sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (opa5, EnterText, AggregationLengthEquals, Press, Properties) {
    "use strict";
    var sViewNamePallet = "PalletGS1Label";
    var sPOInputId = "container-palletgs1label---PalletGS1Label--smartFilterBar-filterItemControl_BASIC-PO_Number";
    var sDateInputId = "container-palletgs1label---PalletGS1Label--smartFilterBar-filterItemControlA_-Creation_Date";
    var sTableId = "container-palletgs1label---PalletGS1Label--customTable";
    var names = {
        "idSearch": "container-palletgs1label---PalletGS1Label--idSearch",
        "idGenLabel": "container-palletgs1label---PalletGS1Label--idGenerateLabelBtn",
        "labelCreationFragId": "container-palletgs1label---PalletGS1Label--labelCreationFragId",
        "glCancel": "container-palletgs1label---PalletGS1Label--glCancel",
        "glNext": "container-palletgs1label---PalletGS1Label--glNext",
        "glBack": "container-palletgs1label---PalletGS1Label--glBack",
        "glSavePalletPDF": "container-palletgs1label---PalletGS1Label--glSavePalletPDF"
    };
    opa5.createPageObjects({
        onThePGSPage: {
            actions: {
                iTriggerBtnPress: function (bRefPallet) {
                    var bId = names[bRefPallet];
                    this.waitFor({
                        viewName: sViewNamePallet,
                        id: bId,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + bRefPallet
                    });
                },

                iSelectTableRow: function () {
                    this.waitFor({
                        viewName: sViewNamePallet,
                        controlType: "sap.m.ColumnListItem",
                        id: "customTable",

                        actions: function (oTablePallet) {
                            var itemPallet = oTablePallet.getItems()[0];
                            oTablePallet.setSelectedItem(itemPallet, true, true);
                        },
                        errorMessage: "Could not select item"
                    });
                },

                iEnterPOForSearchAndPressEnter: function (poNumPallet) {
                    return this.waitFor({
                        id: sPOInputId,
                        viewName: sViewNamePallet,
                        actions: [new EnterText({ text: poNumPallet, pressEnterKey: true })],
                        errorMessage: "The PO Number cannot be entered"
                    });
                },

                iEnterDateForSearchAndPressEnter: function (dRangePallet) {
                    return this.waitFor({
                        id: sDateInputId,
                        viewName: sViewNamePallet,
                        actions: [new EnterText({ text: dRangePallet, pressEnterKey: true })],
                        errorMessage: "The Date range cannot be entered"
                    });
                },

                iClickOnTableItemByFieldValue: function (fNamePallet, fValuePallet) {
                    return this.waitFor({
                        controlType: "sap.m.ColumnListItem",

                        // Retrieve all list items in the table
                        matchers: [function (oCandidateListItem) {
                            var oTableLinePallet = {};
                            oTableLinePallet = oCandidateListItem.getBindingContext().getObject();
                            var sFoundPallet = false;

                            // Iterate through the list items until the specified cell is found
                            for (var sNamePallet in oTableLinePallet) {
                                if ((sNamePallet === fNamePallet) && (oTableLinePallet[sNamePallet].toString() === fValuePallet)) {
                                    QUnit.ok(true, "Cell has been found");
                                    sFoundPallet = true;
                                    break;
                                }
                            }
                            return sFoundPallet;
                        }],

                        // Click on the specified item
                        actions: new Press(),
                        errorMessage: "Cell could not be found in the table"
                    });
                },
                iSearchDialogWithButtonTextAndClick: function (textPallet) {
                    this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Button",
                        matchers: new Properties({
                            text: textPallet
                        }),
                        actions: new Press(),
                        errorMessage: textPallet + " Button Not found"
                    });
                },

                iEnterInputQuantity: function () {
                    return this.waitFor({
                        viewName: sViewNamePallet,
                        controlType: "sap.m.ColumnListItem",
                        id: "customTable",
                        actions: function (oTablePallet) {
                            var inputQuantityPallet = oTablePallet.getSelectedItem().getCells()[9];
                            inputQuantityPallet.setValue("1.000");
                            inputQuantityPallet.fireChange({value: "1.000"});
                        },
                        errorMessage: "Input Quantity cannot be entered"
                    });
                }
            },

            assertions: {
                iShouldSeeBtn: function (buttonReferencePallet) {
                    var bIdPallet = names[buttonReferencePallet];
                    return this.waitFor({
                        id: bIdPallet,
                        success: function () {
                            opa5.assert.ok(true, "Button Found: " + buttonReferencePallet);
                        },
                        errorMessage: "Button not found: " + buttonReferencePallet
                    });
                },
                iShouldSeePurchaseOrder: function () {
                    return this.waitFor({
                        viewName: sViewNamePallet,
                        success: function () {
                            opa5.assert.ok(true, "The " + sViewNamePallet + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewNamePallet + " view"
                    });
                },

                iShouldSeeItemCount: function (iItemCountPallet) {
                    return this.waitFor({
                        id: sTableId,
                        viewName: sViewNamePallet,
                        matchers: [new AggregationLengthEquals({
                            name: "items",
                            length: iItemCountPallet
                        })],
                        success: function () {
                            opa5.assert.ok(true, "The table has " + iItemCountPallet + " item(s)");
                        },
                        errorMessage: "Table does not have expected number of items '" + iItemCountPallet + "'."
                    });
                },

                iShouldSeeFragment: function (fNamePall, dNamePall) {
                    return this.waitFor({
                        fragmentId: fNamePall,
                        id: names[dNamePall],
                        success: function () {
                            opa5.assert.ok(true, "Dialog opened");
                        },
                        errorMessage: "Dialog could not be opened"
                    });
                },

                iShouldNotSeeControl: function (sControlIdPallet) {
                    return this.waitFor({
                        success: function () {
                            var bExistsPallet = (opa5.getJQuery()("#" + sControlIdPallet).length > 0);
                            opa5.assert.ok(!bExistsPallet, "Control does not exists");
                        }
                    });
                },
                iShouldSeePopUp: function (titlePallet) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: titlePallet
                        }),
                        success: function () {
                            opa5.assert.ok(true, titlePallet + " Popup seen");
                        },
                        errorMessage: titlePallet + " PopUp not seen"
                    });
                },
            }
        }
    });
});
