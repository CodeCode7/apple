/*global QUnit*/

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "./pages/App",
    "./pages/PalletGS1Label"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Label Generate Journey");

    opaTest("Should open the Generate Label Popup and close it", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePGSPage.iTriggerBtnPress("idSearch"); //Click Search
        When.onThePGSPage.iSelectTableRow("Plant", "6401"); //Select table row with plant 6401
        When.onThePGSPage.iEnterInputQuantity(); //Enter Input Quantity
        When.onThePGSPage.iTriggerBtnPress("idGenLabel"); //Click Generate label
        
        Then.onThePGSPage.iShouldSeeFragment("PalletLabelGeneration","labelCreationFragId"); //Fragment check
        When.onThePGSPage.iTriggerBtnPress("glCancel"); //Click Cancel
        Then.onThePGSPage.iShouldNotSeeControl("labelCreationFragId"); //Fragment check

        When.onThePGSPage.iEnterInputQuantity(); //Enter Input Quantity
        When.onThePGSPage.iTriggerBtnPress("idGenLabel"); //Click Generate label again
        When.onThePGSPage.iTriggerBtnPress("glNext"); //Click Next
        Then.onThePGSPage.iShouldSeeBtn("glBack"); //Back Button check
        
        When.onThePGSPage.iTriggerBtnPress("glBack"); //Click Back

        When.onThePGSPage.iTriggerBtnPress("glNext"); //Click Next 
        Then.onThePGSPage.iShouldSeeBtn("glSavePalletPDF"); //Save to PDF button check
        When.onThePGSPage.iTriggerBtnPress("glSavePalletPDF"); //Click Save
        Then.onThePGSPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onThePGSPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button
        Then.onThePGSPage.iShouldNotSeeControl("labelCreationFragId"); //Success Pop up not to be seen
        Then.iTeardownMyApp();
    });
});
