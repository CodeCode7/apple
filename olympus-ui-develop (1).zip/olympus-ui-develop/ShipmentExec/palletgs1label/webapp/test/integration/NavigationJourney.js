/*global QUnit*/

sap.ui.define([
    "sap/ui/test/opaQunit",
    "./pages/App",
    "./pages/PalletGS1Label"
], function (opaTest) {
    "use strict";

    QUnit.module("Navigation Journey");
    function jsonOk(body) {
        var mockResponsePallet = new window.Response(JSON.stringify(body), { //the fetch API returns a resolved window Response object
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });

        return Promise.resolve(mockResponsePallet);
    }

    opaTest("Should see the initial page of the app", function (Given, When, Then) {
        // Arrangements
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk({ "AppID": '123' }));
        Given.iStartMyApp();

        // Assertions
        Then.onTheAppPage.iShouldSeeTheApp();

        //Cleanup
        Then.iTeardownMyApp();
    });
});
