sap.ui.define([
    "sap/ui/core/format/NumberFormat"
], function () {
    "use strict";
    var util = {};
    util.formatDatePallet = function(palleDateValue){
        try {
            var date = palleDateValue.substring(0,4) +"-"+ palleDateValue.substring(4,6)+"-"+ palleDateValue.substring(6,8);
            var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var oDate = new Date(date);
            if(oDate  == "Invalid Date"){
                return palleDateValue;
            }else{
                return months[palleDateValue.substring(4,6) - 1] + " " +palleDateValue.substring(6,8)+ ' , ' +palleDateValue.substring(0,4);
            }
        } catch (oError) {
            return palleDateValue;
        }
    };
    return util;
});
