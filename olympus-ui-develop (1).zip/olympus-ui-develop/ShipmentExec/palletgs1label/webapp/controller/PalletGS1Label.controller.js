sap.ui.define([
    "./BaseController",
    "com/apple/scp/palletgs1label/formatter/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox",
],
    function (BaseController, formatter, JSONModel, Fragment, MessageBox) {
        "use strict";
        return BaseController.extend("com.apple.scp.palletgs1label.controller.PalletGS1Label", {
            formatter: formatter,
            onInit: function () {
                this.oBusyDialog = new sap.m.BusyDialog();
                this.checkAutho();
            },
            checkAutho: function () {
                var oModelPallet = new JSONModel();
                this.getView().setModel(oModelPallet, "AuthModel");
                var oAuthModelRef = this.getView().getModel("AuthModelPalletGS");
                return fetch("/getUserInfo")
                    .then(res => res.json())
                    .then(oToken => {
                        var scopeArr = oToken.decodedJWTToken.scope;
                        if (scopeArr.some(a => a.includes("PALLETGS1_CREATE"))) {
                            oAuthModelRef.setProperty('/createAccess', true);
                        }
                        if (scopeArr.some(a => a.includes("PALLETGS1_UPDATE"))) {
                            oAuthModelRef.setProperty('/editAccess', true);
                        }
                        if (scopeArr.some(a => a.includes("PALLETGS1_DISPLAY"))) {
                            oAuthModelRef.setProperty('/displayAccess', true);
                        }
                    })
                    .catch();
            },
            filterIntialisePalletGs1: function () {
                this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").setDisplayFormat("MMM d, yyyy");
                this.hideExportButton();
            },
            hideExportButton:function(){
                var exportButtonID = this.getView().getId()+ '--gs1SmartTable-btnExcelExport';
                var buttonRef = this.getView().byId(exportButtonID);
                buttonRef.setVisible(false);
            },
            onDownload:function(){
                var exportButtonID = this.getView().getId()+ '--gs1SmartTable-btnExcelExport-internalSplitBtn';
                var buttonRef = this.getView().byId(exportButtonID);
                if (buttonRef) {
                    buttonRef.firePress();
                }
            },
            beforeTableRebindPalletGs1: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                var that = this;
                var filterArray = oBindingParams.filters;
                var filterOutLength = filterArray.length;
                if (filterOutLength > 0) {
                    var filterArrayPath = oBindingParams.filters[0];
                    var filterVal1 = this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getFrom();
                    var filterVal2 = this.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo();
                    if (filterOutLength === 1 && filterArrayPath.sPath === "Creation_Date") {
                        filterArrayPath.oValue1 = that.formatDateAsStringPallet(filterVal1);
                        filterArrayPath.oValue2 = that.formatDateAsStringPallet(filterVal2);
                    } else {
                        that.filterDateFormatting(filterArrayPath);
                    }

                }
            },
            filterDateFormatting: function (filterArrayPath) {
                var that = this;
                var filterManyArray = filterArrayPath.aFilters;
                var filterManyLength = filterManyArray.length;
                for (var i = 0; i < filterManyLength; i++) {
                    if (filterManyArray[i].sPath === "Creation_Date") {
                        filterManyArray[i].oValue1 = that.formatDateAsStringPallet(that.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getFrom());
                        filterManyArray[i].oValue2 = that.formatDateAsStringPallet(that.getView().byId("smartFilterBar").getControlByKey("Creation_Date").getTo());
                        break;
                    }
                }

            },
            formatDateAsStringPallet: function (dateObject) {
                var year = dateObject.getFullYear();
                var month = dateObject.getMonth() + 1;
                var date = dateObject.getDate();
                if (month < 10) {
                    month = "0" + month;
                } else {
                    month = month + "";
                }
                if (date < 10) {
                    date = "0" + date;
                } else {
                    date = date + "";
                }
                return year + month + date;
            },
            onSearchPallet: function () {
                this.getView().byId("gs1SmartTable").rebindTable(true);
            },
            onClearPallet: function () {
                this.getView().byId('smartFilterBar').clear();
            },
            selectionChangePallet: function (oEvent) {
                this.oSelItem = oEvent.getSource().getSelectedItems();
                if (this.oSelItem.length) {
                    var sPath = this.oSelItem[0].getBindingContext().sPath;
                    var model = this.getView().byId("gs1SmartTable").getModel();
                    this.selectedOpenQty = model.getProperty(sPath).Open_Quantity;
                }
            },
            typeNumPalletOnly: function (oEvent) {
                var value = oEvent.getParameter("value");
                var bNotnumber = isNaN(value);
                if (bNotnumber === true) {
                    oEvent.getSource().setValue(value.substring(0, value.length - 1));
                }
                return bNotnumber;
            },
            getInputDataPalletGS1: function (oEvent) {
                this.value = oEvent.getParameter("value");
            },
            labelService: function () {
                var that = this;
                this.oBusyDialog.open();
                var tableRef = this.getView().byId("customTable");
                this.selectedItemsBindingData = tableRef.getSelectedItem().getBindingContext().getObject();
                this.selectedItemsBindingData.Quantity_Input = this.value;
                var oGenerateLabelModel = new JSONModel(this.selectedItemsBindingData);
                this.getView().setModel(oGenerateLabelModel, "GenerateLabelModel");
                var sPath = "/GenerateLabel";
                var oGenModel = new JSONModel();
                that.getView().setModel(oGenModel, "GenModel"); //Setting empty model
                var material = new sap.ui.model.Filter({
                    path: "Material",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selectedItemsBindingData.Material
                });
                var plant = new sap.ui.model.Filter({
                    path: "Plant",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: this.selectedItemsBindingData.Plant
                });
                var oPromiseGenData = new Promise(function (resolve, reject) {
                    that.getOwnerComponent().getModel().read(sPath, {
                        filters: [material, plant],
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
                oPromiseGenData.then(function (oData) {
                    var oGen = new JSONModel(oData);
                    that.getView().setModel(oGen, "GenModel");
                    that.oBusyDialog.close();
                }, function (oErr) {
                    that.oBusyDialog.close();
                });
            },
            validateEnteredQty: function () {
                if (!this.value) {
                    this.value = 0;
                }
                return parseFloat(this.value) <= parseFloat(this.selectedOpenQty);
            },
            openLabelGenPalletFrag: function () {
                if (!this.oSelItem) {
                    MessageBox.information(this.getResourceBundle("noRecSelected"));
                    return;
                } else if (!this.validateEnteredQty()) {
                    MessageBox.information(this.getResourceBundle("openQtyError"));
                    return;
                }
                this.labelService();
                var oView = this.getView();
                var that = this;
                if (!this.byId("labelCreationFragId")) {
                    Fragment.load({
                        id: oView.getId(),
                        name: "com.apple.scp.palletgs1label.fragment.PalletLabelGeneration",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        oDialog.open();
                        that.onDialogPalletAfterOpen();
                    });
                } else {
                    this.byId("labelCreationFragId").open();
                    that.onDialogPalletAfterOpen();
                }

            },
            onDialogPalletAfterOpen: function () {
                var oWizardVisiblity = new JSONModel({
                    'stepVisibility': true
                });
                this.getView().setModel(oWizardVisiblity, "wizardVisibilityModel");
                this.oWizard = this.byId("labelWizard");
                this.handlePalletButtonsVisibility();
            },
            handlePalletButtonsVisibility: function () {
                var oModel = this.getView().getModel("wizardVisibilityModel");
                switch (this.oWizard.getProgress()) {
                    case 1:
                        oModel.setProperty("/stepVisibility", true);
                        break;
                    case 2:
                        oModel.setProperty("/stepVisibility", false);
                        break;
                    default: break;
                }

            },
            closeFragmentLabelGen: function () {
                this.SSCC18_NUMBER = "108888484848848845";
                this.getView().byId("scc18").setValue(this.SSCC18_NUMBER);
                var oGen = new JSONModel();
                this.getView().setModel(oGen, "GenModel"); //Clear old model
                this.oWizard.previousStep();
                this.byId("labelCreationFragId").close();
            },
            onDialogNextButton: function () {
                var oGenModelData = this.getView().getModel("GenModel").getData();
                this.SSCC18_NUMBER = this.getView().byId("scc18").getValue();
                this.quantityInput = this.getView().getModel("GenerateLabelModel").getData().Quantity_Input;
                this.refData = oGenModelData.results[0];
                if (oGenModelData.results.length && this.quantityInput && this.sscc18NumberValidation()) {
                    if (this.oWizard.getProgressStep().getValidated()) {
                        this.oWizard.nextStep();
                    }
                    var oLabelData = {
                        "Uuid": "2344345",
                        "PoNbr": this.selectedItemsBindingData.PO_Number,
                        "PoItemNbr": this.selectedItemsBindingData.Item_Number,
                        "PalletType": "SINGLE",
                        "Mpn": this.refData.Material,
                        "CtryAsmbly": this.refData.COUNTRY_OF_ASSEMBLY,
                        "ModelNbr": this.refData.Model_Number,
                        "Coo": this.refData.COUNTRY_OF_ORIGIN,
                        "Gtin": this.refData.GTIN,
                        "CartonCount": this.quantityInput,
                        "Sscc18Nbr": this.SSCC18_NUMBER
                    };
                    this.handlePalletButtonsVisibility();
                    this.getPDF(oLabelData);

                } else {
                    MessageBox.information(this.errorMessage ? this.errorMessage : this.getResourceBundle("noDataMSG"));
                }
            },
            sscc18NumberValidation: function (oEvent) {
                if (oEvent) {
                    this.SSCC18_NUMBER = oEvent.getSource().getValue();
                }
                var sscc18_NUMBERStartIndex = this.SSCC18_NUMBER.substring(0, 1);
                this.errorMessage = "";
                var isValid = true;
                if (this.SSCC18_NUMBER.length !== 18 || sscc18_NUMBERStartIndex !== '1') {
                    this.errorMessage = this.SSCC18_NUMBER.length !== 18 ? 'Please enter a 18 digit SSCC18 number  ' : 'SSCC18 number should start with 1';
                    this.oBusyDialog.close();
                    MessageBox.information(this.errorMessage);
                    isValid = false;
                }
                if (!oEvent) {
                    //Called manually
                    return isValid;

                }
            },
            getPDF: function (oLabelData) {
                var that = this;
                try {
                    var oPromisePDF = new Promise(function (resolve, reject) {
                        var oModel = that.getOwnerComponent().getModel("onPremDestination");
                        oModel.create('/GENERATE_PALLET_LABELSet', oLabelData, {
                            success: function (data) {
                                resolve(data);
                            }, error: function (error) {
                                reject(error);
                            }
                        });
                    });
                    oPromisePDF
                        .then(function (data) {
                            that.convertBase64ToPDF(data.VALUE);
                        }, function (error) {
                            MessageBox.error(error);
                        });

                } catch (error) {
                    MessageBox.error(error);
                }
            },
            convertBase64ToPDF: function (base64EncodedPDFPallet) {
                var decodedPdfContentPallet = atob(base64EncodedPDFPallet);
                var byteArrayPallet = new Uint8Array(decodedPdfContentPallet.length);
                for (var i = 0; i < decodedPdfContentPallet.length; i++) {
                    byteArrayPallet[i] = decodedPdfContentPallet.charCodeAt(i);
                }
                var blob = new Blob([byteArrayPallet.buffer], { type: 'application/pdf' });
                var pdfurlPallet = URL.createObjectURL(blob);
                var oPDFModelPallet = new JSONModel({
                    data: pdfurlPallet
                });
                jQuery.sap.addUrlWhitelist("blob");
                this.getView().setModel(oPDFModelPallet, "pdfModel");
            },
            savePalletPDFData: function () {
                var that = this;
                this.oBusyDialog.open();
                var palletData = {
                    LABEL_ID: "",
                    PO_ITEM_NUMBER: this.selectedItemsBindingData.Item_Number,
                    PALLET_TYPE: "Single",
                    PO_NUMBER: this.selectedItemsBindingData.PO_Number,
                    PART_NUMBER: "13123",
                    COUNTRY_OF_ASSEMBLY: this.refData.COUNTRY_OF_ASSEMBLY,
                    MODEL_NUMBER: this.refData.Model_Number,
                    COUNTRY_OF_ORIGIN: this.refData.COUNTRY_OF_ORIGIN,
                    GLOBAL_TRADE_IDENTIFICATION_NUMBER: this.refData.GTIN,
                    COUNT_OF_CARTONS: this.quantityInput,
                    SSCC18_NUMBER: this.SSCC18_NUMBER
                };
                var oPromise = new Promise(function (resolve, reject) {
                    that.getOwnerComponent().getModel().create("/OEMGS1Label", palletData, {
                        success: function () {
                            resolve();
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
                oPromise.then(function () {
                    MessageBox.success(that.getResourceBundle("sucessMSG"));
                    that.closeFragmentLabelGen();
                    that.onSearchPallet();
                    that.getView().byId("gs1SmartTable").getModel().resetChanges();
                    that.onClearPallet();
                    that.oBusyDialog.close();
                }, function (oError) {
                    MessageBox.error(oError.responseText);
                    that.oBusyDialog.close();

                });

            },
            onDialogBackButton: function () {
                this.oWizard.previousStep();
                this.handlePalletButtonsVisibility();
            }
        });
    });
