sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log",
    "sap/ui/model/json/JSONModel"
], function (MockServer, Log, JSONModel) {
    "use strict";

    var _sAppPathPallet = "com/apple/scp/palletgs1label/",
        _sJsonFilesPathPallet = _sAppPathPallet + "localService/mockdata",
        _aEntitySetsPallet = {
            "mainService": ["PalletGs1label", "DistinctPo", "GenerateLabel"],
            "onPremDestination": ["GENERATE_PALLET_LABELSet"]
        };

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function (serviceName) {
            var sJsonFilesUrlPallet = sap.ui.require.toUrl(_sJsonFilesPathPallet),
                sManifestUrlPallet = sap.ui.require.toUrl(_sAppPathPallet + "manifest.json"),
                oManifestPallet = jQuery.sap.syncGetJSON(sManifestUrlPallet).data,
                oMainDataSourcePallet = oManifestPallet["sap.app"].dataSources[serviceName],
                sMetadataUrlPallett = sap.ui.require.toUrl(_sAppPathPallet + oMainDataSourcePallet.settings.localUri);

            this.sMockServerUrl = oMainDataSourcePallet.uri;

            // init root URI
            this.oMockServer = new MockServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MockServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockServer.simulate(sMetadataUrlPallett, {
                sMockdataBaseUrl: sJsonFilesUrlPallet,
                aEntitySetsNames: _aEntitySetsPallet[serviceName],
                bGenerateMissingMockData: false
            });

            var mockPDFValue = function(oEvent) {
                var lModel = new JSONModel();
                var sPath = sap.ui.require.toUrl(_sJsonFilesPathPallet + "/GENERATE_PALLET_LABELSet.json")
                lModel.loadData(sPath, "", false);

                oEvent.getParameter("oEntity").VALUE = lModel.getProperty("/VALUE");
            };
            this.oMockServer.attachAfter("POST", mockPDFValue, "GENERATE_PALLET_LABELSet");

            this.oMockServer.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrlPallett + "\n" +
                "   mockdata dir: " + sJsonFilesUrlPallet);

            return this;
        }
    };

});
