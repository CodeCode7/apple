sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/palletgs1label/model/models",
    "sap/base/util/UriParameters",
    "com/apple/scp/palletgs1label/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel"
], function (UIComponent, Device, models, UriParams, MockServerPallet, ODataModel) {
    "use strict";
    return UIComponent.extend("com.apple.scp.palletgs1label.Component", {
        metadata: {
            manifest: "json"
        },
        init: function () {
            UIComponent.prototype.init.apply(this, arguments);
            this.getRouter().initialize();
            this.setModel(models.createDeviceModel(), "device");
            this.isMockPallet = UriParams.fromURL(window.location.href).get("responderOn");
            if (this.isMockPallet) {
                this.oMockserver = MockServerPallet.init("mainService");
                var odataModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                    json: true
                });
                this.setModel(odataModel);
                this.oMockserver = MockServerPallet.init("onPremDestination");
                var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                    json: true
                });
                this.setModel(oModel, "onPremDestination")
            } else {
                this.fetchAppIDPalletGS();
            }
        },
        fetchAppIDPalletGS: function () {
            var that = this;
            fetch("/getAppVariables").then(response => response.json()).then(appId => {
                that.loadMetadataWithAppIdPalletGS(appId);
            });
        },

        loadMetadataWithAppIdPalletGS: function (appID) {
            var oParameters = {
                defaultBindingMode: "TwoWay",
                disableHeadRequestForToken: true,
                headers: {
                    appID: appID
                }
            };

            var sUriPallet = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
            var oModelPallet = new sap.ui.model.odata.v2.ODataModel(sUriPallet, oParameters);
            this.setModel(oModelPallet);
            var onPremiseUriPallet = this.getManifestEntry("/sap.app/dataSources/onPremDestination").uri;
            var onPremModelPallet = new sap.ui.model.odata.v2.ODataModel(onPremiseUriPallet, oParameters);
            this.setModel(onPremModelPallet, "onPremDestination");
        }
    });
});

