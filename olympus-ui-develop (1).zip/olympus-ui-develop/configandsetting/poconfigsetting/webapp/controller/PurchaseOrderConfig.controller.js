sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "../util/massUploadUtilities",
    "../util/xlsx"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, massUploadUtilities) {
        "use strict";
        const poBtnEditToggle = '-btnEditToggle',
              poPropEditSaveTrigger = '/editSaveTrigger',
              poPropDisplayMode = '/DisplayMode';

        return Controller.extend("com.apple.scp.poconfigsetting.controller.PurchaseOrderConfig", {
            onInit: function () {
                var aRouter = this.getOwnerComponent().getRouter();
                aRouter.getRoute("RoutePurchaseOrderConfig").attachMatched(this.onRouteMatched, this);
            },

            onRouteMatched: function () {
                this.setUpViewModel();
                this.initializeSmartControls();
                this.checkAuthorisation();
            },

            onInitialise: function () {
                var configData = this.getView().getModel("localModel").getData().SelectedTabConfig;
                this.hideControl([poBtnEditToggle, '-btnExcelExport'], configData);
            },

            checkAuthorisation: function () {
                var lModel = this.getView().getModel("localModel");

                if (this.getOwnerComponent().isMock) {
                    //Mock Mode
                    lModel.setProperty('/createAccess', true);
                    lModel.setProperty('/editAccess', true);
                    lModel.setProperty('/displayAccess', true);
                    return null;
                } else {
                    //Check for authorization
                    return fetch("/getUserInfo")
                        .then(res => res.json())
                        .then(oToken => {
                            var scopeArray = oToken.decodedJWTToken.scope;
                            if (scopeArray.some(a => a.includes("CONFIGANDSETTIING_CREATE"))) {
                                //Create Authorization
                                lModel.setProperty('/createAccess', true);
                            }

                            if (scopeArray.some(a => a.includes("CONFIGANDSETTIING_UPDATE"))) {
                                //Edit Authorization
                                lModel.setProperty('/editAccess', true);
                            }

                            if (scopeArray.some(a => a.includes("CONFIGANDSETTIING_DISPLAY"))) {
                                //Display Authorization
                                lModel.setProperty('/displayAccess', true);
                            }
                        })
                        .catch();
                }
            },

            hideControl: function (idArr, configData) {
                for (let obj in configData) {
                    if (!configData.hasOwnProperty(obj)) {
                        continue;
                    }
                    for (let id in idArr) {
                        if (!idArr.hasOwnProperty(id)) {
                            continue;
                        }
                        var bID = configData[obj].TableID + idArr[id];
                        var idRef = this.getView().byId(bID);
                        if (idRef) {
                            idRef.setVisible(false);
                        }

                    }

                }
            },

            setUpViewModel: function () {
                var localModel = new JSONModel();
                var sPath = sap.ui.require.toUrl("com/apple/scp/poconfigsetting/util/technicalConfig.json");
                localModel.loadData(sPath, "", false);

                this.getView().setModel(localModel, "localModel");
                this.selectedKey = 'keyPO';
            },

            initializeSmartControls: function () {
                this.setTableAndFilterEntities("keyPO");
            },

            setTableAndFilterEntities: function (key) {
                var configData = this.getView().getModel("localModel").getData().SelectedTabConfig[key];

                //Set Entity set of Smart Filter Bar and Smart Table
                var oFilter = this.getView().byId(configData.FilterID);
                var oTable = this.getView().byId(configData.TableID);
                var entity = configData.ServiceEntitySet;
                oFilter.setEntitySet(entity);
                oTable.setEntitySet(entity);
                oTable.setSmartFilterId(configData.FilterID);
                oTable.setHeader(this.getI18nText(configData.i18nHeaderProperty));
            },

            onMassUpload: function () {
                massUploadUtilities.onMassUpload(this);
            },

            fnCloseUploadDialog: function (oEvent) {
                massUploadUtilities.fnCloseUploadDialog(oEvent);
            },

            getI18nText: function (textID) {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(textID);
            },

            onFileUpload: function () {
                var selectedKey = this.getView().byId("idIconTabBar").getSelectedKey();
                massUploadUtilities.onFileUpload(this, this.getView().getModel("localModel").getData().SelectedTabConfig[selectedKey]);
            },

            onUploadChange: function (oEvent) {
                massUploadUtilities.onUploadChange(oEvent, this);
            },

            dataEditSuccessHandler: function (odata, that, tableModel, errRecords, popupDisplayed) {
                sap.ui.core.BusyIndicator.hide();
                //Check odata response status
                if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                    //Forbidden
                    errRecords = errRecords + 1;
                    //Parse the error message
                    var responseText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value;
                    //Show error message in Error popup
                    sap.m.MessageBox.error(responseText);
                    if (tableModel) {
                        tableModel.resetChanges();
                    }
                } else {
                    //Show success message if all records created successfully
                    if (errRecords < 1 && !popupDisplayed) {
                        //Success Message Toast
                        sap.m.MessageToast.show(that.getI18nText("dataUpdated"));
                        popupDisplayed = true;
                    }
                }

                return {"errorRecords": errRecords, "popUpDisplayed": popupDisplayed};
            },

            dataEditErrorHandler: function (aError, errRecords, tableModel) {
                sap.ui.core.BusyIndicator.hide();
                errRecords = errRecords + 1; //Count the number of records for which error is occuring

                //Parse the error message
                try {
                    var respText = JSON.parse(aError.responseText).error.message.value;
                } catch (exception) {
                    respText = aError.responseText;
                }

                //Show error message in Error popup
                sap.m.MessageBox.error(respText);
                if (tableModel) {
                    tableModel.resetChanges();
                }

                return errRecords;
            },

            dataEdited: function (oEvent) {
                if (!oEvent.getParameter('editable') && this.getView().getModel("localModel").getData().editSaveTrigger) {
                    var errRecords = 0,
                        popUpDisplayed = false,
                        that = this;

                    var tModel = oEvent.getSource().getModel(); //Table Model

                    var mParameters = {
                        //Success event of OData model
                        success: function (odata) {
                            var response = that.dataEditSuccessHandler(odata, that, tModel, errRecords, popUpDisplayed);
                            errRecords = response.errRecords;
                            popUpDisplayed = response.popUpDisplayed;
                        },
                        //Error event of OData model
                        error: function (oError) {
                            errRecords = that.dataEditErrorHandler(oError);
                        }
                    };
                    sap.ui.core.BusyIndicator.show(0);
                    tModel.submitChanges(mParameters);
                }

            },

            onTabChange: function (oEvent) {
                this.selectedKey = oEvent.getParameter('selectedKey');
            },

            onSearch: function () {
                var tabID = this.getView().getModel("localModel").getData().SelectedTabConfig[this.selectedKey].TableID;
                this.getView().byId(tabID).rebindTable(true);
            },

            onClear: function () {
                var filterID = this.getView().getModel("localModel").getData().SelectedTabConfig[this.selectedKey].FilterID;
                this.getView().byId(filterID).clear();
            },

            onEdit: function () {
                var localModel = this.getView().getModel("localModel");
                localModel.setProperty(poPropEditSaveTrigger, false);
                localModel.setProperty(poPropDisplayMode, false);
                var bID = localModel.getData().SelectedTabConfig[this.selectedKey].TableID + poBtnEditToggle;
                this.getView().byId(bID).firePress(); //Change Mode
            },

            onEditSave: function () {
                var localModel = this.getView().getModel("localModel");
                localModel.setProperty(poPropEditSaveTrigger, true);
                localModel.setProperty(poPropDisplayMode, true);
                var bID = localModel.getData().SelectedTabConfig[this.selectedKey].TableID + poBtnEditToggle;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onEditCancel: function (oEvent) {
                var localModel = this.getView().getModel("localModel");
                localModel.setProperty(poPropEditSaveTrigger, false);
                localModel.setProperty(poPropDisplayMode, true);
                oEvent.getSource().getParent().getParent().getModel().resetChanges(); //Resets changed data

                var bID = localModel.getData().SelectedTabConfig[this.selectedKey].TableID + poBtnEditToggle;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onDownload: function () {
                var localModel = this.getView().getModel("localModel");
                var bID = localModel.getData().SelectedTabConfig[this.selectedKey].TableID + '-btnExcelExport-internalSplitBtn';
                var bRef = this.getView().byId(bID);
                if (bRef) {
                    this.getView().byId(bID).firePress(); //Standard Export Data Fire
                }
            }
        });
    });
