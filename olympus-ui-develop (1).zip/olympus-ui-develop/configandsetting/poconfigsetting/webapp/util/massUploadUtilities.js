/* Mass Upload function utilities : Uses SheetJS Library */
/* Contains all the methods needed in lifecycle of Excel Mass upload to OData Service.
   Author : Jyotsna Singam (jsingam) */
sap.ui.define([
    'sap/ui/core/IconPool',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageItem',
    'sap/m/MessageView',
    'sap/m/Button',
    'sap/m/Dialog',
    'sap/m/Title'], function (IconPool, JSONModel, MessageItem, MessageView, Button, Dialog, Title) {
        "use strict";
        var massUploadUtil = {};

        /* Function to open the mass upload fragment and save it reference in the controller instance for future references.
        Called on click of Upload Button from table toolbar
        Parameters: oReference - Controller Reference */
        massUploadUtil.onMassUpload = function (oReference) {
            if (!oReference.oUpload) {
                //Create fragment for Mass Create
                oReference.oUpload = sap.ui.xmlfragment("com.apple.scp.poconfigsetting.fragments.massUpload", oReference);
                oReference.getView().addDependent(oReference.oUpload);
            }
            oReference.oUpload.open();
        };

        /* Functions used to close the dialog instance. Called on click of close button on upload Dialog
        Parameters: oEvent - Triggered Event */
        massUploadUtil.fnCloseUploadDialog = function (oEvent) {
            oEvent.getSource().getParent().close();
            oEvent.getSource().getParent().getContent()[0]._aElements[0].clear(); //Clear file uploader
        };

        /* Helper function to get Friendly error text */
        massUploadUtil.getErrorText = function (oReference, statusCode, oMessage) {
            var message;
            switch (statusCode) {
                case '400':
                    message = oReference.getI18nText("IncorrectFile");
                    break;
                case '401':
                    message = oReference.getI18nText("ReAuthError");
                    break;
                case '403':
                    message = oReference.getI18nText("AuthErr");
                    break;
                case '404':
                    message = oReference.getI18nText("SyntaxErr");
                    break;
                case '409':
                    message = oReference.getI18nText("DuplicateErr");
                    break;
                default:
                    message = oMessage;
            }
            return message;
        };

        massUploadUtil.parseErrorMessage = function (oErr) {
            try {
                var responseText = JSON.parse(oErr.responseText);
                var message = responseText.error.message.value;
            } catch (exception) {
                message = oErr.responseText;
            }

            return message;
        };

        /* Helper Function for error handler */
        massUploadUtil.errorHandler = function (oErr, oReference, errRec) {
            sap.ui.core.BusyIndicator.hide();

            errRec = errRec + 1; //Count the number of error records
            oReference.oUpload.close(); //Close Dialog popup

            var message = massUploadUtil.parseErrorMessage(oErr);

            oReference.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear();

            if (oReference.getView().getModel()) {
                oReference.getView().getModel().resetChanges(); //Reset OData model pending changes
            }

            return { "errRec": errRec, "message": message };
        };

        /* Helper Function Collect Error messages */
        massUploadUtil.prepareErrArr = function (eStatCode, oReference, sMessage, errArray, that) {
            var message = {'type': 'Error', 'title': that.getErrorText(oReference, eStatCode, sMessage)};

            if (eStatCode !== '400') { message.description = sMessage; }

            var existingRec = errArray.find(rec => rec.title === message.title && rec.description === message.description);
            if (existingRec) {
                if (eStatCode !== '400') { existingRec.counter++; }
            } else { //New Error
                if (eStatCode !== '400') { message.counter = 1; }
                errArray.push(message); //Do not push duplicates
            }

            return errArray;
        };

        /* Helper Function */
        massUploadUtil.triggerPostCalls = function (oPayload, tempModel, oParameters, oServiceName) {
            //Make POST calls one by one for each record in the file
            for (var j in oPayload) {
                if (oPayload.hasOwnProperty(j)) {
                    oParameters.properties = oPayload[j];
                    oParameters.changeSetId = "changeset " + j; //Force Unique changeset
                    if (tempModel) {
                        tempModel.createEntry(oServiceName, oParameters);
                    }
                }
            }
        };

        massUploadUtil.fileSuccessHandler = function (odata, response, oReference, tempModel, errRec, popUpDisplayed) {
            console.log(response);
            sap.ui.core.BusyIndicator.hide();
            oReference.oUpload.close(); //Close dialog popup

            if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                //Forbidden - Auth Error from API
                errRec = errRec + 1;
                var responseText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value; //Parse the error message
                sap.m.MessageBox.error(responseText); //Show error message in Error popup

                if (tempModel) {
                    tempModel.resetChanges();
                }
            } else {
                //Show success message if all records created successfully
                if (errRec < 1 && !popUpDisplayed) {
                    sap.m.MessageToast.show(oReference.getI18nText("objectsCreated")); //Success Message Toast
                    popUpDisplayed = true;
                }
            }
            oReference.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear(); //Clear file uploader file

            return { "errRec": errRec, "popUpDisplayed": popUpDisplayed };
        };

        /* Function for Upload Data click. Reads, parses and calls function to build Payload and triggers batch POST call on the
           service entity passed in configurationData.ServiceEntitySet
           Parameters:
            oReference - Calling controller Reference
            configurationData - JSON Model holding
            {"ServiceEntitySet": "<Entity Name>",
                "DataFields": { "<DateFieldName1>" : true,
                                "<DateFieldName2>" : true" ... } } */
        massUploadUtil.onFileUpload = function (oReference, configurationData) {
            //Mass Create
            var errRec = 0,
                popUpDisplayed = false,
                excelData = {},
                that = this,
                errArray = [];

            var oServiceName = configurationData.ServiceEntitySet;

            //Return if no file is available to upload
            if (oReference.selFile === undefined) {
                sap.m.MessageBox.error(oReference.getI18nText("fileNotFound"));
            }

            //Get XLSX Instance
            if (XLS) {
                var exInstance = XLS;
            } else if (XLSX) {
                exInstance = XLSX;
            }

            //Check if file exists
            if (oReference.selFile && window.FileReader) {
                var reader = new FileReader();
                reader.onload = function (rawData) {
                    var data = rawData.target.result;
                    //Read data from excel file
                    var workbook = exInstance.read(data, {
                        type: 'binary'
                    });
                    workbook.SheetNames.forEach(function (sheetName) {
                        // Here is your object for every sheet in workbook
                        excelData = exInstance.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                    });

                    //Return if file contains no data
                    if (excelData.length < 1) {
                        sap.m.MessageBox.error(oReference.getI18nText("fileContainsNoRecord"));
                        return;
                    }
                    //Prepare payload for upload
                    var oPayload = that.prepareMassPayload(excelData, configurationData);

                    //Get default OData model
                    var tempModel = oReference.getView().getModel();
                    tempModel.setUseBatch(true);

                    var oParameters = {
                        //Success event of OData model
                        success: function (odata, response) {
                            var returnData = massUploadUtil.fileSuccessHandler(odata, response, oReference, tempModel, errRec, popUpDisplayed);
                            errRec = returnData.errRec;
                            popUpDisplayed = returnData.errRec;
                        },
                        //Error event of OData model
                        error: function (oErr) {
                            var returnRecord = massUploadUtil.errorHandler(oErr, oReference, errRec);
                            errRec = returnRecord.errRec;
                            errArray = massUploadUtil.prepareErrArr(oErr.statusCode, oReference, returnRecord.message, errArray, that);
                        }
                    };

                    //Make POST calls one by one for each record in the file
                    massUploadUtil.triggerPostCalls(oPayload, tempModel, oParameters, oServiceName);

                    sap.ui.core.BusyIndicator.show(0);
                    //Submit OData model pending changes
                    var oPromise = new Promise(function (resolve, reject) {
                        tempModel.submitChanges({
                            success: function () {
                                resolve();
                            },
                            error: function (oErr) {
                                reject(oErr);
                            }
                        });
                    });
                    oPromise
                        .then(function () {
                            //Do nothing - No log to be shown
                        }, function (oErr) {
                            var message = massUploadUtil.parseErrorMessage(oErr); //Parse Error Message
                            errArray = massUploadUtil.prepareErrArr(oErr.statusCode, oReference, message, errArray, this); //Collect Error messages
                        })
                        .finally(() => {
                            if (errArray.length > 0) {
                                //Show consolidated Error log at the end of submitChanges processing, if any
                                that.showErrorLog(oReference, errArray);
                            }
                        });
                };
                reader.onerror = function (exception) {
                    sap.m.MessageBox.error(oReference.getI18nText("ReadError"));
                    console.log(exception); //For troubleshooting
                };
                reader.readAsBinaryString(oReference.selFile);
            }
        };

        /* Helper function to show Message View for Errors, if any */
        massUploadUtil.showErrorLog = function (oReference, errArray) {
            var that = this;
            var oMsgTemplate = new MessageItem({
                type: '{type}',
                title: '{title}',
                description: '{description}',
                counter: '{counter}'
            });

            var oModel = new JSONModel();
            oModel.setData(errArray);

            var oBackBtn = new Button({
                icon: IconPool.getIconURI("nav-back"),
                visible: false,
                press: function () {
                    that.oMsgView.navigateBack();
                    this.setVisible(false);
                }
            });

            this.oMsgView = new MessageView({
                showDetailsPageHeader: false,
                itemSelect: function () {
                    oBackBtn.setVisible(true);
                },
                items: {
                    path: "/",
                    template: oMsgTemplate
                }
            });

            this.oMsgView.setModel(oModel);

            this.eDialog = new Dialog({
                resizable: true,
                content: this.oMsgView,
                state: 'Error',
                beginButton: new Button({
                    press: function () {
                        this.getParent().close();
                    },
                    text: oReference.getI18nText("close")
                }),
                customHeader: new sap.m.Bar({
                    contentLeft: [oBackBtn],
                    contentMiddle: [
                        new Title({ text: oReference.getI18nText("ErrorLog") })
                    ]
                }),
                contentHeight: "50%",
                contentWidth: "50%",
                verticalScrolling: false
            });

            this.oMsgView.navigateBack();
            this.eDialog.open();
        };

        /* Function used internally to prepare payload from excel data
        Parameters: excelData - Excel Data
                    configurationData - configurationData - JSON Model holding
                    {"ServiceEntitySet": "<Entity Name>",
                     "DataFields": { "<DateFieldName1>" : true,
                                     "<DateFieldName2>" : true" ... } }*/
        massUploadUtil.prepareMassPayload = function (excelData, configurationData) {
            var rowObject = {},
                oPayload = [];

            //Prepare payload for Mass Create Upload - Loop over each rows' cell
            for (let a = 0; a < excelData.length; a++) { //Loops over rows
                rowObject = {};
                for (let cell in excelData[a]) { //Reads each column within the row
                    if (!excelData[a].hasOwnProperty(cell)) {
                        continue;
                    }
                    if (configurationData.DateFields && configurationData.DateFields[cell]) {
                        //Value to be collected as Date instead of string
                        rowObject[cell] = new Date(excelData[a][cell]);
                    }
                    else if (configurationData.BooleanFields && configurationData.BooleanFields[cell]) {
                        //Value to be collected as Boolean instead of string
                        rowObject[cell] = this.stringToBoolean(excelData[a][cell]);
                    }
                    else {
                        rowObject[cell] = (excelData[a][cell]).toString();
                    }

                }
                oPayload.push(rowObject);
            }
            return oPayload;
        };

        /* Helper function to convert string to boolean */
        massUploadUtil.stringToBoolean = function (string) {
            switch (string.toLowerCase().trim()) {
                case "true": case "yes": case "1": return true;
                case "false": case "no": case "0": return false;
                default: return Boolean(string);
            }
        };

        /* 'change' Event handler function when FileUploader
            Parameters: oEvent - Triggered Event
                        oReference - Calling controller Reference */
        massUploadUtil.onUploadChange = function (oEvent, oReference) {
            //Update selected file for future reference
            oReference.selFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        };

        return massUploadUtil;
    });
