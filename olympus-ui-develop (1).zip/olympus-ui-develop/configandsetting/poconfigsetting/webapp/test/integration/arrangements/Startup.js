sap.ui.define([
    "sap/ui/test/Opa5"
], function (Opa5) {
    "use strict";

    return Opa5.extend("com.apple.scp.poconfigsetting.test.integration.arrangements.Startup", {

        iStartMyApp: function (oOptionsParam) {
            var oOptns = oOptionsParam || {};

            // start the app with a minimal delay to make tests fast but still async to discover basic timing issues
            oOptns.delay = oOptns.delay || 50;

            // start the app UI component
            this.iStartMyUIComponent({
                componentConfig: {
                    name: "com.apple.scp.poconfigsetting",
                    async: true
                },
                hash: oOptns.hash,
                autoWait: oOptns.autoWait
            });
        },

        iTeardownTheApp: function () {
            this.iTeardownMyUIComponent();
        }
    });
});
