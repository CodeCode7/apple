/* global QUnit */

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/poconfigsetting/test/integration/pages/PurchaseOrderConfig",
    "com/apple/scp/poconfigsetting/test/integration/arrangements/Startup"
], function (opaQunit, Opa5) {
    "use strict";

    QUnit.module("Edit Journey");

    opaQunit("Edit Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePOPage.iTriggerBtnPress("searchBtn"); //Search
        When.onThePOPage.iTriggerBtnPress("editBtn"); //Edit
        Then.onThePOPage.iShouldSeeBtn("saveBtn"); //Save
        When.onThePOPage.iTriggerBtnPress("cancelBtn"); //Cancel
        Then.onThePOPage.iShouldSeeBtn("editBtn"); //Edit
        When.onThePOPage.iTriggerBtnPress("editBtn"); //Edit
        When.onThePOPage.iTriggerBtnPress("saveBtn"); //Save
        Then.onThePOPage.iShouldSeeBtn("editBtn"); //Edit

        Then.iTeardownMyApp();
    });

    QUnit.module("Upload Journey");

    opaQunit("Upload Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePOPage.iTriggerBtnPress("uploadBtn"); //Upload
        Then.onThePOPage.iShouldSeeUploadFragment();

        When.onThePOPage.iSearchDialogAndClickButton("dialogClose");
        When.onThePOPage.iTriggerBtnPress("uploadBtn"); //Upload
        When.onThePOPage.iSearchDialogAndClickButton("dialogUpload"); //Dialog Upload
        Then.onThePOPage.iShouldSeeErrorPopUp();

        Then.iTeardownMyApp();
    });
});
