sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (opa5, Press, Properties) {
    "use strict";
    var oViewName = "PurchaseOrderConfig";
    var buttonNames = {
        "searchBtn": "container-poconfigsetting---PurchaseOrderConfig--poFragment--idSearch",
        "editBtn": "container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnEdit",
        "saveBtn": "container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnSave",
        "cancelBtn": "container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnCancel",
        "uploadBtn" : "container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnUpload",
        "dialogUpload": "Upload",
        "dialogClose": "closeUpload"
    };

    opa5.createPageObjects({
        onThePOPage: {

            actions: {
                iTriggerBtnPress: function (bRef) {
                    var bId = buttonNames[bRef];
                    this.waitFor({
                        viewName: oViewName,
                        id: bId,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + bRef
                    });
                },

                iSearchDialogAndClickButton: function(bRef){
                    var bId  = buttonNames[bRef];
                    this.waitFor({
                        searchOpenDialogs: true,
                        id: bId,
                        viewName: oViewName,
                        actions: new Press(),
                        errorMessage : "Button Not found: " + bRef
                    });
                }
            },

            assertions: {
                iShouldSeeBtn: function (bRef) {
                    var bId = buttonNames[bRef];
                    return this.waitFor({
                        id: bId,
                        success: function () {
                            opa5.assert.ok(true, "Button Found: " + bRef);
                        },
                        errorMessage: "Button not found: " + bRef
                    });
                },

                iShouldSeeUploadFragment: function(){
                    return this.waitFor({
                        fragmentId: "massUpload",
                        id: "idUploadDialog",
                        success: function(){
                            opa5.assert.ok(true, "Upload Dialog opened");
                        },
                        errorMessage: "Upload Dialog could not be opened"
                    });
                },

                iShouldSeeErrorPopUp : function(){
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: "Error"
                        }),
                        success: function(){
                            opa5.assert.ok(true, "Error Popup seen");
                        },
                        errorMessage: "Error PopUp not seen"
                    });
                },

                iShouldSeeTheApp: function () {
                    return this.waitFor({
                        viewName: oViewName,
                        success: function () {
                            opa5.assert.ok(true, "The " + oViewName + " view is displayed");
                        },
                        errorMessage: "Did not find the " + oViewName + " view"
                    });
                }
            }
        }
    });

});
