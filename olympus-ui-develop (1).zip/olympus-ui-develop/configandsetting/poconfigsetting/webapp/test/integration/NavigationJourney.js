/*global QUnit*/

sap.ui.define([
    "sap/ui/test/opaQunit",
    "./pages/PurchaseOrderConfig"
], function (opaTest) {
    "use strict";

    QUnit.module("Navigation Journey");
    function jsonOK(body) {
        var mockResp = new window.Response(JSON.stringify(body), { //the fetch API returns a resolved window Response object
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });

        return Promise.resolve(mockResp);
    }
    opaTest("Should see the initial page of the app", function (Given, When, Then) {
        // Arrangements
        let wStub = sinon.stub(window, 'fetch'); //add stub
        wStub.onCall(0).returns(jsonOK({ "AppID": '123' }));
        Given.iStartMyApp();

        // Assertions
        Then.onThePOPage.iShouldSeeTheApp();

        //Cleanup
        Then.iTeardownMyApp();
    });
});
