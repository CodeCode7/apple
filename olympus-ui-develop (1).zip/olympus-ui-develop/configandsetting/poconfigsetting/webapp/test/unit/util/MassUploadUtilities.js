/*global QUnit*/

sap.ui.define([
    "com/apple/scp/poconfigsetting/controller/PurchaseOrderConfig.controller",
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "com/apple/scp/poconfigsetting/util/massUploadUtilities",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/unified/FileUploader"
], function (Controller, oController, UIComponent, massUploadUtilities, ResourceModel, JSONModel, FileUploader) {
    "use strict";
    const Core = new sap.ui.core.Core(),
        View = sap.ui.core.mvc.View,
        Dialog = sap.m.Dialog;
    const
        modulePath = "com/apple/scp/poconfigsetting",
        i18nPath = "/i18n/i18n.properties",
        saErr = "Sample Error";

    QUnit.module("Mass Upload Utilities", {
        beforeEach: function () {
            this.oPOController = new Controller();
        },
        afterEach: function () {
            this.oPOController.destroy();
        }
    });

    QUnit.test("getErrorText Helper function Test", function (assert) {
        let err = " Error Text to be returned";
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '400'), "Incorrect input file/data, please recheck the file and then re-upload", "400" + err);
        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '401'), "Unauthorized request. Please re-authenticate and try again.", "401" + err);
        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '403'), "You are not authorised to perform requested action", "403" + err);
        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '404'), "Syntax Error in service. Reload and check, if issue persists contact admin", "404" + err);
        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '409'), "Duplicate Insert: Record already exists", "409" + err);
        assert.strictEqual(massUploadUtilities.getErrorText(this.oPOController, '4', saErr), saErr, "Message to be passed back as is");

        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
        this._oResourceModel.destroy();
    });

    QUnit.test("strToBoolean function test", function (assert) {
        let trueVal = "Boolean true to be returned",
            falseVal = "Boolean false to be returned";

        //Assert
        var isoFunction = massUploadUtilities.stringToBoolean;
        assert.strictEqual(isoFunction("true"), true, trueVal);
        assert.strictEqual(isoFunction("yes"), true, trueVal);
        assert.strictEqual(isoFunction("1"), true, trueVal);
        assert.strictEqual(isoFunction("false"), false, falseVal);
        assert.strictEqual(isoFunction("no"), false, falseVal);
        assert.strictEqual(isoFunction("0"), false, falseVal);
        assert.strictEqual(isoFunction("00"), true, trueVal);
    });

    QUnit.test("prepareMassPayload function test", function (assert) {
        var localData = [{
            "City": "Austin",
            "Fax": "1-212-9876543",
            "Mark_For_Deletion": "No",
            "Name1": "APPLE INC.",
            "Name2": "Apple Inc",
            "Postal_Code": "78754-5205",
            "Region": "TX",
            "Street_House_NO": "1 Infinite Loop",
            "Supplier": "P0061",
            "Telephone": "+1 213 555 3912"
        }, {
            "City": "Austin",
            "Fax": "1-212-9876543",
            "Mark_For_Deletion": "No",
            "Name1": "APPLE INC.",
            "Name2": "Apple Inc",
            "Postal_Code": "78754-5205",
            "Region": "TX",
            "Street_House_NO": "7400 49th Ave . N",
            "Supplier": "00312101P",
            "Telephone": "+1 213 555 3912"
        }
        ];

        var localModel = new JSONModel();
        var oPath = sap.ui.require.toUrl("com/apple/scp/poconfigsetting/util" + "/technicalConfig.json");
        localModel.loadData(oPath, "", false);

        var outputData = massUploadUtilities.prepareMassPayload(localData, localModel.getData().SelectedTabConfig.keyPO);
        assert.strictEqual(outputData.length, 2, "Payload with 2 records to be created");
    });

    QUnit.test("showErrorLog function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var errMsgs = [{ "type": "Error", "title": "Sample Title", "description": "Long Error" }];
        massUploadUtilities.showErrorLog(this.oPOController, errMsgs);
        assert.ok(massUploadUtilities.eDialog);

        massUploadUtilities.eDialog.destroy();
        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("prepareErrArr function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var errArr = massUploadUtilities.prepareErrArr('400', this.oPOController, 'Sample Error', [], massUploadUtilities);
        errArr = massUploadUtilities.prepareErrArr('401', this.oPOController, 'Sample Error 2', errArr, massUploadUtilities);
        errArr = massUploadUtilities.prepareErrArr('401', this.oPOController, 'Sample Error 2', errArr, massUploadUtilities);

        assert.ok(errArr);

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
    });

    QUnit.test("errorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": saErr } } }'
        };

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var oView = new View({});
        var modelStub = sinon.stub(oView, 'getModel').returns(false); //add stub
        this.oPOController.oUpload = new Dialog("dDialog");
        var oGetViewStub = sinon.stub(oController.prototype, "getView").returns(oView);
        var returnRec = massUploadUtilities.errorHandler(oError, this.oPOController, 0);

        assert.ok(returnRec);

        coreStub.restore();
        oGetViewStub.restore();
        oView.destroy();
        dUploader.destroy();
        modelStub.restore();
        this.oPOController.oUpload.destroy();
    });

    QUnit.test("parseErrorMessage function test", function (assert) {
        var oError = {
            "responseText": saErr
        };
        var msg = massUploadUtilities.parseErrorMessage(oError);
        assert.strictEqual(msg, saErr, "Error Message for 401 to be parsed correctly");

        oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Error" } } }'
        };

        msg = massUploadUtilities.parseErrorMessage(oError);
        assert.strictEqual(msg, "Error", "Error for non 401 to be parsed correctly");
    });

    QUnit.test("triggerPostCalls function test", function (assert) {
        var aPayload = [{ "F1": "V1" }, { "F1": "V2" }];
        massUploadUtilities.triggerPostCalls(aPayload, undefined, {}, undefined);

        assert.ok(true);
    });

    QUnit.test("fileSuccessHandler function test", function (assert) {
        this.oPOController.oUpload = new Dialog("dDialog1");

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var oView = new View({});
        var oGetViewStub = sinon.stub(oController.prototype, "getView").returns(oView);

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var sResponse = {};
        var resp = massUploadUtilities.fileSuccessHandler(sResponse, {}, this.oPOController, undefined, 0, false);
        assert.strictEqual(resp.popUpDisplayed, true, "All Success: Success popup to be displayed");

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
        oView.destroy();
        oGetViewStub.restore();
        dUploader.destroy();
        coreStub.restore();
        this.oPOController.oUpload.destroy();
    });
});
