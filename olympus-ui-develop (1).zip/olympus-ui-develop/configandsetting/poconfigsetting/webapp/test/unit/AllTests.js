sap.ui.define([
    "./controller/App.controller",
    "./controller/PurchaseOrderConfig.controller",
    "./model/models",
    "./util/MassUploadUtilities"
], function () {
    "use strict";
});
