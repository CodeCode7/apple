
sap.ui.define([
    "com/apple/scp/poconfigsetting/controller/App.controller"
], function (Controller) {
    "use strict";
    QUnit.module("App Controller");
    QUnit.test("App controller Load", function (assert) {
        var aController = new Controller();
        aController.onInit();
        assert.ok(aController);
    });

});
