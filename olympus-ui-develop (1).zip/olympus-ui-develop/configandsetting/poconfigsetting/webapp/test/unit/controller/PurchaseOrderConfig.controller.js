/*global QUnit*/

sap.ui.define([
    "com/apple/scp/poconfigsetting/controller/PurchaseOrderConfig.controller",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel"
], function (Controller, UIComponent, aController, sFB, sTable, ManagedObject, JSONModel) {
    "use strict";
    const Button = sap.m.Button,
          ResourceModel = sap.ui.model.resource.ResourceModel,
          Event = sap.ui.base.Event,
          InstanceManager = sap.m.InstanceManager;
    const
        i18nPath = "com/apple/scp/poconfigsetting/i18n/i18n.properties";

    QUnit.module("PurchaseOrderConfig Controller", {
        beforeEach: function () {
            this.oPOController = new Controller();
        },
        afterEach: function () {
            this.oPOController.destroy();
        }
    });

    function jsonOk(bContent) {
        var mResponse = new window.Response(JSON.stringify(bContent), {
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });

        return Promise.resolve(mResponse);
    }

    function setUpViewAndLocalModel(oRef) {
        var aViewStub = new ManagedObject({});
        var localModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/poconfigsetting/util/technicalConfig.json");

        localModel.loadData(sPath, "", false);
        aViewStub.setModel(localModel, "localModel");
        oRef.selectedKey = 'keyPO';
        return aViewStub;
    }

    QUnit.test("PurchaseOrderConfig controller", function (assert) {
        // Arrange
        var alocalRouter = new sap.m.routing.Router([
            {
                "name": "RoutePurchaseOrderConfig",
                "pattern": "",
                "target": [
                    "TargetPurchaseOrderConfig"
                ]
            }
        ]);

        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getRouter").returns(alocalRouter);
        this.oPOController.onInit();
        assert.ok(this.oPOController);

        oCompStub.restore();
        oControllerStub.restore();
        oComp.destroy();
        alocalRouter.destroy();
    });

    QUnit.test("Smart Table search test", function (assert) {

        //Arrange
        var oSTable = new sTable("idsmartTable");
        var aViewStub = new ManagedObject({});

        var localModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/poconfigsetting/util/technicalConfig.json");
        localModel.loadData(sPath, "", false);

        aViewStub.setModel(localModel, "localModel");
        this.oPOController.selectedKey = 'keyPO';

        var oSTableSpy = this.stub(sap.ui.comp.smarttable.SmartTable.prototype, "rebindTable");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(aViewStub);
        var oSTableStub = sinon.stub(ManagedObject.prototype, "byId").returns(oSTable);

        //Act
        this.oPOController.onSearch();

        //Assert
        assert.strictEqual(oSTableSpy.callCount, 1, "Smart Table rebindTable event to be triggered");

        //CleanUp
        oSTableSpy.restore();
        oSTableStub.restore();
        oGetViewStub.restore();
        aViewStub.destroy();
        oSTable.destroy();
    });

    QUnit.test("Smart Filter Bar clear test", function (assert) {
        //Arrange
        var oSFB = new sFB("idsmartFilterBar");
        var aViewStub = setUpViewAndLocalModel(this.oPOController);

        var oSFBSpy = this.stub(sap.ui.comp.smartfilterbar.SmartFilterBar.prototype, "clear");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(aViewStub);
        var oSFBStub = sinon.stub(ManagedObject.prototype, "byId").returns(oSFB);

        //Act
        this.oPOController.onClear();

        //Assert
        assert.strictEqual(oSFBSpy.callCount, 1, "Smart Filter Bar clear to be triggered");

        //CleanUp
        oSFBSpy.restore();
        oSFBStub.restore();
        oGetViewStub.restore();
        oSFB.destroy();
        aViewStub.destroy();
    });

    QUnit.test("Table Edit Functionality test", function (assert) {
        //Arrange
        var aViewStub = setUpViewAndLocalModel(this.oPOController);
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(aViewStub);

        var btn = new Button();
        var viewByIdStub = sinon.stub(ManagedObject.prototype, "byId").returns(btn);

        this.oPOController.selectedKey = 'keyPO';

        //Act & Assert
        this.oPOController.onEdit();
        var localModel = aViewStub.getModel("localModel");
        var mode = localModel.getProperty("/DisplayMode");
        assert.strictEqual(mode, false, "Edit Mode Set");


        this.oPOController.onEditSave();
        assert.strictEqual(localModel.getProperty("/DisplayMode"), true, "Display Mode Set");

        //Cleanup
        oGetViewStub.restore();
        viewByIdStub.restore();
        btn.destroy();
        aViewStub.destroy();
    });

    QUnit.test("getI18nText function test", function (assert) {
        //Arrange
        var oComp = new UIComponent();
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oResourceModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl(i18nPath) });
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResourceModel);

        //Action
        var aText = this.oPOController.getI18nText("appTitle");

        //Assert
        assert.strictEqual(aText, "Purchase Order", "Text for appTitle to be returned");

        //CleanUp
        oComp.destroy();
        oControllerStub.restore();
        oResourceModel.destroy();
        oCompStub.restore();
    });

    QUnit.test("View Initialisation", function (assert) {
        //Arrange
        var aViewStub = new ManagedObject({});
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(aViewStub);

        var oSFB = new sFB("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartFilterBar");
        var oSTable = new sTable("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable");

        var byIdStub = this.stub(ManagedObject.prototype, "byId");
        byIdStub.withArgs("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartFilterBar").returns(oSFB);
        byIdStub.withArgs("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable").returns(oSTable);

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(i18nPath)
        });

        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        //System under test & Assert
        this.oPOController.onRouteMatched();
        assert.strictEqual(this.oPOController.selectedKey, "keyPO", "SourceList to be set as default tab");
        assert.strictEqual(oSTable.getHeader(), "Ship-To & Ship-From Data", "Smart Table Header to be initialised correctly");

        //Cleanup
        oGetViewStub.restore();
        byIdStub.restore();
        aViewStub.destroy();
        oSFB.destroy();
        oSTable.destroy();
        oControllerStub.restore();
        this._oResourceModel.destroy();
        oCompStub.restore();
        oComp.destroy();
    });

    QUnit.test("checkAuthorisation function test", function (assert) {
        //Arrange
        var fnDone = assert.async();
        var aViewStub = setUpViewAndLocalModel(this.oPOController);
        var oGetViewStub = sinon.stub(this.oPOController, "getView").returns(aViewStub);
        var oComp = new UIComponent;
        oComp.isMock = false;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);

        var localJWT = {
            "decodedJWTToken":
                {
                    "scope": [
                            "configandsetting!t9525.CONFIGANDSETTIING_DISPLAY",
                            "configandsetting!t9525.CONFIGANDSETTIING_CREATE",
                            "configandsetting!t9525.CONFIGANDSETTIING_UPDATE"
                        ]
                }
            };
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk(localJWT));

        var localModel = aViewStub.getModel("localModel");
        this.oPOController.checkAuthorisation().then(function () {
            //Assert
            assert.strictEqual(localModel.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(localModel.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(localModel.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDone();

            //Cleanup
            oComp.destroy();
            oControllerStub.restore();
            oGetViewStub.restore();
            aViewStub.destroy();
        });
    });

    QUnit.test("onMassUpload function test", function (assert) {
        var aViewStub = new ManagedObject({});
        var oGetViewStub = sinon.stub(this.oPOController, "getView").returns(aViewStub);
        this.oPOController.onMassUpload();
        assert.ok(this.oPOController.oUpload);
        aViewStub.destroy();
        oGetViewStub.restore();
    });

    QUnit.test("onDownload function test", function (assert) {
        var aViewStub = setUpViewAndLocalModel(this.oPOController);
        var oGetViewStub = sinon.stub(this.oPOController, "getView").returns(aViewStub);

        var oBtn = new Button();
        var oBtnStub = sinon.stub(ManagedObject.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oPOController.onDownload();

        assert.strictEqual(oBtnSpy.callCount, 1, "Download function to be triggered");

        aViewStub.destroy();
        oGetViewStub.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });

    QUnit.test("onInitialise function test", function (assert) {
        //Arrange
        var aViewStub = setUpViewAndLocalModel(this.oPOController);
        var oGetViewStub = sinon.stub(this.oPOController, "getView").returns(aViewStub);
        var oBtnToggle = new Button("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnEditToggle");
        var oBtnExport = new Button("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnExcelExport");

        var oByIDStub = sinon.stub(ManagedObject.prototype, "byId");
        oByIDStub.withArgs("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnEditToggle").returns(oBtnToggle);
        oByIDStub.withArgs("container-poconfigsetting---PurchaseOrderConfig--poFragment--idsmartTable-btnExcelExport").returns(oBtnExport);

        //System Under test
        this.oPOController.onInitialise();

        //Assert
        assert.strictEqual(oBtnToggle.getVisible(), false, "Standard Toolbar Toggle button visibility to be set to false");
        assert.strictEqual(oBtnExport.getVisible(), false, "Standard Toolbar Export button visibility to be set to false");

        //Clean Up
        aViewStub.destroy();
        oGetViewStub.restore();
        oBtnToggle.destroy();
        oBtnExport.destroy();
        oByIDStub.restore();
    });

    QUnit.test("onTabChange function test", function (assert) {
        var dEvent = new Event('oEvent', {}, { 'selectedKey': "keyME" });
        this.oPOController.onTabChange(dEvent);
        assert.strictEqual(this.oPOController.selectedKey, "keyME", "selectedKey Property to be updated to Material Extension");
    });

    QUnit.test("onUploadChange function test", function (assert) {
        var obj = { "name": "test.xlsx" };
        var dEvent = new Event("oEvent", {}, { "files": [obj] });
        this.oPOController.onUploadChange(dEvent);
        assert.strictEqual(this.oPOController.selFile, obj, "File selected to be captured");
    });

    QUnit.test("dataEditSuccessHandler function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPOController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var res = this.oPOController.dataEditSuccessHandler({}, this.oPOController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, true, "Success popup to be displayed");

        var sResponse = { "__batchResponses": [{ "response": { "statusCode": '403', "body": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Sample Error" } } }' } }] };
        res = this.oPOController.dataEditSuccessHandler(sResponse, this.oPOController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, false, "Success popup not to be displayed");

        InstanceManager.closeAllDialogs();
        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("dataEditErrorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Sample Error" } } }'
        };

        var errRec = this.oPOController.dataEditErrorHandler(oError, 0);
        assert.strictEqual(errRec, 1, "Error Record count to be incremented by 1");

        oError = {
            "responseText": "Sample Error"
        };

        errRec = this.oPOController.dataEditErrorHandler(oError, 0);
        assert.ok(errRec);
        InstanceManager.closeAllDialogs();

    });
});
