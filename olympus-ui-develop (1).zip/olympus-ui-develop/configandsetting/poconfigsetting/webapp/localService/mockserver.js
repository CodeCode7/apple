sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log"
], function (mockserver, Log) {
    "use strict";

    var _sApplicationPath = "com/apple/scp/poconfigsetting/",
        _aJsonFilesPath = _sApplicationPath + "localService/mockdata",
        _eEntitySets = ["shiptofromaddress", "DisplaySupplierShipTOFromAddr"];

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function () {
            var sJsonFilesURL = sap.ui.require.toUrl(_aJsonFilesPath),
                sManifestURL = sap.ui.require.toUrl(_sApplicationPath + "manifest.json"),
                aManifest = jQuery.sap.syncGetJSON(sManifestURL).data,
                oMainDataSrc = aManifest["sap.app"].dataSources.mainService,
                sMetadataURL = sap.ui.require.toUrl(_sApplicationPath + oMainDataSrc.settings.localUri);

            this.sMockServerUrl = oMainDataSrc.uri;

            // init root URI
            this.oMockserver = new mockserver({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            mockserver.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.oMockserver.simulate(sMetadataURL, {
                sMockdataBaseUrl: sJsonFilesURL,
                aEntitySetsNames: _eEntitySets,
                bGenerateMissingMockData: false
            });

            this.oMockserver.start();

            Log.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataURL + "\n" +
                "   mockdata dir: " + sJsonFilesURL);

            return this;
        }
    };

});
