module.exports = function (config) {
    config.set({
        frameworks: ["ui5"],
        browserNoActivityTimeout: 900000,
        pingTimeout: 900000,
        browsers: ["ChromeHeadless"],
        ui5: {
            configPath: "ui5-test.yaml"
        },

        reporters: ['progress', 'coverage'],
        preprocessors: {
            'webapp/!(test)/!(xlsx).js': ['coverage'],
            'webapp/Component.js': ['coverage']
        },
        coverageReporter: { type: 'lcov', dir: 'coverage', subdir: 'reports' }
    });

    require("karma-ui5/helper").configureIframeCoverage(config);
};
