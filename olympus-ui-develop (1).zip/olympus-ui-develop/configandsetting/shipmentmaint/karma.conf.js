module.exports = function (config) {
    config.set({
        frameworks: ["ui5"],
        async: true,

        ui5: {
            configPath: "ui5-test.yaml"
        },

        reporters: ['progress', 'coverage'],
        browsers: ["ChromeHeadless"],
        preprocessors: {
            'webapp/!(test)/!(xlsx).js': ['coverage'],
            'webapp/Component.js': ['coverage']
        },

        coverageReporter: { type: 'lcov', dir: 'coverage', subdir: 'reports' },

        pingTimeout: 900000,
        browserNoActivityTimeout: 900000

    });

    require("karma-ui5/helper").configureIframeCoverage(config);
};
