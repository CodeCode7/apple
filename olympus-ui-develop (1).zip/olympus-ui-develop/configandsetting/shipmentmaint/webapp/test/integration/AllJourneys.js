sap.ui.define([
    "sap/ui/test/Opa5",
    "./arrangements/Startup",
    "./NavigationJourney",
    "./EditAndUploadJourney"
], function (Opa5, Startup) {
    "use strict";

    Opa5.extendConfig({
        arrangements: new Startup(),
        viewNamespace: "com.apple.scp.shipmentmaint.view.",
        autoWait: true,
        timeout: 210
    });
});
