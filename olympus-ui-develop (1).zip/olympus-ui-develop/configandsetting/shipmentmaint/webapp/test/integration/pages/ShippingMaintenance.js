sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (Opa5, Press, Properties) {
    "use strict";
    var sViewName = "ShippingMaintenance";
    var btnNames = {
        "searchBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idSearch",
        "NRsearchBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idSearch",
        "editBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnEdit",
        "saveBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnSave",
        "cancelBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnCancel",
        "uploadBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnUpload",
        "dialogUpload": "Upload",
        "dialogClose": "closeUpload",
        "addBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnAdd",
        "NRaddBtn": "container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idsmartTable-btnAdd",
        "dialogAdd": "idAdd",
        "dialogCloseAdd": "closeDialog",
    };

    Opa5.createPageObjects({
        onTheSMPage: {

            actions: {
                iTriggerBtnPress: function (buttonReference) {
                    var bId = btnNames[buttonReference];
                    this.waitFor({
                        viewName: sViewName,
                        id: bId,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + buttonReference
                    });
                },

                iSearchDialogAndClickButton: function (buttonReference) {
                    var bId = btnNames[buttonReference];
                    this.waitFor({
                        searchOpenDialogs: true,
                        id: bId,
                        viewName: sViewName,
                        actions: new Press(),
                        errorMessage: "Button Not found: " + buttonReference
                    });
                },

                iSearchDialogWithButtonTextAndClick: function (text) {
                    this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Button",
                        matchers: new Properties({
                            text: text
                        }),
                        actions: new Press(),
                        errorMessage: text + " Button Not found"
                    });
                },

                iSelectIconTabItem: function (id) {
                    this.waitFor({
                        viewName: sViewName,
                        id: "idIconTabBar",
                        success: function (iTabBar) {
                            iTabBar.setSelectedKey(id);
                        },
                        errorMessage: "Icon tab bar not found"
                    });
                },

                iSearchDeleteButtonInTable: function (fName, nValue) {
                    this.waitFor({
                        viewName: sViewName,
                        controlType: "sap.m.ColumnListItem",

                        // Retrieve all list items in the table
                        matchers: [function (oCandidateListItem) {
                            var sFound = false;
                            var oTableLine = {};
                            oTableLine = oCandidateListItem.getBindingContext().getObject();

                            for (var sName in oTableLine) {
                                if ((sName === fName) && (oTableLine[sName].toString() === nValue)) {
                                    sFound = true;
                                    break;
                                }
                            }
                            return sFound;
                        }],

                        // Click on the specified item
                        actions: function (oCandidateListItem) {
                            var delBtn = oCandidateListItem.getCells()[2];
                            if (delBtn) {
                                delBtn.firePress();
                            }
                        },
                        errorMessage: "Delete button for " + nValue + " could not be found in the table"
                    });
                }
            },

            assertions: {
                iShouldSeeBtn: function (buttonReference) {
                    var bId = btnNames[buttonReference];
                    return this.waitFor({
                        id: bId,
                        success: function () {
                            Opa5.assert.ok(true, "Button Found: " + buttonReference);
                        },
                        errorMessage: "Button not found: " + buttonReference
                    });
                },

                iShouldSeeUploadFragment: function () {
                    return this.waitFor({
                        id: "idUploadDialog",
                        fragmentId: "massUpload",
                        errorMessage: "Upload Dialog could not be opened",
                        success: function () {
                            Opa5.assert.ok(true, "Upload Dialog opened");
                        },
                    });
                },

                iShouldSeeAddFragment: function () {
                    return this.waitFor({
                        fragmentId: "AddConfigValues",
                        id: "idAddDialog",
                        success: function () {
                            Opa5.assert.ok(true, "Add Dialog opened");
                        },
                        errorMessage: "Add Dialog could not be opened"
                    });
                },

                iShouldSeePopUp: function (title) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: title
                        }),
                        success: function () {
                            Opa5.assert.ok(true, title + " Popup seen");
                        },
                        errorMessage: title + " PopUp not seen"
                    });
                },

                iShouldNotSeeControl: function (sControlId) {
                    return this.waitFor({
                        success: function () {
                            var bExists = (Opa5.getJQuery()("#" + sControlId).length > 0);
                            Opa5.assert.ok(!bExists, "Control does not exists");
                        }
                    });
                },

                iShouldSeeTheApp: function () {
                    return this.waitFor({
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The " + sViewName + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewName + " view"
                    });
                }
            }
        }
    });

});
