/* global QUnit */

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/shipmentmaint/test/integration/pages/ShippingMaintenance",
    "com/apple/scp/shipmentmaint/test/integration/arrangements/Startup"
], function (opaTest, Opa5) {
    "use strict";
    const shipmentPathSuffix = "../../index.html?responderOn=true",
          shipmentFrameToLoad = "The frame to be loaded";

    QUnit.module("Edit Journey");

    opaTest("Edit Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame(shipmentPathSuffix).done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), shipmentFrameToLoad);
        });

        //Actions & Assersions
        When.onTheSMPage.iTriggerBtnPress("searchBtn"); //Search
        When.onTheSMPage.iTriggerBtnPress("editBtn"); //Edit
        Then.onTheSMPage.iShouldSeeBtn("saveBtn"); //Save
        When.onTheSMPage.iTriggerBtnPress("cancelBtn"); //Cancel
        Then.onTheSMPage.iShouldSeeBtn("editBtn"); //Edit
        When.onTheSMPage.iTriggerBtnPress("editBtn"); //Edit
        When.onTheSMPage.iTriggerBtnPress("saveBtn"); //Save
        Then.onTheSMPage.iShouldSeeBtn("editBtn"); //Edit

        Then.iTeardownMyApp();
    });

    QUnit.module("Upload Journey");

    opaTest("Upload Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame(shipmentPathSuffix).done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), shipmentFrameToLoad);
        });

        //Actions & Assersions
        When.onTheSMPage.iTriggerBtnPress("uploadBtn"); //Upload
        Then.onTheSMPage.iShouldSeeUploadFragment();

        When.onTheSMPage.iSearchDialogAndClickButton("dialogClose");
        When.onTheSMPage.iTriggerBtnPress("uploadBtn"); //Upload
        When.onTheSMPage.iSearchDialogAndClickButton("dialogUpload"); //Dialog Upload
        Then.onTheSMPage.iShouldSeePopUp("Error");

        Then.iTeardownMyApp();
    });

    QUnit.module("Add Journey");

    opaTest("Add Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame(shipmentPathSuffix).done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), shipmentFrameToLoad);
        });

        //Actions & Assersions
        When.onTheSMPage.iTriggerBtnPress("addBtn"); //Add
        Then.onTheSMPage.iShouldSeeAddFragment("idAddDialog"); //Fragment to be opened

        When.onTheSMPage.iSearchDialogAndClickButton("dialogCloseAdd"); //Close Button
        Then.onTheSMPage.iShouldNotSeeControl("idCreateSuccess"); //Add Fragment to be closed

        When.onTheSMPage.iTriggerBtnPress("addBtn"); //Add
        When.onTheSMPage.iSearchDialogAndClickButton("dialogAdd"); //Dialog Add
        Then.onTheSMPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onTheSMPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button
        Then.onTheSMPage.iShouldNotSeeControl("idCreateSuccess"); //Success Pop up not to be seen

        //Select Number Ranges Tab and repeat
        When.onTheSMPage.iSelectIconTabItem("keyNR"); //Number Ranges Tab
        When.onTheSMPage.iTriggerBtnPress("NRaddBtn"); //Add
        Then.onTheSMPage.iShouldSeeAddFragment(); //Fragment to be opened

        When.onTheSMPage.iSearchDialogAndClickButton("dialogAdd"); //Dialog Add
        Then.onTheSMPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onTheSMPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button
        Then.onTheSMPage.iShouldNotSeeControl("idCreateSuccess"); //Success Pop up not to be seen

        Then.iTeardownMyApp();
    });

    QUnit.module("Delete Journey");

    opaTest("Delete Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onTheSMPage.iTriggerBtnPress("searchBtn"); //Search
        When.onTheSMPage.iSearchDeleteButtonInTable("NAME", "LOADREQ_N1"); //Click Delete
        Then.onTheSMPage.iShouldSeePopUp("Success"); //Success pop up to be seen

        When.onTheSMPage.iSearchDialogWithButtonTextAndClick("OK"); //OK button on success popup
        Then.onTheSMPage.iShouldNotSeeControl("idDeleteSuccess"); //Success Pop up not to be seen

        Then.iTeardownMyApp();
    });
});
