sap.ui.define([
    "sap/ui/test/Opa5"
], function (Opa5) {
    "use strict";

    return Opa5.extend("com.apple.scp.shipmentmaint.test.integration.arrangements.Startup", {
        iTeardownTheApp: function () {
            this.iTeardownMyUIComponent();
        },
        iStartMyApp: function (eOptions) {
            var oOptions = eOptions || {};

            // start the app with a minimal delay to make tests fast but still async to discover basic timing issues
            oOptions.delay = oOptions.delay || 50;

            // start the app UI component
            this.iStartMyUIComponent({
                componentConfig: {
                    name: "com.apple.scp.shipmentmaint",
                    async: true
                },
                hash: oOptions.hash,
                autoWait: oOptions.autoWait
            });
        }
    });
});
