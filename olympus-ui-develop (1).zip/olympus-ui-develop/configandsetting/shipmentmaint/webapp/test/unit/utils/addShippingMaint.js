/*global QUnit*/

sap.ui.define([
    "com/apple/scp/shipmentmaint/controller/ShippingMaintenance.controller",
    "sap/ui/core/mvc/Controller",
    "com/apple/scp/shipmentmaint/utils/addShippingMaint",
], function (Controller, aController, addShippingMaint) {
    "use strict";

    QUnit.module("Add Shipping Maint", {
        beforeEach: function () {
            this.oSMController = new Controller();
        },
        afterEach: function () {
            this.oSMController.destroy();
        }
    });
});
