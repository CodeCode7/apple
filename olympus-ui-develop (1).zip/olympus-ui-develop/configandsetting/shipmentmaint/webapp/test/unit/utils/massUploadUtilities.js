/*global QUnit*/

sap.ui.define([
    "com/apple/scp/shipmentmaint/controller/ShippingMaintenance.controller",
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "com/apple/scp/shipmentmaint/utils/massUploadUtilities",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/unified/FileUploader"
], function (Controller, aController, UIComponent, uploadUtils, ResourceModel, JSONModel, FileUploader) {
    "use strict";
    const Core = new sap.ui.core.Core(),
        ManagedObject = sap.ui.core.mvc.View,
        Dialog = sap.m.Dialog;
    const
        modPath = "com/apple/scp/shipmentmaint",
        i18Path = "/i18n/i18n.properties",
        sError = "Sample Error";

    QUnit.module("Mass Upload Utilities", {
        beforeEach: function () {
            this.oSMController = new Controller();
        },
        afterEach: function () {
            this.oSMController.destroy();
        }
    });

    QUnit.test("getErrorText Helper function Test", function (assert) {
        let rText = " Error Text to be returned";

        this._oResModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modPath + i18Path)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResModel);

        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '400'), "Incorrect input file/data, please recheck the file and then re-upload", "400" + rText);
        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '401'), "Unauthorized request. Please re-authenticate and try again.", "401" + rText);
        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '403'), "You are not authorised to perform requested action", "403" + rText);
        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '404'), "Syntax Error in service. Reload and check, if issue persists contact admin", "404" + rText);
        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '409'), "Duplicate Insert: Record already exists", "409" + rText);
        assert.strictEqual(uploadUtils.getErrorText(this.oSMController, '4', sError), sError, "Message to be passed back as is");

        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
        this._oResModel.destroy();
    });

    QUnit.test("strToBoolean function test", function (assert) {
        //Assert
        let trueText = "Boolean true to be returned",
            falseText = "Boolean false to be returned";

        var isolatedFcn = uploadUtils.strToBoolean;
        assert.strictEqual(isolatedFcn("true"), true, trueText);
        assert.strictEqual(isolatedFcn("yes"), true, trueText);
        assert.strictEqual(isolatedFcn("0"), false, falseText);
        assert.strictEqual(isolatedFcn("false"), false, falseText);
        assert.strictEqual(isolatedFcn("1"), true, trueText);
        assert.strictEqual(isolatedFcn("00"), true, trueText);
        assert.strictEqual(isolatedFcn("no"), false, falseText);
    });

    QUnit.test("prepareMassPayload function test", function (assert) {
        var data = [{
            "NAME": "HAWB",
            "VENDOR": "0002959VP",
            "STARTING_NUMBER": "1",
            "MAXIMUM_NUMBER": "9999999999",
            "CURRENT_NUMBER": "1000000288"
        }, {
            "NAME": "LOADREQ",
            "VENDOR": "0002959VP",
            "STARTING_NUMBER": "1",
            "MAXIMUM_NUMBER": "99999",
            "CURRENT_NUMBER": "307"
        }
        ];

        var lModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/shipmentmaint/utils/technicalConfig.json");
        lModel.loadData(sPath, "", false);

        var outputData = uploadUtils.prepareMassPayload(data, lModel.getData().SelectedTabConfig.keySL);
        assert.strictEqual(outputData.length, 2, "Payload with 2 records to be created");
    });

    QUnit.test("showErrorLog function test", function (assert) {
        this._oResModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modPath + i18Path)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResModel);

        var errMsgs = [{ "type": "Error", "title": "Sample Title", "description": "Long Error" }];
        uploadUtils.showErrorLog(this.oSMController, errMsgs);
        assert.ok(uploadUtils.eDialog);

        uploadUtils.eDialog.destroy();
        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("prepareErrArr function test", function (assert) {
        this._oResModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modPath + i18Path)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResModel);

        var errArr = uploadUtils.prepareErrArr('400', this.oSMController, 'Sample Error', [], uploadUtils);
        errArr = uploadUtils.prepareErrArr('401', this.oSMController, 'Sample Error 2', errArr, uploadUtils);
        errArr = uploadUtils.prepareErrArr('401', this.oSMController, 'Sample Error 2', errArr, uploadUtils);

        assert.ok(errArr);

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
    });

    QUnit.test("parseErrorMessage function test", function (assert) {
        var oError = {
            "responseText": sError
        };
        var msg = uploadUtils.parseErrorMessage(oError);
        assert.strictEqual(msg, sError, "Error Message for 401 to be parsed correctly");

        oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Error" } } }'
        };

        msg = uploadUtils.parseErrorMessage(oError);
        assert.strictEqual(msg, "Error", "Error for non 401 to be parsed correctly");
    });

    QUnit.test("triggerPostCalls function test", function (assert) {
        var aPayload = [{ "F1": "V1" }, { "F1": "V2" }];
        uploadUtils.triggerPostCalls(aPayload, undefined, {}, undefined);

        assert.ok(true);
    });

    QUnit.test("errorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": sError } } }'
        };

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var oView = new ManagedObject({});
        var modelStub = sinon.stub(oView, 'getModel').returns(false); //add stub
        this.oSMController.oUpload = new Dialog("dDialog");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oView);
        var returnRec = uploadUtils.errorHandler(oError, this.oSMController, 0);

        assert.ok(returnRec);

        coreStub.restore();
        oGetViewStub.restore();
        oView.destroy();
        dUploader.destroy();
        modelStub.restore();
        this.oSMController.oUpload.destroy();
    });

    QUnit.test("fileSuccessHandler function test", function (assert) {
        this.oSMController.oUpload = new Dialog("dDialog");

        this._oResModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modPath + i18Path)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResModel);

        var oView = new ManagedObject({});
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oView);

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var sResponse = {};
        var resp = uploadUtils.fileSuccessHandler(sResponse, {}, this.oSMController, undefined, 0, false);
        assert.strictEqual(resp.popUpDisplayed, true, "All Success: Success popup to be displayed");

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
        oView.destroy();
        oGetViewStub.restore();
        dUploader.destroy();
        coreStub.restore();
        this.oSMController.oUpload.destroy();
    });
});
