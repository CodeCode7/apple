/*global QUnit*/
sap.ui.define([
    "com/apple/scp/shipmentmaint/model/models",
    "sap/ui/Device"
], function (aModel, Device) {
    "use strict";

    QUnit.module("createDeviceModel", {
        afterEach: function () {
            this.oDeviceMod.destroy();
        }
    });

    function isPhoneTestCase(assert, aIsPhone) {
        // Arrange
        this.stub(Device, "system", { phone: aIsPhone });

        // System under test
        this.oDeviceMod = aModel.createDeviceModel();

        // Assert
        assert.strictEqual(this.oDeviceMod.getData().system.phone, aIsPhone, "IsPhone property is correct");
    }

    QUnit.test("Should initialize a device model for desktop", function (assert) {
        isPhoneTestCase.call(this, assert, false);
    });

    QUnit.test("Should initialize a device model for phone", function (assert) {
        isPhoneTestCase.call(this, assert, true);
    });

    function isTouchTest(assert, bIsTouch) {
        // Arrange
        this.stub(Device, "support", { touch: bIsTouch });

        // System under test
        this.oDeviceMod = aModel.createDeviceModel();

        // Assert
        assert.strictEqual(this.oDeviceMod.getData().support.touch, bIsTouch, "IsTouch property is correct");
    }

    QUnit.test("Should initialize a device model for non touch devices", function (assert) {
        isTouchTest.call(this, assert, false);
    });

    QUnit.test("Should initialize a device model for touch devices", function (assert) {
        isTouchTest.call(this, assert, true);
    });

    QUnit.test("The binding mode of the device model should be one way", function (assert) {

        // System under test
        this.oDeviceMod = aModel.createDeviceModel();

        // Assert
        assert.strictEqual(this.oDeviceMod.getDefaultBindingMode(), "OneWay", "Binding mode is correct");
    });
});
