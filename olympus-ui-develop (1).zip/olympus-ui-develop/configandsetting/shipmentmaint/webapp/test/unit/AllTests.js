sap.ui.define([
    "./controller/App.controller",
    "./controller/ShippingMaintenance.controller",
    "./model/models",
    "./utils/massUploadUtilities"
], function () {
    "use strict";
});
