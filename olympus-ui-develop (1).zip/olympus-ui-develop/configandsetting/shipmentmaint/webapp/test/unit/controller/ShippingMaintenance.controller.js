/*global QUnit*/

sap.ui.define([
    "com/apple/scp/shipmentmaint/controller/ShippingMaintenance.controller",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/m/Button",
    "sap/ui/base/Event",
    "sap/m/InstanceManager"
], function (smController, UiComp, eController, smFB, smTable, ManagedObject, JSONMod, ResourceModel, Btn, Event, InstanceManager) {
    "use strict";
    const i18nPath = "com/apple/scp/shipmentmaint/i18n/i18n.properties",
        samError = "Sample Error";
    QUnit.module("ShippingMaintenance Controller", {
        beforeEach: function () {
            this.oSMController = new smController();
        },
        afterEach: function () {
            this.oSMController.destroy();
        }
    });

    function jsonOk(body) {
        var mockResponse = new window.Response(JSON.stringify(body), { //the fetch API returns a resolved window Response object
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });

        return Promise.resolve(mockResponse);
    }

    function setViewAndLocalModel(oRef) {
        var mViewStub = new ManagedObject({});
        var lModel = new JSONMod();
        var sPath = sap.ui.require.toUrl("com/apple/scp/shipmentmaint/utils/technicalConfig.json");
        lModel.loadData(sPath, "", false);
        mViewStub.setModel(lModel, "localModel");
        oRef.selectedKey = 'keyCV';
        return mViewStub;
    }

    QUnit.test("ShippingMaintenance controller", function (assert) {
        // Arrange
        var olocalRouter = new sap.m.routing.Router([
            {
                "name": "ShippingMaintenance",
                "pattern": "",
                "target": [
                    "ShippingMaintenance"
                ]
            }
        ]);

        var smComp = new UiComp;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(smComp);
        var oCompStub = sinon.stub(UiComp.prototype, "getRouter").returns(olocalRouter);
        this.oSMController.onInit();
        assert.ok(this.oSMController);

        oCompStub.restore();
        oControllerStub.restore();
        smComp.destroy();
        olocalRouter.destroy();
    });

    QUnit.test("Smart Table search test", function (assert) {

        //Arrange
        var mSTable = new smTable("idsmartTable");
        var mViewStub = new ManagedObject({});

        var lModel = new JSONMod();
        var sPath = sap.ui.require.toUrl("com/apple/scp/shipmentmaint/utils/technicalConfig.json");
        lModel.loadData(sPath, "", false);

        mViewStub.setModel(lModel, "localModel");
        this.oSMController.selectedKey = 'keyCV';

        var oSTableSpy = this.stub(sap.ui.comp.smarttable.SmartTable.prototype, "rebindTable");
        var mGetViewStub = sinon.stub(eController.prototype, "getView").returns(mViewStub);
        var oSTableStub = sinon.stub(ManagedObject.prototype, "byId").returns(mSTable);

        //Act
        this.oSMController.onSearch();

        //Assert
        assert.strictEqual(oSTableSpy.callCount, 1, "Smart Table rebindTable event to be triggered");

        //CleanUp
        oSTableSpy.restore();
        oSTableStub.restore();
        mGetViewStub.restore();
        mViewStub.destroy();
        mSTable.destroy();
    });

    QUnit.test("Smart Filter Bar clear test", function (assert) {
        //Arrange
        var mSFB = new smFB("idsmartFilterBar");
        var mViewStub = setViewAndLocalModel(this.oSMController);

        var oSFBSpy = this.stub(sap.ui.comp.smartfilterbar.SmartFilterBar.prototype, "clear");
        var mGetViewStub = sinon.stub(eController.prototype, "getView").returns(mViewStub);
        var oSFBStub = sinon.stub(ManagedObject.prototype, "byId").returns(mSFB);

        //Act
        this.oSMController.onClear();

        //Assert
        assert.strictEqual(oSFBSpy.callCount, 1, "Smart Filter Bar clear to be triggered");

        //CleanUp
        oSFBSpy.restore();
        oSFBStub.restore();
        mGetViewStub.restore();
        mSFB.destroy();
        mViewStub.destroy();
    });

    QUnit.test("Table Edit Functionality test", function (assert) {
        //Arrange
        var mViewStub = setViewAndLocalModel(this.oSMController);
        var mGetViewStub = sinon.stub(eController.prototype, "getView").returns(mViewStub);

        var btn = new Btn();
        var viewByIdStub = sinon.stub(ManagedObject.prototype, "byId").returns(btn);

        this.oSMController.selectedKey = 'keyCV';

        //Act & Assert
        this.oSMController.onEdit();
        var lModel = mViewStub.getModel("localModel");
        var mode = lModel.getProperty("/DisplayMode");
        assert.strictEqual(mode, false, "Edit Mode Set");


        this.oSMController.onEditSave();
        assert.strictEqual(lModel.getProperty("/DisplayMode"), true, "Display Mode Set");

        //Cleanup
        mGetViewStub.restore();
        viewByIdStub.restore();
        btn.destroy();
        mViewStub.destroy();
    });

    QUnit.test("getI18nText function test", function (assert) {
        //Arrange
        var smComp = new UiComp();
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(smComp);
        var oResourceModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl(i18nPath) });
        var oCompStub = sinon.stub(UiComp.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResourceModel);

        //Action
        var aText = this.oSMController.getI18nText("appTitle");

        //Assert
        assert.strictEqual(aText, "Shipping Maintenance", "Text for appTitle to be returned");

        //CleanUp
        smComp.destroy();
        oControllerStub.restore();
        oResourceModel.destroy();
        oCompStub.restore();
    });

    QUnit.test("View Initialisation", function (assert) {
        //Arrange
        var mViewStub = new ManagedObject({});
        var mGetViewStub = sinon.stub(eController.prototype, "getView").returns(mViewStub);

        var mSFB = new smFB("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartFilterBar");
        var mSTable = new smTable("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable");

        var mSFB2 = new smFB("container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idsmartFilterBar");
        var mSTable2 = new smTable("container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idsmartTable");

        var byIDStub = this.stub(ManagedObject.prototype, "byId");
        byIDStub.withArgs("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartFilterBar").returns(mSFB);
        byIDStub.withArgs("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable").returns(mSTable);
        byIDStub.withArgs("container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idsmartFilterBar").returns(mSFB2);
        byIDStub.withArgs("container-com.apple.scp.shipmentmaint---ShippingMaintenance--nrFragment--idsmartTable").returns(mSTable2);

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(i18nPath)
        });

        var smComp = new UiComp;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(smComp);
        var oCompStub = sinon.stub(UiComp.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        //System under test & Assert
        this.oSMController.onRouteMatched();
        assert.strictEqual(this.oSMController.selectedKey, "keyCV", "ConfigValues to be set as default tab");
        assert.strictEqual(mSTable.getHeader(), "Configuration Values", "Smart Table Header to be initialised correctly");

        //Cleanup
        mGetViewStub.restore();
        byIDStub.restore();
        mViewStub.destroy();
        mSFB.destroy();
        mSTable.destroy();
        mSFB2.destroy();
        mSTable2.destroy();
        oControllerStub.restore();
        this._oResourceModel.destroy();
        oCompStub.restore();
        smComp.destroy();
    });

    QUnit.test("checkAuthorization function test", function (assert) {
        //Arrange
        var fnDone = assert.async();
        var mViewStub = setViewAndLocalModel(this.oSMController);
        var mGetViewStub = sinon.stub(this.oSMController, "getView").returns(mViewStub);
        var smComp = new UiComp;
        smComp.isMockMode = false;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(smComp);

        var localJWT = {
            "decodedJWTToken": {
                "scope": [
                    "configandsetting!t9525.CONFIGANDSETTIING_DISPLAY",
                    "configandsetting!t9525.CONFIGANDSETTIING_CREATE",
                    "configandsetting!t9525.CONFIGANDSETTIING_UPDATE"
                ]
            }
        };
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk(localJWT));

        var lModel = mViewStub.getModel("localModel");
        this.oSMController.checkAuthorization().then(function () {
            //Assert
            assert.strictEqual(lModel.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(lModel.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(lModel.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDone();

            //Cleanup
            mGetViewStub.restore();
            mViewStub.destroy();
            smComp.destroy();
            oControllerStub.restore();
        });
    });

    QUnit.test("onMassUpload function test", function (assert) {
        var mViewStub = new ManagedObject({});
        var mGetViewStub = sinon.stub(this.oSMController, "getView").returns(mViewStub);
        this.oSMController.onMassUpload();
        assert.ok(this.oSMController.oUpload);
        mViewStub.destroy();
        mGetViewStub.restore();
    });

    QUnit.test("onDownload function test", function (assert) {
        var mViewStub = setViewAndLocalModel(this.oSMController);
        var mGetViewStub = sinon.stub(this.oSMController, "getView").returns(mViewStub);

        var oBtn = new Btn();
        var oBtnStub = sinon.stub(ManagedObject.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oSMController.onDownload();

        assert.strictEqual(oBtnSpy.callCount, 1, "Download function to be triggered");

        mViewStub.destroy();
        mGetViewStub.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });

    QUnit.test("onInitialise function test", function (assert) {
        //Arrange
        var mViewStub = setViewAndLocalModel(this.oSMController);
        var mGetViewStub = sinon.stub(this.oSMController, "getView").returns(mViewStub);
        var oBtnToggle = new Btn("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnEditToggle");

        var oByIDStub = sinon.stub(ManagedObject.prototype, "byId");
        oByIDStub.withArgs("container-com.apple.scp.shipmentmaint---ShippingMaintenance--cvFragment--idsmartTable-btnEditToggle").returns(oBtnToggle);

        //System Under test
        this.oSMController.onInitialise();

        //Assert
        assert.strictEqual(oBtnToggle.getVisible(), false, "Standard Toolbar Toggle button visibility to be set to false");

        //Clean Up
        mViewStub.destroy();
        mGetViewStub.restore();
        oBtnToggle.destroy();
        oByIDStub.restore();
    });

    QUnit.test("onTabChange function test", function (assert) {
        var dEvent = new Event('oEvent', {}, { 'selectedKey': "keyNR" });
        this.oSMController.onTabChange(dEvent);
        assert.strictEqual(this.oSMController.selectedKey, "keyNR", "selectedKey Property to be updated to Number Ranges");
    });

    QUnit.test("onUploadChange function test", function (assert) {
        var obj = { "name": "test.xlsx" };
        var dEvent = new Event("oEvent", {}, { "files": [obj] });
        this.oSMController.onUploadChange(dEvent);
        assert.strictEqual(this.oSMController.selectedFile, obj, "File selected to be captured");
    });

    QUnit.test("dataEditSuccessHandler function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(i18nPath)
        });
        var smComp = new UiComp;
        var oControllerStub = sinon.stub(this.oSMController, "getOwnerComponent").returns(smComp);
        var oCompStub = sinon.stub(UiComp.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var res = this.oSMController.dataEditSuccessHandler({}, this.oSMController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, true, "Success popup to be displayed");

        var sResponse = { "__batchResponses": [{ "response": { "statusCode": '403', "body": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Sample"} } }' } }] };
        res = this.oSMController.dataEditSuccessHandler(sResponse, this.oSMController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, false, "Success popup not to be displayed");

        InstanceManager.closeAllDialogs();
        smComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("dataEditErrorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": samError } } }'
        };

        var errRec = this.oSMController.dataEditErrorHandler(oError, 0);
        assert.strictEqual(errRec, 1, "Error Record count to be incremented by 1");

        oError = {
            "responseText": samError
        };

        errRec = this.oSMController.dataEditErrorHandler(oError, 0);
        assert.ok(errRec);
        InstanceManager.closeAllDialogs();

    });

});
