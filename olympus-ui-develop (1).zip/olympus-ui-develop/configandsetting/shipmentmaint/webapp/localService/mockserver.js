sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/base/Log"
], function (MServer, Logger) {
    "use strict";

    var _modulePath = "com/apple/scp/shipmentmaint/",
        _mockFilesPath = _modulePath + "localService/mockdata",
        _mEntitySets = ["ConfigValues", "NumberRanges"];

    return {
        /**
         * mockserver creation
         * @returns {sap.ui.core.util.MockServer} an initialized and started mockserver
         */

        init: function () {
            var sJsonFilesUrl = sap.ui.require.toUrl(_mockFilesPath),
                eManifestUrl = sap.ui.require.toUrl(_modulePath + "manifest.json"),
                oManifest = jQuery.sap.syncGetJSON(eManifestUrl).data,
                eMainDataSource = oManifest["sap.app"].dataSources.mainService,
                sMetadataUrl = sap.ui.require.toUrl(_modulePath + eMainDataSource.settings.localUri);

            this.sMockServerUrl = eMainDataSource.uri;

            // init root URI
            this.eMockServer = new MServer({
                rootUri: this.sMockServerUrl
            });

            // configure mock server with a potential delay
            MServer.config({
                autoRespond: true
            });

            // load local mock data (if there's any)
            this.eMockServer.simulate(sMetadataUrl, {
                sMockdataBaseUrl: sJsonFilesUrl,
                aEntitySetsNames: _mEntitySets,
                bGenerateMissingMockData: false
            });

            this.eMockServer.start();

            Logger.info("MockServer started w/\n" +
                "   baseURL: " + this.sMockServerUrl + "\n" +
                "   metadata from " + sMetadataUrl + "\n" +
                "   mockdata dir: " + sJsonFilesUrl);

            return this;
        }
    };

});
