sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/apple/scp/shipmentmaint/model/models",
    "sap/base/util/UriParameters",
    "com/apple/scp/shipmentmaint/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel"
],
    function (UiComp, device, models, URIParams, MServer, odataModel) {
        "use strict";

        return UiComp.extend("com.apple.scp.shipmentmaint.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UiComp.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
                this.isMockMode = URIParams.fromURL(window.location.href).get("responderOn");
                if (this.isMockMode) {
                    //Start Mock Server
                    this.eMockServer = MServer.init();

                    //Set Mockmodel to Component
                    var eModel = new odataModel(this.eMockServer.sMockServerUrl, {
                        json: true
                    });

                    this.setModel(eModel);
                } else {
                    this.getAppId();
                }
            },

            getAppId: function () {
                var that = this;
                fetch("/getAppVariables").then(resp => resp.json()).then(appToken => {
                    that.loadMetaWithAppID(appToken);
                });
            },

            loadMetaWithAppID: function (appToken) {
                var oParameters = {
                    defaultBindingMode: "TwoWay",
                    disableHeadRequestForToken: true,
                    headers: {
                        appID: appToken
                    }
                };

                var sUri = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
                var eModel = new odataModel(sUri, oParameters);
                this.setModel(eModel);
            }
        });
    }
);
