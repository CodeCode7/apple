sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "../utils/addShippingMaint",
    "../utils/massUploadUtilities",
    "../utils/xlsx",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, jsonModel, addShippingMaint, smMassUploadUtil) {
        "use strict";
        const btnToggle = '-btnEditToggle',
            btnAddToggle = '-btnAddToggle',
            btnExport = '-btnExcelExport',
            displayMode = '/DisplayMode',
            editSaveTrigger = '/editSaveTrigger';

        return Controller.extend("com.apple.scp.shipmentmaint.controller.ShippingMaintenance", {
            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("ShippingMaintenance").attachMatched(this.onRouteMatched, this);
            },
            onRouteMatched: function () {
                this.setUpViewModel(); //Set up model
                this.initSmartControls(); //Initializes the smart controls
                this.checkAuthorization();
                var oModel = new jsonModel({
                    "NAME": "",
                    "VALUE": ""
                });
                this.getView().setModel(oModel, "ConfigModel");

                var oNumberRangeModel = new jsonModel({
                    "NAME": "",
                    "VENDOR": "",
                    "STARTING_NUMBER": "",
                    "MAXIMUM_NUMBER": "",
                    "CURRENT_NUMBER": ""
                });
                this.getView().setModel(oNumberRangeModel, "NumberRangeModel");

            },
            onInitialise: function () {
                var configurationData = this.getView().getModel("localModel").getData().SelectedTabConfig;
                this.hideControl([btnToggle, btnAddToggle, btnExport], configurationData); //Standard Toolbar buttons
            },
            checkAuthorization: function () {
                var smModel = this.getView().getModel("localModel");
                if (this.getOwnerComponent().isMockMode) {
                    //Mock Mode
                    smModel.setProperty('/createAccess', true);
                    smModel.setProperty('/editAccess', true);
                    smModel.setProperty('/displayAccess', true);
                    return null;
                } else {
                    //Check for authorization
                    return fetch("/getUserInfo")
                        .then(mRes => mRes.json())
                        .then(oToken => {
                            var scopesArray = oToken.decodedJWTToken.scope;
                            if (scopesArray.some(a => a.includes("CONFIGANDSETTIING_CREATE"))) {
                                //Create Authorization
                                smModel.setProperty('/createAccess', true);
                            }
                            if (scopesArray.some(a => a.includes("CONFIGANDSETTIING_UPDATE"))) {
                                //Edit Authorization
                                smModel.setProperty('/editAccess', true);
                            }
                            if (scopesArray.some(a => a.includes("CONFIGANDSETTIING_DISPLAY"))) {
                                //Display Authorization
                                smModel.setProperty('/displayAccess', true);
                            }
                        })
                        .catch();
                }
            },

            hideControl: function (idsArray, configurationData) {
                for (var obj in configurationData) {
                    if (!configurationData.hasOwnProperty(obj)) {
                        continue;
                    }
                    for (var id in idsArray) {
                        if (!idsArray.hasOwnProperty(id)) {
                            continue;
                        }
                        var bID = configurationData[obj].TableID + idsArray[id];
                        var mRefID = this.getView().byId(bID);
                        if (mRefID) {
                            mRefID.setVisible(false);
                        }

                    }

                }
            },

            setUpViewModel: function () {
                var smModel = new jsonModel();
                var sPath = sap.ui.require.toUrl("com/apple/scp/shipmentmaint/utils/technicalConfig.json");
                smModel.loadData(sPath, "", false);

                this.getView().setModel(smModel, "localModel");
                this.selectedKey = 'keyCV';

                var fragmentModel = smModel.getData().createFragment[this.selectedKey];
                smModel.setProperty("/fields", fragmentModel);
            },

            initSmartControls: function () {
                this.setTableAndFilterEntities("keyCV");
                this.setTableAndFilterEntities("keyNR");
            },

            setTableAndFilterEntities: function (key) {
                var configurationData = this.getView().getModel("localModel").getData().SelectedTabConfig[key];

                //Set Entity set of Smart Filter Bar and Smart Table
                var eFilter = this.getView().byId(configurationData.FilterID);
                var eTable = this.getView().byId(configurationData.TableID);
                var sEntity = configurationData.ServiceEntitySet;
                eFilter.setEntitySet(sEntity);
                eTable.setEntitySet(sEntity);
                eTable.setSmartFilterId(configurationData.FilterID);
                eTable.setHeader(this.getI18nText(configurationData.i18nHeaderProperty));
            },

            onMassUpload: function () {
                smMassUploadUtil.onMassUpload(this);
            },

            fnCloseUploadDialog: function (oEvent) {
                smMassUploadUtil.fnCloseUploadDialog(oEvent);
            },

            getI18nText: function (textID) {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(textID);
            },

            onFileUpload: function () {
                var selKey = this.getView().byId("idIconTabBar").getSelectedKey();
                smMassUploadUtil.onFileUpload(this, this.getView().getModel("localModel").getData().SelectedTabConfig[selKey]);
            },

            onUploadChange: function (oEvent) {
                smMassUploadUtil.onUploadChange(oEvent, this);
            },

            dataEditSuccessHandler: function (odata, that, eModel, errorEntries, popUpDisplayed) {
                sap.ui.core.BusyIndicator.hide();
                //Check odata response status
                if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                    //Forbidden
                    errorEntries = errorEntries + 1;
                    //Parse the error message
                    var mRespText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value;
                    //Show error message in Error popup
                    sap.m.MessageBox.error(mRespText);
                    if (eModel) {
                        eModel.resetChanges();
                    }
                } else {
                    //Show success message if all records created successfully
                    if (errorEntries < 1 && !popUpDisplayed) {
                        //Success Message Toast
                        sap.m.MessageToast.show(that.getI18nText("dataUpdated"));
                        popUpDisplayed = true;
                    }
                }

                return { "errorEntries": errorEntries, "popUpDisplayed": popUpDisplayed };
            },

            dataEditErrorHandler: function (oError, errorEntries, eModel) {
                sap.ui.core.BusyIndicator.hide();
                errorEntries = errorEntries + 1; //Count the number of records for which error is occuring

                //Parse the error message
                try {
                    var mRespText = JSON.parse(oError.responseText).error.message.value;
                } catch (exception) {
                    mRespText = oError.responseText;
                }

                //Show error message in Error popup
                sap.m.MessageBox.error(mRespText);
                if (eModel) {
                    eModel.resetChanges();
                }

                return errorEntries;
            },

            dataEdited: function (oEvent) {
                if (!oEvent.getParameter('editable') && this.getView().getModel("localModel").getData().editSaveTrigger) {
                    var errorEntries = 0,
                        popUpDisplayed = false,
                        that = this;

                    var eModel = oEvent.getSource().getModel(); //Table Model

                    var eParameters = {
                        //Success event of OData model
                        success: function (odata) {
                            var mRes = that.dataEditSuccessHandler(odata, that, eModel, errorEntries, popUpDisplayed);
                            errorEntries = mRes.errorEntries;
                            popUpDisplayed = mRes.popUpDisplayed;
                        },
                        //Error event of OData model
                        error: function (oError) {
                            errorEntries = that.dataEditErrorHandler(oError);
                        }
                    };
                    sap.ui.core.BusyIndicator.show(0);
                    eModel.submitChanges(eParameters);
                }
            },

            onTabChange: function (mEvent) {
                this.selectedKey = mEvent.getParameter('selectedKey');
            },

            onSearch: function () {
                var tableID = this.getView().getModel("localModel").getData().SelectedTabConfig[this.selectedKey].TableID;
                this.getView().byId(tableID).rebindTable(true);
            },

            onClear: function () {
                var filterId = this.getView().getModel("localModel").getData().SelectedTabConfig[this.selectedKey].FilterID;
                this.getView().byId(filterId).clear();
            },
            onEdit: function () {
                var smModel = this.getView().getModel("localModel");
                smModel.setProperty(editSaveTrigger, false);
                smModel.setProperty(displayMode, false);
                var bID = smModel.getData().SelectedTabConfig[this.selectedKey].TableID + btnToggle;
                this.getView().byId(bID).firePress(); //Change Mode
            },

            onEditSave: function () {
                var smModel = this.getView().getModel("localModel");
                smModel.setProperty(editSaveTrigger, true);
                smModel.setProperty(displayMode, true);
                var bID = smModel.getData().SelectedTabConfig[this.selectedKey].TableID + btnToggle;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onEditCancel: function (oEvent) {
                var smModel = this.getView().getModel("localModel");
                smModel.setProperty(editSaveTrigger, false);
                smModel.setProperty(displayMode, true);
                oEvent.getSource().getParent().getParent().getModel().resetChanges(); //Resets changed data

                var bID = smModel.getData().SelectedTabConfig[this.selectedKey].TableID + btnToggle;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onAddConfigValues: function () {
                addShippingMaint.onAddConfigValues(this);
            },

            fnCloseAddDialog: function (oEvent) {
                addShippingMaint.fnCloseAddDialog(oEvent);
            },

            onAddFields: function (oEvent) {
                var selKey = this.getView().byId("idIconTabBar").getSelectedKey();
                var configurationData = this.getView().getModel("localModel").getData().SelectedTabConfig[selKey];
                var sEntity = configurationData.ServiceEntitySet;
                if (selKey === "keyCV") {
                    var oPromise = this.insertEntry(sEntity, this.getView().getModel("ConfigModel").getData(), oEvent);
                } else {
                    oPromise = this.insertEntry(sEntity, this.getView().getModel("NumberRangeModel").getData(), oEvent);
                }

                return oPromise;
            },
            insertEntry: function (sEntity, data, oEvent) {
                this.oButtonEvent = oEvent.getSource().getParent();
                var that = this;
                var model = this.getOwnerComponent().getModel();
                var oPromise = new Promise(function (resolve, reject) {
                    model.create("/" + sEntity, data, {
                        success: function () {
                            resolve();
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });

                oPromise
                    .then(
                        function () {
                            if (sEntity === "ConfigValues") {
                                that.getView().getModel("ConfigModel").setData({
                                    "NAME": "",
                                    "VALUE": ""
                                }, true);
                            } else {
                                that.getView().getModel("NumberRangeModel").setData({
                                    "NAME": "",
                                    "VENDOR": "",
                                    "STARTING_NUMBER": "",
                                    "MAXIMUM_NUMBER": "",
                                    "CURRENT_NUMBER": ""
                                }, true);
                            }
                            sap.m.MessageBox.success(that.getI18nText("CreateSuccess"), {
                                onClose: function (oAction) {
                                    if (oAction === "OK") {
                                        that.oButtonEvent.close();
                                    }
                                },
                                id: "idCreateSuccess"
                            });
                        },
                        function (oError) {
                            sap.m.MessageBox.error(oError.responseText);
                        });

                return oPromise;
            },
            deleteEntry: function (oEvent) {
                var selKey = this.getView().byId("idIconTabBar").getSelectedKey();
                var deletedRow = oEvent.getSource().getBindingContext().getObject();
                var that = this;
                if (selKey === "keyCV") {
                    var sPath = "/ConfigValues('" + deletedRow.NAME + "')";
                } else {
                    sPath = "/NumberRanges(NAME='" + deletedRow.NAME + "',VENDOR='" + deletedRow.VENDOR + "')";
                }

                this.getOwnerComponent().getModel().remove(sPath, {
                    success: function () {
                        sap.m.MessageBox.success(that.getI18nText("DeleteSuccess"), {
                            id: "idDeleteSuccess"
                        });
                    },
                    error: function (oError) {
                        sap.m.MessageBox.error(oError.responseText);
                    }
                });
            },

            onDownload: function () {
                var smModel = this.getView().getModel("localModel");
                var bID = smModel.getData().SelectedTabConfig[this.selectedKey].TableID + '-btnExcelExport-internalSplitBtn';
                var eBtnRef = this.getView().byId(bID);
                if (eBtnRef) {
                    this.getView().byId(bID).firePress(); //Standard Export Data Fire
                }
            }
        });
    });
