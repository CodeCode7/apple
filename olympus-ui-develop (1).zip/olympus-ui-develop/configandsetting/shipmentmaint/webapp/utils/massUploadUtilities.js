
sap.ui.define([
    'sap/ui/core/IconPool',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageItem',
    'sap/m/MessageView',
    'sap/m/Button',
    'sap/m/Dialog',
    'sap/m/Title'], function (IPool, JSONModel, MsgItem, MessageView, Button, Dialog, Title) {
        "use strict";
        var mUploadUtil = {};

        mUploadUtil.onMassUpload = function (aReference) {
            if (!aReference.oUpload) {
                //Create fragment for Mass Create
                aReference.oUpload = sap.ui.xmlfragment("com.apple.scp.shipmentmaint.fragments.massUpload", aReference);
                aReference.getView().addDependent(aReference.oUpload);
            }
            aReference.oUpload.open();
        };

        /* Functions used to close the dialog instance. Called on click of close button on upload Dialog
        Parameters: aEvent - Triggered Event */
        mUploadUtil.fnCloseUploadDialog = function (aEvent) {
            aEvent.getSource().getParent().close();
            aEvent.getSource().getParent().getContent()[0]._aElements[0].clear(); //Clear file uploader
        };

        /* Helper function to get Friendly error text */
        mUploadUtil.getErrorText = function (aReference, statusCode, aMsg) {
            var aMessage;
            switch (statusCode) {
                case '400':
                    aMessage = aReference.getI18nText("IncorrectFile");
                    break;
                case '401':
                    aMessage = aReference.getI18nText("ReAuthError");
                    break;
                case '403':
                    aMessage = aReference.getI18nText("AuthErr");
                    break;
                case '404':
                    aMessage = aReference.getI18nText("SyntaxErr");
                    break;
                case '409':
                    aMessage = aReference.getI18nText("DuplicateErr");
                    break;
                default:
                    aMessage = aMsg;
            }
            return aMessage;
        };

        mUploadUtil.parseErrorMessage = function (sError) {
            try {
                var responseText = JSON.parse(sError.responseText);
                var msg = responseText.error.message.value;
            } catch (exception) {
                msg = sError.responseText;
            }

            return msg;
        };

        /* Helper Function for error handler */
        mUploadUtil.errorHandler = function (sError, aReference, errRecords) {
            sap.ui.core.BusyIndicator.hide();

            errRecords = errRecords + 1; //Count the number of error records
            aReference.oUpload.close(); //Close Dialog popup

            var msg = mUploadUtil.parseErrorMessage(sError);

            aReference.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear();

            if (aReference.getView().getModel()) {
                aReference.getView().getModel().resetChanges(); //Reset OData model pending changes
            }

            return { "errRecords": errRecords, "msg": msg };
        };

        /* Helper Function Collect Error messages */
        mUploadUtil.prepareErrArr = function (eStatusCode, aReference, msg, errArr, that) {
            var aMessage = {'type': 'Error', 'title': that.getErrorText(aReference, eStatusCode, msg)};

            if (eStatusCode !== '400') { aMessage.description = msg; }

            var existingRecord = errArr.find(rec => rec.title === aMessage.title && rec.description === aMessage.description);
            if (existingRecord) {
                if (eStatusCode !== '400') { existingRecord.counter++; }
            } else { //New Error
                if (eStatusCode !== '400') { aMessage.counter = 1; }
                errArr.push(aMessage); //Do not push duplicates
            }

            return errArr;
        };

        /* Helper Function */
        mUploadUtil.triggerPostCalls = function (aPayload, eModel, oParameters, entityName) {
            //Make POST calls one by one for each record in the file
            for (var j in aPayload) {
                if (aPayload.hasOwnProperty(j)) {
                    oParameters.properties = aPayload[j];
                    oParameters.changeSetId = "changeset " + j; //Force Unique changeset
                    if (eModel) {
                        eModel.createEntry(entityName, oParameters);
                    }
                }
            }
        };

        mUploadUtil.fileSuccessHandler = function (odata, response, aReference, eModel, errRecords, popUpDisplayed) {
            console.log(response);
            sap.ui.core.BusyIndicator.hide();
            aReference.oUpload.close(); //Close dialog popup

            if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                //Forbidden - Auth Error from API
                errRecords = errRecords + 1;
                var responseText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value; //Parse the error message
                sap.m.MessageBox.error(responseText); //Show error message in Error popup

                if (eModel) {
                    eModel.resetChanges();
                }
            } else {
                //Show success message if all records created successfully
                if (errRecords < 1 && !popUpDisplayed) {
                    sap.m.MessageToast.show(aReference.getI18nText("objectsCreated")); //Success Message Toast
                    popUpDisplayed = true;
                }
            }
            aReference.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear(); //Clear file uploader file

            return { "errRecords": errRecords, "popUpDisplayed": popUpDisplayed };
        };

        /* Function for Upload Data click. Reads, parses and calls function to build Payload and triggers batch POST call on the
           service entity passed in configData.ServiceEntitySet
           Parameters:
            aReference - Calling controller Reference
            configData - JSON Model holding
            {"ServiceEntitySet": "<Entity Name>",
                "DataFields": { "<DateFieldName1>" : true,
                                "<DateFieldName2>" : true" ... } } */
        mUploadUtil.onFileUpload = function (aReference, configData) {
            //Mass Create
            var errRecords = 0,
                popUpDisplayed = false,
                exceldata = {},
                that = this,
                errArr = [];

            var entityName = configData.ServiceEntitySet;

            //Return if no file is available to upload
            if (aReference.selectedFile === undefined) {
                sap.m.MessageBox.error(aReference.getI18nText("fileNotFound"));
            }

            //Get XLSX Instance
            if (XLSX) {
                var xlsInstance = XLSX;
            } else if (XLS) {
                xlsInstance = XLS;
            }


            //Check if file exists
            if (aReference.selectedFile && window.FileReader) {
                var reader = new FileReader();
                reader.onload = function (rawData) {
                    var data = rawData.target.result;
                    //Read data from excel file
                    var wbook = xlsInstance.read(data, {
                        type: 'binary'
                    });
                    wbook.SheetNames.forEach(function (sheetName) {
                        // Here is your object for every sheet in wbook
                        exceldata = xlsInstance.utils.sheet_to_row_object_array(wbook.Sheets[sheetName]);
                    });

                    //Return if file contains no data
                    if (exceldata.length < 1) {
                        sap.m.MessageBox.error(aReference.getI18nText("fileContainsNoRecord"));
                        return;
                    }
                    //Prepare payload for upload
                    var aPayload = that.prepareMassPayload(exceldata, configData);

                    //Get default OData model
                    var eModel = aReference.getView().getModel();
                    eModel.setUseBatch(true);

                    var oParameters = {
                        //Success event of OData model
                        success: function (odata, response) {
                            var returnData = mUploadUtil.fileSuccessHandler(odata, response, aReference, eModel, errRecords, popUpDisplayed);
                            errRecords = returnData.errRecords;
                            popUpDisplayed = returnData.errRecords;
                        },
                        //Error event of OData model
                        error: function (sError) {
                            var returnRec = mUploadUtil.errorHandler(sError, aReference, errRecords);
                            errRecords = returnRec.errRecords;
                            errArr = mUploadUtil.prepareErrArr(sError.statusCode, aReference, returnRec.msg, errArr, that);
                        }
                    };

                    //Make POST calls one by one for each record in the file
                    mUploadUtil.triggerPostCalls(aPayload, eModel, oParameters, entityName);

                    sap.ui.core.BusyIndicator.show(0);
                    //Submit OData model pending changes
                    var oPromise = new Promise(function (resolve, reject) {
                        eModel.submitChanges({
                            success: function () {
                                resolve();
                            },
                            error: function (sError) {
                                reject(sError);
                            }
                        });
                    });
                    oPromise
                        .then(function () {
                            //Do nothing - No log to be shown
                        }, function (sError) {
                            var msg = mUploadUtil.parseErrorMessage(sError); //Parse Error Message
                            errArr = mUploadUtil.prepareErrArr(sError.statusCode, aReference, msg, errArr, this); //Collect Error messages
                        })
                        .finally(() => {
                            if (errArr.length > 0) {
                                //Show consolidated Error log at the end of submitChanges processing, if any
                                that.showErrorLog(aReference, errArr);
                            }
                        });
                };
                reader.onerror = function (exception) {
                    sap.m.MessageBox.error(aReference.getI18nText("ReadError"));
                    console.log(exception); //For troubleshooting
                };
                reader.readAsBinaryString(aReference.selectedFile);
            }
        };

        /* Helper function to show Message View for Errors, if any */
        mUploadUtil.showErrorLog = function (aReference, errArr) {
            var that = this;
            var oMessageTemplate = new MsgItem({
                type: '{type}',
                title: '{title}',
                description: '{description}',
                counter: '{counter}'
            });

            var oModel = new JSONModel();
            oModel.setData(errArr);

            var oBackButton = new Button({
                visible: false,
                icon: IPool.getIconURI("nav-back"),
                press: function () {
                    that.eMessageView.navigateBack();
                    this.setVisible(false);
                }
            });

            this.eMessageView = new MessageView({
                showDetailsPageHeader: false,
                itemSelect: function () {
                    oBackButton.setVisible(true);
                },
                items: {
                    path: "/",
                    template: oMessageTemplate
                }
            });

            this.eMessageView.setModel(oModel);

            this.eDialog = new Dialog({
                resizable: true,
                content: this.eMessageView,
                state: 'Error',
                beginButton: new Button({
                    press: function () {
                        this.getParent().close();
                    },
                    text: aReference.getI18nText("close")
                }),
                customHeader: new sap.m.Bar({
                    contentLeft: [oBackButton],
                    contentMiddle: [
                        new Title({ text: aReference.getI18nText("ErrorLog") })
                    ]
                }),
                contentHeight: "50%",
                contentWidth: "50%",
                verticalScrolling: false
            });

            this.eMessageView.navigateBack();
            this.eDialog.open();
        };

        /* Function used internally to prepare payload from excel data
        Parameters: exceldata - Excel Data
                    configData - configData - JSON Model holding
                    {"ServiceEntitySet": "<Entity Name>",
                     "DataFields": { "<DateFieldName1>" : true,
                                     "<DateFieldName2>" : true" ... } }*/
        mUploadUtil.prepareMassPayload = function (exceldata, configData) {
            var rowObj = {},
                aPayload = [];

            //Prepare payload for Mass Create Upload - Loop over each rows' cell
            for (let a = 0; a < exceldata.length; a++) { //Loops over rows
                rowObj = {};
                for (let cell in exceldata[a]) { //Reads each column within the row
                    if (!exceldata[a].hasOwnProperty(cell)) {
                        continue;
                    } else {
                        rowObj[cell] = (exceldata[a][cell]).toString();
                    }

                }
                aPayload.push(rowObj);
            }
            return aPayload;
        };

        /* Helper function to convert string to boolean */
        mUploadUtil.strToBoolean = function (str) {
            switch (str.toLowerCase().trim()) {
                case "true": case "yes": case "1": return true;
                case "false": case "no": case "0": return false;
                default: return Boolean(str);
            }
        };

        /* 'change' Event handler function when FileUploader
            Parameters: oEvent - Triggered Event
                        aReference - Calling controller Reference */
        mUploadUtil.onUploadChange = function (oEvent, aReference) {
            //Update selected file for future reference
            aReference.selectedFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        };

        return mUploadUtil;
    });
