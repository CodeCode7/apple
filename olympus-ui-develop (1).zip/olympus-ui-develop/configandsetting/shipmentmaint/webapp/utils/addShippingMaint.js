sap.ui.define([], function () {
    "use strict";
    var addShippingMaint = {};

    /* Function to open the add Configuration fragment and save it reference in the controller instance for future references.
    Called on click of Add Button from table toolbar
    Parameters: oRef - Controller Reference */
    addShippingMaint.onAddConfigValues = function (oRef) {

        if (!oRef.oAddShipValues) {
            //Create fragment for Add Shipping Values
            oRef.oAddShipValues = sap.ui.xmlfragment("com.apple.scp.shipmentmaint.fragments.AddConfigValues", oRef);
            oRef.getView().getModel("localModel").refresh(true);

            oRef.getView().addDependent(oRef.oAddShipValues);
        }
        var oCVFieldsVisibility = sap.ui.getCore().byId("FormFields");
        var oNRFieldsVisibility = sap.ui.getCore().byId("NRFormFields");
        if (oRef.selectedKey === "keyCV") {
            oCVFieldsVisibility.setVisible(true);
            oNRFieldsVisibility.setVisible(false);
        } else {
            oCVFieldsVisibility.setVisible(false);
            oNRFieldsVisibility.setVisible(true);
        }
        oRef.oAddShipValues.open();
    };

    addShippingMaint.fnCloseAddDialog = function (tEvent) {
        tEvent.getSource().getParent().close();
    };

    return addShippingMaint;
});
