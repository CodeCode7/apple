sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties"
], function (Opa5, Press, Properties) {
    "use strict";
    var sViewName = "PrimaryData";
    var btnNames = {
        "searchBtn": "container-masterdataconfigsetting---PrimaryData--slFragment--idSearch",
        "editBtn": "container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnEdit",
        "saveBtn": "container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnSave",
        "cancelBtn": "container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnCancel",
        "uploadBtn" : "container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnUpload",
        "dialogUpload": "Upload",
        "dialogClose": "closeUpload"
    };

    Opa5.createPageObjects({
        onThePDPage: {

            actions: {
                iTriggerBtnPress: function (bRef) {
                    var bId = btnNames[bRef];
                    this.waitFor({
                        viewName: sViewName,
                        id: bId,
                        actions: new Press(),
                        errorMessage: "Button Not Found: " + bRef
                    });
                },

                iSearchDialogAndClickButton: function(bRef){
                    var bId  = btnNames[bRef];
                    this.waitFor({
                        searchOpenDialogs: true,
                        id: bId,
                        viewName: sViewName,
                        actions: new Press(),
                        errorMessage : "Button Not found: " + bRef
                    });
                }
            },

            assertions: {
                iShouldSeeBtn: function (bRef) {
                    var bId = btnNames[bRef];
                    return this.waitFor({
                        id: bId,
                        success: function () {
                            Opa5.assert.ok(true, "Button Found: " + bRef);
                        },
                        errorMessage: "Button not found: " + bRef
                    });
                },

                iShouldSeeUploadFragment: function(){
                    return this.waitFor({
                        fragmentId: "massUpload",
                        id: "idUploadDialog",
                        success: function(){
                            Opa5.assert.ok(true, "Upload Dialog opened");
                        },
                        errorMessage: "Upload Dialog could not be opened"
                    });
                },

                iShouldSeeErrorPopUp : function(){
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.Dialog",
                        matchers: new Properties({
                            title: "Error"
                        }),
                        success: function(){
                            Opa5.assert.ok(true, "Error Popup seen");
                        },
                        errorMessage: "Error PopUp not seen"
                    });
                },

                iShouldSeeTheApp: function () {
                    return this.waitFor({
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The " + sViewName + " view is displayed");
                        },
                        errorMessage: "Did not find the " + sViewName + " view"
                    });
                }
            }
        }
    });

});
