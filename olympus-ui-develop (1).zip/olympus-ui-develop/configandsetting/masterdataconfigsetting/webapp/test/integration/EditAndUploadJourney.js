/* global QUnit */

sap.ui.define([
    "sap/ui/test/opaQunit",
    "sap/ui/test/Opa5",
    "com/apple/scp/masterdataconfigsetting/test/integration/pages/PrimaryData",
    "com/apple/scp/masterdataconfigsetting/test/integration/arrangements/Startup"
], function (opaTest, Opa5) {
    "use strict";

    QUnit.module("Edit Journey");

    opaTest("Edit Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePDPage.iTriggerBtnPress("searchBtn"); //Search
        When.onThePDPage.iTriggerBtnPress("editBtn"); //Edit
        Then.onThePDPage.iShouldSeeBtn("saveBtn"); //Save
        When.onThePDPage.iTriggerBtnPress("cancelBtn"); //Cancel
        Then.onThePDPage.iShouldSeeBtn("editBtn"); //Edit
        When.onThePDPage.iTriggerBtnPress("editBtn"); //Edit
        When.onThePDPage.iTriggerBtnPress("saveBtn"); //Save
        Then.onThePDPage.iShouldSeeBtn("editBtn"); //Edit

        Then.iTeardownMyApp();
    });

    QUnit.module("Upload Journey");

    opaTest("Upload Functionality Lifecycle", function (Given, When, Then) {
        // Arrangements
        Given.iStartMyAppInAFrame("../../index.html?responderOn=true").done(function () {
            Opa5.assert.ok(document.getElementById("OpaFrame"), "The frame to be loaded");
        });

        //Actions & Assersions
        When.onThePDPage.iTriggerBtnPress("uploadBtn"); //Upload
        Then.onThePDPage.iShouldSeeUploadFragment();

        When.onThePDPage.iSearchDialogAndClickButton("dialogClose");
        When.onThePDPage.iTriggerBtnPress("uploadBtn"); //Upload
        When.onThePDPage.iSearchDialogAndClickButton("dialogUpload"); //Dialog Upload
        Then.onThePDPage.iShouldSeeErrorPopUp();

        Then.iTeardownMyApp();
    });
});
