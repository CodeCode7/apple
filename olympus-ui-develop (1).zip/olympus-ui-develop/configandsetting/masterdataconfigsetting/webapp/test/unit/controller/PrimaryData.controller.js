/*global QUnit*/

sap.ui.define([
    "com/apple/scp/masterdataconfigsetting/controller/PrimaryData.controller",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/smartfilterbar/SmartFilterBar",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel"
], function (Controller, UIComponent, aController, sFB, sTable, ManagedObject, JSONModel) {
    "use strict";
    const Button = sap.m.Button,
        ResourceModel = sap.ui.model.resource.ResourceModel,
        Event = sap.ui.base.Event,
        InstanceManager = sap.m.InstanceManager;
    const modulePath = "com/apple/scp/masterdataconfigsetting";
    QUnit.module("PrimaryData Controller", {
        beforeEach: function () {
            this.oPDController = new Controller();
        },
        afterEach: function () {
            this.oPDController.destroy();
        }
    });

    function jsonOk(body) {
        var mockResponse = new window.Response(JSON.stringify(body), { //the fetch API returns a resolved window Response object
            status: 200,
            headers: {
                'Content-type': 'application/json'
            }
        });

        return Promise.resolve(mockResponse);
    }

    function setViewAndLocalModel(oRef) {
        var oViewStub = new ManagedObject({});
        var lModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/masterdataconfigsetting/util" + "/technicalConfig.json")
        lModel.loadData(sPath, "", false);
        oViewStub.setModel(lModel, "localModel");
        oRef.selectedKey = 'keySL';
        return oViewStub;
    }

    QUnit.test("PrimaryData controller", function (assert) {
        // Arrange
        var olocalRouter = new sap.m.routing.Router([
            {
                "name": "RoutePrimaryData",
                "pattern": "",
                "target": [
                    "TargetPrimaryData"
                ]
            }
        ]);

        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getRouter").returns(olocalRouter);
        this.oPDController.onInit();
        assert.ok(this.oPDController);

        oCompStub.restore();
        oControllerStub.restore();
        oComp.destroy();
        olocalRouter.destroy();
    });

    QUnit.test("Smart Table search test", function (assert) {

        //Arrange
        var oSTable = new sTable("idsmartTable");
        var oViewStub = new ManagedObject({});

        var lModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/masterdataconfigsetting/util" + "/technicalConfig.json")

        lModel.loadData(sPath, "", false);

        oViewStub.setModel(lModel, "localModel");
        this.oPDController.selectedKey = 'keySL';

        var oSTableSpy = this.stub(sap.ui.comp.smarttable.SmartTable.prototype, "rebindTable");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oViewStub);
        var oSTableStub = sinon.stub(ManagedObject.prototype, "byId").returns(oSTable);

        //Act
        this.oPDController.onSearch();

        //Assert
        assert.strictEqual(oSTableSpy.callCount, 1, "Smart Table rebindTable event to be triggered");

        //CleanUp
        oSTableSpy.restore();
        oSTableStub.restore();
        oGetViewStub.restore();
        oViewStub.destroy();
        oSTable.destroy();
    });

    QUnit.test("Smart Filter Bar clear test", function (assert) {
        //Arrange
        var oSFB = new sFB("idsmartFilterBar");
        var oViewStub = setViewAndLocalModel(this.oPDController);

        var oSFBSpy = this.stub(sap.ui.comp.smartfilterbar.SmartFilterBar.prototype, "clear");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oViewStub);
        var oSFBStub = sinon.stub(ManagedObject.prototype, "byId").returns(oSFB);

        //Act
        this.oPDController.onClear();

        //Assert
        assert.strictEqual(oSFBSpy.callCount, 1, "Smart Filter Bar clear to be triggered");

        //CleanUp
        oSFBSpy.restore();
        oSFBStub.restore();
        oGetViewStub.restore();
        oSFB.destroy();
        oViewStub.destroy();
    });

    QUnit.test("Table Edit Functionality test", function (assert) {
        //Arrange
        var oViewStub = setViewAndLocalModel(this.oPDController);
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oViewStub);

        var btn = new Button();
        var viewByIdStub = sinon.stub(ManagedObject.prototype, "byId").returns(btn);

        this.oPDController.selectedKey = 'keySL';

        //Act & Assert
        this.oPDController.onEdit();
        var lModel = oViewStub.getModel("localModel");
        var mode = lModel.getProperty("/DisplayMode");
        assert.strictEqual(mode, false, "Edit Mode Set");


        this.oPDController.onEditSave();
        assert.strictEqual(lModel.getProperty("/DisplayMode"), true, "Display Mode Set");

        //Cleanup
        oGetViewStub.restore();
        viewByIdStub.restore();
        btn.destroy();
        oViewStub.destroy();
    });

    QUnit.test("getI18nText function test", function (assert) {
        //Arrange
        var oComp = new UIComponent();
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oResourceModel = new ResourceModel({ bundleUrl: sap.ui.require.toUrl("com/apple/scp/masterdataconfigsetting/i18n/i18n.properties") });
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(oResourceModel);

        //Action
        var aText = this.oPDController.getI18nText("appTitle");

        //Assert
        assert.strictEqual(aText, "Product Data", "Text for appTitle to be returned");

        //CleanUp
        oComp.destroy();
        oControllerStub.restore();
        oResourceModel.destroy();
        oCompStub.restore();
    });

    QUnit.test("View Initialisation", function (assert) {
        //Arrange
        var oViewStub = new ManagedObject({});
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oViewStub);

        var oSFB = new sFB("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartFilterBar");
        var oSTable = new sTable("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable");

        var oSFB2 = new sFB("container-masterdataconfigsetting---PrimaryData--meFragment--idsmartFilterBar");
        var oSTable2 = new sTable("container-masterdataconfigsetting---PrimaryData--meFragment--idsmartTable");

        var byIdStub = this.stub(ManagedObject.prototype, "byId");
        byIdStub.withArgs("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartFilterBar").returns(oSFB);
        byIdStub.withArgs("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable").returns(oSTable);
        byIdStub.withArgs("container-masterdataconfigsetting---PrimaryData--meFragment--idsmartFilterBar").returns(oSFB2);
        byIdStub.withArgs("container-masterdataconfigsetting---PrimaryData--meFragment--idsmartTable").returns(oSTable2);

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + "/i18n/i18n.properties")
        });

        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        //System under test & Assert
        this.oPDController.onRouteMatched();
        assert.strictEqual(this.oPDController.selectedKey, "keySL", "SourceList to be set as default tab");
        assert.strictEqual(oSTable.getHeader(), "Source List", "Smart Table Header to be initialised correctly");

        //Cleanup
        oGetViewStub.restore();
        byIdStub.restore();
        oViewStub.destroy();
        oSFB.destroy();
        oSTable.destroy();
        oSFB2.destroy();
        oSTable2.destroy();
        oControllerStub.restore();
        this._oResourceModel.destroy();
        oCompStub.restore();
        oComp.destroy();
    });

    QUnit.test("checkAuthorization function test", function (assert) {
        //Arrange
        var fnDone = assert.async();
        var oViewStub = setViewAndLocalModel(this.oPDController);
        var oGetViewStub = sinon.stub(this.oPDController, "getView").returns(oViewStub);
        var oComp = new UIComponent;
        oComp.isMock = false;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);

        var localJWT = {
            "decodedJWTToken":
                {
                    "scope":
                        [
                            "configandsetting!t9525.CONFIGANDSETTIING_DISPLAY",
                            "configandsetting!t9525.CONFIGANDSETTIING_CREATE",
                            "configandsetting!t9525.CONFIGANDSETTIING_UPDATE"
                        ]
                }
            };
        let stub = sinon.stub(window, 'fetch'); //add stub
        stub.onCall(0).returns(jsonOk(localJWT));

        var lModel = oViewStub.getModel("localModel");
        this.oPDController.checkAuthorization().then(function () {
            //Assert
            assert.strictEqual(lModel.getProperty("/createAccess"), true, "Create access to be granted");
            assert.strictEqual(lModel.getProperty("/editAccess"), true, "Edit access to be granted");
            assert.strictEqual(lModel.getProperty("/displayAccess"), true, "Display access to be granted");

            fnDone();

            //Cleanup
            oGetViewStub.restore();
            oViewStub.destroy();
            oComp.destroy();
            oControllerStub.restore();
        });
    });

    QUnit.test("onMassUpload function test", function (assert) {
        var oViewStub = new ManagedObject({});
        var oGetViewStub = sinon.stub(this.oPDController, "getView").returns(oViewStub);
        this.oPDController.onMassUpload();
        assert.ok(this.oPDController.oUpload);
        oViewStub.destroy();
        oGetViewStub.restore();
    });

    QUnit.test("onDownload function test", function (assert) {
        var oViewStub = setViewAndLocalModel(this.oPDController);
        var oGetViewStub = sinon.stub(this.oPDController, "getView").returns(oViewStub);

        var oBtn = new Button();
        var oBtnStub = sinon.stub(ManagedObject.prototype, "byId").returns(oBtn);
        var oBtnSpy = this.stub(sap.m.Button.prototype, "firePress");

        this.oPDController.onDownload();

        assert.strictEqual(oBtnSpy.callCount, 1, "Download function to be triggered");

        oViewStub.destroy();
        oGetViewStub.restore();
        oBtnStub.restore();
        oBtn.destroy();
    });

    QUnit.test("onInitialise function test", function (assert) {
        //Arrange
        var oViewStub = setViewAndLocalModel(this.oPDController);
        var oGetViewStub = sinon.stub(this.oPDController, "getView").returns(oViewStub);
        var oBtnToggle = new Button("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnEditToggle");
        var oBtnExport = new Button("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnExcelExport");

        var oByIDStub = sinon.stub(ManagedObject.prototype, "byId");
        oByIDStub.withArgs("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnEditToggle").returns(oBtnToggle);
        oByIDStub.withArgs("container-masterdataconfigsetting---PrimaryData--slFragment--idsmartTable-btnExcelExport").returns(oBtnExport);

        //System Under test
        this.oPDController.onInitialise();

        //Assert
        assert.strictEqual(oBtnToggle.getVisible(), false, "Standard Toolbar Toggle button visibility to be set to false");
        assert.strictEqual(oBtnExport.getVisible(), false, "Standard Toolbar Export button visibility to be set to false");

        //Clean Up
        oViewStub.destroy();
        oGetViewStub.restore();
        oBtnToggle.destroy();
        oBtnExport.destroy();
        oByIDStub.restore();
    });

    QUnit.test("onTabChange function test", function (assert) {
        var dEvent = new Event('oEvent', {}, { 'selectedKey': "keyME" });
        this.oPDController.onTabChange(dEvent);
        assert.strictEqual(this.oPDController.selectedKey, "keyME", "selectedKey Property to be updated to Material Extension");
    });

    QUnit.test("onUploadChange function test", function (assert) {
        var obj = { "name": "test.xlsx" };
        var dEvent = new Event("oEvent", {}, { "files": [obj] });
        this.oPDController.onUploadChange(dEvent);
        assert.strictEqual(this.oPDController.selectedFile, obj, "File selected to be captured");
    });

    QUnit.test("dataEditSuccessHandler function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + "/i18n/i18n.properties")
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var res = this.oPDController.dataEditSuccessHandler({}, this.oPDController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, true, "Success popup to be displayed");

        var sResponse = { "__batchResponses": [{ "response": { "statusCode": '403', "body": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Sample Error" } } }' } }] };
        res = this.oPDController.dataEditSuccessHandler(sResponse, this.oPDController, undefined, 0, false);
        assert.strictEqual(res.popUpDisplayed, false, "Success popup not to be displayed");

        InstanceManager.closeAllDialogs();
        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("dataEditErrorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Sample Error" } } }'
        };

        var errRec = this.oPDController.dataEditErrorHandler(oError, 0);
        assert.strictEqual(errRec, 1, "Error Record count to be incremented by 1");

        oError = {
            "responseText": "Sample Error"
        };

        errRec = this.oPDController.dataEditErrorHandler(oError, 0);
        assert.ok(errRec);
        InstanceManager.closeAllDialogs();

    });
});
