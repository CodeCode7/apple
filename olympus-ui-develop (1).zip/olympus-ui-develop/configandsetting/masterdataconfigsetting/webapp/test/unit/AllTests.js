sap.ui.define([
    "./controller/App.controller",
    "./controller/PrimaryData.controller",
    "./model/models",
    "./util/massUploadUtilities"
], function () {
    "use strict";
});
