/*global QUnit*/

sap.ui.define([
    "com/apple/scp/masterdataconfigsetting/controller/PrimaryData.controller",
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "com/apple/scp/masterdataconfigsetting/util/massUploadUtilities",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/unified/FileUploader"
], function (Controller, aController, UIComponent, massUploadUtil, ResourceModel, JSONModel, FileUploader) {
    "use strict";
    const Core = new sap.ui.core.Core(),
        ManagedObject = sap.ui.core.mvc.View,
        Dialog = sap.m.Dialog;
    const modulePath = "com/apple/scp/masterdataconfigsetting",
        i18nPath = "/i18n/i18n.properties",
        sErr = "Sample Error";

    QUnit.module("Mass Upload Utilities", {
        beforeEach: function () {
            this.oPDController = new Controller();
        },
        afterEach: function () {
            this.oPDController.destroy();
        }
    });

    QUnit.test("getErrorText Helper function Test", function (assert) {
        let tRet = " Error Text to be returned";

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '400'), "Incorrect input file/data, please recheck the file and then re-upload", "400" + tRet);
        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '401'), "Unauthorized request. Please re-authenticate and try again.", "401" + tRet);
        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '403'), "You are not authorised to perform requested action", "403" + tRet);
        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '404'), "Syntax Error in service. Reload and check, if issue persists contact admin", "404" + tRet);
        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '409'), "Duplicate Insert: Record already exists", "409" + tRet);
        assert.strictEqual(massUploadUtil.getErrorText(this.oPDController, '4', sErr), sErr, "Message to be passed back as is");

        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
        this._oResourceModel.destroy();
    });

    QUnit.test("strToBoolean function test", function (assert) {
        let tText = "Boolean true to be returned",
            fText = "Boolean false to be returned";

        //Assert
        var isolatedFcn = massUploadUtil.strToBoolean;
        assert.strictEqual(isolatedFcn("true"), true, tText);
        assert.strictEqual(isolatedFcn("yes"), true, tText);
        assert.strictEqual(isolatedFcn("1"), true, tText);
        assert.strictEqual(isolatedFcn("false"), false, fText);
        assert.strictEqual(isolatedFcn("no"), false, fText);
        assert.strictEqual(isolatedFcn("0"), false, fText);
        assert.strictEqual(isolatedFcn("00"), true, tText);
    });

    QUnit.test("prepareMassPayload function test", function (assert) {
        var data = [{
            "Created_By": "E0658289",
            "Created_On": "2003-01-28",
            "Mark_For_Deletion": "No",
            "Material": "M8892LL/A999",
            "Plant": "5601",
            "Valid_From": "2020-01-01",
            "Valid_To": "9999-12-31",
            "Vendor": "00029514P"
        }, {
            "Created_By": "E0658289",
            "Created_On": "2003-01-28",
            "Mark_For_Deletion": "No",
            "Material": "M8892LL",
            "Plant": "5601",
            "Valid_From": "2020-01-02",
            "Valid_To": "9999-12-31",
            "Vendor": "00029514P"
        }
        ];

        var lModel = new JSONModel();
        var sPath = sap.ui.require.toUrl("com/apple/scp/masterdataconfigsetting/util" + "/technicalConfig.json");
        lModel.loadData(sPath, "", false);

        var outputData = massUploadUtil.prepareMassPayload(data, lModel.getData().SelectedTabConfig.keySL);
        assert.strictEqual(outputData.length, 2, "Payload with 2 records to be created");
    });

    QUnit.test("showErrorLog function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var errMsgs = [{ "type": "Error", "title": "Sample Title", "description": "Long Error" }];
        massUploadUtil.showErrorLog(this.oPDController, errMsgs);
        assert.ok(massUploadUtil.oDialog);

        massUploadUtil.oDialog.destroy();
        oComp.destroy();
        oControllerStub.restore();
        oCompStub.restore();
    });

    QUnit.test("prepareErrArr function test", function (assert) {
        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var errArr = massUploadUtil.prepareErrArr('400', this.oPDController, 'Sample Error', [], massUploadUtil);
        errArr = massUploadUtil.prepareErrArr('401', this.oPDController, 'Sample Error 2', errArr, massUploadUtil);
        errArr = massUploadUtil.prepareErrArr('401', this.oPDController, 'Sample Error 2', errArr, massUploadUtil);

        assert.ok(errArr);

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
    });

    QUnit.test("parseErrorMessage function test", function (assert) {
        var oError = {
            "responseText": sErr
        };
        var msg = massUploadUtil.parseErrorMessage(oError);
        assert.strictEqual(msg, sErr, "Error Message for 401 to be parsed correctly");

        oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": "Error" } } }'
        };

        msg = massUploadUtil.parseErrorMessage(oError);
        assert.strictEqual(msg, "Error", "Error for non 401 to be parsed correctly");
    });

    QUnit.test("triggerPostCalls function test", function (assert) {
        var aPayload = [{ "F1": "V1" }, { "F1": "V2" }];
        massUploadUtil.triggerPostCalls(aPayload, undefined, {}, undefined);

        assert.ok(true);
    });

    QUnit.test("errorHandler function test", function (assert) {
        var oError = {
            "responseText": '{ "error": { "code": "BAD_REQUEST", "message": { "value": sErr } } }'
        };

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var oView = new ManagedObject({});
        var modelStub = sinon.stub(oView, 'getModel').returns(false); //add stub
        this.oPDController.oUpload = new Dialog("dDialog");
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oView);
        var returnRec = massUploadUtil.errorHandler(oError, this.oPDController, 0);

        assert.ok(returnRec);

        coreStub.restore();
        oGetViewStub.restore();
        oView.destroy();
        dUploader.destroy();
        modelStub.restore();
        this.oPDController.oUpload.destroy();
    });

    QUnit.test("fileSuccessHandler function test", function (assert) {
        this.oPDController.oUpload = new Dialog("dDialog");

        this._oResourceModel = new ResourceModel({
            bundleUrl: sap.ui.require.toUrl(modulePath + i18nPath)
        });
        var oComp = new UIComponent;
        var oControllerStub = sinon.stub(this.oPDController, "getOwnerComponent").returns(oComp);
        var oCompStub = sinon.stub(UIComponent.prototype, "getModel");
        oCompStub.withArgs("i18n").returns(this._oResourceModel);

        var oView = new ManagedObject({});
        var oGetViewStub = sinon.stub(aController.prototype, "getView").returns(oView);

        var dUploader = new FileUploader();
        var coreStub = sinon.stub(Core, "byId").returns(dUploader);

        var sResponse = {};
        var resp = massUploadUtil.fileSuccessHandler(sResponse, {}, this.oPDController, undefined, 0, false);
        assert.strictEqual(resp.popUpDisplayed, true, "All Success: Success popup to be displayed");

        oControllerStub.restore();
        oComp.destroy();
        oCompStub.restore();
        oView.destroy();
        oGetViewStub.restore();
        dUploader.destroy();
        coreStub.restore();
        this.oPDController.oUpload.destroy();
    });
});
