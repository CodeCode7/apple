sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "../util/massUploadUtilities",
    "../util/xlsx",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, massUploadUtil) {
        "use strict";
        const toggleBtn = '-btnEditToggle',
            exportBtn = '-btnExcelExport',
            propDisMode = '/DisplayMode',
            propEditSave = '/editSaveTrigger',
            propCreateAccess = '/createAccess',
            propEditAccess = '/editAccess',
            propDisAccess = '/displayAccess',
            modelName = 'localModel';

        return Controller.extend("com.apple.scp.masterdataconfigsetting.controller.PrimaryData", {
            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("RoutePrimaryData").attachMatched(this.onRouteMatched, this);
            },

            onRouteMatched: function () {
                this.setUpViewModel(); //Set up model
                this.initSmartControls(); //Initializes the smart controls
                this.checkAuthorization();
            },

            onInitialise: function () {
                var cData = this.getView().getModel(modelName).getData().SelectedTabConfig;
                this.hideControl([toggleBtn, exportBtn], cData); //Standard Toolbar buttons
            },

            checkAuthorization: function () {
                var localModel = this.getView().getModel(modelName);
                if (this.getOwnerComponent().isMock) {
                    //Mock Mode
                    localModel.setProperty(propCreateAccess, true);
                    localModel.setProperty(propEditAccess, true);
                    localModel.setProperty(propDisAccess, true);
                    return null;
                } else {
                    //Check for authorization
                    return fetch("/getUserInfo")
                        .then(res => res.json())
                        .then(oToken => {
                            var scopeArr = oToken.decodedJWTToken.scope;
                            if (scopeArr.some(a => a.includes("CONFIGANDSETTIING_CREATE"))) {
                                //Create
                                localModel.setProperty(propCreateAccess, true);
                            }

                            if (scopeArr.some(a => a.includes("CONFIGANDSETTIING_UPDATE"))) {
                                //Edit Authorization
                                localModel.setProperty(propEditAccess, true);
                            }

                            if (scopeArr.some(a => a.includes("CONFIGANDSETTIING_DISPLAY"))) {
                                //Display Authorization
                                localModel.setProperty(propDisAccess, true);
                            }
                        })
                        .catch();
                }
            },

            hideControl: function (idArr, cData) {
                for (var obj in cData) {
                    if (!cData.hasOwnProperty(obj)) {
                        continue;
                    }
                    for (var id in idArr) {
                        if (!idArr.hasOwnProperty(id)) {
                            continue;
                        }
                        var bID = cData[obj].TableID + idArr[id];
                        var refID = this.getView().byId(bID);
                        if (refID) {
                            refID.setVisible(false);
                        }

                    }

                }
            },

            setUpViewModel: function () {
                var lModel = new JSONModel();
                var sPath = sap.ui.require.toUrl("com/apple/scp/masterdataconfigsetting/util" + "/technicalConfig.json")
                lModel.loadData(sPath, "", false);

                this.getView().setModel(lModel, modelName);
                this.selectedKey = 'keySL';
            },

            initSmartControls: function () {
                this.setTableAndFilterEntities("keySL");
                this.setTableAndFilterEntities("keyME");
            },

            setTableAndFilterEntities: function (key) {
                var cData = this.getView().getModel(modelName).getData().SelectedTabConfig[key];

                //Set Entity set of Smart Filter Bar and Smart Table
                var oFilter = this.getView().byId(cData.FilterID);
                var oTable = this.getView().byId(cData.TableID);
                var entity = cData.ServiceEntitySet;
                oFilter.setEntitySet(entity);
                oTable.setEntitySet(entity);
                oTable.setSmartFilterId(cData.FilterID);
                oTable.setHeader(this.getI18nText(cData.i18nHeaderProperty));
            },

            onMassUpload: function () {
                massUploadUtil.onMassUpload(this);
            },

            fnCloseUploadDialog: function (oEvent) {
                massUploadUtil.fnCloseUploadDialog(oEvent);
            },

            getI18nText: function (idText) {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(idText);
            },

            onFileUpload: function () {
                var selKey = this.getView().byId("idIconTabBar").getSelectedKey();
                massUploadUtil.onFileUpload(this, this.getView().getModel(modelName).getData().SelectedTabConfig[selKey]);
            },

            onUploadChange: function (oEvent) {
                massUploadUtil.onUploadChange(oEvent, this);
            },

            dataEditSuccessHandler: function (odata, that, tabModel, errorRecords, popUpDisplayed) {
                sap.ui.core.BusyIndicator.hide();
                //Check odata response status
                if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                    //Forbidden
                    errorRecords = errorRecords + 1;
                    //Parse the error message
                    var responseText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value;
                    //Show error message in Error popup
                    sap.m.MessageBox.error(responseText);
                    if (tabModel) {
                        tabModel.resetChanges();
                    }
                } else {
                    //Show success message if all records created successfully
                    if (errorRecords < 1 && !popUpDisplayed) {
                        //Success Message Toast
                        sap.m.MessageToast.show(that.getI18nText("dataUpdated"));
                        popUpDisplayed = true;
                    }
                }

                return { "errorRecords": errorRecords, "popUpDisplayed": popUpDisplayed };
            },

            dataEditErrorHandler: function (oError, errorRecords, tabModel) {
                sap.ui.core.BusyIndicator.hide();
                errorRecords = errorRecords + 1; //Count the number of records for which error is occuring
                //Parse the error message
                try {
                    var responseText = JSON.parse(oError.responseText).error.message.value;
                } catch (exception) {
                    responseText = oError.responseText;
                }

                //Show error message in Error popup
                sap.m.MessageBox.error(responseText);
                if (tabModel) {
                    tabModel.resetChanges();
                }

                return errorRecords;
            },

            dataEdited: function (oEvent) {
                if (!oEvent.getParameter('editable') && this.getView().getModel(modelName).getData().editSaveTrigger) {
                    var errorRecords = 0,
                        popUpDisplayed = false,
                        that = this;

                    var tabModel = oEvent.getSource().getModel(); //Table Model

                    var mParameters = {
                        //Success event of OData model
                        success: function (odata) {
                            var res = that.dataEditSuccessHandler(odata, that, tabModel, errorRecords, popUpDisplayed);
                            errorRecords = res.errorRecords;
                            popUpDisplayed = res.popUpDisplayed;
                        },
                        //Error event of OData model
                        error: function (oError) {
                            errorRecords = that.dataEditErrorHandler(oError);
                        }
                    };
                    sap.ui.core.BusyIndicator.show(0);
                    tabModel.submitChanges(mParameters);
                }
            },

            onTabChange: function (tEvent) {
                this.selectedKey = tEvent.getParameter('selectedKey');
            },

            onSearch: function () {
                var tabId = this.getView().getModel(modelName).getData().SelectedTabConfig[this.selectedKey].TableID;
                this.getView().byId(tabId).rebindTable(true);
            },

            onClear: function () {
                var filterId = this.getView().getModel(modelName).getData().SelectedTabConfig[this.selectedKey].FilterID;
                this.getView().byId(filterId).clear();
            },

            onEdit: function () {
                var lModel = this.getView().getModel(modelName);
                lModel.setProperty(propEditSave, false);
                lModel.setProperty(propDisMode, false);
                var bID = lModel.getData().SelectedTabConfig[this.selectedKey].TableID + toggleBtn;
                this.getView().byId(bID).firePress(); //Change Mode
            },

            onEditSave: function () {
                var lModel = this.getView().getModel(modelName);
                lModel.setProperty(propEditSave, true);
                lModel.setProperty(propDisMode, true);
                var bID = lModel.getData().SelectedTabConfig[this.selectedKey].TableID + toggleBtn;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onEditCancel: function (oEvent) {
                var lModel = this.getView().getModel(modelName);
                lModel.setProperty(propEditSave, false);
                lModel.setProperty(propDisMode, true);
                oEvent.getSource().getParent().getParent().getModel().resetChanges(); //Resets changed data

                var bID = lModel.getData().SelectedTabConfig[this.selectedKey].TableID + toggleBtn;
                this.getView().byId(bID).firePress(); //Display Mode
            },

            onDownload: function () {
                var lModel = this.getView().getModel(modelName);
                var bID = lModel.getData().SelectedTabConfig[this.selectedKey].TableID + '-btnExcelExport-internalSplitBtn';
                var btnRef = this.getView().byId(bID);
                if (btnRef) {
                    this.getView().byId(bID).firePress(); //Standard Export Data Fire
                }
            }
        });
    });
