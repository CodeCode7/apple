/* Mass Upload function utilities : Uses SheetJS Library */
/* Contains all the methods needed in lifecycle of Excel Mass upload to OData Service.
   Author : Jyotsna Singam (jsingam) */
sap.ui.define([
    'sap/ui/core/IconPool',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageItem',
    'sap/m/MessageView',
    'sap/m/Button',
    'sap/m/Dialog',
    'sap/m/Title'], function (IconPool, JSONModel, MessageItem, MessageView, Button, Dialog, Title) {
        "use strict";
        var massUploadUtilities = {};

        /* Function to open the mass upload fragment and save it reference in the controller instance for future references.
        Called on click of Upload Button from table toolbar
        Parameters: oRef - Controller Reference */
        massUploadUtilities.onMassUpload = function (oRef) {
            if (!oRef.oUpload) {
                //Create fragment for Mass Create
                oRef.oUpload = sap.ui.xmlfragment("com.apple.scp.masterdataconfigsetting.fragments.massUpload", oRef);
                oRef.getView().addDependent(oRef.oUpload);
            }
            oRef.oUpload.open();
        };

        /* Functions used to close the dialog instance. Called on click of close button on upload Dialog
        Parameters: tEvent - Triggered Event */
        massUploadUtilities.fnCloseUploadDialog = function (tEvent) {
            tEvent.getSource().getParent().close();
            tEvent.getSource().getParent().getContent()[0]._aElements[0].clear(); //Clear file uploader
        };

        /* Helper function to get Friendly error text */
        massUploadUtilities.getErrorText = function (oRef, statusCode, omsg) {
            var message;
            switch (statusCode) {
                case '400':
                    message = oRef.getI18nText("IncorrectFile");
                    break;
                case '401':
                    message = oRef.getI18nText("ReAuthError");
                    break;
                case '403':
                    message = oRef.getI18nText("AuthErr");
                    break;
                case '404':
                    message = oRef.getI18nText("SyntaxErr");
                    break;
                case '409':
                    message = oRef.getI18nText("DuplicateErr");
                    break;
                default:
                    message = omsg;
            }
            return message;
        };

        massUploadUtilities.parseErrorMessage = function (oError) {
            try {
                var responseText = JSON.parse(oError.responseText);
                var msg = responseText.error.message.value;
            } catch (exception) {
                msg = oError.responseText;
            }

            return msg;
        };

        /* Helper Function for error handler */
        massUploadUtilities.errorHandler = function (oError, oRef, errRecords) {
            sap.ui.core.BusyIndicator.hide();

            errRecords = errRecords + 1; //Count the number of error records
            oRef.oUpload.close(); //Close Dialog popup

            var msg = massUploadUtilities.parseErrorMessage(oError);

            oRef.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear();

            if (oRef.getView().getModel()) {
                oRef.getView().getModel().resetChanges(); //Reset OData model pending changes
            }

            return { "errRecords": errRecords, "msg": msg };
        };

        /* Helper Function Collect Error messages */
        massUploadUtilities.prepareErrArr = function (eStatusCode, oRef, msg, errArr, that) {
            var message = {'type': 'Error', 'title': that.getErrorText(oRef, eStatusCode, msg)};

            if (eStatusCode !== '400') { message.description = msg; }

            var existingRecord = errArr.find(rec => rec.title === message.title && rec.description === message.description);
            if (existingRecord) {
                if (eStatusCode !== '400') { existingRecord.counter++; }
            } else { //New Error
                if (eStatusCode !== '400') { message.counter = 1; }
                errArr.push(message); //Do not push duplicates
            }

            return errArr;
        };

        /* Helper Function */
        massUploadUtilities.triggerPostCalls = function (aPayload, tModel, oParameters, oServName) {
            //Make POST calls one by one for each record in the file
            for (var j in aPayload) {
                if (aPayload.hasOwnProperty(j)) {
                    oParameters.properties = aPayload[j];
                    oParameters.changeSetId = "changeset " + j; //Force Unique changeset
                    if (tModel) {
                        tModel.createEntry(oServName, oParameters);
                    }
                }
            }
        };

        massUploadUtilities.fileSuccessHandler = function (odata, response, oRef, tModel, errRecords, popUpDisplayed) {
            console.log(response);
            sap.ui.core.BusyIndicator.hide();
            oRef.oUpload.close(); //Close dialog popup

            if (odata.__batchResponses && odata.__batchResponses[0].response.statusCode === '403') {
                //Forbidden - Auth Error from API
                errRecords = errRecords + 1;
                var responseText = JSON.parse(odata.__batchResponses[0].response.body).error.message.value; //Parse the error message
                sap.m.MessageBox.error(responseText); //Show error message in Error popup

                if (tModel) {
                    tModel.resetChanges();
                }
            } else {
                //Show success message if all records created successfully
                if (errRecords < 1 && !popUpDisplayed) {
                    sap.m.MessageToast.show(oRef.getI18nText("objectsCreated")); //Success Message Toast
                    popUpDisplayed = true;
                }
            }
            oRef.getView().setBusy(false);
            sap.ui.getCore().byId("idFileUploader").clear(); //Clear file uploader file

            return { "errRecords": errRecords, "popUpDisplayed": popUpDisplayed };
        };

        /* Function for Upload Data click. Reads, parses and calls function to build Payload and triggers batch POST call on the
           service entity passed in configData.ServiceEntitySet
           Parameters:
            oRef - Calling controller Reference
            configData - JSON Model holding
            {"ServiceEntitySet": "<Entity Name>",
                "DataFields": { "<DateFieldName1>" : true,
                                "<DateFieldName2>" : true" ... } } */
        massUploadUtilities.onFileUpload = function (oRef, configData) {
            //Mass Create
            var errRecords = 0,
                popUpDisplayed = false,
                exceldata = {},
                that = this,
                errArr = [];

            var oServName = configData.ServiceEntitySet;

            //Return if no file is available to upload
            if (oRef.selectedFile === undefined) {
                sap.m.MessageBox.error(oRef.getI18nText("fileNotFound"));
            }

            //Get XLSX Instance
            if (XLS) {
                var exInst = XLS;
            } else if (XLSX) {
                exInst = XLSX;
            }

            //Check if file exists
            if (oRef.selectedFile && window.FileReader) {
                var reader = new FileReader();
                reader.onload = function (rawData) {
                    var data = rawData.target.result;
                    //Read data from excel file
                    var wbook = exInst.read(data, {
                        type: 'binary'
                    });
                    wbook.SheetNames.forEach(function (sheetName) {
                        // Here is your object for every sheet in wbook
                        exceldata = exInst.utils.sheet_to_row_object_array(wbook.Sheets[sheetName]);
                    });

                    //Return if file contains no data
                    if (exceldata.length < 1) {
                        sap.m.MessageBox.error(oRef.getI18nText("fileContainsNoRecord"));
                        return;
                    }
                    //Prepare payload for upload
                    var aPayload = that.prepareMassPayload(exceldata, configData);

                    //Get default OData model
                    var tModel = oRef.getView().getModel();
                    tModel.setUseBatch(true);

                    var oParameters = {
                        //Success event of OData model
                        success: function (odata, response) {
                            var returnData = massUploadUtilities.fileSuccessHandler(odata, response, oRef, tModel, errRecords, popUpDisplayed);
                            errRecords = returnData.errRecords;
                            popUpDisplayed = returnData.errRecords;
                        },
                        //Error event of OData model
                        error: function (oError) {
                            var returnRec = massUploadUtilities.errorHandler(oError, oRef, errRecords);
                            errRecords = returnRec.errRecords;
                            errArr = massUploadUtilities.prepareErrArr(oError.statusCode, oRef, returnRec.msg, errArr, that);
                        }
                    };

                    //Make POST calls one by one for each record in the file
                    massUploadUtilities.triggerPostCalls(aPayload, tModel, oParameters, oServName);

                    sap.ui.core.BusyIndicator.show(0);
                    //Submit OData model pending changes
                    var oPromise = new Promise(function (resolve, reject) {
                        tModel.submitChanges({
                            success: function () {
                                resolve();
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                    });
                    oPromise
                        .then(function () {
                            //Do nothing - No log to be shown
                        }, function (oError) {
                            var msg = massUploadUtilities.parseErrorMessage(oError); //Parse Error Message
                            errArr = massUploadUtilities.prepareErrArr(oError.statusCode, oRef, msg, errArr, this); //Collect Error messages
                        })
                        .finally(() => {
                            if (errArr.length > 0) {
                                //Show consolidated Error log at the end of submitChanges processing, if any
                                that.showErrorLog(oRef, errArr);
                            }
                        });
                };
                reader.onerror = function (exception) {
                    sap.m.MessageBox.error(oRef.getI18nText("ReadError"));
                    console.log(exception); //For troubleshooting
                };
                reader.readAsBinaryString(oRef.selectedFile);
            }
        };

        /* Helper function to show Message View for Errors, if any */
        massUploadUtilities.showErrorLog = function (oRef, errArr) {
            var that = this;
            var oMessageTemplate = new MessageItem({
                type: '{type}',
                title: '{title}',
                description: '{description}',
                counter: '{counter}'
            });

            var oModel = new JSONModel();
            oModel.setData(errArr);

            var oBackButton = new Button({
                icon: IconPool.getIconURI("nav-back"),
                visible: false,
                press: function () {
                    that.oMessageView.navigateBack();
                    this.setVisible(false);
                }
            });

            this.oMessageView = new MessageView({
                showDetailsPageHeader: false,
                itemSelect: function () {
                    oBackButton.setVisible(true);
                },
                items: {
                    path: "/",
                    template: oMessageTemplate
                }
            });

            this.oMessageView.setModel(oModel);

            this.oDialog = new Dialog({
                resizable: true,
                content: this.oMessageView,
                state: 'Error',
                beginButton: new Button({
                    press: function () {
                        this.getParent().close();
                    },
                    text: oRef.getI18nText("close")
                }),
                customHeader: new sap.m.Bar({
                    contentLeft: [oBackButton],
                    contentMiddle: [
                        new Title({ text: oRef.getI18nText("ErrorLog") })
                    ]
                }),
                contentHeight: "50%",
                contentWidth: "50%",
                verticalScrolling: false
            });

            this.oMessageView.navigateBack();
            this.oDialog.open();
        };

        /* Function used internally to prepare payload from excel data
        Parameters: exceldata - Excel Data
                    configData - configData - JSON Model holding
                    {"ServiceEntitySet": "<Entity Name>",
                     "DataFields": { "<DateFieldName1>" : true,
                                     "<DateFieldName2>" : true" ... } }*/
        massUploadUtilities.prepareMassPayload = function (exceldata, configData) {
            var rowObj = {},
                aPayload = [];

            //Prepare payload for Mass Create Upload - Loop over each rows' cell
            for (let a = 0; a < exceldata.length; a++) { //Loops over rows
                rowObj = {};
                for (let cell in exceldata[a]) { //Reads each column within the row
                    if (!exceldata[a].hasOwnProperty(cell)) {
                        continue;
                    }
                    if (configData.DateFields && configData.DateFields[cell]) {
                        //Value to be collected as Date instead of string
                        rowObj[cell] = new Date(exceldata[a][cell]);
                    }
                    else if (configData.BooleanFields && configData.BooleanFields[cell]) {
                        //Value to be collected as Boolean instead of string
                        rowObj[cell] = this.strToBoolean(exceldata[a][cell]);
                    }
                    else {
                        rowObj[cell] = (exceldata[a][cell]).toString();
                    }

                }
                aPayload.push(rowObj);
            }
            return aPayload;
        };

        /* Helper function to convert string to boolean */
        massUploadUtilities.strToBoolean = function (str) {
            switch (str.toLowerCase().trim()) {
                case "true": case "yes": case "1": return true;
                case "false": case "no": case "0": return false;
                default: return Boolean(str);
            }
        };

        /* 'change' Event handler function when FileUploader
            Parameters: oEvent - Triggered Event
                        oRef - Calling controller Reference */
        massUploadUtilities.onUploadChange = function (oEvent, oRef) {
            //Update selected file for future reference
            oRef.selectedFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        };

        return massUploadUtilities;
    });
