sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/apple/scp/masterdataconfigsetting/model/models",
    "sap/ui/Device",
    "sap/base/util/UriParameters",
    "com/apple/scp/masterdataconfigsetting/localService/mockserver",
    "sap/ui/model/odata/v2/ODataModel"
], function (UIComponent, model, Device, UriParameters, MockServer, ODataModel) {
    "use strict";

    return UIComponent.extend("com.apple.scp.masterdataconfigsetting.Component", {

        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            UIComponent.prototype.init.apply(this, arguments); // call the base component's init function
            this.getRouter().initialize(); // enable routing
            this.setModel(model.createDeviceModel(), "device"); // set the device model

            this.isMock = UriParameters.fromURL(window.location.href).get("responderOn");
            if (this.isMock) {
                //Start Mock Server
                this.oMockserver = MockServer.init();

                //Set Mockmodel to Component
                var oModel = new ODataModel(this.oMockserver.sMockServerUrl, {
                    json: true
                });

                this.setModel(oModel);
            } else {
                this.fetchAppID();
            }
        },

        fetchAppID: function () {
            var that = this;
            fetch("/getAppVariables").then(response => response.json()).then(appID => {
                that.loadMetadataWithAppID(appID);
            });
        },

        loadMetadataWithAppID: function (id) {
            var oParams = {
                defaultBindingMode: "TwoWay",
                disableHeadRequestForToken: true,
                headers: {
                    appID: id
                }
            };

            var uri = this.getManifestEntry("/sap.app/dataSources/mainService").uri;
            var oDataModel = new sap.ui.model.odata.v2.ODataModel(uri, oParams);
            this.setModel(oDataModel);
        }

    });
});
