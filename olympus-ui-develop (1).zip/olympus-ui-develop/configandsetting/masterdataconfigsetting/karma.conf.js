module.exports = function (config) {
    config.set({
        async: true,
        frameworks: ["ui5"],

        ui5: {
            configPath: "ui5-test.yaml"
        },

        browsers: ["ChromeHeadless"],

        reporters: ['progress', 'coverage'],
        preprocessors: {
            'webapp/Component.js': ['coverage'],
            'webapp/!(test)/!(xlsx).js': ['coverage']
        },
        pingTimeout: 900000,
        coverageReporter: { type: 'lcov', dir: 'coverage', subdir: 'reports' },
        browserNoActivityTimeout: 900000
    });

    require("karma-ui5/helper").configureIframeCoverage(config);
};
