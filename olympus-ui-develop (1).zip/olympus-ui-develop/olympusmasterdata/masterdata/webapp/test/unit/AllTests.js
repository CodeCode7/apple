sap.ui.define([
    "./formatter/formatter",
    "./controller/App.controller",
    "./controller/BaseController",
    "./controller/MasterData.controller",
    "./controller/MasterDetails.controller",
    "./model/models"
], function () {
    "use strict";
});
