sap.ui.define([
    "./BaseController"
],
    function (BaseController) {
        "use strict";

        return BaseController.extend("com.apple.scp.masterdata.controller.MasterData", {
            onInit: function () {
            },
            onSearch: function () {
                this.getView().byId("masterSmartTable").rebindTable(true);
            },
            filterIntialise:function(){
                this.hideExportButtonMasterData();
            },
            hideExportButtonMasterData:function(){
                var exportButtonID = this.getView().getId()+ '--masterSmartTable-btnExcelExport';
                var buttonRef = this.getView().byId(exportButtonID);
                buttonRef.setVisible(false);
            },
            onDownloadMasterData:function(){
                var exportButtonID = this.getView().getId()+ '--masterSmartTable-btnExcelExport-internalSplitBtn';
                var buttonRef = this.getView().byId(exportButtonID);
                if (buttonRef) {
                    buttonRef.firePress();
                }
            },
            onClear: function () {
                this.getView().byId('smartFilterBar').clear();
            },
            navigateToMasterDetails: function (oEvent) {
                var bindingPath = oEvent.getSource().getBindingContextPath();
                var dataRef = oEvent.getSource().getModel().getProperty(bindingPath);
                this.getRouter().navTo("MasterDetails", {
                    MPN: encodeURIComponent(dataRef.Material)
                });
            },
        });
    });
