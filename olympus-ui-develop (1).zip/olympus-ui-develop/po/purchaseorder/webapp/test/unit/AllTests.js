sap.ui.define([
    "./formatter/formatter",
    "./controller/App.controller",
    "./controller/BaseController",
    "./controller/PurchaseOrder.controller",
    "./controller/PODetails.controller",
    "./model/models"
], function () {
    "use strict";
});
