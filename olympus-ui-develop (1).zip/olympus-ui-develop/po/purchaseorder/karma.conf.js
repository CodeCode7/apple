module.exports = function (config) {
    config.set({
        async: true,
        frameworks: ["ui5"],

        ui5: {
            failOnEmptyTestPage: true,
            configPath: "ui5-test.yaml"
        },

        singleRun: true,

        reporters: ['progress', 'coverage'],
        preprocessors: {
            'webapp/Component.js': ['coverage'],
            'webapp/!(test)/*.js': ['coverage']
        },
        coverageReporter: { type: 'lcov', dir: 'coverage', subdir: 'reports' },
        browsers: ["ChromeHeadless"],
        pingTimeout: 900000,
        browserNoActivityTimeout: 10000
    });

    require("karma-ui5/helper").configureIframeCoverage(config);
};
