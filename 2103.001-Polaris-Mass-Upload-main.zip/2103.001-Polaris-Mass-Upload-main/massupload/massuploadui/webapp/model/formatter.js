sap.ui.define([], function () {
    "use strict";

    return {

        fnIconStatusState: function (sIconStatus) {
            var strIcon;
            if (sIconStatus === "C") {
                strIcon = "sap-icon://message-success";
                return strIcon;
            } else if (sIconStatus === "E") {
                strIcon = "sap-icon://message-error";
                return strIcon;

            } else if (sIconStatus === "P") {
                strIcon = "sap-icon://message-warning";
                return strIcon;
            } else {
                strIcon = "sap-icon://message-information";
                return strIcon;
            }
        },
        fnErrorStatus: function (sMsgStatus) {
            if (sMsgStatus === "E") {
                return "View Details  |";
            } else if (sMsgStatus === "C") {
                return "";

            }
        },
        fnErrorDwdStatus: function (sMsgStatus) {
            if (sMsgStatus === "E") {
                return "Download";
            } else if (sMsgStatus === "C") {
                return "";

            }
        },

        fnMessageTextStatus: function (sMsgStatus) {

            if (sMsgStatus === "C") {
                return "Success";
            } else if (sMsgStatus === "E") {
                return "Error";

            } else if (sMsgStatus === "P") {
                return "In Progress";

            } else if (sMsgStatus === "I") {
                return "Duplicate";

            } else {
                return "Waiting";
            }
        },

        fnFileStatus: function (sMsgStatus) {

            if (sMsgStatus === "Success") {
                return "C";
            } else if (sMsgStatus === "Error") {
                return "E";

            } else if (sMsgStatus === "In Progress") {
                return "P";

            } else {
                return "";
            }
        },
        fnMessageStatusState: function (sMsgStatus) {

            if (sMsgStatus === "C") {
                return "Success";
            } else if (sMsgStatus === "E") {
                return "Error";

            } else if (sMsgStatus === "P") {
                return "Warning";

            } else {
                return "None";
            }
        },
        isValidDate: function (date) {
            if (date.length > 8) {
                return false;
            } else {
                var sDate = date.slice(0, 4) + '/' + date.slice(4, 6) + '/' + date.slice(6, 8);
                var matches = /(\d{4})[-\/](\d{2})[-\/](\d{2})/.exec(sDate);
                if (matches == null) {
                    return false;
                }
                return true;
            }
        },
        isValidTime: function (sTime) {
            var pattern = /^(?:[01]?\d|2[0-3]):[0-5]\d:[0-5]\d$/;
            if (!sTime.match(pattern)) {
                return false;
            }
        },
        dateFormat: function (oDate) {
            var dateText = oDate.slice(0, 4) + '-' + oDate.slice(4, 6) + '-' + oDate.slice(6, 8);

            return dateText;

        },
        timeFormat: function (oTime) {
            var timeText = oTime.slice(0, 2) + ':' + oTime.slice(2, 4) + ':' + oTime.slice(4, 6);
            return timeText;

        },
    };

});
