sap.ui.define([
 "sap/ui/core/UIComponent",
 "sap/ui/Device",
 "com/apple/massuploadui/model/models",
 "sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
 "use strict";

 return UIComponent.extend("com.apple.massuploadui.Component", {

        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            var sMUUrl = window.parent.location.href;
            var sMsgTxt = "Please access Mass Upload from Enterprise Portal";
            var sMsgTitle = "Access From Enterprise Portal";

            if (sMUUrl.includes("epweb")) {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);
                // enable routing
                this.getRouter().initialize();
                // set the device model
                this.setModel(models.createDeviceModel(), "device");
            }
            if (sMUUrl.includes("massuploadcloud")) {
            
                MessageBox.error(sMsgTxt, {
                    title: sMsgTitle,
                    onClose: function (oAction) {

                        if (oAction === "OK") {

                            return;
                        }
                    },

                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK,
                    initialFocus: MessageBox.Action.OK,

                    textDirection: sap.ui.core.TextDirection.Inherit
                });

            }



        }
    });
});