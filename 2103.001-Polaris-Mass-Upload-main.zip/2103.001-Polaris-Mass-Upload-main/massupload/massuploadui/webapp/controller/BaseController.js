sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/m/MessageBox",
    "sap/m/BusyDialog",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    "jquery.sap.global",
    "sap/m/MessageToast",
], function (Controller, formatter, MessageBox, BusyDialog, Export, ExportTypeCSV, JQuery, MessageToast) {
    "use strict";

    return Controller.extend("com.apple.massuploadui.controller.BaseController", {
        formatter: formatter,
        onInit: function () {
            this.oBusyDialog = new BusyDialog();
        },

        onDownloadAll: function () {
            this.onShipmentDownload();
            this.onNBConfirm();
            this.onBConfirm();
        },
        handleErrorDownload: function (oEvent) {
            var indexErr = parseInt(oEvent.getSource().getBindingContext().getPath().split("/HistoryData/")[1]);
            var sErrLogData = this.oHistoryDataModel.getProperty("/HistoryLineData");
            var sErrLogLineItem = sErrLogData[indexErr];
            this.oHistoryDataModel.setProperty("/LineItems", sErrLogLineItem);
            var test = ["URN_NO", "CTN", "CONTAINER_NO", "SHIPMENT_ID", "SRCID", "EVTID", "EVTDAT", "BOL", "ERROR_LOG"];
            var testHeaders = ["Reference No.", "Carrier Tracking No.", "Container No.", "Shipment ID", "Source ID", "Event ID", "Event Date", "BOL", "Error Log"];

            this.errorData = [];
            for (var k = 0; k < testHeaders.length; k++) {
                var objError = {};
                var objTemplate = {};
                objError.name = testHeaders[k];
                objError.template = objTemplate;
                objTemplate.content = "{" + test[k] + "}";
                this.errorData.push(objError);

            }
            var oELExport = new Export({
                exportType: new ExportTypeCSV({
                    fileExtension: "csv",
                    separatorChar: ","
                }),
                models: this.oHistoryDataModel,
                rows: {
                    path: "/LineItems"
                },
                columns: this.errorData
            });
            oELExport.saveFile("ErrorLogs").catch(function (oError) {
                sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
            }).then(function () {
                oELExport.destroy();
            });
        },
        assetExport: function (sDType, sURNum,sDwnFile) {
            var dSCAC = "";
            var sDwdFile = sDwnFile.split(".")[0];
            var that = this;
            if (sDType === "214") {
                that.getShipmentData(that.columnHeaders);
                var aAssetData = that.ApplicationModel.getProperty("/GetAssetData");
                for (var i = 0; i < aAssetData.length; i++) {
                    dSCAC = aAssetData[1].SCAC;
                    aAssetData[i].EventTimezone = aAssetData[i]["Event Time zone(UTC+/-HH:MM)"];
                    aAssetData[i].NetWeightUOM = aAssetData[i]["Net Weight UOM(KG/LB)"];

                }
                that.ApplicationModel.setProperty("/GetSAssetData", aAssetData);
                var oASTExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: that.ApplicationModel,
                    rows: {
                        path: "/GetSAssetData"
                    },
                    columns: that.shipmentData
                });
              
            
                oASTExport.saveFile(sDwdFile).catch(function (oError) {
                MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oASTExport.destroy();
                    that.ApplicationModel.setProperty("/GetAssetData", []);
                    that.ApplicationModel.setProperty("/GetSAssetData", []);
                });
            }
            if (sDType === "315NBF") {
                that.getNBookData(that.columnNBFHeaders);
                var aAssetData = that.ApplicationModel.getProperty("/GetAssetData");
                for (var i = 0; i < aAssetData.length; i++) {
                    dSCAC = aAssetData[1].SCAC;
                    aAssetData[i].EventTimezone = aAssetData[i]["Event Time zone(UTC+/-HH:MM)"];
                    aAssetData[i].FlightNo = aAssetData[i]["Flight/Voyage No."];
                }
                that.ApplicationModel.setProperty("/GetNBAssetData", aAssetData);
                var oNBFExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: that.ApplicationModel,
                    rows: {
                        path: "/GetNBAssetData"
                    },
                    columns: that.NBData
                });
                oNBFExport.saveFile(sDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oNBFExport.destroy();
                    that.ApplicationModel.setProperty("/GetAssetData", []);
                    that.ApplicationModel.setProperty("/GetNBAssetData", []);
                });
            }
            if (sDType === "315BF") {
                this.getBookData(that.columnBFHeaders);
                var aAssetData = that.ApplicationModel.getProperty("/GetAssetData");
                for (var i = 0; i < aAssetData.length; i++) {
                    dSCAC = aAssetData[1].SCAC;
                    aAssetData[i].EventTimezone = aAssetData[i]["Event Time zone(UTC+/-HH:MM)"];

                }
                that.ApplicationModel.setProperty("/GetBAssetData", aAssetData);
                var oBFExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: that.ApplicationModel,
                    rows: {
                        path: "/GetBAssetData"
                    },
                    columns: that.BData
                });

                oBFExport.saveFile(sDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oBFExport.destroy();
                    that.ApplicationModel.setProperty("/GetAssetData", []);
                    that.ApplicationModel.setProperty("/GetBAssetData", []);
                });
            }

        },
        onChangeButton: function () {
            this.byId("idLabelType").setVisible(false);
            this.byId("idCombo").setVisible(false);
            this.byId("idLabelUpload").setVisible(false);
            this.byId("idResetButton").setVisible(false);
            this.byId("idUploadButton").setVisible(false);
            this.byId("fileUploader").setVisible(false);
            this.byId("idPanel").setVisible(true);
            this.byId("idCancelButton").setVisible(true);
        },
        pythonSTValidation: function (sDocType, oFile) {
            this.count = "";
            this.sDocType = sDocType;
            var that = this;
            var aValdata = [];
            var form_data = new FormData();
            form_data.append('file', oFile, oFile.name);
            JQuery.ajax({
                "url": "/UI5/v1/users/validate-file",
                "method": "POST",
                "mimeType": "multipart/form-data",
                "data": form_data,
                "processData": false,
                contentType: false,
                success: function (data, textStatus, XMLHttpRequest) {
                    var aValRes = JSON.parse(data).Result;
                    if (Object.keys(aValRes).length > 0) {
                        var aNOR = JSON.parse(data).number_of_records;
                        that.count = parseInt(aNOR);
                        for (var q = 1; q <= parseInt(aNOR); q++) {
                            if (aValRes[q] !== undefined && aValRes[q].Error !== undefined) {
                                aValdata.push(aValRes[q]);
                                aErrorlog.push({ ErrorFlag: true });
                            } else {
                                aValdata.push(aValRes[q]);
                            }
                        }
                        that.byId("idDwdtemplate").setVisible(false);
                        that.byId("idErrordwnd").setVisible(true);

                    }
                    that.ApplicationModel.setProperty("/UploadData", aValdata);
                    var aSValdata = that.ApplicationModel.getProperty("/UploadData");
                    that.byId("idUploadTable").setModel(that.ApplicationModel);
                    that.onShipmentPostValidation(aSValdata);

                },
                error: function (data) {

                    that.oBusyDialog.close();

                    var eData = data.status;
                    var eEData = data.responseText;
                    MessageToast.show("Sevice Error:" + eData + "-" + eEData);
                }
            });

        },
        pythonBFValidation: function (sBDocType, oBFile) {
            this.count = "";
            this.sDocType = sBDocType;
            var that = this;
            var aBValdata = [];
            var bform_data = new FormData();
            bform_data.append('file', oBFile, oBFile.name);
            JQuery.ajax({
                "method": "POST",
                "mimeType": "multipart/form-data",
                "url": "/UI5/v1/users/validate-file",
                "data": bform_data,
                "processData": false,
                contentType: false,
                success: function (data, textStatus, XMLHttpRequest) {
                    var aBValRes = JSON.parse(data).Result;
                    if (Object.keys(aBValRes).length > 0) {
                        var aBNOR = JSON.parse(data).number_of_records;
                        that.count = parseInt(aBNOR);
                        for (var h = 1; h <= parseInt(aBNOR); h++) {
                            if (aBValRes[h] !== undefined && aBValRes[h].Error !== undefined) {
                                aBValdata.push(aBValRes[h]);
                                aErrorlog.push({ ErrorFlag: true });
                            } else {
                                aBValdata.push(aBValRes[h]);
                            }
                        }
                        that.byId("idDwdtemplate").setVisible(false);
                        that.byId("idErrordwnd").setVisible(true);

                    }
                    that.ApplicationModel.setProperty("/UploadData", aBValdata);
                    that.byId("idBookTable").setModel(that.ApplicationModel);
                    that.onBookingPostValidation(aBValdata);

                },
                error: function (data) {

                    that.oBusyDialog.close();

                    var eBData = data.status;
                    var eBEData = data.responseText;
                    MessageToast.show("Sevice Error:" + eBData + "-" + eBEData);
                }
            });

        },
        pythonNBFValidation: function (sNBDocType, oNBFile) {
            this.count = "";
            this.sDocType = sNBDocType;
            var that = this;
            var aNBValdata = [];
            var nbform_data = new FormData();
            nbform_data.append('file', oNBFile, oNBFile.name);
            JQuery.ajax({
                "method": "POST",
                "mimeType": "multipart/form-data",
                "url": "/UI5/v1/users/validate-file",
                "data": nbform_data,
                "processData": false,
                contentType: false,
                success: function (data, textStatus, XMLHttpRequest) {
                    var aNBValRes = JSON.parse(data).Result;
                    if (Object.keys(aNBValRes).length > 0) {
                        var aNBNOR = JSON.parse(data).number_of_records;
                        that.count = parseInt(aNBNOR);
                        for (var m = 1; m <= parseInt(aNBNOR); m++) {
                            if (aNBValRes[m] !== undefined && aNBValRes[m].Error !== undefined) {
                                aNBValdata.push(aNBValRes[m]);
                                aErrorlog.push({ ErrorFlag: true });
                            } else {
                                aNBValdata.push(aNBValRes[m]);
                            }
                        }
                        that.byId("idDwdtemplate").setVisible(false);
                        that.byId("idErrordwnd").setVisible(true);

                    }
                    that.ApplicationModel.setProperty("/UploadData", aNBValdata);
                    that.byId("idNonBookTable").setModel(that.ApplicationModel);
                    that.onNonBookingPostValidation(aNBValdata);

                },
                error: function (data) {

                    that.oBusyDialog.close();

                    var eBData = data.status;
                    var eBEData = data.responseText;
                    MessageToast.show("Sevice Error:" + eBData + "-" + eBEData);
                }
            });

        },
        onShipmentPostValidation: function (aSValdata) {
            if (aErrorlog.length > 0) {
                this.oBusyDialog.close();
                this.byId("IdColError").setVisible(true);
                this.onChangeButton();
                this.byId("idUploadTable").setVisible(true);
            } else {

                aErrorlog = [];
                var startST = Date.now().toString();
                startST = "URN_" + startST;
                var sTotDateST = new Date().toISOString();
                var sCreateDateST = sTotDateST.split(".")[0];
                var sUserST = this.UserName;
                var sNDayST = "7";
                var sCreateTimeST = sCreateDateST.split("T")[1];
                var sFileNameDateST = sCreateDateST.split("T")[0];
                var sTimeFormatST = sCreateDateST.split("T")[0] + sCreateDateST.split("T")[1];
                var sTypeST = "214";
                var sIDST = "idUploadTable";
                var sFileNameST = "AAPL_MU_" + this.sCAC + "_214_" + sFileNameDateST.replaceAll("-", "") + sCreateTimeST.replaceAll(":", "");
                this.fileUpload(startST, sFileNameST, sFileNameDateST, sTimeFormatST, sUserST, sNDayST, sTypeST, sIDST);

            }
        },
        onBookingPostValidation: function (aBValdata) {
            if (aErrorlog.length > 0) {
                this.oBusyDialog.close();
                this.byId("IdColBTError").setVisible(true);
                this.onChangeButton();
                this.byId("idBookTable").setVisible(true);

            } else {
                aErrorlog = [];
                var startBT = Date.now().toString();
                startBT = "URN_" + startBT;
                var sTotDateBT = new Date().toISOString();
                var sCreateDateBT = sTotDateBT.split(".")[0];
                var sUserBT = this.UserName;
                var sIDBT = "idBookTable";
                var sNDaysBT = "7";
                var sCreateTimeBT = sCreateDateBT.split("T")[1];
                var sFileNameDateBT = sCreateDateBT.split("T")[0];
                var sTimeFormatBT = sCreateDateBT.split("T")[0] + sCreateDateBT.split("T")[1];
                var sTypeBT = "315BF";

                var sFileNameBT = "AAPL_MU_" + this.sCAC + "_315B_" + sFileNameDateBT.replaceAll("-", "") + sCreateTimeBT.replaceAll(":", "");
                this.fileUpload(startBT, sFileNameBT, sFileNameDateBT, sTimeFormatBT, sUserBT, sNDaysBT, sTypeBT, sIDBT);

            }
        },
        onNonBookingPostValidation: function (aNBValdata) {
            if (aErrorlog.length > 0) {
                this.oBusyDialog.close();
                this.byId("IdNBColError").setVisible(true);
                this.onChangeButton();
                this.byId("idNonBookTable").setVisible(true);
                this.byId("idNonBookTable").setModel(this.ApplicationModel);
            } else {
                aErrorlog = [];
                var start = Date.now().toString();
                start = "URN_" + start;
                var sTotDate = new Date().toISOString();
                var sCreateDate = sTotDate.split(".")[0];
                var sUser = this.UserName;
                var sNDays = "7";
                var sCreateTime = sCreateDate.split("T")[1];
                var sFileNameDate = sCreateDate.split("T")[0];
                var sTimeFormat = sCreateDate.split("T")[0] + sCreateDate.split("T")[1];
                var sType = "315NBF";
                var sID = "idNonBookTable";
                var sFileName = "AAPL_MU_" + this.sCAC + "_315NB_" + sFileNameDate.replaceAll("-", "") + sCreateTime.replaceAll(":", "");
                this.fileUpload(start, sFileName, sFileNameDate, sTimeFormat, sUser, sNDays, sType, sID);
            }
        },
        onErrorDownload: function () {
            var shipmentErrorModel = new sap.ui.model.json.JSONModel();
            if (this.sDocType === "214") {
                this.getShipmentData(this.columnHeaders);
                var errcol = { name: "Error", template: { content: "{Error}" } };
                var colSData = this.shipmentData;
                colSData.push(errcol);
                var aSTErrorData = this.ApplicationModel.getProperty("/UploadData");
                for (var c = 0; c < aSTErrorData.length; c++) {
                    aSTErrorData[c].EventTimezone = aSTErrorData[c]["Event Time zone(UTC+/-HH:MM)"];
                    aSTErrorData[c].NetWeightUOM = aSTErrorData[c]["Net Weight UOM(KG/LB)"];
                    if (aSTErrorData[c].Error) {
                        aSTErrorData[c].Error = aSTErrorData[c].Error.Error_Message;
                    }
                }
                shipmentErrorModel.setProperty("/ShipErrorData", aSTErrorData);
                var oSTErrExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: shipmentErrorModel,
                    rows: {
                        path: "/ShipErrorData"
                    },
                    columns: colSData
                });
                var sShipDwdFile = "AAPL_MU_214_ErrorLogs";
                oSTErrExport.saveFile(sShipDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oSTErrExport.destroy();
                });
            }

            if (this.sDocType === "315BF") {
                this.getBookData(this.columnBFHeaders);
                var errBcol = { name: "Error", template: { content: "{Error}" } };
                var colBData = this.BData;
                colBData.push(errBcol);
                var aBFErrorData = this.ApplicationModel.getProperty("/UploadData");
                for (var b = 0; b < aBFErrorData.length; b++) {

                    aBFErrorData[b].EventTimezone = aBFErrorData[b]["Event Time zone(UTC+/-HH:MM)"];
                    aBFErrorData[b].FlightNo = aBFErrorData[b]["Flight/Voyage No."];
                    if (aBFErrorData[b].Error) {
                        aBFErrorData[b].Error = aBFErrorData[b].Error.Error_Message;
                    }
                }
                shipmentErrorModel.setProperty("/BookErrorData", aBFErrorData);
                var oBFErrExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: shipmentErrorModel,
                    rows: {
                        path: "/BookErrorData"
                    },
                    columns: colBData
                });
                var sBFErrDwdFile = "AAPL_MU_" + "315BF_ErrorLogs";
                oBFErrExport.saveFile(sBFErrDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oBFErrExport.destroy();
                });


            }
            if (this.sDocType === "315NBF") {
                this.getNBookData(this.columnNBFHeaders);
                var errNBcol = { name: "Error", template: { content: "{Error}" } };
                var colNBData = this.NBData;
                colNBData.push(errNBcol);
                var aNBFErrorData = this.ApplicationModel.getProperty("/UploadData");
                for (var a = 0; a < aNBFErrorData.length; a++) {

                    aNBFErrorData[a].EventTimezone = aNBFErrorData[a]["Event Time zone(UTC+/-HH:MM)"];
                    aNBFErrorData[a].FlightNo = aNBFErrorData[a]["Flight/Voyage No."];
                    if (aNBFErrorData[a].Error) {
                        aNBFErrorData[a].Error = aNBFErrorData[a].Error.Error_Message;
                    }
                }
                shipmentErrorModel.setProperty("/NonBookErrorData", aNBFErrorData);
                var oNBFErrExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: shipmentErrorModel,
                    rows: {
                        path: "/NonBookErrorData"
                    },
                    columns: colNBData
                });
                var sNBFErrDwdFile = "AAPL_MU_" + "315NBF_ErrorLogs";
                oNBFErrExport.saveFile(sNBFErrDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oNBFErrExport.destroy();
                });


            }
        },
        tempSTValidation: function (sFile, oFile, sDocType) {

            var that = this;
            var reader = new FileReader();
            if (oFile && window.FileReader) {
                reader.onload = function (evt) {
                    var strCSV = evt.target.result;
                    that.csvJSONShipment(strCSV, sDocType, oFile);
                };
                reader.readAsText(oFile);
            }

        },
        tempBFValidation: function (sFile, oFile, sDocType) {
            var that = this;
            var reader = new FileReader();
            if (oFile && window.FileReader) {
                reader.onload = function (evt) {
                    var strCSV = evt.target.result;
                    that.csvJSONBooking(strCSV, sDocType, oFile);
                };
                reader.readAsText(oFile);
            }
        },

        tempNBFValidation: function (sFile, oFile, sDocType) {
            var that = this;
            var reader = new FileReader();
            if (oFile && window.FileReader) {
                reader.onload = function (evt) {
                    var strCSV = evt.target.result;
                    that.csvJSONNonBooking(strCSV, sDocType, oFile);
                };
                reader.readAsText(oFile);
            }
        },
        csvJSONNonBooking: function (csv, sDocType, oFile) {
            var that = this;
            var NBooklines = csv.split("\n");
            this.getNBookData(this.columnNBFHeaders);
            var NBookheaders = NBooklines[0].split(",");
            var bValueNBF = this.validColumns(NBookheaders, this.columnNBFHeaders);
            if (bValueNBF === false) {
                MessageBox.error("Template has error..Please correct the template and upload again", {
                    actions: [MessageBox.Action.CLOSE],
                    onClose: function (sAction) {
                        if (sAction === "CLOSE") {
                            that.byId("fileUploader").clear();
                            that.oBusyDialog.close();
                        }
                    }
                });
            } else {
                this.pythonNBFValidation(sDocType, oFile);
            }
        },
        csvJSONBooking: function (csv, sDocType, oFile) {
            var that = this;
            var booklines = csv.split("\n");
            this.getBookData(this.columnBFHeaders);
            var bookheaders = booklines[0].split(",");
            var bValueBF = this.validColumns(bookheaders, this.columnBFHeaders);
            if (bValueBF === false) {
                MessageBox.error("Template has error..Please correct the template and upload again", {
                    actions: [MessageBox.Action.CLOSE],
                    onClose: function (sAction) {
                        if (sAction === "CLOSE") {
                            that.byId("fileUploader").clear();
                            that.oBusyDialog.close();
                        }
                    }
                });
            } else {
                this.pythonBFValidation(sDocType, oFile);
            }
        },
        csvJSONShipment: function (csv, sDocType, oFile) {
            var that = this;
            var lines = csv.split("\n");
            this.getShipmentData(this.columnHeaders);
            var headers = lines[0].split(",");
            var x = this.validColumns(headers, this.columnHeaders);
            if (x === false) {

                MessageBox.error("Template has error..Please correct the template and upload again", {
                    actions: [MessageBox.Action.CLOSE],
                    onClose: function (sAction) {
                        if (sAction === "CLOSE") {
                            that.byId("fileUploader").clear();
                            that.oBusyDialog.close();
                        }
                    }
                });
            } else {
                this.pythonSTValidation(sDocType, oFile);
            }
        },
        validColumns: function (headers, columnHeaders) {
            for (var i = 0; i < columnHeaders.length; i++) {
                var voa = headers[i].split("=", 2);
                var value = voa[0].trim();
                var items = false;
                if (columnHeaders.includes(value)) {
                    items = true;
                }
                if (!items) {
                    return false;
                }
            }
        }
    });
});