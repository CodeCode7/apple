var aErrorlog = [];
sap.ui.define([
    "./BaseController",
    "sap/m/MessageBox",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    "sap/ui/model/json/JSONModel",
    "jquery.sap.global",
    "sap/m/MessageToast",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/m/BusyDialog"

],

    function (BaseController, MessageBox, Export, ExportTypeCSV, JSONModel, JQuery, MessageToast, formatter, Filter, BusyDialog) {
        "use strict";

        return BaseController.extend("com.apple.massuploadui.controller.Home", {
            formatter: formatter,
            onInit: function () {
                this.sDocType = "";
                this.sDocName = "";
                this.token = "";
                this.count = "";

                this.oBusyDialog = new BusyDialog();
                this.sCAC = "";
                this.fileName = "";
                this.UserName = "";
                this.sFlag = " ";
                this.sRole = "";
                this._userModel = new JSONModel();
                var sNDays = "7";
                let me = this;
                fetch("/getAppVariables")
                    .then(res => res.json())
                    .then(variables => {
                        this.appidvalue = variables;

                    });
                fetch("/getUserInfo")
                    .then(res => res.json())
                    .then(data => {
                        me._userModel.setProperty("/", data);
                        me.UserName = me._userModel.getProperty("/decodedJWTToken/email");
                        var aScope = me._userModel.getProperty("/decodedJWTToken/scope");
                        var sScope = aScope[0].split(".")[1];
                        this.sRole = sScope;
                        if (sScope === "U_IGB_HIST") {
                            me.sFlag = "X";
                            me.byId("idIconTabBarMulti").setVisible(true);
                            me.byId("idTabHistory").setVisible(true); 
                            me.byId("idDwdtemplate").setVisible(false);
                            this.getHistoryData(me.UserName, sNDays, me.sFlag);
                        } else if (sScope === "W_OWW_MASS") {
                            me.sFlag = " ";
                             me.byId("idIconTabBarMulti").setVisible(true);
                            me.byId("idDwdtemplate").setVisible(true);
                            me.byId("idTabfileupload").setVisible(true);
                            me.byId("idTabHistory").setVisible(true); 
                            this.getHistoryData(me.UserName, sNDays, me.sFlag);

                        } else {
                            MessageBox.warning("You don't have any roles assigned", {
                                icon: MessageBox.Icon.WARNING,
                                title: "Access denied",
                                actions: [MessageBox.Action.OK],
                                onClose: function (sAction) {
                                }
                            });
                            return;
                        }


                    })
                    .catch(err => console.log(err));
                this.oHistoryDataModel = this.getOwnerComponent().getModel("HistoryDataModel");
                this.oHistoryDataModel.setProperty("/HistoryData", []);
                this.oHistoryDataModel.setProperty("/HistoryLineData", []);
                this.ApplicationModel = this.getOwnerComponent().getModel("ApplicationModel");
                this.ApplicationModel.setProperty("/UploadData", []);

                this.columnHeaders = [
                    "Carrier Tracking No.", "Previous Carrier Tracking No.", "Shipment ID(AUSID)", "SCAC", "Event Code(As per the Spec)", "Reason Code(As per the Spec)", "Event Date(YYYYMMDD)", "Event Time(HH:MM:SS)", "Event Time zone(UTC+/-HH:MM)", "Event Location City", "Event Location State code", "Event Location Country code", "Comments", "Net Weight", "Net Weight UOM(KG/LB)", "Receiver"];
                this.columnBFHeaders = [
                    "Shipment ID(AUSID)", "Container", "SCAC", "Event Date(YYYYMMDD)", "Event Time(HH:MM:SS)", "Event Time zone(UTC+/-HH:MM)", "Event Location City", "Event Location State code", "Event Location Country code", "Way Bill Number", "Bill Of Ladding", "Vessel"];
                this.columnNBFHeaders = [
                    "Container", "Shipment ID(AUSID)", "Event Code", "Event Date(YYYYMMDD)", "Event Time(HH:MM:SS)", "Event Time zone(UTC+/-HH:MM)", "Event Location City", "Event Location State code", "Event Location Country code", "Bill Of Lading", "SCAC", "Booking Number", "Way Bill Number", "Flight/Voyage No.", "Vessel Name", "Port of Loading", "Port of Discharge"];
                this.shipmentData = [];
                this.BData = [];
                this.NBData = [];
            },
            getHistoryData: function (sUser, sNDays, sFlag) {
                this.oBusyDialog.open();
                var that = this;
                JQuery.ajax({
                    "url": "/UI5URC/v1/polaris/mass-upload/HISTORYSet?$filter=(USR_EMAIL eq '" + sUser + "' and SRCH_DAYS eq '" + sNDays + "' and IST_FLAG eq '" + sFlag + "')&$expand=Error",
                    "method": "GET",
                    "dataType": "json",
                    async: false,
                    beforeSend: function (request) {
                        request.setRequestHeader("appid", that.appidvalue);
                    },
                    success: function (data) {
                        that.oBusyDialog.close();
                        var aLinedata = [];
                        var aData = data.d.results;
                        for (var i = 0; i < aData.length; i++) {
                            var aItems = aData[i].Error.results;
                            aLinedata.push(aItems);
                        }
                        that.oHistoryDataModel.setProperty("/HistoryData", aData);
                        that.oHistoryDataModel.setProperty("/HistoryLineData", aLinedata);
                        that.byId("idHistoryTable").setModel(that.oHistoryDataModel);

                    },
                    error: function (Error) {
                        var eHData;
                        that.oBusyDialog.close();
                        if (Error.responseJSON) {
                            eHData = Error.responseJSON.error.message.value;
                        }
                        else {
                            eHData = Error.responseText;
                        }
                        MessageBox.error("Service error: " + eHData, {
                            actions: [MessageBox.Action.OK],
                            onClose: function (sAction) {
                            }
                        });
                    }
                });
            },
            getAsset: function (sURNum) {
                var that = this;
                JQuery.ajax({
                    "url": "/UI5URC/v1/polaris/hana-db/getFile/" + sURNum,
                    "method": "GET",
                    async: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("appid", that.appidvalue);
                    },
                    success: function (data, textStatus, XMLHttpRequest) {
                       var sResponse= XMLHttpRequest;
                        if (sResponse.status === 200) {
                         that.csvGetAsset(data);
                        } else {
                                return false;
                            }
                    },
                    error: function (error) {

                        MessageToast.show("Service Error:" + error.message);
                    }
                });

            },
            csvGetAsset: function (csv) {
                var lines = csv.split("\n");
                var result = [];
                var headers = lines[0].split(",");

                for (var i = 1; i < lines.length; i++) {
                    var obj = {};
                    var currentline = lines[i].split(",");
                    for (var j = 0; j < headers.length; j++) {
                        obj[headers[j]] = currentline[j];
                    }
                    result.push(obj);
                }
                var oStringResult = JSON.stringify(result);
                var oFinalResult = JSON.parse(oStringResult.replace(/\\r/g, ""));
                this.ApplicationModel.setProperty("/GetAssetData", oFinalResult);
            },
            handleTypeMissmatch: function (oEvent) {
                var aFileTypes = oEvent.getSource().getFileType();
                JQuery.each(aFileTypes, function (key, value) {
                    aFileTypes[key] = "*." + value;
                });
                MessageToast.show("File Type is not supported ..Upload in .csv format");
            },
            onSearch: function (oEvent) {

                var aFilters = [];
                var sQuery = oEvent.getSource().getValue();

                if (sQuery && sQuery.length) {
                    var oFilter1 = new Filter("URN_NO", sap.ui.model.FilterOperator.EQ, sQuery, true);
                    var oFilter2 = new Filter("ERNAM", sap.ui.model.FilterOperator.EQ, sQuery, true);
                    var oFilter3 = new Filter("FILENAME", sap.ui.model.FilterOperator.EQ, sQuery, true);

                    aFilters = new Filter({
                        filters: [oFilter1, oFilter2, oFilter3]
                    });

                }
                var oTable = this.byId("idHistoryTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter(aFilters);
            },
            onDownload: function () {
                this.getDialog();
                this.oDialog.open();
            },
            getDialog: function () {
                if (!this.oDialog) {
                    this.oDialog = sap.ui.xmlfragment(this.getView().getId(), "com.apple.massuploadui.fragments.DownloadTemplate",
                        this);
                    this.getView().addDependent(this.oDialog);
                }
                return this.oDialog;
            },
            handleFilterButtonPressed: function () {
                this.getFilterDialog();
                this.FilterDialog.open();
            },
            onClearFilter: function () {
                this.byId("idFilFTCombo").setSelectedItem().setSelectedKey("");
                this.byId("idRecordStatus").setSelectedItem().setSelectedKey("");
                this.byId("idFilterFromDate").setValue("");
                this.byId("idFilterToDate").setValue("");
                this.byId("idFilterFromTime").setValue("");
                this.byId("idFilterToTime").setValue("");
            },
            onApplyFilter: function () {
                var that = this;
                var aFilter = [];
                var aFTFilter = [];
                var aRSFilter = [];
                var aCDFilter = [];
                var aCTFilter = [];
                var oTable = this.byId("idHistoryTable");
                var oBinding = oTable.getBinding("items");
                var sFileType = this.byId("idFilFTCombo").getSelectedItem();
                var sRecordStatus = this.byId("idRecordStatus").getSelectedItem();
                var sFilFromDate = this.byId("idFilterFromDate").getValue();
                var sFilToDate = this.byId("idFilterToDate").getValue();
                var sFilFromTime = this.byId("idFilterFromTime").getValue();
                var sFilToTime = this.byId("idFilterToTime").getValue();
                var sVFilFromDate = formatter.dateFormat(sFilFromDate);
                var sVFilToDate = formatter.dateFormat(sFilToDate);

                if (sFileType) {
                    sFileType = sFileType.getText();
                    aFTFilter.push(new Filter({
                        filters: [
                            new Filter("DOC_TYPE", sap.ui.model.FilterOperator.EQ, sFileType)
                        ],
                        or: true
                    }));
                    aFilter.push(new Filter(aFTFilter));
                }
                if (sRecordStatus) {
                    sRecordStatus = sRecordStatus.getKey();
                    aRSFilter.push(new Filter({
                        filters: [
                            new Filter("STATUS", sap.ui.model.FilterOperator.EQ, sRecordStatus)
                        ],
                        or: true
                    }));
                    aFilter.push(new Filter(aRSFilter));
                }
                if (sFilFromDate && sFilToDate) {
                    if (Date.parse(sVFilToDate) <= Date.parse(sVFilFromDate) && (sVFilFromDate !== sVFilToDate)) {
                        MessageBox.error("End Date should be greater than From Date....!", {
                            actions: [MessageBox.Action.CLOSE],
                            onClose: function (sAction) {
                                if (sAction === "CLOSE") {
                                    that.byId("idFilterFromDate").setValue("");
                                    that.byId("idFilterToDate").setValue("");
                                }
                            }
                        });
                        return;
                    }

                    aCDFilter.push(new Filter({
                        filters: [
                            new Filter("CREATION_DT", sap.ui.model.FilterOperator.BT, sFilFromDate, sFilToDate),

                        ],
                        or: true
                    }));
                    aFilter.push(new Filter(aCDFilter));
                }
                if (sFilFromTime && sFilToTime) {
                    aCTFilter.push(new Filter({
                        filters: [
                            new Filter("CREATION_TM", sap.ui.model.FilterOperator.BT, sFilFromTime, sFilToTime),
                        ],
                        or: true
                    }));
                    aFilter.push(new Filter(aCTFilter));
                }
                oBinding.filter(aFilter);
                this.onDialogClose();
            },

            getFilterDialog: function () {
                if (!this.FilterDialog) {
                    this.FilterDialog = sap.ui.xmlfragment(this.getView().getId(), "com.apple.massuploadui.fragments.FilterDialog",
                        this);
                    this.getView().addDependent(this.FilterDialog);

                }
                return this.FilterDialog;
            },
            onReset: function () {
                this.byId("idCombo").setSelectedItem().setSelectedKey("");
                this.byId("fileUploader").clear();
                this.byId("idCombo").setValueState("None");
                this.byId("fileUploader").setValueState("None");
            },
            onChangeType: function () {
                aErrorlog = [];
                this.byId("IdColError").setVisible(false);
                this.byId("IdColBTError").setVisible(false);
                this.byId("IdNBColError").setVisible(false);
                this.ApplicationModel.setProperty("/UploadData", []);
            },
            onChangeDate: function () {
                var oItem = this.byId("idHistoryTabCombo").getSelectedItem().getKey();
                var sUser = this.UserName;
                var sFlag = this.sFlag;
                var sNDays = "";
                if (oItem === "Last7") {
                    sNDays = "7";
                    this.getHistoryData(sUser, sNDays, sFlag);
                    this.byId("idHistoryTable").setModel(this.oHistoryDataModel);
                }
                if (oItem === "Last30") {
                    sNDays = "30";
                    this.getHistoryData(sUser, sNDays, sFlag);
                    this.byId("idHistoryTable").setModel(this.oHistoryDataModel);
                }
                if (oItem === "Last45") {
                    sNDays = "45";
                    this.getHistoryData(sUser, sNDays, sFlag);
                    this.byId("idHistoryTable").setModel(this.oHistoryDataModel);
                }
                if (oItem === "CustomDate") {
                    this.getDateDialog();
                    this.oDialog.open();
                }
            },
            onSelectDate: function () {
                var that = this;
                var sUser = this.UserName;
                var sFlag = this.sFlag;
                var sFDate = this.byId("idFromDate").getValue();
                var sTDate = this.byId("idToDate").getValue();
                var sValidFDate = formatter.dateFormat(sFDate);
                var sValidTDate = formatter.dateFormat(sTDate);
                if (Date.parse(sValidTDate) <= Date.parse(sValidFDate) && (sValidFDate !== sValidTDate)) {
                    MessageBox.error("End Date should be greater than From Date....!", {
                        actions: [MessageBox.Action.CLOSE],
                        onClose: function (sAction) {
                            if (sAction === "CLOSE") {
                                that.byId("idFromDate").setValue("");
                                that.byId("idToDate").setValue("");
                            }
                        }
                    });
                    return;
                }
                JQuery.ajax({
                    "url": "/UI5URC/v1/polaris/mass-upload/HISTORYSet?$filter=(USR_EMAIL eq '" + sUser + "' and FROM_DATE eq '" + sFDate + "' and  TO_DATE eq '" + sTDate + "' and IST_FLAG eq '" + sFlag + "')&$expand=Error",
                    "method": "GET",
                    "dataType": "json",
                    async: false,
                    beforeSend: function (request) {
                        request.setRequestHeader("appid", that.appidvalue);
                    },

                    success: function (data) {
                        var aLinedata = [];
                        var aData = data.d.results;
                        for (var j = 0; j < aData.length; j++) {
                            var aItems = aData[j].Error.results;
                            aLinedata.push(aItems);
                        }
                        that.oHistoryDataModel.setProperty("/HistoryData", aData);
                        that.oHistoryDataModel.setProperty("/HistoryLineData", aLinedata);
                        that.byId("idHistoryTable").setModel(that.oHistoryDataModel);
                    },
                    error: function (Error) {
                        var eHData;
                        that.oBusyDialog.close();
                        if (Error.responseJSON) {
                            eHData = Error.responseJSON.error.message.value;
                        }
                        else {
                            eHData = Error.responseText;
                        }
                        MessageBox.error("Service error: " + eHData, {
                            actions: [MessageBox.Action.OK],
                            onClose: function (sAction) {
                            }
                        });

                    }
                });
                this.onDialogClose();
            },
            getDateDialog: function () {
                if (!this.oDialog) {
                    this.oDialog = sap.ui.xmlfragment(this.getView().getId(), "com.apple.massuploadui.fragments.SelectDateDialog",
                        this);
                    this.getView().addDependent(this.oDialog);
                }
                return this.oDialog;
            },
            onChange: function (oEvent) {
                this.oBusyDialog.open();
                var oFileUploader = this.byId("fileUploader");
                var sFileUpload = this.byId("fileUploader").getValue();
                var sAttachment = this.byId("idCombo").getSelectedItem();
                var that = this;
                if (!sAttachment) {
                    MessageBox.error("Select the file type", {
                        actions: [MessageBox.Action.CLOSE],
                        onClose: function (sAction) {
                            if (sAction === "CLOSE") {
                                that.byId("idCombo").setSelectedItem().setSelectedKey("");
                                that.byId("fileUploader").clear();
                            }
                        }
                    });
                    this.oBusyDialog.close();
                    this.byId("idCombo").setValueState("Error");
                    return;
                }
                if (!sFileUpload) {
                    MessageBox.error("Select a file to upload", {
                        actions: [MessageBox.Action.CLOSE],
                        onClose: function (sAction) {
                            if (sAction === "CLOSE") {
                                that.byId("fileUploader").clear();
                            }
                        }
                    });
                    this.oBusyDialog.close();
                    this.byId("fileUploader").setValueState("Error");
                    return;
                }
                var sFile = sAttachment.getText();
                this.byId("idCombo").setValueState("None");
                this.byId("fileUploader").setValueState("None");
                var oFile = oFileUploader.getFocusDomRef().files[0];
                var totalSize = oFile.size;
                var totalSizeMB = totalSize / Math.pow(1024, 2);
                this.fileName = oFile.name;
                var sFileSize = Math.round(totalSizeMB);
                if (sFileSize > 5) {
                    MessageBox.error("File size exceeds the limit..Upload file size within 5MB");
                    this.oBusyDialog.close();
                    return;
                }
                var sFilelen = oFile.name.length;
                if (sFilelen > 40) {
                    MessageBox.error("File name exceeds the limit..Character length should not be more than 40");
                    this.oBusyDialog.close();
                    return;
                }
                var sDocType = "";
                if (sFile === "Shipment") {
                    sDocType = "214";
                    this.tempSTValidation(sFile, oFile, sDocType);

                }
                else if (sFile === "Container Booking Confirmed") {
                    sDocType = "315BF";
                    this.tempBFValidation(sFile, oFile, sDocType);


                } else if (sFile === "Container NonBooking Confirmed") {
                    sDocType = "315NBF";
                    this.tempNBFValidation(sFile, oFile, sDocType);


                }
            },

            getShipmentData: function (col) {
                this.shipmentData = [];
                for (var r = 0; r < col.length; r++) {
                    var oShipment = {};
                    var oTemplate = {};
                    oShipment.name = col[r];
                    oShipment.template = oTemplate;
                    var strValue = col[r];
                    if (strValue === "Event Time zone(UTC+/-HH:MM)") {
                        strValue = "EventTimezone";
                    }
                    if (strValue === "Net Weight UOM(KG/LB)") {
                        strValue = "NetWeightUOM";
                    }
                    oTemplate.content = "{" + strValue + "}";
                    this.shipmentData.push(oShipment);

                }
            },

            getBookData: function (columnBFHeaders) {
                this.BData = [];
                for (var s = 0; s < columnBFHeaders.length; s++) {
                    var oBook = {};
                    var oBTemplate = {};
                    oBook.name = columnBFHeaders[s];
                    oBook.template = oBTemplate;
                    var strValue = columnBFHeaders[s];
                    if (strValue === "Event Time zone(UTC+/-HH:MM)") {
                        strValue = "EventTimezone";
                    }
                    oBTemplate.content = "{" + strValue + "}";
                    this.BData.push(oBook);

                }

            },
            getNBookData: function (columnNBFHeaders) {
                this.NBData = [];
                for (var s = 0; s < columnNBFHeaders.length; s++) {
                    var oNBook = {};
                    var oNBTemplate = {};
                    oNBook.name = columnNBFHeaders[s];
                    oNBook.template = oNBTemplate;
                    var strNBValue = columnNBFHeaders[s];
                    if (strNBValue === "Event Time zone(UTC+/-HH:MM)") {
                        strNBValue = "EventTimezone";
                    }
                    if (strNBValue === "Flight/Voyage No.") {
                        strNBValue = "FlightNo";
                    }
                    oNBTemplate.content = "{" + strNBValue + "}";
                    this.NBData.push(oNBook);
                }

            },
            handleRefreshButtonPressed: function () {
                this.oBusyDialog.open();
                var sUser = this.UserName;
                var sNDays = "7";
                var sFlag = this.sFlag;
                this.getHistoryData(sUser, sNDays, sFlag);
                this.oBusyDialog.close();
            },
            onCancel: function () {
                aErrorlog = [];
                this.byId("IdColError").setVisible(false);
                this.byId("IdColBTError").setVisible(false);
                this.byId("IdNBColError").setVisible(false);
                this.ApplicationModel.setProperty("/UploadData", []);
                this.byId("idLabelType").setVisible(true);
                this.byId("idCombo").setVisible(true);
                this.byId("idCombo").setSelectedItem().setSelectedKey("");
                this.byId("idLabelUpload").setVisible(true);
                this.byId("idResetButton").setVisible(true);
                this.byId("idUploadButton").setVisible(true);
                this.byId("fileUploader").setVisible(true);
                this.byId("fileUploader").clear();
                this.byId("idDwdtemplate").setVisible(true);
                this.byId("idErrordwnd").setVisible(false);
                this.byId("idPanel").setVisible(false);
                this.byId("idUploadTable").setVisible(false);
                this.byId("idBookTable").setVisible(false);
                this.byId("idNonBookTable").setVisible(false);
                this.byId("idCancelButton").setVisible(false);
            },
            onShipmentDownload: function () {
                var shipmentModel = new sap.ui.model.json.JSONModel();
                var rowHeaders = [{
                    "Carrier Tracking No.": "Required",
                    "Previous Carrier Tracking No.": "Optional",
                    "Shipment ID(AUSID)": "Optional",
                    "SCAC": "Required",
                    "Event Code(As per the Spec)": "Required",
                    "Reason Code(As per the Spec)": "Required",
                    "Event Date(YYYYMMDD)": "Required",
                    "Event Time(HH:MM:SS)": "Required",
                    "EventTimezone": "Optional",
                    "Event Location City": "Required",
                    "Event Location State code": "Optional",
                    "Event Location Country code": "Required",
                    "Comments": "Optional",
                    "Net Weight": "Optional",
                    "NetWeightUOM": "Optional",
                    "Receiver": "Required for D1"
                }];
                shipmentModel.setData(rowHeaders);
                this.getShipmentData(this.columnHeaders);
                var oSTExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: shipmentModel,
                    rows: {
                        path: "/"
                    },
                    columns: this.shipmentData
                });
                var sDwdFile = "AAPL_MU_<<SCAC>>_214";
                oSTExport.saveFile(sDwdFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oSTExport.destroy();
                });
            },
            onNBConfirm: function () {
                var NonBookingModel = new sap.ui.model.json.JSONModel();
                var rowNBFHeaders = [{
                    "Container": "Required",
                    "Shipment ID(AUSID)": "Required",
                    "Event Code": "Required",
                    "Event Date(YYYYMMDD)": "Required",
                    "Event Time(HH:MM:SS)": "Required",
                    "EventTimezone": "Optional",
                    "Event Location City": "Required",
                    "Event Location State code": "Required",
                    "Event Location Country code": "Required",
                    "Bill Of Lading": "Required",
                    "SCAC": "Required",
                    "Booking Number": "Optional",
                    "Way Bill Number": "Required",
                    "FlightNo": "Optional",
                    "Vessel Name": "Optional",
                    "Port of Loading": "Required",
                    "Port of Discharge": "Required"
                }
                ];
                this.getNBookData(this.columnNBFHeaders);
                NonBookingModel.setData(rowNBFHeaders);
                var oNBExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: NonBookingModel,
                    rows: {
                        path: "/"
                    },
                    columns: this.NBData
                });
                var sDwdNBFile = "AAPL_MU_<<SCAC>>_315NBF";
                oNBExport.saveFile(sDwdNBFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oNBExport.destroy();
                });
            },
            onBConfirm: function () {
                var BookModel = new sap.ui.model.json.JSONModel();
                var rowBHeaders = [{
                    "Shipment ID(AUSID)": "Required",
                    "Container": "Required",
                    "SCAC": "Required",
                    "Event Date(YYYYMMDD)": "Required",
                    "Event Time(HH:MM:SS)": "Required",
                    "EventTimezone": "Optional",
                    "Event Location City": "Required",
                    "Event Location State code": "Optional",
                    "Event Location Country code": "Required",
                    "Way Bill Number": "Required",
                    "Bill Of Ladding": "Required",
                    "Vessel": "Optional"
                }];
                this.getBookData(this.columnBFHeaders);
                BookModel.setData(rowBHeaders);
                var oBExport = new Export({
                    exportType: new ExportTypeCSV({
                        fileExtension: "csv",
                        separatorChar: ","
                    }),
                    models: BookModel,
                    rows: {
                        path: "/"
                    },
                    columns: this.BData
                });
                var sDwdBFile = "AAPL_MU_<<SCAC>>_315BF";
                oBExport.saveFile(sDwdBFile).catch(function (oError) {
                    sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
                }).then(function () {
                    oBExport.destroy();
                });
            },
            onDialogClose: function (oDialog) {
                if (this.oDialog !== undefined) {
                    this.oDialog.destroy();
                    this.oDialog = undefined;
                } else if (this.FilterDialog !== undefined) {
                    this.FilterDialog.destroy();
                    this.FilterDialog = undefined;
                } else if (this.ViewDialog !== undefined) {
                    this.ViewDialog.destroy();
                    this.ViewDialog = undefined;
                }
            },

            handleAssetDownload: function (oEvent) {
                var sURNum = oEvent.getSource().getBindingContext().getProperty("URN_NO");
                if (this.sRole === "W_OWW_MASS" || this.sRole === "U_IGB_HIST") {
                    var sURNum = oEvent.getSource().getBindingContext().getProperty("URN_NO");
                    var sDType = oEvent.getSource().getBindingContext().getProperty("DOC_TYPE");
                    var sDwnFile = oEvent.getSource().getBindingContext().getProperty("FILENAME");
                    var bDwd =this.getAsset(sURNum);
                    if(bDwd === undefined){
                    this.assetExport(sDType, sURNum,sDwnFile);
                    } else{
                           MessageBox.error("You are not authorized to download file", {
                                    actions: [MessageBox.Action.OK],
                                    onClose: function (sAction) {
                                    }
                                });
                                return;
                            }
                }
                else {
                    MessageToast.show("You are not authorized to use this service");
                }
            },
            handleViewDetails: function (oEvent) {
                var index = parseInt(oEvent.getSource().getBindingContext().getPath().split("/HistoryData/")[1]);
                var sData = this.oHistoryDataModel.getProperty("/HistoryLineData");
                var sLineItem = sData[index];
                this.oHistoryDataModel.setProperty("/LineItems", sLineItem);
                this.getViewDialog();
                this.ViewDialog.open();
                this.byId("idErrorTable").setModel(this.oHistoryDataModel);
            },
            getViewDialog: function () {
                if (!this.ViewDialog) {
                    this.ViewDialog = sap.ui.xmlfragment(this.getView().getId(), "com.apple.massuploadui.fragments.ViewDetailsDialog",
                        this);
                    this.getView().addDependent(this.ViewDialog);
                }
                return this.ViewDialog;
            },
            fileUpload: function (fileDName, sFileName, sFileNameDate, sTimeFormat, sUser, sNDays, sType, sID) {
                var that = this;
                var sFlag = this.sFlag;
                if (that.sRole === "W_OWW_MASS") {
                    that.oBusyDialog.open();
                    var oFileUploader = that.byId("fileUploader");
                    var oFile = oFileUploader.getFocusDomRef().files[0];

                    var form_data = new FormData();
                    form_data.append('file', oFile, oFile.name);
                    JQuery.ajax({
                        "url": "/UI5URC/v1/polaris/hana-db/saveDb",
                        "method": "POST",
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader("appid", that.appidvalue);
                            xhr.setRequestHeader("Doctype", sType);
                        },
                        "mimeType": "multipart/form-data",
                        "data": form_data,
                        "processData": false,
                        contentType: false,

                        success: function (data) {
                            that.oBusyDialog.close();
                            var fData = JSON.parse(data);
                            if (fData.status === "200 OK") {
                                var sNewUrn = fData.message;
                                sNewUrn = sNewUrn.replace("Data is posted succesfully", "");
                                that.getHistoryData(sUser, sNDays, sFlag);
                                MessageBox.success("File successfully submitted.\n\n Reference No.: " + sNewUrn + " \n\n No.of Records submitted: " + that.count + "\n", { styleClass: "icon" }, {
                                    actions: [MessageBox.Action.OK],
                                    onClose: function (sAction) {

                                    }
                                });

                            } else {
                                that.oBusyDialog.close();
                                MessageToast.show("Sevice Error:" + fData.message);
                            }
                        },
                        error: function (error) {
                            that.oBusyDialog.close();
                            MessageToast.show("Service Error:" + error.message);
                        }
                    });
                } else {
                    that.oBusyDialog.close();
                    MessageToast.show("You are not authorized to use this service");
                }
                this.onReset();
            }
        });
    });

