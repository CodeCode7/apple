sap.ui.define([
 "comapple./logonui/test/unit/controller/main.controller"
], function () {
 "use strict";
});
